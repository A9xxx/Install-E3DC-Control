import json
import os


def load_config(base_path):
    """
    Lädt alle Konfigurationsdaten aus:
      - config.json
      - e3dc.config.txt.check
      - E3DC_CONF.h

    Gibt ein Dictionary mit allen Werten zurück.
    """
    config = {}

    # ------------------------------------------------------------
    # 1) config.json laden
    # ------------------------------------------------------------
    json_path = os.path.join(base_path, "config.json")
    if os.path.isfile(json_path):
        with open(json_path, "r") as f:
            config.update(json.load(f))

    # ------------------------------------------------------------
    # 2) e3dc.config.txt.check laden
    # ------------------------------------------------------------
    config_file = os.path.join(base_path, "e3dc.config.txt.check")
    if os.path.isfile(config_file):
        with open(config_file, "r") as f:
            for line in f:
                parts = line.split()

                # Erwartetes Format: key = value
                if len(parts) == 3:
                    key = parts[0]
                    value = parts[2].replace(",", ".")

                    # Float oder Int automatisch erkennen
                    try:
                        if "." in value:
                            config[key] = float(value)
                        else:
                            config[key] = int(value)
                    except ValueError:
                        config[key] = value  # Fallback: String

    # ------------------------------------------------------------
    # 3) E3DC_CONF.h laden (Version extrahieren)
    # ------------------------------------------------------------
    header_file = os.path.join(base_path, "E3DC_CONF.h")
    if os.path.isfile(header_file):
        with open(header_file, "r") as f:
            for line in f:
                if "VERSION" in line:
                    parts = line.split()
                    if len(parts) >= 3:
                        config["cver"] = parts[2].replace('"', "")
                    break

    return config