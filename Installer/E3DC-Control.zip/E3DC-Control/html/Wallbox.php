<?php
// Datei-Pfade
$datei1 = "/home/pi/E3DC-Control/e3dc.wallbox.txt";
$datei2 = "e3dc.wallbox.txt";

if (file_exists($datei2))
    $datei = $datei2;
elseif (file_exists($datei1))
    $datei = $datei1;
else
    $datei = $datei1; // Fallback

$alleZeilen = [];
$zeile = "1";

/* ---------------------------------------------------------
   1. POST-Daten verarbeiten (Speichern der Ladedauer)
--------------------------------------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $neueDauer = isset($_POST["zwei"]) ? trim($_POST["zwei"]) : "0";
    if ($neueDauer === "") $neueDauer = "0";

    file_put_contents($datei, $neueDauer . PHP_EOL, LOCK_EX);
    sleep(1);
}

/* ---------------------------------------------------------
   2. Datei vollständig einlesen
--------------------------------------------------------- */
if (file_exists($datei)) {
    $alleZeilen = file($datei, FILE_IGNORE_NEW_LINES);
}

if (count($alleZeilen) > 0) {
    $zeile = $alleZeilen[0];
}
?>

<h1>Wallbox Ladeplanung</h1>

<div class="wallbox-box">

    <?php
    /* ---------------------------------------------------------
       3. Ausgabe der Ladeinformationen
    --------------------------------------------------------- */

    if ($zeile < "1") {
        echo "<p>Es wurden keine Ladezeiten geplant.</p>";
    } else {
        if ($zeile < "2")
            echo "<p>Die geplante Ladedauer beträgt <strong>eine Stunde</strong>.</p>";
        else
            echo "<p>Die geplante Ladedauer beträgt <strong>$zeile Stunden</strong>.</p>";
    }

    /* ---------------------------------------------------------
       4. Weitere Zeilen anzeigen
    --------------------------------------------------------- */

    if (count($alleZeilen) > 1) {
        echo "<p><br>Die geplanten Ladezeiten sind:</p><ul>";

        for ($i = 1; $i < count($alleZeilen); $i++) {
            echo "<li>" . htmlspecialchars($alleZeilen[$i]) . "</li>";
        }

        echo "</ul>";
    }
    ?>

    <form action="index.php?seite=wallbox" method="post" class="wallbox-form">
        <label for="zwei">Ladedauer (in Stunden)</label>
        <input type="text" id="zwei" name="zwei" value="<?=$zeile?>" minlength="1" maxlength="2">

        <input type="submit" class="form-button" value="Speichern">
    </form>

</div>

<style>
    .wallbox-box {
        margin-top: 20px;
        background-color: #2f2f2f;
        padding: 20px;
        border-radius: 8px;
    }

    .wallbox-box p {
        font-size: 1.1em;
        line-height: 1.5em;
    }

    .wallbox-box ul {
        margin-top: 10px;
        padding-left: 20px;
    }

    .wallbox-form {
        margin-top: 20px;
        max-width: 300px;
    }

    .wallbox-form label {
        display: block;
        margin-bottom: 8px;
        font-size: 1.1em;
    }

    .wallbox-form input[type="text"] {
        width: 100%;
        padding: 10px;
        border-radius: 4px;
        border: 1px solid #aaa;
        background-color: #333;
        color: white;
        margin-bottom: 15px;
    }

    .form-button {
        padding: 10px 20px;
        background-color: #0073e6;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        display: inline-block;
    }

    .form-button:hover {
        background-color: #005b8e;
    }
</style>