<?php
// archiv.php

// ------------------------------------------------------------
// Schritt 1: Alle vorhandenen awattardebug.X.txt Dateien finden
// ------------------------------------------------------------
$files = glob("/home/pi/E3DC-Control/awattardebug.*.txt");

$entries = [];
foreach ($files as $file) {
    if (preg_match('/awattardebug\.(\d+)\.txt$/', $file, $m)) {
        $entries[] = [
            'num' => intval($m[1]),
            'name' => basename($file)
        ];
    }
}

// Sortieren nach Nummer
usort($entries, fn($a, $b) => $a['num'] <=> $b['num']);

// Ausgewählte Datei bestimmen
$selectedFile = $_GET['file'] ?? null;
$changed = null;
if ($selectedFile) {
    $fullpath = "/home/pi/E3DC-Control/" . $selectedFile;
    if (file_exists($fullpath)) {
        $changed = date("d.m.Y H:i", filemtime($fullpath));
    }
}
?>

<h2 style="text-align:center; margin-top:20px;">Archiv – Diagramm auswählen</h2>

<!-- ------------------------------------------------------------
     Schritt 2: Elegante Auswahl (Dropdown oder Buttons)
     ------------------------------------------------------------ -->

<div style="text-align:center; margin-top:20px;">
    <form method="GET" action="index.php">
        <input type="hidden" name="seite" value="archiv">

        <select name="file" style="padding:8px; font-size:16px;">
            <option value="">Bitte wählen…</option>

            <?php foreach ($entries as $e): ?>
                <option value="<?= htmlspecialchars($e['name']) ?>"
                    <?= ($selectedFile === $e['name']) ? 'selected' : '' ?>>
                    Datei <?= $e['num'] ?> (<?= $e['name'] ?>)
                </option>
            <?php endforeach; ?>
        </select>

        <button type="submit" class="form-button">Anzeigen</button>
    </form>
</div>

<?php if ($selectedFile): ?>
    <h3 style="text-align:center; margin-top:30px;">
        Archiv-Diagramm: <?= htmlspecialchars($selectedFile) ?>
        <?php if ($changed): ?>
            <span style="color:#ccc; font-size:0.9em;">
                (geändert am <?= $changed ?>)
            </span>
        <?php endif; ?>
    </h3>
    <iframe src="archiv_diagramm.php?file=<?= urlencode($selectedFile) ?>&ts=<?= time() ?>"
            style="width:100%; height:600px; border:none; margin-top:20px;">
    </iframe>
<?php endif; ?>