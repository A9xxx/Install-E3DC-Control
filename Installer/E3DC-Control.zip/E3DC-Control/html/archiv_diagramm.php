<?php
if (!isset($_GET['file'])) {
    die("Keine Datei angegeben.");
}

$file = basename($_GET['file']);
$fullpath = "/home/pi/E3DC-Control/" . $file;

if (!file_exists($fullpath)) {
    die("Datei nicht gefunden: " . htmlspecialchars($fullpath));
}

// Archiv-Skript starten
exec("python3 /home/pi/E3DC-Control/plot_soc_changes.py " . escapeshellarg($fullpath) . " archiv");

// Warten, bis das Archiv-Diagramm fertig ist
$doneFile = "/var/www/html/tmp/plot_soc_done_archiv";
$timeout = 10; // Sekunden
$start = time();

while (!file_exists($doneFile)) {
    usleep(200000); // 0.2 Sekunden
    if (time() - $start > $timeout) {
        break;
    }
}

// Archiv-Diagramm ausgeben
readfile("/var/www/html/archiv_diagramm.html");
?>