<?php
$config_file_path = '/home/pi/E3DC-Control/e3dc.config.txt';
$message = '';

// Funktion zum Lesen der Konfigurationsdatei
function readConfig($file_path) {
    if (!file_exists($file_path)) {
        return ['error' => 'Die Konfigurationsdatei existiert nicht.'];
    }

    $lines = file($file_path, FILE_IGNORE_NEW_LINES);
    $config = [];

    foreach ($lines as $line) {
        if (strpos($line, 'Wbhour') !== false) {
            list($key, $value) = explode('=', $line, 2) + [null, null];
            $key = trim($key);
            $value = trim($value);
            if ($key === 'Wbhour') {
                $config[$key] = $value;
            }
        }
    }

    if (empty($config)) {
        return ['error' => 'Wbhour nicht in der Konfigurationsdatei gefunden.'];
    }

    return $config;
}

// Funktion zum Schreiben
function writeConfig($file_path, $config) {
    $lines = file($file_path, FILE_IGNORE_NEW_LINES);
    $new_lines = [];

    foreach ($lines as $line) {
        if (strpos($line, 'Wbhour') !== false) {
            $new_lines[] = "Wbhour = " . $config['Wbhour'];
        } else {
            $new_lines[] = $line;
        }
    }

    file_put_contents($file_path, implode("\n", $new_lines));
}

$config = readConfig($config_file_path);

if (isset($config['error'])) {
    $message = "<span style='color:red;'>Fehler: " . htmlspecialchars($config['error']) . "</span>";
    $config = [];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['Wbhour'])) {
        $config['Wbhour'] = $_POST['Wbhour'];
        writeConfig($config_file_path, $config);
        $message = "<span style='color:green;'>Wert wurde erfolgreich gespeichert!</span>";
    }
}
?>

<h1>Einstellungen für Ladeautomatik</h1>

<?php if (!empty($message)): ?>
    <div class="message-box"><?php echo $message; ?></div>
<?php endif; ?>

<form method="POST" class="auto-form">
    <?php if (!empty($config)): ?>
        <div class="config-item">
            <label for="Wbhour">Wbhour</label>
            <input type="text" id="Wbhour" name="Wbhour" value="<?php echo htmlspecialchars($config['Wbhour']); ?>">
        </div>

        <input type="submit" class="form-button" value="Speichern">
    <?php else: ?>
        <p style="color: red;">Es konnte keine gültige Konfiguration geladen werden.</p>
    <?php endif; ?>

</form>

<style>
    .auto-form {
        margin-top: 20px;
        max-width: 500px;
    }

    .config-item label {
        display: block;
        margin-top: 15px;
        font-size: 1.1em;
    }

    .config-item input {
        width: 100%;
        padding: 10px;
        margin-top: 5px;
        border-radius: 4px;
        border: 1px solid #aaa;
        background-color: #333;
        color: white;
    }

    .form-button {
        padding: 10px 20px;
        background-color: #0073e6;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        display: inline-block;
        margin-top: 20px;
    }

    .form-button:hover {
        background-color: #005b8e;
    }

    .message-box {
        margin-top: 15px;
        padding: 10px;
        background-color: #e8f5e9;
        border-left: 5px solid #4caf50;
        color: #2e7d32;
        font-weight: bold;
        display: inline-block;
    }
</style>