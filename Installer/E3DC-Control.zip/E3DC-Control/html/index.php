<?php
/* ------------------ SICHERES ROUTING ------------------ */
$allowed = ['start','wallbox','config','auto','archiv'];
$seite = $_GET['seite'] ?? 'start';
if (!in_array($seite, $allowed)) {
    $seite = 'start';
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">

    <!-- Mobile / PWA -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#005b8e">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

    <title>E3DC Control</title>

    <!-- PWA -->
    <link rel="manifest" href="/manifest.json">
    <link rel="apple-touch-icon" href="/icons/icon-192.png">

    <style>
        html, body {
            margin: 0;
            padding: 0;
            background-color: #242424;
            color: #fff;
            font-family: Arial, sans-serif;
            overflow-x: hidden;
        }

        .container {
            max-width: 1200px;
            margin: auto;
            padding: 20px;
            box-sizing: border-box;
        }

        h1 {
            color: #005b8e;
            text-align: center;
        }

        /* Buttons Desktop */
        .button {
            padding: 10px 20px;
            background-color: #0073e6;
            color: #fff;
            border-radius: 4px;
            text-decoration: none;
            margin-right: 10px;
            display: inline-block;
        }
        /* Startseite: Aktualisieren-Button */
        .update-button {
            padding: 10px 20px;
            background-color: #0073e6;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 15px;
            margin-top: 15px;
            display: inline-block;
        }

        .update-button:hover {
            background-color: #005b8e;
        }

        .button:hover {
            background-color: #005b8e;
        }

        /* Mobile Men� */
        #menu-toggle {
            display: none;
        }

        .menu-icon {
            display: none;
            font-size: 32px;
            padding: 10px;
            cursor: pointer;
        }

        .mobile-menu {
            display: none;
            flex-direction: column;
            background: #333;
        }

        .mobile-menu a {
            padding: 12px;
            color: white;
            text-decoration: none;
            border-bottom: 1px solid #444;
        }

        #menu-toggle:checked + .menu-icon + .mobile-menu {
            display: flex;
        }

        @media (max-width: 600px) {
            .menu-icon { display: block; }
            .button { display: none; }
        }

        #fussnoten {
            text-align: center;
            font-size: 0.8em;
            padding: 20px;
            opacity: 0.8;
        }

        #fussnoten a {
            color: #ccc;      /* gut lesbares hellgrau */
        }

        #fussnoten a:hover {
            color: #fff;      /* beim �berfahren noch heller */
        }

        /* Globale Buttons */
        .link-button, .form-button {
            padding: 10px 20px;
            background-color: #0073e6;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }

        .tooltip-icon {
            display: inline-flex;
            justify-content: center;
            align-items: center;
            width: 18px;
            height: 18px;
            background-color: #0073e6;
            color: white;
            border-radius: 50%;
            font-size: 12px;
            font-weight: bold;
            margin-left: 6px;
            cursor: pointer;
        }

        .button:hover, .link-button:hover, .form-button:hover {
            background-color: #005b8e;
        }

        /* Einheitliche Eingabefelder */
        input[type="text"], select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 4px;
            border: 1px solid #aaa;
            background-color: #333;
            color: white;
        }

        /* Einheitliche Box */
        .config-box {
            margin-top: 20px;
            background-color: #2f2f2f;
            padding: 20px;
            border-radius: 8px;
        }
    </style>
</head>

<body>

<!-- Mobile Men� -->
<input type="checkbox" id="menu-toggle">
<label for="menu-toggle" class="menu-icon">&#9776;</label>

<nav class="mobile-menu">
    <a href="?seite=start">Startseite</a>
    <a href="?seite=wallbox">Wallbox</a>
    <a href="?seite=config">Config</a>
    <a href="?seite=auto">Auto</a>
    <a href="?seite=archiv">Archiv</a>
</nav>

<div class="container">
    <h1>E3DC-Control Anzeige & Steuerung</h1>

    <!-- Desktop Navigation -->
    <a class="button" href="?seite=start">Startseite</a>
    <a class="button" href="?seite=wallbox">Wallbox</a>
    <a class="button" href="?seite=config">Config</a>
    <a class="button" href="?seite=auto">Auto</a>
    <a class="button" href="?seite=archiv">Archiv</a>

    <main id="content">
        <?php
        switch ($seite) {
            case 'wallbox':
                include 'Wallbox.php';
                break;
            case 'config':
                include 'config_editor.php';
                break;
            case 'auto':
                include 'auto.php';
                break;
            case 'archiv':
                include 'archiv.php';
                break;
            case 'start':
            default:
                include 'start_content.php';
                break;

        }
        ?>
    </main>
</div>

<footer id="fussnoten">
    <h2>Das Projekt</h2>
    <p>
        <a href="https://github.com/Eba-M/E3DC-Control" target="_blank">GitHub</a> |
        <a href="https://www.photovoltaikforum.com" target="_blank">Photovoltaikforum</a>
    </p>
</footer>

<!-- Service Worker -->
<script>
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/service-worker.js')
            .catch(err => console.error('SW Fehler:', err));
    });
}
</script>

</body>
</html>
