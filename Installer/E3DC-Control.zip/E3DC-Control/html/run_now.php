<?php
$lock = "/var/www/html/tmp/plot_soc_running";

// Wenn schon läuft → sofort melden
if (file_exists($lock)) {
    echo "running";
    exit;
}

// Lockfile SOFORT erzeugen
touch($lock);

// Python starten
exec("/usr/bin/python3 /home/pi/E3DC-Control/plot_soc_changes.py /home/pi/E3DC-Control/awattardebug.txt normal > /dev/null 2>&1 &");

// Antwort an JS
echo "started";