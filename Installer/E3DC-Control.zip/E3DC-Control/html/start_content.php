<?php
$stamp = "/var/www/html/tmp/plot_soc_last_run";
$lock  = "/var/www/html/tmp/plot_soc_running";
$done  = "/var/www/html/tmp/plot_soc_done";

$diagramm = "/var/www/html/diagramm.html";

$needsUpdate = false;

if (!file_exists($stamp) || (time() - filemtime($stamp)) > 600) {
    $needsUpdate = true;
}

if (!file_exists($diagramm) || (time() - filemtime($diagramm)) > 600) {
    $needsUpdate = true;
}

if ($needsUpdate) {
    exec("/usr/bin/python3 /home/pi/E3DC-Control/plot_soc_changes.py /home/pi/E3DC-Control/awattardebug.txt normal > /dev/null 2>&1 &");}

$initialStatus = "";
if (file_exists($lock)) {
    $initialStatus = "Diagramm wird aktualisiert…";
}
?>

<div style="text-align:center; margin:15px;">
    <button id="forceUpdateBtn" class="update-button">Diagramm aktualisieren</button>
</div>

<iframe id="diagrammFrame" style="width:100%; height:600px; border:none;"></iframe>

<div id="lastUpdate" style="text-align:center; margin-top:10px; font-size:14px; color:#aaa;"></div>
<div id="updateStatus" style="text-align:center; margin-top:10px; font-size:14px; color:#aaa;"></div>

<script>
const updateStatus = document.getElementById("updateStatus");
const diagrammFrame = document.getElementById("diagrammFrame");
const lastUpdate = document.getElementById("lastUpdate");

let statusInterval = null;
let missingCount = 0;

// --- checkStatus MUSS GLOBAL sein ---
function checkStatus() {
    fetch("tmp/plot_soc_running", { method: "HEAD" })
        .then(res => {
            if (res.status === 200) {
                updateStatus.innerHTML = "Diagramm wird aktualisiert…";
                missingCount = 0;
            } else {
                missingCount++;
                if (missingCount >= 3) {
                    updateStatus.innerHTML = "";
                    clearInterval(statusInterval);
                    statusInterval = null;
                }
            }
        })
        .catch(() => {
            missingCount++;
            if (missingCount >= 3) {
                updateStatus.innerHTML = "";
                clearInterval(statusInterval);
                statusInterval = null;
            }
        });
}

// --- Button-Handler ---
document.getElementById("forceUpdateBtn").addEventListener("click", () => {
    updateStatus.innerHTML = "Manuelle Aktualisierung gestartet…";
    missingCount = 0;

    fetch("run_now.php")
        .then(res => res.text())
        .then(txt => {
            if (txt === "running") {
                updateStatus.innerHTML = "Läuft bereits…";
            } else if (txt === "started") {
                updateStatus.innerHTML = "Aktualisierung gestartet…";
                missingCount = 0;

                if (!statusInterval) {
                    statusInterval = setInterval(checkStatus, 2000);
                }
            } else {
                updateStatus.innerHTML = "Unbekannte Antwort: " + txt;
            }
        })
        .catch(() => {
            updateStatus.innerHTML = "Fehler beim Starten.";
        });
});

// --- DOMContentLoaded ---
document.addEventListener("DOMContentLoaded", () => {

    let lastSize = 0;
    let stableSize = 0;
    let stableSince = 0;

    function checkUpdate() {
        fetch("diagramm.html", { method: "HEAD" })
            .then(res => {
                const size = res.headers.get("Content-Length");
                if (!size) return;

                const newSize = parseInt(size, 10);
                const now = Date.now();

                if (newSize !== stableSize) {
                    stableSize = newSize;
                    stableSince = now;
                    return;
                }

                if (now - stableSince < 1000) {
                    return;
                }

                if (newSize !== lastSize) {
                    lastSize = newSize;

                    lastUpdate.innerHTML =
                        "Letzte Aktualisierung: " + new Date().toLocaleTimeString();

                    diagrammFrame.src = "diagramm.html?ts=" + now;
                }
            });
    }

    setTimeout(() => {
        fetch("tmp/plot_soc_running", { method: "HEAD" })
            .then(res => {
                if (res.status === 200) {
                    missingCount = 0;
                    statusInterval = setInterval(checkStatus, 2000);
                } else {
                    // WICHTIG: Status NICHT löschen
                    // Kein Prozess läuft → kein Status nötig
                }
            });
    }, 3000);

    setInterval(checkUpdate, 8000);

    diagrammFrame.src = "diagramm.html?ts=" + Date.now();
});
</script>