import os
from datetime import datetime, timedelta
import pytz

def parse_simulation_file(sim_file, dt_modification_time, awmwst, awnebenkosten, speichergroesse):
    """
    Liest die Simulationsdatei (awattardebug.txt/out) und extrahiert:
      - Zeitstempel
      - Preiswerte
      - Temperatur
      - Wärmepumpenlast
      - PV-Ertrag
      - SoC nach Simulation
      - Min/Max-Werte
    """

    if not os.path.isfile(sim_file):
        raise FileNotFoundError(f"Datei nicht gefunden: {sim_file}")

    times = []
    times_dt = []
    price_values = []
    temperatur_values = []
    yellow_line_values = []
    combined_values_pre_simulation = []
    soc_values_post_simulation = []

    after_simulation = False
    day_offset = 0
    last_dt_gmt = None  # Robuste Mitternachtserkennung
    base_date = dt_modification_time.date()

    wpmin = float("inf")
    wpmax = float("-inf")
    temperatur_min = float("inf")
    temperatur_max = float("-inf")

    with open(sim_file, "r") as f:
        for line in f:

            # Umschaltpunkte Simulation / Data
            if "Simulation" in line:
                after_simulation = True
                continue

            if "Data" in line:
                after_simulation = False
                continue

            parts = line.split()
            if len(parts) < 4:
                continue

            # --------------------------------------------------------
            # Zeit aus Simulation (GMT)
            # --------------------------------------------------------
            h, f = parts[0].split(".")
            hour = int(h)
            minute = round(float("0." + f) * 60)

            if last_dt_gmt is None:
                # erster Eintrag: Start = Dateidatum + Uhrzeit
                dt_gmt = datetime(
                    year=dt_modification_time.year,
                    month=dt_modification_time.month,
                    day=dt_modification_time.day,
                    hour=hour,
                    minute=minute,
                    tzinfo=pytz.utc
                )
            else:
                # gleiche Basis wie letzter Timestamp, nur Uhrzeit ersetzen
                dt_gmt = last_dt_gmt.replace(hour=hour, minute=minute)

                # wenn Zeit zurückspringt oder gleich ist → nächster Tag
                if dt_gmt <= last_dt_gmt:
                    dt_gmt += timedelta(days=1)

            last_dt_gmt = dt_gmt

            # --------------------------------------------------------
            # Nach lokaler Zeit (CET/CEST) umrechnen
            # --------------------------------------------------------
            dt_local = dt_gmt.astimezone()

            times.append(dt_local.strftime("%a %H:%M"))
            times_dt.append(dt_local)

            # --------------------------------------------------------
            # Werte vor Simulation
            # --------------------------------------------------------
            if not after_simulation:

                price_raw = float(parts[1])
                price_value = price_raw / 10 * (awmwst / 100 + 1) + awnebenkosten

                # Neue Preislogik ab 19.12.2024
                if dt_modification_time > datetime(2024, 12, 19):
                    price_value = price_raw * (awmwst / 100 + 1) + awnebenkosten

                price_values.append(round(price_value, 2))

                yellow_value = round(float(parts[4]) * 40 * speichergroesse, 2)
                yellow_line_values.append(yellow_value)

                wp = round(float(parts[3]) * speichergroesse * 4 / 100, 2)
                combined_values_pre_simulation.append(wp)

                wpmin = min(wpmin, wp)
                wpmax = max(wpmax, wp)

                temp = float(parts[5])
                temperatur_values.append(temp)

                temperatur_min = min(temperatur_min, temp)
                temperatur_max = max(temperatur_max, temp)

            # --------------------------------------------------------
            # Werte nach Simulation (SoC)
            # --------------------------------------------------------
            else:
                soc = float(parts[2])
                soc_values_post_simulation.append(soc)

    return {
        "times": times,
        "times_dt": times_dt,
        "price_values": price_values,
        "temperatur_values": temperatur_values,
        "yellow_line_values": yellow_line_values,
        "combined_values": combined_values_pre_simulation,
        "soc_values": soc_values_post_simulation,
        "wpmin": wpmin if wpmin != float("inf") else 0,
        "wpmax": wpmax if wpmax != float("-inf") else 0,
        "tmin": temperatur_min if temperatur_min != float("inf") else 0,
        "tmax": temperatur_max if temperatur_max != float("-inf") else 0
    }