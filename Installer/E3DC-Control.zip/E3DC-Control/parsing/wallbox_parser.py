#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import datetime
import re
from typing import List, Dict


# ------------------------------------------------------------
# Hilfsfunktionen
# ------------------------------------------------------------

def _parse_date(line: str) -> datetime.date:
    """
    Erwartet z.B. 'am 28.1.' und liefert ein datetime.date.
    Jahr = aktuelles Jahr.
    """
    m = re.search(r"(\d+)\.(\d+)\.", line + ".")
    if not m:
        raise ValueError(f"Kein Datum gefunden: {line}")

    day, month = map(int, m.groups())
    year = datetime.datetime.now().year
    return datetime.date(year, month, day)


_TIME_PRICE_RE = re.compile(
    r"um\s+(\d+):\s*(\d+)\s+zu\s+([\d\.]+)ct/kWh"
)


def _parse_time_price(line: str, base_date: datetime.date):
    """
    Erwartet z.B. 'um 0:15 zu 28.900ct/kWh'
    Liefert (datetime, preis_ct)
    """
    m = _TIME_PRICE_RE.search(line)
    if not m:
        return None

    hour = int(m.group(1))
    minute = int(m.group(2))
    price = float(m.group(3).replace(",", "."))

    dt = datetime.datetime(
        base_date.year,
        base_date.month,
        base_date.day,
        hour,
        minute
    )
    return dt, price


# ------------------------------------------------------------
# Hauptparser
# ------------------------------------------------------------

def parse_wallbox_file(path: str) -> List[Dict]:
    with open(path, "r", encoding="utf-8") as f:
        lines = [l.strip() for l in f.readlines() if l.strip()]

    if len(lines) < 2:
        return []

    # Erste Zeile = Anzahl manueller Stunden
    try:
        manual_hours = int(lines[0])
    except Exception:
        manual_hours = 0

    entries = []
    base_date = None
    source = "manual"
    manual_count = 0

    for line in lines[1:]:

        # Datum aktualisieren
        if line.startswith("am "):
            try:
                base_date = _parse_date(line)
            except Exception:
                pass
            continue

        # Automatik-Block beginnt
        if line.startswith("Von der Ladezeitenautomatik"):
            source = "auto"
            continue

        # Ende
        if line == "CET":
            break

        # Zeit/Preis parsen
        if base_date is not None:
            parsed = _parse_time_price(line, base_date)
            if parsed:
                dt, price = parsed

                # manuelle Stunden zählen
                if source == "manual":
                    if manual_count >= manual_hours:
                        # obwohl wir noch im manual-Block sind,
                        # sind die angegebenen Stunden vorbei → auto
                        source = "auto"
                    else:
                        manual_count += 0.25  # 15 Minuten = 0.25h

                entries.append({
                    "dt": dt,
                    "price_ct": price,
                    "source": source
                })

    entries.sort(key=lambda e: e["dt"])
    return entries


# ------------------------------------------------------------
# Optional: 48h‑Raster
# ------------------------------------------------------------

def build_48h_grid(base_date: datetime.date, entries: List[Dict]) -> List[Dict]:
    """
    Baut ein 48h‑Raster in 15‑Minuten‑Schritten ab 00:00 des base_date.
    """
    start = datetime.datetime(base_date.year, base_date.month, base_date.day, 0, 0)
    end = start + datetime.timedelta(hours=48)

    price_map = {
        (e["dt"].hour, e["dt"].minute): (e["price_ct"], e["source"])
        for e in entries
    }

    grid = []
    current = start

    while current < end:
        key = (current.hour, current.minute)

        if key in price_map:
            price, source = price_map[key]
        else:
            price, source = None, None

        grid.append({
            "dt": current,
            "price_ct": price,
            "source": source
        })

        current += datetime.timedelta(minutes=15)

    return grid