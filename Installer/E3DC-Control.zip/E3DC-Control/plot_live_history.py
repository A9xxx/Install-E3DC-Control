#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E3DC-Control - Live-History-Diagramm (Dark Mode)
Liest JSON-Lines aus der Ramdisk und erstellt ein optimiertes Diagramm im Dark-Mode.
Inklusive dynamischer Preis-Integration.
"""

import os
import sys
import json
import logging
import argparse
from datetime import timedelta
from datetime import datetime
from pathlib import Path

# ============================================================
# KONFIGURATION
# ============================================================

LIVE_HISTORY_FILE = "/var/www/html/ramdisk/live_history.txt"
OUTPUT_HTML = "/var/www/html/live_diagramm.html"
LOCKFILE = "/var/www/html/tmp/plot_live_history_running"
STAMP_FILE = "/var/www/html/tmp/plot_live_history_last_run"
LOG_DIR = "/var/www/html/logs"

go = None # Lazy Loading für Plotly

# ============================================================
# HELPER: LOCKING & LOGGING
# ============================================================

def setup_logging():
    os.makedirs(LOG_DIR, exist_ok=True)
    logging.basicConfig(
        filename=os.path.join(LOG_DIR, "diagram.log"),
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    return logging.getLogger("diagram")

def acquire_lock():
    os.makedirs(os.path.dirname(LOCKFILE), mode=0o775, exist_ok=True)
    try:
        fd = os.open(LOCKFILE, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o666)
        os.close(fd)
        return True
    except FileExistsError:
        return False

def release_lock():
    try:
        if os.path.exists(LOCKFILE):
            os.remove(LOCKFILE)
    except Exception:
        pass

def load_darkmode_config():
    """Liest die darkmode-Einstellung aus der e3dc.config.txt"""
    try:
        # Versuche Standardpfad
        with open("/home/pi/E3DC-Control/e3dc.config.txt", "r") as f:
            for line in f:
                if "darkmode" in line.lower() and "=" in line:
                    val = line.split("=")[1].strip().lower()
                    return val in ['1', 'true', 'on']
    except:
        pass
    return True # Default Dark

# ============================================================
# DATEN PARSEN (JSON-LINES) MIT DOWNSAMPLING & ZEITFILTER
# ============================================================

def parse_live_history(filepath, hours_to_show=6):
    data = {
        "times": [], "pv": [], "bat": [], "home": [], 
        "grid": [], "soc": [], "wp": [], "wb": [], "price": []
    }

    if not os.path.exists(filepath):
        return None

    # Gruppierung nach Minuten für Mittelwertbildung
    minute_data = {} 

    try:
        with open(filepath, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line: continue
                try:
                    entry_raw = json.loads(line)
                    entry = {k.lower(): v for k, v in entry_raw.items()}
                    dt = datetime.fromisoformat(entry["ts"])
                    # Schlüssel für die Minute (Sekunden auf 0 setzen)
                    m_key = dt.replace(second=0, microsecond=0)

                    if m_key not in minute_data:
                        minute_data[m_key] = []
                    minute_data[m_key].append(entry)
                except (json.JSONDecodeError, ValueError, KeyError):
                    continue
                    
        if not minute_data:
            return None

        # Sortieren und Mittelwerte berechnen
        sorted_minutes = sorted(minute_data.keys())
        latest_time = sorted_minutes[-1]
        cutoff_time = latest_time - timedelta(hours=hours_to_show)

        for m_dt in sorted_minutes:
            if m_dt < cutoff_time:
                continue
            
            entries = minute_data[m_dt]
            n = len(entries)
            
            data["times"].append(m_dt)
            data["pv"].append(sum(float(e.get("pv", 0)) for e in entries) / n)
            data["bat"].append(sum(float(e.get("bat", 0)) for e in entries) / n)
            # 'home' ist der korrigierte Hausverbrauch (ohne WP), mit Fallback auf 'home_raw'
            data["home"].append(sum(float(e.get("home", e.get("home_raw", 0))) for e in entries) / n)
            data["grid"].append(sum(float(e.get("grid", 0)) for e in entries) / n)
            data["soc"].append(sum(float(e.get("soc", 0)) for e in entries) / n)
            data["wp"].append(sum(float(e.get("wp", 0)) for e in entries) / n)
            data["wb"].append(sum(float(e.get("wb", 0)) for e in entries) / n)
            
            # Preis ist meist pro Stunde gleich, Mittelwert schadet aber nicht
            prices = [float(e["price_ct"]) for e in entries if e.get("price_ct") is not None]
            data["price"].append(sum(prices) / len(prices) if prices else None)

        return data
    except Exception as e:
        print(f"Fehler beim Parsen: {e}", file=sys.stderr)
        return None

# ============================================================
# DIAGRAMM ERSTELLEN (DARK MODE)
# ============================================================

def create_live_diagram(data):
    last_time = data["times"][-1]
    stand_str = last_time.strftime("%d.%m. %H:%M Uhr")

    # Preise separat auswerten für eigene Skalierung auf y3
    valid_prices = [p for p in data["price"] if p is not None]
    p_min = min(valid_prices) if valid_prices else 0
    p_max = max(valid_prices) if valid_prices else 50

    dark_mode = load_darkmode_config()
    
    if dark_mode:
        template = "plotly_dark"
        c_bg_paper = "#121212"
        c_bg_plot = "#1e1e1e"
        c_text = "#e0e0e0"
        c_grid = "#333333"
        c_soc_fill = 'rgba(144, 238, 144, 0.15)'
        c_price = '#BA55D3'
        c_pv = '#FFD700'
        c_bat_load = '#98FB98'
        c_bat_unload = '#2E7D32'
        c_home = '#FF4500'
    else:
        template = "plotly_white"
        c_bg_paper = "#ffffff"
        c_bg_plot = "#f8f9fa"
        c_text = "#333333"
        c_grid = "#e0e0e0"
        c_soc_fill = 'rgba(85, 139, 47, 0.2)'
        c_price = '#8E24AA'
        c_pv = '#F57F17'
        c_bat_load = '#558B2F'
        c_bat_unload = '#33691E'
        c_home = '#D84315'

    fig = go.Figure()

    # 1. SOC als Fläche ohne Linie auf eigener Achse (y2)
    fig.add_trace(go.Scatter(
        x=data["times"], y=data["soc"], name="SOC %",
        fill='tozeroy',
        mode='lines',
        line=dict(width=0), # Keine sichtbare Linie
        fillcolor=c_soc_fill,
        yaxis="y2",
        hovertemplate='SOC: %{y:.1f}%<extra></extra>'
    ))
    
    # 2. Preis als Stufendiagramm auf dritter Achse (y3)
    fig.add_trace(go.Scatter(
        x=data["times"], y=data["price"], name="Preis (ct)", mode='lines',
        line=dict(color=c_price, width=2, shape='hv'),
        yaxis="y3",
        hovertemplate='Preis: %{y:.2f} ct<extra></extra>'
    ))

    # Die restlichen Leistungswerte
    fig.add_trace(go.Scatter(x=data["times"], y=data["pv"], name="PV", line=dict(color=c_pv, width=2), hovertemplate='PV: %{y:.0f} W<extra></extra>'))
    
    # Batterie & Netz: Negative Werte werden nach oben geklappt (abs) mit sauberem Hover
    # Auf Wunsch getauscht: Positive Werte werden als Laden (hellgrün), negative als Entladen (dunkelgrün) dargestellt.
    fig.add_trace(go.Scatter(x=data["times"], y=[v if v >= 0 else 0 for v in data["bat"]], name="Bat. Laden", line=dict(color=c_bat_load, width=2), hovertemplate='Batterie Laden: %{y:.0f} W<extra></extra>'))
    fig.add_trace(go.Scatter(x=data["times"], y=[abs(v) if v < 0 else 0 for v in data["bat"]], name="Bat. Entladen", line=dict(color=c_bat_unload, width=2), hovertemplate='Batterie Entladen: %{y:.0f} W<extra></extra>'))
    
    fig.add_trace(go.Scatter(x=data["times"], y=data["home"], name="Haus", line=dict(color=c_home, width=2), hovertemplate='Hausverbrauch: %{y:.0f} W<extra></extra>'))
    
    fig.add_trace(go.Scatter(x=data["times"], y=[v if v > 1 else 0 for v in data["grid"]], name="Netzbezug", line=dict(color='#A9A9A9', width=2, dash='dot'), hovertemplate='Netzbezug: %{y:.0f} W<extra></extra>'))
    fig.add_trace(go.Scatter(x=data["times"], y=[abs(v) if v < -1 else 0 for v in data["grid"]], name="Einspeisung", line=dict(color='#FF8C00', width=2, dash='dot'), hovertemplate='Netzeinspeisung: %{y:.0f} W<extra></extra>'))
    
    fig.add_trace(go.Scatter(x=data["times"], y=data["wp"], name="WP", line=dict(color='#1E90FF', width=2), hovertemplate='Wärmepumpe: %{y:.0f} W<extra></extra>'))
    fig.add_trace(go.Scatter(x=data["times"], y=data["wb"], name="WB", line=dict(color='#00CED1', width=2), hovertemplate='Wallbox: %{y:.0f} W<extra></extra>'))

    # Dark Mode Layout
    fig.update_layout(
        template=template,
        title=dict(text=f"Live Verlauf (Stand: {stand_str})", x=0.5, xanchor='center', font=dict(color=c_text)),
        font=dict(color=c_text), 
        margin=dict(l=50, r=50, t=60, b=80), 
        legend=dict(
            orientation="h", 
            y=-0.15, # Legende unter die X-Achse schieben
            x=0.5, 
            xanchor='center', 
            font=dict(color=c_text, size=10)
        ),
        hovermode="x unified",
        hoverdistance=1, # Verhindert das "Einfangen" von Nachbarminuten
        
        paper_bgcolor=c_bg_paper, 
        plot_bgcolor=c_bg_plot,  
        
        xaxis=dict(
            type='date', tickformat="%H:%M", tickmode="auto",
            gridcolor=c_grid, zerolinecolor=c_grid,
            domain=[0.05, 0.85] # Platz für die Y-Achsen rechts schaffen
        ),
        yaxis=dict(
            title="Leistung (W)",
            gridcolor=c_grid, 
            zeroline=True, zerolinecolor="#666666", zerolinewidth=2,
            side="left",
            range=[0, None] # Startet bei 0, da alles nach oben geklappt wurde
        ),
        yaxis2=dict(
            title=dict(text="SOC (%)", font=dict(color="#00FF7F")),
            tickfont=dict(color="#00FF7F"),
            overlaying="y", side="right", 
            range=[0, 105],
            showgrid=False
        ),
        yaxis3=dict(
            title=dict(text="Preis (ct)", font=dict(color=c_price)),
            tickfont=dict(color=c_price),
            overlaying="y", side="right",
            anchor="free",
            position=0.95,
            range=[p_min - 2, p_max + 2],
            showgrid=False
        )
    )
    return fig

# ============================================================
# MAIN
# ============================================================

def main():
    # Argument-Parser für die Stunden
    parser = argparse.ArgumentParser()
    parser.add_argument("--hours", type=int, default=6, help="Anzahl der anzuzeigenden Stunden (wird für Archivdateien ignoriert und auf 24 gesetzt).")
    parser.add_argument("--file", type=str, default=None, help="Pfad zu einer Archiv-Datei, die statt der Live-Daten genutzt werden soll.")
    args = parser.parse_args()

    if not acquire_lock(): return 0
    try:
        logger = setup_logging()
        
        # Entscheiden, welche Datei verwendet wird: Archiv oder Live-Standard
        source_file = args.file if args.file else LIVE_HISTORY_FILE
        is_archive = bool(args.file)
        
        # Parse mit Filter
        data = parse_live_history(source_file, hours_to_show=args.hours)
        if not data or not data["times"]:
            logger.warning(f"Keine gültigen Daten im Zeitraum in Datei '{source_file}' gefunden.")
            return 0

        global go
        import plotly.graph_objects as go

        fig = create_live_diagram(data)
        
        os.makedirs(os.path.dirname(OUTPUT_HTML), mode=0o755, exist_ok=True)
        fig.write_html(
            OUTPUT_HTML,
            include_plotlyjs="cdn",
            full_html=False,
            config={"displaylogo": False, "displayModeBar": False}
        )
        
        try: Path(STAMP_FILE).touch(mode=0o666)
        except Exception: pass

        log_msg = (
            f"Archiv-Diagramm '{os.path.basename(source_file)}' erstellt." if is_archive
            else f"Live-Diagramm aktualisiert ({args.hours}h). Stand: {data['times'][-1]}"
        )
        logger.info(log_msg)
        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        if 'logger' in locals(): logger.exception("Kritischer Fehler im Plotter")
        return 1
    finally:
        release_lock()

if __name__ == "__main__":
    sys.exit(main())