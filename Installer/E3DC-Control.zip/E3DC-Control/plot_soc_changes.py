#!/usr/bin/env python3
# ------------------------------------------------------------
# Projekt E3DC-Control
# plot_soc_changes.py (modulare Version)
# ------------------------------------------------------------

import os
import sys
from datetime import datetime
from plotly.subplots import make_subplots

# ------------------------------------------------------------
# Eingabedatei & Modus
# ------------------------------------------------------------
input_file = sys.argv[1] if len(sys.argv) > 1 else "awattardebug.txt"
mode = sys.argv[2] if len(sys.argv) > 2 else "normal"

output_file = (
    "/var/www/html/archiv_diagramm.html"
    if mode == "archiv"
    else "/var/www/html/diagramm.html"
)

# ------------------------------------------------------------
# Lockfile
# ------------------------------------------------------------
if mode == "archiv":
    lockfile = "/var/www/html/tmp/plot_soc_running_archiv"
else:
    lockfile = "/var/www/html/tmp/plot_soc_running"
    open(lockfile, "w").close()

# ------------------------------------------------------------
# Eigene Module
# ------------------------------------------------------------
from config.config_loader import load_config
from parsing.simulation_parser import parse_simulation_file
from parsing.wallbox_parser import parse_wallbox_file

from plotting.traces import (
    add_soc_trace,
    add_wallbox_bars,
    add_temperature_trace,
    add_wp_trace,
    add_price_trace,
    add_pv_trace
)

from plotting.layout import apply_layout
from plotting.annotations import add_annotations

# ------------------------------------------------------------
# Grundpfad
# ------------------------------------------------------------
BASE_PATH = "/home/pi/E3DC-Control/"

# ------------------------------------------------------------
# Version
# ------------------------------------------------------------
version = "2026.01.29"

# ------------------------------------------------------------
# 1) Config laden
# ------------------------------------------------------------
config = load_config(BASE_PATH)

awmwst = config.get("awmwst", 19.0)
awnebenkosten = config.get("awnebenkosten", 0.0)
speichergroesse = config.get("speichergroesse", 0)
cver = config.get("cver", "")

# Zeitstempel der Datei
dt_modification_time = datetime.fromtimestamp(os.path.getmtime(input_file))
local_time = dt_modification_time.astimezone()

# ------------------------------------------------------------
# 2) Simulation / Wallbox parsen
# ------------------------------------------------------------
# Simulation wird IMMER geladen
heatpump_data = parse_simulation_file(
    input_file,
    dt_modification_time,
    awmwst,
    awnebenkosten,
    speichergroesse
)
wallbox_data = None

if config.get("enable_wallbox"):
    wallbox_data = parse_wallbox_file(input_file)

# ------------------------------------------------------------
# 3) Wallbox-Einträge aus e3dc.wallbox.txt
# ------------------------------------------------------------
wallbox_entries = parse_wallbox_file(
    os.path.join(BASE_PATH, "e3dc.wallbox.txt")
)

wallbox_auto = [e["dt"] for e in wallbox_entries if e["source"] == "auto"]
wallbox_manual = [e["dt"] for e in wallbox_entries if e["source"] == "manual"]

# ------------------------------------------------------------
# 4) Plot erstellen
# ------------------------------------------------------------
sim = heatpump_data  # Alias für Kompatibilität

fig = make_subplots(specs=[[{"secondary_y": True}]])

# SoC
add_soc_trace(fig, sim["times"], sim["soc_values"])

# Wallbox
add_wallbox_bars(fig, sim["times"], sim["times_dt"], wallbox_auto, "rgba(255,0,0,0.5)")
add_wallbox_bars(fig, sim["times"], sim["times_dt"], wallbox_manual, "rgba(0,128,255,0.5)")

# Temperatur, WP, Preis, PV
add_temperature_trace(fig, sim["times"], sim["temperatur_values"])
if config.get("enable_heatpump"):
    add_wp_trace(fig, sim["times"], sim["combined_values"])
add_price_trace(fig, sim["times"], sim["price_values"])
add_pv_trace(fig, sim["times"], sim["yellow_line_values"])

# ------------------------------------------------------------
# 5) Layout anwenden
# ------------------------------------------------------------
ld = round(len(sim["price_values"]) / 5)

apply_layout(
    fig,
    ld=ld,
    wpmin=sim["wpmin"],
    wpmax=sim["wpmax"],
    tmin=sim["tmin"],
    tmax=sim["tmax"]
)

# ------------------------------------------------------------
# 6) Annotationen
# ------------------------------------------------------------
add_annotations(
    fig,
    dt_modification_time=dt_modification_time,
    local_time=local_time,
    cver=cver,
    version=version
)

try:
    # ------------------------------------------------------------
    # 7) HTML speichern
    # ------------------------------------------------------------
    fig.write_html(
        output_file,
        include_plotlyjs="cdn",
        full_html=False,
        config={"displaylogo": False, "displayModeBar": True}
    )

    # ------------------------------------------------------------
    # 8) Done-File setzen
    # ------------------------------------------------------------
    if mode == "archiv":
        open("/var/www/html/tmp/plot_soc_done_archiv", "w").close()
    else:
        open("/var/www/html/tmp/plot_soc_done", "w").close()

    open("/var/www/html/tmp/plot_soc_last_run", "w").close()

finally:
    # ------------------------------------------------------------
    # 9) Lockfile IMMER löschen
    # ------------------------------------------------------------
    if os.path.exists(lockfile):
        os.remove(lockfile)