def add_annotations(fig, dt_modification_time, local_time, cver, version):
    """
    Fügt Kopf- und Fußzeilen-Annotationen zum Diagramm hinzu.
    """

    # Titel
    fig.add_annotation(
        xref="x domain",
        yref="y domain",
        x=0,
        y=1.18,
        text="<b>Speichernutzungsplan</b>",
        showarrow=False,
        xanchor="left",
        font=dict(size=16)
    )

    # Zeitstempel (UTC + lokale Zeitzone)
    fig.add_annotation(
        xref="x domain",
        yref="y domain",
        x=0,
        y=1.10,
        text=(
            dt_modification_time.strftime("%d.%m.%y  %H:%M:%S")
            + f'{local_time.strftime(" %z ")[:4] + local_time.strftime(" %Z")}'
        ),
        showarrow=False,
        xanchor="left"
    )

    # Versionen (E3DC + Dashboard)
    fig.add_annotation(
        xref="x domain",
        yref="y domain",
        x=0,
        y=-0.3,
        text=f"{cver} • {version}",
        showarrow=False,
        xanchor="left"
    )

    # Datum (Wochentag)
    fig.add_annotation(
        xref="x domain",
        yref="y domain",
        x=0,
        y=-0.14,
        text=dt_modification_time.strftime("%a %d.%m.%y"),
        showarrow=False,
        xanchor="center"
    )