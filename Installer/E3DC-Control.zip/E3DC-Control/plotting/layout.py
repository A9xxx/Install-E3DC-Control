def apply_layout(fig, ld, wpmin, wpmax, tmin, tmax):
    """
    Wendet das komplette Layout für das Diagramm an.
    """

    fig.update_layout(
        modebar_remove=[
            'zoom', 'pan', 'zoomIn', 'zoomOut',
            'autoscale', 'select'
        ],

        paper_bgcolor='#242424',
        plot_bgcolor='#242424',
        font=dict(color='rgb(230,230,230)'),

        hovermode="x unified",
        hoverlabel=dict(
            bgcolor="#333333",
            font_size=12,
            font_color="white"
        ),

        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=-0.35,
            xanchor="center",
            x=0.5
        ),

        # ------------------------------------------------------------
        # X‑Achse
        # ------------------------------------------------------------
        xaxis=dict(
            type="category",
            tickmode="linear",
            dtick=8,
            ticklabelstandoff=3,
            showgrid=False,
            gridcolor='#444',
            linecolor='white'
        ),

        # ------------------------------------------------------------
        # Y‑Achsen
        # ------------------------------------------------------------

        # SoC
        yaxis=dict(
            visible=False,
            range=[0, 101],
            rangemode="tozero",
            ticksuffix=" %",
            side="right",
            showgrid=False
        ),

        # PV‑Ertrag
        yaxis2=dict(
            title="PV Ertrag",
            side="right",
            title_standoff=8,
            rangemode="tozero",
            showgrid=False,
            ticksuffix=' W'
        ),

        # Strompreis
        yaxis3=dict(
            title="Strompreis",
            anchor="free",
            overlaying="y",
            title_standoff=0,
            ticksuffix=" ct",
            showgrid=False,
            shift=-5
        ),

        # Wärmepumpe
        yaxis4=dict(
            overlaying="y",
            visible=False,
            range=[wpmin, wpmax],
            rangemode="tozero",
            showgrid=False,
            ticksuffix=' kW'
        ),

        # Temperatur
        yaxis5=dict(
            overlaying="y",
            visible=False,
            range=[tmin, tmax],
            rangemode="tozero",
            showgrid=False,
            ticksuffix=' °'
        ),

        # Wallbox‑Balken
        yaxis6=dict(
            overlaying="y",
            visible=False,
            range=[0, 2],
            showgrid=False
        )
    )