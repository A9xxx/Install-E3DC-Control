import plotly.graph_objects as go


# ------------------------------------------------------------
# SoC nach Simulation
# ------------------------------------------------------------
def add_soc_trace(fig, times, soc_values):
    fig.add_trace(
        go.Scatter(
            x=times,
            y=soc_values,
            name="SoC",
            marker_color="#9AC353",
            line=dict(width=3),
            fill="tozeroy",
            fillcolor="rgba(154,195,83,0.3)"
        )
    )
    fig.data[-1].showlegend = False


# ------------------------------------------------------------
# Wallbox-Balken (AUTO / MANUAL)
# ------------------------------------------------------------
def add_wallbox_bars(fig, times, times_dt, wb_times, color, name="WB"):
    # naive Zeitstempel für Matching
    times_dt_naive = [t.replace(tzinfo=None) for t in times_dt]

    for wb_time in wb_times:
        # Nächstgelegenen Index finden
        closest_index = min(
            range(len(times_dt_naive)),
            key=lambda i: abs((times_dt_naive[i] - wb_time).total_seconds())
        )

        delta = abs((times_dt_naive[closest_index] - wb_time).total_seconds())

        # Nur anzeigen, wenn innerhalb 15 Minuten
        if delta <= 900:
            fig.add_trace(
                go.Bar(
                    x=[times[closest_index]],
                    y=[1],
                    name=name,
                    marker_color=color,
                    width=0.5,
                    opacity=0.6,
                    showlegend=False,
                    yaxis="y6"
                )
            )


# ------------------------------------------------------------
# Temperatur
# ------------------------------------------------------------
def add_temperature_trace(fig, times, temperatur_values):
    fig.add_trace(
        go.Scatter(
            x=times,
            y=temperatur_values,
            name="AT",
            marker_color="#00FF7F",
            line=dict(width=3),
            opacity=0.8,
            yaxis="y5"
        )
    )


# ------------------------------------------------------------
# Wärmepumpe
# ------------------------------------------------------------
def add_wp_trace(fig, times, wp_values):
    fig.add_trace(
        go.Scatter(
            x=times,
            y=wp_values,
            name="WP",
            marker_color="#1E90FF",
            line=dict(width=3),
            opacity=0.8,
            yaxis="y4"
        )
    )


# ------------------------------------------------------------
# Strompreis
# ------------------------------------------------------------
def add_price_trace(fig, times, price_values):
    fig.add_trace(
        go.Scatter(
            x=times,
            y=price_values,
            name="Preis",
            mode="lines",
            line_shape="hv",
            line=dict(color="#BA55D3", width=3),
            opacity=0.6,
            yaxis="y3"
        )
    )


# ------------------------------------------------------------
# PV-Ertrag
# ------------------------------------------------------------
def add_pv_trace(fig, times, pv_values):
    fig.add_trace(
        go.Scatter(
            x=times,
            y=pv_values,
            name="PV",
            marker_color="rgba(255,194,56,1)",
            line=dict(width=3),
            line_shape="spline",
            yaxis="y2"
        )
    )