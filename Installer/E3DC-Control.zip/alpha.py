import socket
import struct
import json
import time

def fetch_bytes(sock, n):
    """Hilfsfunktion: Wartet geduldig, bis exakt n Bytes empfangen wurden."""
    data = b''
    while len(data) < n:
        try:
            packet = sock.recv(n - len(data))
            if not packet:
                return None
            data += packet
        except socket.timeout:
            continue
    return data

def get_luxtronik_data():
    host = '192.168.178.88'
    port = 8889
    
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(5.0)
    
    try:
        s.connect((host, port))
        time.sleep(0.5) # Kurze Gedenksekunde für die Luxtronik
        
        # Befehl 3004 senden
        s.sendall(struct.pack('>II', 3004, 0))
        
        # Header (12 Bytes) sicher lesen
        header_raw = fetch_bytes(s, 12)
        if not header_raw:
            return {"Fehler": "Keine Antwort vom Header erhalten"}
            
        echo, status, count = struct.unpack('>III', header_raw)
        
        # Alle Werte (count * 4 Bytes) sicher lesen
        expected_size = count * 4
        raw_values = fetch_bytes(s, expected_size)
        if not raw_values:
            return {"Fehler": "Datenbereich unvollständig"}
        
        s.close()

        # In Liste umwandeln
        v = [struct.unpack('>i', raw_values[i:i+4])[0] for i in range(0, len(raw_values), 4)]
        
        # Dein exaktes Mapping aus dem erfolgreichen Scan
        output = {
            "Vorlauf": v[10] / 10,
            "Ruecklauf": v[11] / 10,
            "Rueckl_Soll": v[12] / 10,
            "Heissgas": v[14] / 10,
            "Aussentemp": v[15] / 10,
            "Mitteltemp": v[16] / 10,
            "Warmwasser_Ist": v[17] / 10,
            "Warmwasser_Soll": v[18] / 10,
            "Waermequelle_Ein": v[19] / 10,
            "Waermequelle_Aus": v[20] / 10,
            "Betriebsstunden_VD1": round(v[56] / 3600, 1), # Sek -> Std (aus deinem Scan: 9329h)
            "Impulse_VD1": v[57],
            "Waermemenge_Heizung_kWh": v[151] / 10,
            "Waermemenge_WW_kWh": v[152] / 10,
            "Waermemenge_Gesamt_kWh": round((v[151] + v[152]) / 10, 1),
            "Status_Code": v[80],
            "Status_Text": "Keine Anforderung" if v[80] == 5 else "Aktiv",
            "Zeitstempel": time.strftime("%d.%m.%Y %H:%M:%S")
        }
        return output

    except Exception as e:
        return {"Fehler": str(e)}
    finally:
        try: s.close()
        except: pass

# --- Start ---
result = get_luxtronik_data()

# JSON speichern
with open('waermepumpe.json', 'w') as f:
    json.dump(result, f, indent=4)

if "Fehler" in result:
    print(f"Abbruch: {result['Fehler']}")
else:
    print("ERFOLG! Daten in waermepumpe.json gespeichert.")
    print(json.dumps(result, indent=4))