import socket
import struct
import time

def get_3004_live():
    host = '192.168.178.88'
    port = 8889
    
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(10)
        print(f"Verbinde mit {host} auf Port {port}...")
        s.connect((host, port))
        
        # Befehl 3004 senden
        print("Sende Befehl 3004...")
        s.sendall(struct.pack('>II', 3004, 0))
        
        # Header lesen (12 Bytes)
        header = b""
        while len(header) < 12:
            chunk = s.recv(12 - len(header))
            if not chunk: break
            header += chunk
            
        if len(header) < 12:
            print("Fehler: Luxtronik antwortet nicht.")
            return

        echo, status, count = struct.unpack('>III', header)
        print(f"Erfolg! Empfange {count} Werte.\n")

        # Werte einzeln lesen und sofort ausgeben
        for i in range(count):
            val_raw = b""
            while len(val_raw) < 4:
                chunk = s.recv(4 - len(val_raw))
                if not chunk: break
                val_raw += chunk
            
            if len(val_raw) == 4:
                value = struct.unpack('>i', val_raw)[0]
                # Wir geben den Index und den Wert aus
                print(f"Index {i:3}: {value}")
        
        s.close()
        print("\n--- Scan beendet ---")

    except Exception as e:
        print(f"Fehler: {e}")

if __name__ == "__main__":
    get_3004_live()