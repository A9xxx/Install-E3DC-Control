import socket
import struct
import time

def debug_read(host, addr, count=1, func=4):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2)
        s.connect((host, 502))
        # MBAP + PDU
        req = struct.pack('>HHHBBHH', 1, 0, 6, 1, func, addr, count)
        s.sendall(req)
        resp = s.recv(12) # Header + Daten
        s.close()
        if len(resp) >= 9 + (count*2):
            data = resp[9:]
            return struct.unpack('>' + 'H' * count, data)
    except:
        return None
    return None

host = '192.168.178.88'
print(f"--- Modbus Deep Scan ({host}) ---")

# Wir scannen die Energie-Register (10310 - 10325)
print("\nEnergie-Register (Rohwerte):")
for a in range(10310, 10325):
    val = debug_read(host, a)
    print(f"Register {a}: {val[0] if val else 'Timeout'}")
    time.sleep(0.2) # Wichtig für die Luxtronik!