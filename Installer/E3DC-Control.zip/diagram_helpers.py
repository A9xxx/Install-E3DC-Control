#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E3DC-Control - Diagramm-Generator Hilfsfunktionen
"""

import os
import sys
import json
import logging
import pwd
import grp
from datetime import datetime, timedelta, timezone
from pathlib import Path

WEB_ROOT = "/var/www/html"

# ============================================================
# PERMISSION HELPER
# ============================================================

def get_web_file_owner():
    """Ermittelt UID des install_user und GID von www-data dynamisch."""
    try:
        install_user = None

        # Bevorzugt: installer Web-Config
        config_path = os.path.join(WEB_ROOT, "e3dc_paths.json")
        if os.path.isfile(config_path):
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    web_cfg = json.load(f)
                install_user = web_cfg.get("install_user")
            except Exception:
                pass

        # Fallback 1: Aus Pfad /home/<user>/E3DC-Control ableiten
        if not install_user:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            parts = script_dir.split(os.sep)
            if len(parts) >= 3 and parts[1] == "home":
                install_user = parts[2]

        # Fallback 2: Umgebungsvariablen
        if not install_user:
            env_user = os.environ.get("SUDO_USER") or os.environ.get("USER")
            if env_user and env_user != "root":
                install_user = env_user

        if not install_user:
            install_user = pwd.getpwuid(os.getuid()).pw_name

        install_uid = pwd.getpwnam(install_user).pw_uid
        www_data_gid = grp.getgrnam("www-data").gr_gid
        return install_uid, www_data_gid
    except (KeyError, OSError):
        # Fallback zu Standard-IDs
        return 1000, 33

def set_web_file_permissions(path, mode=0o664):
    """
    Setzt Permissions für Web-Dateien (install_user:www-data).
    
    Args:
        path: Dateipath
        mode: Oktalzahl für Permissions (Standard: 664 für Dateien, 775 für Dirs)
    """
    try:
        if os.path.exists(path):
            install_uid, www_data_gid = get_web_file_owner()
            os.chown(path, install_uid, www_data_gid)
            os.chmod(path, mode)
    except Exception:
        # Fallback: nur chmod versuchen
        try:
            os.chmod(path, mode)
        except:
            pass

def set_web_directory_permissions(dirpath, mode=0o775):
    """
    Setzt Permissions für Web-Verzeichnisse (install_user:www-data 775).
    
    Args:
        dirpath: Verzeichnispath
        mode: Oktalzahl für Permissions (Standard: 775)
    """
    try:
        if os.path.exists(dirpath):
            install_uid, www_data_gid = get_web_file_owner()
            os.chown(dirpath, install_uid, www_data_gid)
            os.chmod(dirpath, mode)
    except Exception:
        try:
            os.chmod(dirpath, mode)
        except:
            pass

# ============================================================
# LOGGING HELPER
# ============================================================

def get_or_create_logger(name, log_file=None):
    """
    Erstellt oder holt Logger mit separater Datei und Formatter.
    
    Args:
        name: Logger-Name (z.B. "diagram")
        log_file: Optional, absoluter Pfad zur Log-Datei
    
    Returns:
        Logger-Instanz mit propagate=False (keine Doppel-Logs!)
    """
    logger = logging.getLogger(name)
    
    if not logger.handlers:
        if log_file:
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
            handler = logging.FileHandler(log_file, encoding='utf-8')
            formatter = logging.Formatter('%(asctime)s - [%(levelname)s] - %(message)s')
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            
            # Setze Ownership auf Install-User
            set_web_file_permissions(log_file)
        
        logger.setLevel(logging.INFO)
        logger.propagate = False
    
    return logger

# ============================================================
# CONFIG HELPER
# ============================================================

def load_config():
    """Lädt Config aus config.json und e3dc.config.txt"""
    def _parse_numeric(value):
        """Konvertiert Konfig-Werte robust nach float/int (inkl. deutschem Komma)."""
        if isinstance(value, (int, float)):
            return value
        if not isinstance(value, str):
            return value

        cleaned = value.strip().strip('"').strip("'")
        if not cleaned:
            return value

        normalized = cleaned.replace(',', '.')

        try:
            if any(ch in normalized for ch in ['.', 'e', 'E']):
                return float(normalized)
            return int(normalized)
        except Exception:
            return value

    config = {
        'awmwst': 19.0,
        'awnebenkosten': 0.0,
        'speichergroesse': 13.5,
        'cver': 'E3DC v?.?.?',
        'enable_heatpump': True,
        'darkmode': True,
    }
    
    # config.json
    json_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
    if os.path.isfile(json_path):
        try:
            with open(json_path, "r", encoding='utf-8') as f:
                config.update(json.load(f))
        except:
            pass
    
    # e3dc.config.txt
    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "e3dc.config.txt")
    if os.path.isfile(config_path):
        try:
            with open(config_path, "r", encoding='utf-8') as f:
                for line in f:
                    if '=' in line:
                        parts = line.split('=')
                        if len(parts) == 2:
                            key = parts[0].strip().lower()
                            value_str = parts[1].strip()
                            config[key] = _parse_numeric(value_str)
                            if key == 'darkmode':
                                config['darkmode'] = (value_str.lower() in ['1', 'true', 'on'])
        except:
            pass
    
    # E3DC_CONF.h (Versionsnummer)
    header_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "E3DC_CONF.h")
    if os.path.isfile(header_path):
        try:
            with open(header_path, "r", encoding='utf-8') as f:
                for line in f:
                    if "VERSION" in line or "version" in line:
                        parts = line.split()
                        if len(parts) >= 3:
                            config['cver'] = parts[2].strip().replace('"', '')
                        break
        except:
            pass

    # Numerische Kernwerte immer robust in float/int normalisieren
    for num_key, default_value in {
        'awmwst': 19.0,
        'awnebenkosten': 0.0,
        'speichergroesse': 13.5,
    }.items():
        parsed = _parse_numeric(config.get(num_key, default_value))
        if isinstance(parsed, (int, float)):
            config[num_key] = float(parsed)
        else:
            config[num_key] = float(default_value)
    
    return config

