<?php
$config_file_path = '/home/pi/E3DC-Control/e3dc.config.txt';
$message = ''; // Nachricht für Erfolg oder Fehler

// Funktion zum Lesen der Konfigurationsdatei, nur Wbhour verarbeiten
function readConfig($file_path) {
    if (!file_exists($file_path)) {
        return ['error' => 'Die Konfigurationsdatei existiert nicht.'];
    }

    $lines = file($file_path, FILE_IGNORE_NEW_LINES);
    $config = [];

    foreach ($lines as $line) {
        if (strpos($line, 'Wbhour') !== false) {
            list($key, $value) = explode('=', $line, 2) + [null, null];
            $key = trim($key);
            $value = trim($value);
            if ($key === 'Wbhour') {
                $config[$key] = $value;
            }
        }
    }

    if (empty($config)) {
        return ['error' => 'Wbhour nicht in der Konfigurationsdatei gefunden.'];
    }

    return $config;
}

// Funktion zum Schreiben der Konfigurationsdatei, nur Wbhour schreiben
function writeConfig($file_path, $config) {
    $lines = file($file_path, FILE_IGNORE_NEW_LINES);
    $new_lines = [];

    foreach ($lines as $line) {
        if (strpos($line, 'Wbhour') !== false) {
            $new_lines[] = "Wbhour = " . $config['Wbhour'];
        } else {
            $new_lines[] = $line;
        }
    }

    file_put_contents($file_path, implode("\n", $new_lines));
}

$config = readConfig($config_file_path);

if (isset($config['error'])) {
    $message = "<span style='color:red;'>Fehler: " . htmlspecialchars($config['error']) . "</span>";
    $config = [];
}

// Wenn das Formular gesendet wird
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['Wbhour'])) {
        $config['Wbhour'] = $_POST['Wbhour'];
        writeConfig($config_file_path, $config);
        $message = "<span style='color:green;'>✅ Wert wurde erfolgreich gespeichert!</span>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Einstellungen für Birgit</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #242424;
            color: #fff;
        }
        .container {
            width: 60%;
            margin: auto;
            background-color: #242424;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #005b8e;
        }
        label {
            display: block;
            margin-top: 10px;
            color: #fff;
        }
        input[type='text'] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .button, .link-button {
            padding: 10px 20px;
            background-color: #0073e6;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }
        .button:hover, .link-button:hover {
            background-color: #005b8e;
        }
        .message-box {
            margin-top: 15px;
            padding: 10px;
            background-color: #e8f5e9;
            border-left: 5px solid #4caf50;
            color: #2e7d32;
            font-weight: bold;
            display: inline-block;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Einstellungen für Birgit</h1>

        <!-- Nachricht anzeigen -->
        <?php if (!empty($message)): ?>
            <div class="message-box"><?php echo $message; ?></div>
        <?php endif; ?>

        <form method="POST">
            <?php if (!empty($config)): ?>
                <div class="config-item">
                    <label for="Wbhour">Wbhour</label>
                    <input type="text" id="Wbhour" name="Wbhour" value="<?php echo htmlspecialchars($config['Wbhour']); ?>">
                </div>
                <input type="submit" class="button" value="Speichern">
            <?php else: ?>
                <p style="color: red;">Es konnte keine gültige Konfiguration geladen werden. Bitte überprüfen Sie die Datei.</p>
            <?php endif; ?>
            <a href="diagramm.html" class="link-button">Diagramm anzeigen</a>
        </form>
    </div>
</body>
</html>
