<?php
/* =====================================================================
   E3DC-Control - Wallbox.php (Hauptseite: Direkt + Automatik)
   ===================================================================== */

$paths = getInstallPaths();
$install_user = $paths['install_user'];
$base_path = rtrim($paths['install_path'], '/') . '/';

$wallbox_file = null;
$fallback_wallbox_file = 'e3dc.wallbox.txt';
if (file_exists($base_path . 'e3dc.wallbox.txt')) {
    $wallbox_file = $base_path . 'e3dc.wallbox.txt';
} elseif (file_exists($fallback_wallbox_file)) {
    $wallbox_file = $fallback_wallbox_file;
} else {
    $wallbox_file = $base_path . 'e3dc.wallbox.txt';
}

$config_file = $base_path . 'e3dc.config.txt';

$message = '';
$alleZeilen = [];
$zeile = '1';

function parseWallboxConfigValues($filePath) {
    $result = [
        'wbhour' => '1',
        'wbvon' => '00:00',
        'wbbis' => '23:59'
    ];

    if (!is_file($filePath) || !is_readable($filePath)) {
        return $result;
    }

    $lines = file($filePath, FILE_IGNORE_NEW_LINES);
    foreach ($lines as $line) {
        if (preg_match('/^\s*([a-z0-9_]+)\s*=\s*(.*?)\s*$/i', $line, $m)) {
            $key = strtolower(trim($m[1]));
            $value = trim($m[2]);
            if (array_key_exists($key, $result)) {
                $result[$key] = $value;
            }
        }
    }

    return $result;
}

function upsertWallboxConfigValues($filePath, $updates) {
    $lines = is_file($filePath) ? file($filePath, FILE_IGNORE_NEW_LINES) : [];
    if ($lines === false) {
        return false;
    }

    $found = [];
    foreach ($updates as $key => $_) {
        $found[$key] = false;
    }

    $newLines = [];
    foreach ($lines as $line) {
        if (preg_match('/^\s*([a-z0-9_]+)\s*=\s*(.*?)\s*$/i', $line, $m)) {
            $existingKey = trim($m[1]);
            $existingLower = strtolower($existingKey);
            if (array_key_exists($existingLower, $updates)) {
                $newLines[] = $existingKey . ' = ' . $updates[$existingLower];
                $found[$existingLower] = true;
                continue;
            }
        }
        $newLines[] = $line;
    }

    $canonical = [
        'wbhour' => 'Wbhour',
        'wbvon' => 'Wbvon',
        'wbbis' => 'Wbbis'
    ];

    foreach ($updates as $key => $value) {
        if (!$found[$key]) {
            $newLines[] = $canonical[$key] . ' = ' . $value;
        }
    }

    return @file_put_contents($filePath, implode("\n", $newLines), LOCK_EX) !== false;
}

function parseTimeToMinutes($value) {
    $value = trim((string)$value);
    if (!preg_match('/^(\d{1,2})(?::(\d{1,2}))?$/', $value, $m)) {
        return false;
    }

    $hour = (int)$m[1];
    $minute = isset($m[2]) ? (int)$m[2] : 0;

    if ($hour < 0 || $hour > 23 || $minute < 0 || $minute > 59) {
        return false;
    }

    return $hour * 60 + $minute;
}

function normalizeTime($value) {
    $minutes = parseTimeToMinutes($value);
    if ($minutes === false) {
        return false;
    }

    $hour = floor($minutes / 60);
    $minute = $minutes % 60;
    return sprintf('%02d:%02d', $hour, $minute);
}

function normalizeFullHourTime($value) {
    $normalized = normalizeTime($value);
    if ($normalized === false) {
        return false;
    }

    if (substr($normalized, -2) !== '00') {
        return false;
    }

    return $normalized;
}

function normalizeHourInput($value) {
    $value = trim((string)$value);
    if ($value === '') {
        return false;
    }

    if (preg_match('/^\d{1,2}$/', $value)) {
        $hour = (int)$value;
        if ($hour < 0 || $hour > 23) {
            return false;
        }
        return sprintf('%02d:00', $hour);
    }

    return normalizeFullHourTime($value);
}

function wallboxFileHasAutomaticEntries($filePath) {
    if (!is_file($filePath) || !is_readable($filePath)) {
        return false;
    }

    $lines = file($filePath, FILE_IGNORE_NEW_LINES);
    if (!is_array($lines)) {
        return false;
    }

    foreach ($lines as $line) {
        if (preg_match('/automatik/i', (string)$line)) {
            return true;
        }
    }

    return false;
}

function wallboxFileHasAutomaticEntriesFromPreviousDay($filePath) {
    if (!is_file($filePath) || !is_readable($filePath)) {
        return false;
    }

    $lines = file($filePath, FILE_IGNORE_NEW_LINES);
    if (!is_array($lines)) {
        return false;
    }

    $inAutomaticBlock = false;
    $todayLabel = date('j.n.');

    foreach ($lines as $lineRaw) {
        $line = trim((string)$lineRaw);
        if ($line === '') {
            continue;
        }

        if (preg_match('/automatik/i', $line)) {
            $inAutomaticBlock = true;
            continue;
        }

        if ($inAutomaticBlock && preg_match('/^am\s+(\d{1,2})\.(\d{1,2})\.?/iu', $line, $m)) {
            $label = ((int)$m[1]) . '.' . ((int)$m[2]) . '.';
            if ($label !== $todayLabel) {
                return true;
            }
        }
    }

    return false;
}

$wallboxConfig = parseWallboxConfigValues($config_file);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $quickAction = null;
    if (isset($_POST['quick_action'])) {
        $quickAction = $_POST['quick_action'];
        if ($quickAction === 'start_now') {
            $_POST['zwei'] = '99';
        } elseif ($quickAction === 'clear_times') {
            $_POST['zwei'] = '0';
        }
    }

    if (isset($_POST['zwei'])) {
        $neueDauer = trim((string)$_POST['zwei']);
        $neueDauerInt = (int)$neueDauer;

        if (!is_numeric($neueDauer) || $neueDauerInt < 0 || ($neueDauerInt > 24 && $neueDauerInt < 99) || $neueDauerInt > 99) {
            $message = errorMessage('Ungültige Eingabe', 'Die Ladedauer muss zwischen 0 und 24 Stunden oder 99 = unbegrenzt liegen.');
        } else {
            $oldUmask = umask(0002);
            $writeResult = @file_put_contents($wallbox_file, $neueDauerInt . PHP_EOL, LOCK_EX);
            umask($oldUmask);

            if ($writeResult !== false) {
                $message = successMessage('✓ Wallbox-Ladedauer gespeichert.');
                usleep(500000);

                if ($quickAction === 'clear_times') {
                    $maxPolls = 6;
                    for ($poll = 0; $poll < $maxPolls; $poll++) {
                        if (is_file($wallbox_file) && is_readable($wallbox_file)) {
                            $tmpLines = file($wallbox_file, FILE_IGNORE_NEW_LINES);
                            if (is_array($tmpLines) && count($tmpLines) > 1) {
                                break;
                            }
                        }
                        usleep(350000);
                    }
                }
            } else {
                $message = errorMessage(
                    'Datei-Zugriff verweigert',
                    'Datei: <code>' . htmlspecialchars($wallbox_file) . '</code><br>' .
                    'Bitte Berechtigungen prüfen, z. B.:<br>' .
                    '<code>sudo chown ' . htmlspecialchars($install_user) . ':www-data ' . htmlspecialchars($wallbox_file) . '</code><br>' .
                    '<code>sudo chmod 664 ' . htmlspecialchars($wallbox_file) . '</code>'
                );
            }
        }
    }

    if (isset($_POST['save_auto_settings'])) {
        $previousConfig = parseWallboxConfigValues($config_file);
        $postedWbhour = trim((string)($_POST['Wbhour'] ?? ''));
        $postedWbvon = trim((string)($_POST['Wbvon'] ?? ''));
        $postedWbbis = trim((string)($_POST['Wbbis'] ?? ''));
        $adjustWbvon = isset($_POST['adjust_wbvon']) && $_POST['adjust_wbvon'] === '1';

        $wallboxConfig['wbhour'] = $postedWbhour;
        $wallboxConfig['wbvon'] = $postedWbvon;
        $wallboxConfig['wbbis'] = $postedWbbis;

        if (!is_numeric($postedWbhour) || (int)$postedWbhour < 0) {
            $message = errorMessage('Ungültige Eingabe', 'Wbhour muss ein numerischer Wert >= 0 sein.');
        } else {
            $wbvonNorm = normalizeHourInput($postedWbvon);
            $wbbisNorm = normalizeHourInput($postedWbbis);

            if ($wbvonNorm === false || $wbbisNorm === false) {
                $message = errorMessage('Ungültige Zeit', 'Wbvon und Wbbis müssen als ganze Stunden 0-23 eingegeben werden (z. B. 6 oder 22).');
            } else {
                $nowMinutes = (int)date('G') * 60 + (int)date('i');
                $wbvonMinutes = parseTimeToMinutes($wbvonNorm);

                if ($wbvonMinutes !== false && $nowMinutes > $wbvonMinutes && !$adjustWbvon) {
                    $message = errorMessage(
                        'Abfrage Wbvon',
                        'Die aktuelle Zeit liegt nach Wbvon (<code>' . htmlspecialchars($wbvonNorm) . '</code>). ' .
                        'Bitte bestätigen Sie im Formular „Wbvon auf aktuelle Zeit setzen“, falls Wbvon angepasst werden soll.'
                    );
                    $wallboxConfig['wbvon'] = $wbvonNorm;
                    $wallboxConfig['wbbis'] = $wbbisNorm;
                } else {
                    if ($adjustWbvon && $nowMinutes > $wbvonMinutes) {
                        $nextHourTs = strtotime(date('Y-m-d H:00:00')) + 3600;
                        $wbvonNorm = date('H:00', $nextHourTs);
                    }

                    $updates = [
                        'wbhour' => (string)(int)$postedWbhour,
                        'wbvon' => $wbvonNorm,
                        'wbbis' => $wbbisNorm
                    ];

                    $previousWbvon = normalizeHourInput($previousConfig['wbvon']);
                    $previousWbbis = normalizeHourInput($previousConfig['wbbis']);
                    $isTimeChange = ($previousWbvon !== false && $previousWbbis !== false)
                        ? ($previousWbvon !== $wbvonNorm || $previousWbbis !== $wbbisNorm)
                        : true;

                    $hasAutoEntries = wallboxFileHasAutomaticEntries($wallbox_file);
                    $hasPreviousDayAutoEntries = wallboxFileHasAutomaticEntriesFromPreviousDay($wallbox_file);
                    $newWbhourValue = (int)$postedWbhour;
                    $needsSafetyReset = $newWbhourValue > 0 && ($hasPreviousDayAutoEntries || ($hasAutoEntries && $isTimeChange));
                    $canWriteAutoSettings = true;

                    if ($needsSafetyReset) {
                        $resetResult = upsertWallboxConfigValues($config_file, ['wbhour' => '0']);
                        if (!$resetResult) {
                            $message = errorMessage(
                                'Sicherheits-Reset fehlgeschlagen',
                                'Wbhour konnte nicht vorab auf 0 gesetzt werden. Bitte Dateiberechtigungen prüfen.'
                            );
                            $wallboxConfig = parseWallboxConfigValues($config_file);
                            $canWriteAutoSettings = false;
                        } else {
                            sleep(5);
                        }
                    }

                    if ($canWriteAutoSettings) {
                        $writeResult = upsertWallboxConfigValues($config_file, $updates);
                        if ($writeResult) {
                            if ($needsSafetyReset) {
                                $message = successMessage('✓ Automatik-Einstellungen gespeichert (Sicherheits-Reset 5s mit Wbhour=0 durchgeführt).');
                            } else {
                                $message = successMessage('✓ Automatik-Einstellungen gespeichert.');
                            }
                            $wallboxConfig = parseWallboxConfigValues($config_file);
                        } else {
                            $message = errorMessage(
                                'Schreibberechtigung fehlt',
                                'Datei: <code>' . htmlspecialchars($config_file) . '</code><br>' .
                                'Bitte Berechtigungen prüfen, z. B.:<br>' .
                                '<code>sudo chown ' . htmlspecialchars($install_user) . ':www-data ' . htmlspecialchars($config_file) . '</code><br>' .
                                '<code>sudo chmod 664 ' . htmlspecialchars($config_file) . '</code>'
                            );
                        }
                    }
                }
            }
        }
    }
}

if (file_exists($wallbox_file)) {
    $readCheck = checkFileAccess($wallbox_file, 'read');
    if ($readCheck === true) {
        $alleZeilen = file($wallbox_file, FILE_IGNORE_NEW_LINES);
    }
}

if (count($alleZeilen) > 0) {
    $zeile = $alleZeilen[0];
}

$formAction = getContextPageUrl('wallbox');
$nowMinutes = (int)date('G') * 60 + (int)date('i');
$currentWbvonMinutes = parseTimeToMinutes($wallboxConfig['wbvon']);
$showWbvonHint = $currentWbvonMinutes !== false && $nowMinutes > $currentWbvonMinutes;

$wbvonDisplayHour = ($currentWbvonMinutes !== false) ? (string)floor($currentWbvonMinutes / 60) : preg_replace('/[^0-9]/', '', (string)$wallboxConfig['wbvon']);
$wbbisMinutes = parseTimeToMinutes($wallboxConfig['wbbis']);
$wbbisDisplayHour = ($wbbisMinutes !== false) ? (string)floor($wbbisMinutes / 60) : preg_replace('/[^0-9]/', '', (string)$wallboxConfig['wbbis']);
?>

<h1>Wallbox Steuerung</h1>

<?php if (!empty($message)): ?>
    <?= $message ?>
<?php endif; ?>

<div class="config-box">
    <h2>Geplante Ladezeiten</h2>
    <?php
    $plannedEntries = [];
    $planSource = 'Unbekannt';
    $currentDateLabel = '';
    $currentSourceCode = 'D';

    if (count($alleZeilen) > 1) {
        for ($i = 1; $i < count($alleZeilen); $i++) {
            $line = trim($alleZeilen[$i]);
            if ($line === '') {
                continue;
            }

            if (preg_match('/automatik/i', $line)) {
                $planSource = 'Ladezeitenautomatik';
                $currentSourceCode = 'A';
                continue;
            }

            if (preg_match('/manuell|direkt/i', $line)) {
                $planSource = 'Direkte Steuerung';
                $currentSourceCode = 'D';
                continue;
            }

            if (preg_match('/^am\s+(.+)$/iu', $line, $dateMatch)) {
                $currentDateLabel = trim($dateMatch[1]);
                continue;
            }

            if (preg_match('/^um\s+(\d{1,2}):\s*(\d{1,2})\s+zu\s+(.+)$/iu', $line, $timeMatch)) {
                $plannedEntries[] = [
                    'time' => sprintf('%02d:%02d', (int)$timeMatch[1], (int)$timeMatch[2]),
                    'price' => trim($timeMatch[3]),
                    'date' => ($currentDateLabel !== '' ? $currentDateLabel : 'ohne Datum'),
                    'source' => $currentSourceCode
                ];
            }
        }
    }

    $groupedEntries = [];
    foreach ($plannedEntries as $entry) {
        $dateKey = $entry['date'];
        if (!isset($groupedEntries[$dateKey])) {
            $groupedEntries[$dateKey] = [];
        }
        $groupedEntries[$dateKey][] = $entry;
    }

    $dateSortKey = function($dateLabel) {
        if (preg_match('/(\d{1,2})\.(\d{1,2})\.?/', $dateLabel, $m)) {
            $day = (int)$m[1];
            $month = (int)$m[2];
            return sprintf('%02d-%02d', $month, $day);
        }
        return '99-99';
    };

    if (count($groupedEntries) > 1) {
        uksort($groupedEntries, function($a, $b) use ($dateSortKey) {
            return strcmp($dateSortKey($a), $dateSortKey($b));
        });
    }

    foreach ($groupedEntries as $dateKey => $entriesByDate) {
        usort($entriesByDate, function($left, $right) {
            return strcmp($left['time'], $right['time']);
        });
        $groupedEntries[$dateKey] = $entriesByDate;
    }

    $formatMinutes = function($minutes) {
        $hours = intdiv($minutes, 60);
        $rest = $minutes % 60;
        if ($hours > 0 && $rest > 0) {
            return $hours . 'h ' . $rest . 'min';
        }
        if ($hours > 0) {
            return $hours . 'h';
        }
        return $rest . 'min';
    };

    $totalPlannedMinutes = count($plannedEntries) * 15;

    $sourceCodes = [];
    foreach ($plannedEntries as $entry) {
        $sourceCodes[$entry['source']] = true;
    }
    $sourceCodeList = implode('/', array_keys($sourceCodes));
    if ($sourceCodeList === 'A') {
        $planSource = 'Ladezeitenautomatik';
    } elseif ($sourceCodeList === 'D') {
        $planSource = 'Direkte Steuerung';
    } elseif ($sourceCodeList !== '') {
        $planSource = 'Gemischt';
    }
    ?>
    <?php if (count($plannedEntries) > 0): ?>
        <?php
        $plannedCount = count($plannedEntries);
        $hoursText = $formatMinutes($totalPlannedMinutes);
        ?>
        <details class="wallbox-times-dropdown">
            <summary>
                <?= $plannedCount ?> Ladezeit<?= ($plannedCount === 1 ? '' : 'en') ?> geplant (gesamt <?= htmlspecialchars($hoursText) ?>)
            </summary>
            <p style="margin:8px 0 0 0; color:#aaa; font-size:0.9em;">
                Quelle: <?= htmlspecialchars($planSource) ?><?= ($sourceCodeList !== '' ? ' [' . htmlspecialchars($sourceCodeList) . ']' : '') ?>
            </p>
            <p style="margin:4px 0 0 0; color:#aaa; font-size:0.9em;">
                Legende: D = Direktsteuerung, A = Ladezeitenautomatik
            </p>
            <ul>
                <?php foreach ($groupedEntries as $date => $entriesByDate): ?>
                    <li>
                        <strong>am <?= htmlspecialchars($date) ?></strong>
                        <ul class="wallbox-times-sublist">
                            <?php foreach ($entriesByDate as $entry): ?>
                                <li>
                                    [<?= htmlspecialchars($entry['source']) ?>]
                                    um <?= htmlspecialchars($entry['time']) ?>
                                    zu <?= htmlspecialchars($entry['price']) ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </li>
                <?php endforeach; ?>
            </ul>
        </details>
    <?php else: ?>
        <p>Keine geplanten Ladezeiten vorhanden.</p>
    <?php endif; ?>
</div>

<div class="config-box" style="margin-top: 25px;">
    <h2>Direktsteuerung</h2>

    <?php
    if ($zeile < '1') {
        echo '<p>Es wurden keine direkten Ladezeiten geplant.</p>';
    } elseif ($zeile < '2') {
        echo '<p>Die geplante Ladedauer beträgt <strong>eine Stunde</strong>.</p>';
    } else {
        echo '<p>Die geplante Ladedauer beträgt <strong>' . htmlspecialchars($zeile) . ' Stunden</strong>.</p>';
    }
    ?>

    <form action="<?= htmlspecialchars($formAction) ?>" method="post" style="margin-top: 20px;">
        <div class="config-item">
            <label for="zwei">Ladedauer über gesamten Preisbereich (Stunden)</label>
            <input type="number" id="zwei" name="zwei"
                   value="<?= htmlspecialchars($zeile) ?>"
                   min="0" max="99" step="1"
                   title="0-24 oder 99 (unbegrenzt)">
            <p style="font-size: 0.85em; color: #aaa; margin-top: 8px;">
                99 = Laden sofort starten, 0 = Ladezeiten löschen.
            </p>
        </div>

        <div class="wallbox-actions-row">
            <button type="submit" class="form-button">✓ Speichern</button>
            <button type="submit" name="quick_action" value="start_now" class="form-button">⚡ Sofort (99)</button>
            <button type="submit" name="quick_action" value="clear_times" class="form-button">🗑 Löschen (0)</button>
        </div>
    </form>
</div>

<div class="config-box" style="margin-top: 25px;">
    <h2>Automatik (Wbhour / Wbvon / Wbbis)</h2>

    <form action="<?= htmlspecialchars($formAction) ?>" method="post" style="margin-top: 12px;">
        <div class="config-item">
            <label for="Wbhour">Wbhour (Ladedauer im Zeitfenster)</label>
            <input type="number" id="Wbhour" name="Wbhour"
                   value="<?= htmlspecialchars($wallboxConfig['wbhour']) ?>"
                   min="0" step="1">
        </div>

        <div class="config-item">
            <label for="Wbvon">Wbvon (Startzeit)</label>
             <input type="number" id="Wbvon" name="Wbvon"
                 value="<?= htmlspecialchars($wbvonDisplayHour) ?>"
                 min="0" max="23" step="1" title="Nur ganze Stunden 0-23">
        </div>

        <div class="config-item">
            <label for="Wbbis">Wbbis (Endzeit)</label>
             <input type="number" id="Wbbis" name="Wbbis"
                 value="<?= htmlspecialchars($wbbisDisplayHour) ?>"
                 min="0" max="23" step="1" title="Nur ganze Stunden 0-23">
        </div>

        <div class="config-item" style="padding:12px 15px;">
            <label style="display:flex; align-items:center; gap:8px; margin:0;">
                <input type="checkbox" name="adjust_wbvon" value="1" style="width:auto; margin:0;">
                Wbvon bei Speicherung auf nächste volle Stunde setzen, falls aktuelle Zeit bereits nach Wbvon liegt
            </label>
            <?php if ($showWbvonHint): ?>
                <p style="font-size:0.85em; color:#fbbf24; margin:10px 0 0 0;">
                    Hinweis: Aktuell ist es bereits nach Wbvon (<?= htmlspecialchars($wallboxConfig['wbvon']) ?>).
                </p>
            <?php endif; ?>
        </div>

        <button type="submit" name="save_auto_settings" value="1" class="form-button">✓ Automatik speichern</button>
    </form>
</div>

<style>
    .wallbox-times-dropdown {
        margin-top: 10px;
        background: #333333;
        border-radius: 6px;
        padding: 12px 14px;
    }

    .wallbox-times-dropdown summary {
        cursor: pointer;
        color: #87ceeb;
        font-weight: 600;
    }

    .wallbox-times-dropdown ul {
        margin-top: 8px;
        margin-bottom: 0;
        padding-left: 18px;
    }

    .wallbox-times-sublist {
        margin-top: 6px;
        margin-bottom: 6px;
        padding-left: 18px;
    }

    .wallbox-actions-row {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .config-item label {
        display: block;
        margin-top: 0;
        font-size: 1.05em;
        font-weight: 500;
    }

    .config-item input[type="number"],
    .config-item input[type="text"] {
        margin-top: 8px;
        max-width: 260px;
    }

    .form-button {
        width: auto;
    }
</style>
