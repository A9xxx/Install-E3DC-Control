<?php
/* =====================================================================
   E3DC-Control - Wallbox.php (Überarbeitete Version)
   
   - helpers.php für Fehlerbehandlung genutzt
   - Konsistente Dark-Mode Farbgebung
   - Bessere Input-Validierung
   ===================================================================== */

// Dateipfade
$datei = null;
$base_path = '/home/pi/E3DC-Control/';
$fallback_path = 'e3dc.wallbox.txt';
$message = '';
$read_error = false;

// Prüfe beide Pfade
if (file_exists($fallback_path)) {
    $datei = $fallback_path;
} elseif (file_exists($base_path . 'e3dc.wallbox.txt')) {
    $datei = $base_path . 'e3dc.wallbox.txt';
} else {
    // Fallback: versuche zu erstellen
    $datei = $fallback_path;
    if (!is_writable(dirname($datei))) {
        $parent_writable = is_writable(dirname($datei));
        
        echo "<div style='background: #1e1e1e; border: 1px solid #555; border-radius: 6px; padding: 20px; margin: 20px; color: #fff; max-width: 900px;'>";
        echo "<div style='padding: 15px; background: #3d1f1f; border-left: 4px solid #f44336; border-radius: 4px; margin-bottom: 20px;'>";
        echo "<strong style='color: #f44336; font-size: 18px;'>⚠ Schreibberechtigung fehlt</strong><br>";
        echo "Datei: <strong>" . htmlspecialchars($datei) . "</strong><br>";
        echo "Eltern-Verzeichnis schreibbar: " . ($parent_writable ? "<span style='color: #4caf50;'>✓ ja</span>" : "<span style='color: #f44336;'>✗ nein</span>");
        echo "</div>";
        
        echo "<strong style='display: block; margin-bottom: 15px; font-size: 16px;'>📋 Lösungsmöglichkeiten:</strong>";
        
        echo "<div style='margin-bottom: 15px;'>";
        echo "<strong>1. Berechtigungen für die Datei reparieren:</strong><br>";
        echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        echo "sudo chown www-data:www-data " . htmlspecialchars($datei) . "<br>";
        echo "sudo chmod 644 " . htmlspecialchars($datei);
        echo "</code>";
        echo "</div>";
        
        echo "<div>";
        echo "<strong>2. Oder gesamtes Verzeichnis reparieren:</strong><br>";
        echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        echo "sudo chown -R www-data:www-data " . htmlspecialchars(dirname($datei)) . "<br>";
        echo "sudo chmod -R 755 " . htmlspecialchars(dirname($datei));
        echo "</code>";
        echo "</div>";
        
        echo "</div>";
        exit;
    }
}

$alleZeilen = [];
$zeile = "1";
$message = '';

/* =============== POST verarbeiten =============== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST["zwei"])) {
        $neueDauer = trim($_POST["zwei"]);
        
        // Validiere numerischen Wert
        if (!is_numeric($neueDauer) || intval($neueDauer) < 0 || intval($neueDauer) > 24) {
            $message = errorMessage("Ungültige Eingabe", 
                "Die Ladedauer muss zwischen 0 und 24 Stunden liegen.");
            $neueDauer = "1";
        } else {
            $file_exists = is_file($datei);
            $file_writable = $file_exists ? is_writable($datei) : false;
            $parent_dir = dirname($datei);
            $parent_writable = is_writable($parent_dir);

            if (($file_exists && !$file_writable) || (!$file_exists && !$parent_writable)) {
                echo "<div style='background: #1e1e1e; border: 1px solid #555; border-radius: 6px; padding: 20px; margin: 20px; color: #fff; max-width: 900px;'>";
                echo "<div style='padding: 15px; background: #3d1f1f; border-left: 4px solid #f44336; border-radius: 4px; margin-bottom: 20px;'>";
                echo "<strong style='color: #f44336; font-size: 18px;'>⚠ Schreibberechtigung fehlt</strong><br>";
                echo "Datei: <strong>" . htmlspecialchars($datei) . "</strong><br>";
                echo "Datei existiert: " . ($file_exists ? "<span style='color: #4caf50;'>✓ ja</span>" : "<span style='color: #f44336;'>✗ nein</span>") . "<br>";
                echo "Eltern-Verzeichnis schreibbar: " . ($parent_writable ? "<span style='color: #4caf50;'>✓ ja</span>" : "<span style='color: #f44336;'>✗ nein</span>");
                echo "</div>";

                echo "<strong style='display: block; margin-bottom: 15px; font-size: 16px;'>📋 Lösungsmöglichkeiten:</strong>";

                echo "<div style='margin-bottom: 15px;'>";
                echo "<strong>1. Berechtigungen für die Datei reparieren:</strong><br>";
                echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
                echo "sudo chown www-data:www-data " . htmlspecialchars($datei) . "<br>";
                echo "sudo chmod 644 " . htmlspecialchars($datei);
                echo "</code>";
                echo "</div>";

                echo "<div>";
                echo "<strong>2. Oder gesamtes Verzeichnis reparieren:</strong><br>";
                echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
                echo "sudo chown -R www-data:www-data " . htmlspecialchars($parent_dir) . "<br>";
                echo "sudo chmod -R 755 " . htmlspecialchars($parent_dir);
                echo "</code>";
                echo "</div>";

                echo "</div>";
                exit;
            }

            if (@file_put_contents($datei, $neueDauer . PHP_EOL, LOCK_EX) !== false) {
                $message = successMessage("✓ Ladedauer erfolgreich gespeichert!");
                sleep(1); // Kurze Verzögerung, damit Datei sicher geschrieben ist
            } else {
                echo "<div style='background: #1e1e1e; border: 1px solid #555; border-radius: 6px; padding: 20px; margin: 20px; color: #fff; max-width: 900px;'>";
                echo "<div style='padding: 15px; background: #3d1f1f; border-left: 4px solid #f44336; border-radius: 4px; margin-bottom: 20px;'>";
                echo "<strong style='color: #f44336; font-size: 18px;'>⚠ Schreibberechtigung fehlt</strong><br>";
                echo "Datei: <strong>" . htmlspecialchars($datei) . "</strong><br>";
                echo "Eltern-Verzeichnis schreibbar: " . ($parent_writable ? "<span style='color: #4caf50;'>✓ ja</span>" : "<span style='color: #f44336;'>✗ nein</span>");
                echo "</div>";

                echo "<strong style='display: block; margin-bottom: 15px; font-size: 16px;'>📋 Lösungsmöglichkeiten:</strong>";

                echo "<div style='margin-bottom: 15px;'>";
                echo "<strong>1. Berechtigungen für die Datei reparieren:</strong><br>";
                echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
                echo "sudo chown www-data:www-data " . htmlspecialchars($datei) . "<br>";
                echo "sudo chmod 644 " . htmlspecialchars($datei);
                echo "</code>";
                echo "</div>";

                echo "<div>";
                echo "<strong>2. Oder gesamtes Verzeichnis reparieren:</strong><br>";
                echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
                echo "sudo chown -R www-data:www-data " . htmlspecialchars($parent_dir) . "<br>";
                echo "sudo chmod -R 755 " . htmlspecialchars($parent_dir);
                echo "</code>";
                echo "</div>";

                echo "</div>";
                exit;
            }
        }
    }
}

/* =============== Datei einlesen =============== */
if (!$read_error && file_exists($datei)) {
    $read_check = checkFileAccess($datei, 'read');
    if ($read_check === true) {
        $alleZeilen = file($datei, FILE_IGNORE_NEW_LINES);
    }
}

if (count($alleZeilen) > 0) {
    $zeile = $alleZeilen[0];
}
?>

<h1>Wallbox Ladeplanung</h1>

<?php if (!empty($message)): ?>
    <?= $message ?>
<?php endif; ?>

<div class="config-box">
    
    <?php
    /* =============== Ausgabe Ladeinformationen =============== */
    if ($zeile < "1") {
        echo "<p>Es wurden keine Ladezeiten geplant.</p>";
    } else {
        if ($zeile < "2") {
            echo "<p>Die geplante Ladedauer beträgt <strong>eine Stunde</strong>.</p>";
        } else {
            echo "<p>Die geplante Ladedauer beträgt <strong>" . htmlspecialchars($zeile) . " Stunden</strong>.</p>";
        }
    }

    /* =============== Weitere Zeilen anzeigen =============== */
    if (count($alleZeilen) > 1) {
        echo "<p style=\"margin-top: 20px;\"><strong>Geplante Ladezeiten:</strong></p>";
        echo "<ul style=\"margin-top: 10px; padding-left: 20px;\">";
        
        for ($i = 1; $i < count($alleZeilen); $i++) {
            echo "<li>" . htmlspecialchars($alleZeilen[$i]) . "</li>";
        }
        
        echo "</ul>";
    }
    ?>

    <form action="index.php?seite=wallbox" method="post" style="margin-top: 20px;">
        <div class="config-item">
            <label for="zwei">Neue Ladedauer (Stunden)</label>
            <input type="number" id="zwei" name="zwei" 
                value="<?= htmlspecialchars($zeile) ?>" 
                min="0" max="24" step="1"
                title="Ladeplanung in Stunden (0-24)">
            <p style="font-size: 0.85em; color: #aaa; margin-top: 8px;">
                Geben Sie die gewünschte Ladedauer in Stunden ein.
            </p>
        </div>

        <button type="submit" class="form-button">✓ Speichern</button>
    </form>

</div>

<style>
    .config-item label {
        display: block;
        margin-top: 0;
        font-size: 1.1em;
        font-weight: 500;
    }

    .config-item input {
        margin-top: 8px;
        max-width: 200px;
    }

    .form-button {
        width: auto;
    }
</style>
