<?php
/* =====================================================================
   E3DC-Control - Wallbox.php (Überarbeitete Version)
   
   - helpers.php für Fehlerbehandlung genutzt
   - Konsistente Dark-Mode Farbgebung
   - Bessere Input-Validierung
   ===================================================================== */

// Dateipfade
$datei = null;
$paths = getInstallPaths();
$base_path = rtrim($paths['install_path'], '/') . '/';  // Sicherstellen dass trailing slash vorhanden ist
$fallback_path = 'e3dc.wallbox.txt';
$message = '';
$read_error = false;

// Prüfe beide Pfade
if (file_exists($base_path . 'e3dc.wallbox.txt')) {
    $datei = $base_path . 'e3dc.wallbox.txt';
} elseif (file_exists($fallback_path)) {
    $datei = $fallback_path;
} else {
    // Fallback: versuche im korrekten Pfad zu erstellen
    $datei = $base_path . 'e3dc.wallbox.txt';
}

$alleZeilen = [];
$zeile = "1";
$message = '';

/* =============== POST verarbeiten =============== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST["zwei"])) {
        $neueDauer = trim($_POST["zwei"]);
        
        // Validiere numerischen Wert (0-24 oder 99)
        $neueDauer_int = intval($neueDauer);
        if (!is_numeric($neueDauer) || $neueDauer_int < 0 || ($neueDauer_int > 24 && $neueDauer_int < 99) || $neueDauer_int > 99) {
            $message = errorMessage("Ungültige Eingabe", 
                "Die Ladedauer muss zwischen 0 und 24 Stunden oder 99 = unbegrenzt liegen.");
            $neueDauer = "1";
        } else {
            // Umask setzen, damit Datei mit korrekten Berechtigungen erstellt wird
            $old_umask = umask(0002);
            
            // Fehler ausgeben statt unterdrücken
            $write_result = file_put_contents($datei, $neueDauer . PHP_EOL, LOCK_EX);
            $error = error_get_last();
            
            umask($old_umask);
            
            if ($write_result !== false) {
                $message = successMessage("✓ Ladedauer erfolgreich gespeichert!");
                sleep(1); // Kurze Verzögerung, damit Datei sicher geschrieben ist
            } else {
                $parent_dir = dirname($datei);
                
                echo "<div style='background: #1e1e1e; border: 1px solid #555; border-radius: 6px; padding: 20px; margin: 20px; color: #fff; max-width: 900px;'>";
                echo "<div style='padding: 15px; background: #3d1f1f; border-left: 4px solid #f44336; border-radius: 4px; margin-bottom: 20px;'>";
                echo "<strong style='color: #f44336; font-size: 18px;'>⚠ Datei-Zugriff verweigert</strong><br>";
                echo "Datei: <strong>" . htmlspecialchars($datei) . "</strong><br>";
                echo "System-Fehler: <strong>" . htmlspecialchars($error_msg) . "</strong><br>";
                echo "</div>";

                echo "<strong style='display: block; margin-bottom: 15px; font-size: 16px;'>📋 Lösung:</strong>";

                echo "<div style='margin-bottom: 15px; padding: 10px; background: #2a2a2a; border-left: 3px solid #4caf50; border-radius: 4px;'>";
                echo "<strong>Datei mit korrekten Berechtigungen erstellen:</strong><br>";
                echo "<code style='display: block; background: #0a0a0a; padding: 10px; margin: 5px 0; border-radius: 4px; font-size: 12px;'>";
                echo "sudo touch " . htmlspecialchars($datei) . "<br>";
                echo "sudo chown " . htmlspecialchars($paths['install_user']) . ":www-data " . htmlspecialchars($datei) . "<br>";
                echo "sudo chmod 664 " . htmlspecialchars($datei);
                echo "</code>";
                echo "<p style='margin-top: 10px; font-size: 0.9em; color: #bbb;'>Dies ermöglicht sowohl dem " . htmlspecialchars($paths['install_user']) . "-Benutzer (für das Hauptprogramm) als auch www-data (für die Web-App) auf die Datei zuzugreifen.</p>";
                echo "</div>";

                echo "</div>";
                exit;
            }
        }
    }
}

/* =============== Datei einlesen =============== */
if (!$read_error && file_exists($datei)) {
    $read_check = checkFileAccess($datei, 'read');
    if ($read_check === true) {
        $alleZeilen = file($datei, FILE_IGNORE_NEW_LINES);
    }
}

if (count($alleZeilen) > 0) {
    $zeile = $alleZeilen[0];
}
?>

<h1>Wallbox Ladeplanung</h1>

<?php if (!empty($message)): ?>
    <?= $message ?>
<?php endif; ?>

<div class="config-box">
    
    <?php
    /* =============== Ausgabe Ladeinformationen =============== */
    if ($zeile < "1") {
        echo "<p>Es wurden keine Ladezeiten geplant.</p>";
    } else {
        if ($zeile < "2") {
            echo "<p>Die geplante Ladedauer beträgt <strong>eine Stunde</strong>.</p>";
        } else {
            echo "<p>Die geplante Ladedauer beträgt <strong>" . htmlspecialchars($zeile) . " Stunden</strong>.</p>";
        }
    }

    /* =============== Weitere Zeilen anzeigen =============== */
    if (count($alleZeilen) > 1) {
        echo "<p style=\"margin-top: 20px;\"><strong>Geplante Ladezeiten:</strong></p>";
        echo "<ul style=\"margin-top: 10px; padding-left: 20px;\">";
        
        for ($i = 1; $i < count($alleZeilen); $i++) {
            echo "<li>" . htmlspecialchars($alleZeilen[$i]) . "</li>";
        }
        
        echo "</ul>";
    }
    ?>

    <form action="index.php?seite=wallbox" method="post" style="margin-top: 20px;">
        <div class="config-item">
            <label for="zwei">Neue Ladedauer (Stunden)</label>
            <input type="number" id="zwei" name="zwei" 
                value="<?= htmlspecialchars($zeile) ?>" 
                min="0" max="99" step="1"
                title="Ladeplanung in Stunden (0-99)">
            <p style="font-size: 0.85em; color: #aaa; margin-top: 8px;">
                Geben Sie die gewünschte Ladedauer in Stunden ein.
            </p>
        </div>

        <button type="submit" class="form-button">✓ Speichern</button>
    </form>

</div>

<style>
    .config-item label {
        display: block;
        margin-top: 0;
        font-size: 1.1em;
        font-weight: 500;
    }

    .config-item input {
        margin-top: 8px;
        max-width: 200px;
    }

    .form-button {
        width: auto;
    }
</style>
