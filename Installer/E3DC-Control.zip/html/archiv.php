<?php
/* =====================================================================
   E3DC-Control - archiv.php (Überarbeitete Version)
   
   - helpers.php für Fehlerbehandlung genutzt
   - Bessere Dateizugriffsprüfung
   - Sicherere Pfadbehandlung
   ===================================================================== */

// Finde alle Archiv-Dateien
$paths = getInstallPaths();
$base_path = rtrim($paths['install_path'], '/') . '/';  // Sicherstellen dass trailing slash vorhanden ist

// Prüfe Zugriff auf Verzeichnis
if (!is_dir($base_path) || !is_readable($base_path)) {
    echo errorMessage("Verzeichnis nicht zugänglich", 
        "Das Verzeichnis <code>" . htmlspecialchars($base_path) . 
        "</code> kann nicht gelesen werden. " .
        "Prüfen Sie die Dateiberechtigungen.");
    exit;
}

$files = glob($base_path . "awattardebug.*.txt");

$entries = [];
foreach ($files as $file) {
    if (preg_match('/awattardebug\.(\d+)\.txt$/', $file, $m)) {
        $entries[] = [
            'num' => intval($m[1]),
            'name' => basename($file),
            'time' => date("d.m.Y H:i", filemtime($file))
        ];
    }
}

// Sortiere nach Nummer (absteigend = neueste zuerst)
usort($entries, fn($a, $b) => $b['num'] <=> $a['num']);

// Ausgewählte Datei bestimmen
$selectedFile = null;
$changed = null;

if (isset($_GET['file'])) {
    $requestedFile = $_GET['file'];
    
    // Sicherheit: Validiere Dateinamen
    if (validateFilename(basename($requestedFile))) {
        $fullpath = $base_path . basename($requestedFile);
        
        // Prüfe existenz und lesbarkeit
        if (file_exists($fullpath) && is_readable($fullpath)) {
            $selectedFile = basename($requestedFile);
            $changed = date("d.m.Y H:i", filemtime($fullpath));
        }
    }
}
?>

<h2 style="text-align:center; margin-top:20px;">Archiv – Diagramm auswählen</h2>

<?php if (empty($entries)): ?>
    <?= errorMessage("Keine Archive gefunden", 
        "Es wurden keine Archiv-Dateien im Verzeichnis gefunden.") ?>
<?php endif; ?>

<div style="text-align:center; margin-top:20px;">
    <form method="GET" action="<?= htmlspecialchars(getContextPageUrl('archiv')) ?>">
        <input type="hidden" name="seite" value="archiv">
        <select name="file" style="padding:8px; font-size:16px; max-width:400px;">
            <option value="">Bitte wählen…</option>

            <?php foreach ($entries as $e): ?>
                <option value="<?= htmlspecialchars($e['name']) ?>"
                    <?= ($selectedFile === $e['name']) ? 'selected' : '' ?>>
                    Datei <?= $e['num'] ?> (<?= $e['time'] ?>)
                </option>
            <?php endforeach; ?>
        </select>

        <button type="submit" class="form-button" style="margin-left:10px;">Anzeigen</button>
    </form>
</div>

<?php if ($selectedFile): ?>
    <h3 style="text-align:center; margin-top:30px;">
        Archiv-Diagramm: <strong><?= htmlspecialchars($selectedFile) ?></strong>
        <?php if ($changed): ?>
            <span style="color:#aaa; font-size:0.9em; display:block; margin-top:8px;">
                (geändert am <?= $changed ?>)
            </span>
        <?php endif; ?>
    </h3>
    <iframe id="archivDiagramm" src="archiv_diagramm.php?file=<?= urlencode($selectedFile) ?>&ts=<?= time() ?>"
            style="width:100%; height: calc(100vh - 280px); border:none; margin-top:20px; border-radius:4px; display:block;">
    </iframe>
<?php endif; ?>

<style>
    select {
        background-color: #333;
        color: white;
        border: 1px solid #555;
        border-radius: 4px;
    }
</style>
