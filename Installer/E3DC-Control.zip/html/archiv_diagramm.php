<?php
/* =====================================================================
   E3DC-Control - archiv_diagramm.php (Überarbeitete Version)
   
   - Bessere Fehlerbehandlung
   - Sicherere Dateizugriffsprüfung
   - Python-Fehler werden abgefangen
   ===================================================================== */

require_once 'helpers.php';

$paths = getInstallPaths();
$base_path = rtrim($paths['install_path'], '/') . '/';  // Sicherstellen dass trailing slash vorhanden ist

if (!isset($_GET['file'])) {
    die(errorMessage("Fehler", "Keine Datei angegeben."));
}

$file = basename($_GET['file']);

// Validiere Dateinamen (nur sichere Zeichen)
if (!validateFilename($file)) {
    die(errorMessage("Sicherheitsfehler", 
        "Dateiname enthält ungültige Zeichen."));
}

$fullpath = $base_path . $file;

// Prüfe Dateizugriff
$access_check = checkFileAccess($fullpath, 'read');
if ($access_check !== true) {
    die($access_check);
}

// Stelle sicher, dass tmp-Verzeichnis existiert
$tmp_dir = "/var/www/html/tmp";
if (!is_dir($tmp_dir)) {
    if (!@mkdir($tmp_dir, 0755, true)) {
        die(errorMessage("Fehler", 
            "Tmp-Verzeichnis konnte nicht erstellt werden."));
    }
}

// Starte Python-Skript
$lockfile_archiv = "/var/www/html/tmp/plot_soc_running_archiv";
$doneFile = "/var/www/html/tmp/plot_soc_done_archiv";

// Lösche alte Done-Datei
@unlink($doneFile);

// Starte Prozess (mit Timeout)
$cmd = "/usr/bin/python3 " . $base_path . "plot_soc_changes.py " . 
       escapeshellarg($fullpath) . " archiv 2>&1";

$output = [];
$returnCode = 0;

exec($cmd, $output, $returnCode);

if ($returnCode !== 0) {
    debugLog("Python-Fehler", [
        'returnCode' => $returnCode,
        'output' => implode("\n", $output)
    ]);
}

// Warte auf Done-Datei (max 10 Sekunden)
$timeout = 10;
$start = time();

while (!file_exists($doneFile) && (time() - $start) < $timeout) {
    usleep(200000); // 0.2 Sekunden
}

if (!file_exists($doneFile)) {
    die(errorMessage("Timeout", 
        "Das Diagramm-Skript hat nicht rechtzeitig abgeschlossen."));
}

// Gebe Diagramm aus
$diagramm_file = "/var/www/html/archiv_diagramm.html";
if (!file_exists($diagramm_file)) {
    die(errorMessage("Fehler", 
        "Diagramm-Datei konnte nicht erstellt werden."));
}

// Lösche Done-Datei wieder
@unlink($doneFile);

// Ausgeben
readfile($diagramm_file);
?>
