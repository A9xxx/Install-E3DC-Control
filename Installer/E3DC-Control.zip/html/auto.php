<?php
/* =====================================================================
   E3DC-Control - auto.php (Überarbeitete Version)
   
   - helpers.php für Fehlerbehandlung genutzt
   - Konsistente Dark-Mode Farbgebung (Fehler mit grünem Hintergrund behoben)
   - Bessere Eingabevalidierung
   ===================================================================== */

$config_file_path = '/home/pi/E3DC-Control/e3dc.config.txt';
$message = '';
$read_error = false;

// Prüfe Dateizugriff direkt
if (!is_readable($config_file_path)) {
    $file_status = is_file($config_file_path);
    $parent_writable = is_writable(dirname($config_file_path));
    
    echo "<div style='background: #1e1e1e; border: 1px solid #555; border-radius: 6px; padding: 20px; margin: 20px; color: #fff; max-width: 900px;'>";
    echo "<div style='padding: 15px; background: #3d1f1f; border-left: 4px solid #f44336; border-radius: 4px; margin-bottom: 20px;'>";
    echo "<strong style='color: #f44336; font-size: 18px;'>⚠ Schreibberechtigung fehlt</strong><br>";
    echo "Datei: <strong>" . htmlspecialchars($config_file_path) . "</strong><br>";
    echo "Datei existiert: " . ($file_status ? "<span style='color: #4caf50;'>✓ ja</span>" : "<span style='color: #f44336;'>✗ nein</span>") . "<br>";
    echo "Eltern-Verzeichnis schreibbar: " . ($parent_writable ? "<span style='color: #4caf50;'>✓ ja</span>" : "<span style='color: #f44336;'>✗ nein</span>");
    echo "</div>";
    
    echo "<strong style='display: block; margin-bottom: 15px; font-size: 16px;'>📋 Lösungsmöglichkeiten:</strong>";
    
    echo "<div style='margin-bottom: 15px;'>";
    echo "<strong>1. Berechtigungen für die Konfigurationsdatei reparieren:</strong><br>";
    echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
    echo "sudo chown pi:www-data " . htmlspecialchars($config_file_path) . "<br>";
    echo "sudo chmod 664 " . htmlspecialchars($config_file_path);
    echo "</code>";
    echo "</div>";
    
    echo "<div>";
    echo "<strong>2. Oder gesamtes Verzeichnis reparieren:</strong><br>";
    echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
    echo "sudo chown -R pi:www-data " . htmlspecialchars(dirname($config_file_path)) . "<br>";
    echo "sudo chmod -R 775 " . htmlspecialchars(dirname($config_file_path));
    echo "</code>";
    echo "</div>";
    
    echo "</div>";
    exit;
}

/* =============== Funktionen =============== */
function readConfig($file_path) {
    $lines = file($file_path, FILE_IGNORE_NEW_LINES);
    $config = [];

    foreach ($lines as $line) {
        if (strpos($line, 'Wbhour') !== false && strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            if ($key === 'Wbhour') {
                $config[$key] = $value;
            }
        }
    }

    return $config;
}

function writeConfig($file_path, $config) {
    $file_exists = is_file($file_path);
    $file_writable = $file_exists ? is_writable($file_path) : false;
    $parent_dir = dirname($file_path);
    $parent_writable = is_writable($parent_dir);

    if (($file_exists && !$file_writable) || (!$file_exists && !$parent_writable)) {
        echo "<div style='background: #1e1e1e; border: 1px solid #555; border-radius: 6px; padding: 20px; margin: 20px; color: #fff; max-width: 900px;'>";
        echo "<div style='padding: 15px; background: #3d1f1f; border-left: 4px solid #f44336; border-radius: 4px; margin-bottom: 20px;'>";
        echo "<strong style='color: #f44336; font-size: 18px;'>⚠ Schreibberechtigung fehlt</strong><br>";
        echo "Datei: <strong>" . htmlspecialchars($file_path) . "</strong><br>";
        echo "Datei existiert: " . ($file_exists ? "<span style='color: #4caf50;'>✓ ja</span>" : "<span style='color: #f44336;'>✗ nein</span>") . "<br>";
        echo "Eltern-Verzeichnis schreibbar: " . ($parent_writable ? "<span style='color: #4caf50;'>✓ ja</span>" : "<span style='color: #f44336;'>✗ nein</span>");
        echo "</div>";

        echo "<strong style='display: block; margin-bottom: 15px; font-size: 16px;'>📋 Lösungsmöglichkeiten:</strong>";

        echo "<div style='margin-bottom: 15px;'>";
        echo "<strong>1. Berechtigungen für die Konfigurationsdatei reparieren:</strong><br>";
        echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        echo "sudo chown pi:www-data " . htmlspecialchars($file_path) . "<br>";
        echo "sudo chmod 664 " . htmlspecialchars($file_path);
        echo "</code>";
        echo "</div>";

        echo "<div>";
        echo "<strong>2. Oder gesamtes Verzeichnis reparieren:</strong><br>";
        echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        echo "sudo chown -R pi:www-data " . htmlspecialchars($parent_dir) . "<br>";
        echo "sudo chmod -R 775 " . htmlspecialchars($parent_dir);
        echo "</code>";
        echo "</div>";

        echo "</div>";
        exit;
    }

    $lines = file($file_path, FILE_IGNORE_NEW_LINES);
    $new_lines = [];

    foreach ($lines as $line) {
        if (strpos($line, 'Wbhour') !== false) {
            $new_lines[] = "Wbhour = " . $config['Wbhour'];
        } else {
            $new_lines[] = $line;
        }
    }

    if (@file_put_contents($file_path, implode("\n", $new_lines), LOCK_EX) === false) {
        $parent_dir = dirname($file_path);
        $parent_writable = is_writable($parent_dir);
        
        echo "<div style='background: #1e1e1e; border: 1px solid #555; border-radius: 6px; padding: 20px; margin: 20px; color: #fff; max-width: 900px;'>";
        echo "<div style='padding: 15px; background: #3d1f1f; border-left: 4px solid #f44336; border-radius: 4px; margin-bottom: 20px;'>";
        echo "<strong style='color: #f44336; font-size: 18px;'>⚠ Schreibberechtigung fehlt</strong><br>";
        echo "Datei: <strong>" . htmlspecialchars($file_path) . "</strong><br>";
        echo "Eltern-Verzeichnis schreibbar: " . ($parent_writable ? "<span style='color: #4caf50;'>✓ ja</span>" : "<span style='color: #f44336;'>✗ nein</span>");
        echo "</div>";
        
        echo "<strong style='display: block; margin-bottom: 15px; font-size: 16px;'>📋 Lösungsmöglichkeiten:</strong>";
        
        echo "<div style='margin-bottom: 15px;'>";
        echo "<strong>1. Berechtigungen für die Konfigurationsdatei reparieren:</strong><br>";
        echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        echo "sudo chown pi:www-data " . htmlspecialchars($file_path) . "<br>";
        echo "sudo chmod 664 " . htmlspecialchars($file_path);
        echo "</code>";
        echo "</div>";
        
        echo "<div>";
        echo "<strong>2. Oder gesamtes Verzeichnis reparieren:</strong><br>";
        echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        echo "sudo chown -R pi:www-data " . htmlspecialchars(dirname($file_path)) . "<br>";
        echo "sudo chmod -R 775 " . htmlspecialchars(dirname($file_path));
        echo "</code>";
        echo "</div>";
        
        echo "</div>";
        exit;
    }
    
    return true; // Erfolg
}

/* =============== Daten laden =============== */
$config = [];
if (!$read_error) {
    $config = readConfig($config_file_path);

    if (empty($config)) {
        $message = errorMessage("Fehler beim Laden", 
            "Wbhour konnte nicht in der Konfigurationsdatei gefunden werden.");
        $config = [];
    }
}

/* =============== POST verarbeiten =============== */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['Wbhour'])) {
        $wbhour = trim($_POST['Wbhour']);
        
        // Validiere numerischen Wert
        if (!is_numeric($wbhour) || intval($wbhour) < 0) {
            $message = errorMessage("Ungültige Eingabe", 
                "Wbhour muss ein numerischer Wert >= 0 sein.");
        } else {
            $config['Wbhour'] = $wbhour;
            
            $write_result = writeConfig($config_file_path, $config);
            if ($write_result === true) {
                $message = successMessage("✓ Wert wurde erfolgreich gespeichert!");
            } else {
                $message = $write_result; // HTML-Fehlermeldung
            }
        }
    }
}
?>

<h1>Einstellungen für Ladeautomatik</h1>

<?php if (!empty($message)): ?>
    <?= $message ?>
<?php endif; ?>

<div class="config-box">
    <form method="POST">
        <?php if (!empty($config)): ?>
            <div class="config-item">
                <label for="Wbhour">Wbhour (Ladedauer in Stunden)</label>
                <input type="number" id="Wbhour" name="Wbhour" 
                    value="<?= htmlspecialchars($config['Wbhour']) ?>" 
                    min="0" step="1" title="Ganze Zahl zwischen 0 und 24">
                <p style="font-size: 0.85em; color: #aaa; margin-top: 8px;">
                    Definiert die automatische Ladedauer der Wallbox.
                </p>
            </div>

            <button type="submit" class="form-button">✓ Speichern</button>
        <?php else: ?>
            <p style="color: #e74c3c;">
                Es konnte keine gültige Konfiguration geladen werden.
            </p>
        <?php endif; ?>
    </form>
</div>

<style>
    .config-item label {
        display: block;
        margin-top: 0;
        font-size: 1.1em;
        font-weight: 500;
    }

    .config-item input {
        margin-top: 8px;
        max-width: 200px;
    }

    .form-button {
        margin-top: 20px;
        width: auto;
    }
</style>
