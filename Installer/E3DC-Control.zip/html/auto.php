<?php
/* =====================================================================
   auto.php - Kompatibilitätsseite
   Leitet logisch auf die zusammengeführte Wallbox-Steuerung.
   ===================================================================== */

include 'Wallbox.php';
