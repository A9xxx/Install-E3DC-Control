<?php
require_once 'helpers.php';
$paths = getInstallPaths();
// Pfad zur Live-Datei (entsprechend deiner Konfiguration)
$source = rtrim($paths['install_path'], '/') . '/live_history.txt';
$backupDir = '/var/www/html/tmp/history_backups/';

if (!is_dir($backupDir)) {
    mkdir($backupDir, 0755, true);
}

// Backup erstellen (mit Datum von gestern, da wir um Mitternacht sichern)
$target = $backupDir . 'history_' . date('Y-m-d', strtotime('yesterday')) . '.txt';
if (file_exists($source)) {
    copy($source, $target);
}

// Alte Backups löschen (> 30 Tage)
$files = glob($backupDir . 'history_*.txt');
foreach ($files as $file) {
    if (time() - filemtime($file) > 30 * 86400) {
        unlink($file);
    }
}
