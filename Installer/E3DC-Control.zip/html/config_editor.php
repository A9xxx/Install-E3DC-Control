<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$paths = getInstallPaths();
$install_user = $paths['install_user'];
$install_path = rtrim($paths['install_path'], '/') . '/'; 

if (!isset($_SESSION['deleted'])) {
    $_SESSION['deleted'] = [];
}

$config_file_path = $install_path . 'e3dc.config.txt';
$message = '';

/* --- DEINE DEFAULTS & TOOLTIPS --- */
$defaults = [
    "wallbox" => "true", "wbmode" => "4", "wbminlade" => "1200", "wbminSoC" => "70",
    "wbmaxladestrom" => "32", "wbminladestrom" => "6", "wbhour" => "0", "wbvon" => "20", "wbbis" => "6", "wbcostpowers" => "7.2, 11.0, 22.0",
    "speichergroesse" => "35", "speicherev" => "80", "speichereta" => "0.97", "unload" => "65",
    "ladeschwelle" => "70", "ladeende" => "85", "ladeende2" => "91", "ladeende2rampe" => "2",
    "maximumladeleistung" => "12500", "awattar" => "1", "awmwst" => "19", "awnebenkosten" => "15.915",
    "awaufschlag" => "12", "awland" => "DE", "awreserve" => "20", "awsimulation" => "1",
    "wp" => "true", "wpheizlast" => "18", "wpheizgrenze" => "13", "wpleistung" => "20",
    "wpmin" => "0.5", "wpmax" => "4.7", "wpehz" => "12 kW", "wpzwe" => "-99", "wpzwepvon" => "25",
    "luxtronik" => "0", "luxtronik_ip" => "192.168.178.88", "wrleistung" => "11700", "hoehe" => "48.60442", "laenge" => "13.41513", "auto_update_enable" => "0", "auto_update_time" => "23:00",
    "forecast1" => "40/-50/15.4", "forecastsoc" => "1.2", "forecastconsumption" => "1", "forecastreserve" => "5", "show_forecast" => "1", "darkmode" => "1", "pvatmosphere" => "0.7",
    "check_updates" => "1", "stop" => "0", "pv_pause_min_at" => "0.0"
];

$tooltips = [
    "wallbox" => "Aktiviert oder deaktiviert die Wallbox-Steuerung.",
    "wbmode" => "0 keine Steuerung\n1 Laden nur bei Abregelung\n2 Überschussladen\n3 Laden, Priorität Hausspeicher\n4 Hausspeicher bevorzugt laden\n5..8 Leitwert ist wbminlade\n9 Die Wallbox hat Prorität.",
    "wbminlade" => "Minimale Ladeleistung der Wallbox in Watt.",
    "wbminsoc" => "Unterer SoC-Grenzwert für Entladen über die Wallbox.",
    "wbmaxladestrom" => "Maximaler Ladestrom der Wallbox in Ampere.",
    "wbminladestrom" => "Minimaler Ladestrom der Wallbox in Ampere.",
    "wbhour" => "Stunden, die im günstigsten Preisfenster geladen werden sollen.",
    "wbvon" => "Startzeit des Ladefensters.",
    "wbbis" => "Endzeit des Ladefensters.",
    "wbcostpowers" => "Komma-getrennte Ladeleistungen (in kW) für die Kostenschätzung in der Wallbox-Ansicht.",
    "speichergroesse" => "Nutzbare Kapazität des Speichers in kWh.",
    "speicherev" => "Eigenverbrauch des Wechselrichters in Watt.",
    "speichereta" => "Wirkungsgrad des Speichers.",
    "unload" => "Bis zu diesem SoC wird morgens entladen.",
    "ladeschwelle" => "Bis zu diesem SoC wird morgens maximal geladen.",
    "ladeende" => "Erster Ladeendpunkt (SoC).",
    "ladeende2" => "Zweiter Ladeendpunkt (SoC).",
    "ladeende2rampe" => "Beschleunigung der Ladung zwischen Ladeende1 und Ladeende2.",
    "maximumladeleistung" => "Maximale Ladeleistung des Speichers in Watt.",
    "awattar" => "0 = aus, 1 = Netzladen aktiv, 2 = ohne Netzladen.",
    "awmwst" => "Mehrwertsteuer in Prozent.",
    "awnebenkosten" => "Nebenkosten pro kWh (brutto).",
    "awaufschlag" => "Prozentualer Aufschlag auf den Börsenpreis.",
    "awland" => "Land für Preisberechnung.",
    "awreserve" => "Reserve-SoC für Verbrauchsprognose.",
    "awsimulation" => "Zusätzliche PV-Spalte in Simulation aktivieren.",
    "wp" => "Wärmepumpe vorhanden = true.",
    "wpheizlast" => "Heizlast der Wärmepumpe.",
    "wpheizgrenze" => "Temperaturgrenze für Heizbetrieb.",
    "wpleistung" => "Elektrische Leistung der WP.",
    "wpmin" => "Minimale elektrische Leistung.",
    "wpmax" => "Maximale elektrische Leistung.",
    "wpehz" => "Leistung der elektrischen Zusatzheizung.",
    "wpzwe" => "ZWE-Modus.",
    "wpzwepvon" => "Temperaturgrenze für ZWE.",
    "luxtronik" => "Aktiviert das Luxtronik-Modul (1=an, 0=aus).",
    "luxtronik_ip" => "IP-Adresse der Luxtronik Wärmepumpe.",
    "hoehe" => "Geografische Höhe für Sonnenstandsberechnung.",
    "laenge" => "Geografische Länge für Sonnenstandsberechnung.",
    "forecast1" => "Dachneigung/Azimuth/kWp.",
    "forecast2" => "Dachneigung/Azimuth/kWp für den 2. PV-String.",
    "forecast3" => "Dachneigung/Azimuth/kWp für den 3. PV-String.",
    "forecast4" => "Dachneigung/Azimuth/kWp für den 4. PV-String.",
    "forecast5" => "Dachneigung/Azimuth/kWp für den 5. PV-String.",
    "forecastsoc" => "Faktor für beschleunigtes Laden.",
    "forecastconsumption" => "Faktor für Verbrauchsprognose.",
    "forecastreserve" => "Reserve in Prozent.",
    "pvatmosphere" => "Atmosphärische Transmission (0.0 - 1.0). Standard 0.7. Höher = klarer Himmel/mehr Leistung.",
    "show_forecast" => "Zeigt Prognose- und Sollwerte im Dashboard an (1=an, 0=aus).",
    "darkmode" => "Darstellungsmodus (1=Dunkel, 0=Hell, auto=System).",
    "check_updates" => "Prüft im Hintergrund regelmäßig auf verfügbare Updates (1=an, 0=aus).",
    "wbtest" => "Testmodus für die Wallbox-Kommunikation.",
    "auto_mode" => "Aktiviert die automatische Regelung durch den Energy Manager (PV-Überschuss, Preise). Wenn aus, nur Monitoring.",
    "grid_start_limit" => "Leistung in Watt, ab der der Boost startet. Negativ = Einspeisung (z.B. -3500 = ab 3500W Einspeisung).",
    "stop_delay_minutes" => "Zeit in Minuten, die der Boost nach Wegfall der Bedingungen weiterläuft (Taktungsschutz).",
    "min_soc" => "Mindest-Ladestand der Hausbatterie in %, damit der PV-Boost freigegeben wird.",
    "at_limit" => "Grenzwert in °C für Sommer/Winter-Umschaltung. Über diesem Wert wird nur Warmwasser erhöht.",
    "wws" => "Zieltemperatur für Warmwasser im Boost-Modus (Sommer).",
    "www" => "Zieltemperatur für Warmwasser im Boost-Modus (Winter).",
    "hz" => "Zieltemperatur für den Heizungs-Rücklauf im Boost-Modus (nur Winter).",
    "price_boost_enable" => "Aktiviert den Boost bei günstigen Strompreisen (aWATTar/Tibber) und pausiert bei teuren Preisen.",
    "price_limit" => "Maximaler Strompreis in ct/kWh, bei dem der Preis-Boost aktiviert wird.",
    "price_hard_limit" => "Preisgrenze, unter der IMMER geboostet wird (ignoriert Tageslimits und Sperren).",
    "price_min_duration" => "Mindestdauer eines Preis-Boost-Intervalls in Minuten.",
    "price_max_daily" => "Maximale Gesamtdauer für Preis-Boosts pro Tag in Minuten.",
    "manual_boost_max_duration" => "Automatische Abschaltung des manuellen Boosts ('Batterie leeren') nach dieser Zeit in Minuten.",
    "manual_boost_min_soc" => "Sicherheits-Grenze: Manuelle Entladung ('Batterie leeren') stoppt, wenn dieser SoC unterschritten wird.",
    "wq_min_temp" => "Sicherheits-Abschaltung des Boosts, wenn die Wärmequelle (Sole) zu kalt wird.",
    "rl_source" => "Auswahl des Temperaturfühlers für die Regelung (Intern oder Extern).",
    "pv_pause_enable" => "Pausiert die Wärmepumpe vor erwarteten PV-Ertragsspitzen, um Platz im Speicher/Estrich zu schaffen.",
    "pv_pause_soc" => "Batterie-SoC, ab dem die 'Aushungern'-Pause vor einer erwarteten PV-Spitze aktiviert wird.",
    "pv_pause_watt" => "PV-Leistung in Watt, die laut Prognose erwartet wird, um die Pause auszulösen.",
    "pv_pause_timeout_minutes" => "Maximale Dauer der Pause in Minuten, falls die Sonne doch nicht kommt.",
    "pv_pause_min_at" => "Auskühlschutz: Unter dieser Außentemperatur (°C) wird die PV-Pause komplett ausgesetzt.",
    "morning_boost_enable" => "Aktiviert die prognosebasierte Entladung des Speichers am frühen Morgen, um Platz für PV-Ertrag zu schaffen.",
    "morning_boost_prio" => "Legt fest, welches Gerät den Speicher leeren soll (Auto oder Wärmepumpe).",
    "morning_boost_wb_power" => "Angenommene Ladeleistung der Wallbox in kW für die Zeitplanung (z.B. 7.0 oder 11.0).",
    "morning_boost_deadline" => "Uhrzeit (Stunde), bis zu der der Speicher auf den Ziel-SoC entladen sein soll.",
    "morning_boost_target_soc" => "Gewünschter Rest-Ladestand nach der morgendlichen Entleerung.",
    "morning_boost_min_hours" => "Mindestanzahl an Stunden mit 99% SoC laut Prognose, um die Entladung zu aktivieren.",
    "morning_boost_min_pv_pct" => "Erwarteter PV-Ertrag (in % der Speicherkapazität) während der Voll-Phasen.",
    "super_intelligence_enable" => "Aktiviert eine aggressive, dynamische Entladung über die Wallbox bei extrem guten PV-Prognosen.",
    "super_intelligence_deadline" => "Uhrzeit, bis zu der die aggressive Entladung abgeschlossen sein soll.",
    "telegram_token" => "Telegram Bot Token für Benachrichtigungen (vom BotFather).",
    "telegram_chat_id" => "Telegram Chat ID, an die Nachrichten gesendet werden.",
    "auto_update_enable" => "Führt gefundene Updates automatisch täglich zur festgelegten Zeit aus (1=an, 0=aus).",
    "auto_update_time" => "Uhrzeit (HH:MM), zu der das automatische Update täglich ausgeführt wird.",
    "wrleistung" => "Maximale Wechselrichterleistung in Watt.",
    "einspeiselimit" => "Maximal zulässige Netzeinspeisung in Watt.",
    "powerfaktor" => "Korrekturfaktor für die Leistungswerte.",
    "rb" => "Untere SoC-Schwelle für die Entladesperre.",
    "re" => "Obere SoC-Schwelle für die Entladesperre.",
    "le" => "Lade-Ende Schwelle (SoC).",
    "shellyem_ip" => "IP-Adresse des Shelly EM zur Leistungsmessung.",
    "openmeteo" => "Wetterprognose über Open-Meteo beziehen (true/false).",
    "server_ip" => "IP-Adresse des E3DC S10 Hauskraftwerks.",
    "server_port" => "Netzwerk-Port für RSCP (Standard: 5033).",
    "e3dc_user" => "E3DC-Portal Benutzername.",
    "e3dc_password" => "E3DC-Portal Passwort.",
    "aes_password" => "RSCP-Passwort (am Gerät vergeben).",
    "debug" => "Debug-Modus aktivieren (0=aus, true=ein).",
    "logfile" => "Pfad zur Logdatei.",
    "ext1" => "Externer Zähler 1.",
    "ext2" => "Externer Zähler 2.",
    "stop" => "Beendet die Bildschirmausgabe (0=aus, 1=ein)."
];

/* --- LOGIK (DATEI LESEN) --- */
function readConfig($file_path) {
    if (!file_exists($file_path)) return [];
    $lines = file($file_path, FILE_IGNORE_NEW_LINES);
    $config = [];
    foreach ($lines as $line) {
        if (trim($line) === '') continue;
        $commented = false;
        if (strpos(ltrim($line), '#') === 0) { $commented = true; $line = ltrim($line, '#'); }
        if (strpos($line, '=') === false) continue;
        list($key, $value) = explode('=', $line, 2);
        $k_lower = strtolower(trim($key));
        if (!isset($config[$k_lower])) {
            $config[$k_lower] = ['value' => trim($value), 'commented' => $commented];
        }
    }
    return $config;
}

$config = readConfig($config_file_path);

/* --- POST LOGIK --- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lines = file_exists($config_file_path) ? file($config_file_path, FILE_IGNORE_NEW_LINES) : [];
    $final_lines = [];

    // Logik für "save_all" (Hauptspeicher-Button)
    if (isset($_POST['save_all'])) {
        $posted_values = $_POST['values'] ?? [];
        $posted_comments = $_POST['comments'] ?? [];
        $updated_keys_lower = [];

        // 1. Bestehende Zeilen aktualisieren
        foreach ($lines as $line) {
            $trimmed_line = trim($line);
            $key_part = ltrim($trimmed_line, '# ');

            if (strpos($key_part, '=') !== false) {
                list($key, $old_value) = explode('=', $key_part, 2);
                $key_trimmed = trim($key);
                $key_lower = strtolower($key_trimmed);

                // Prüfen, ob dieser Key in den POST-Daten vorhanden ist
                if (array_key_exists($key_trimmed, $posted_values)) {
                    $new_value = trim($posted_values[$key_trimmed]);
                    $should_be_commented = in_array($key_trimmed, $posted_comments);
                    $prefix = $should_be_commented ? '# ' : '';
                    $final_lines[] = $prefix . $key_trimmed . " = " . $new_value;
                    $updated_keys_lower[] = $key_lower;
                    continue; // Nächste Zeile
                }
            }
            // Zeile beibehalten, wenn sie nicht aktualisiert wurde
            $final_lines[] = $line;
        }

        // 2. Neue Variablen (aus Defaults, die im Formular waren) hinzufügen
        $keys_in_file_lower = array_map('strtolower', array_keys($config));
        foreach ($posted_values as $key => $value) {
            if (!in_array(strtolower($key), $updated_keys_lower) && !in_array(strtolower($key), $keys_in_file_lower)) {
                $should_be_commented = in_array($key, $posted_comments);
                $prefix = $should_be_commented ? '# ' : '';
                $final_lines[] = $prefix . $key . " = " . trim($value);
            }
        }

        // 3. Manuell hinzugefügte Variable verarbeiten
        if (!empty($_POST['new_key'])) {
            $nk = trim($_POST['new_key']);
            $nk_lower = strtolower($nk);
            if (in_array($nk_lower, $keys_in_file_lower) || in_array($nk_lower, $updated_keys_lower)) {
                $message = "<div class='alert alert-warning py-2 border-0 mb-3 mx-2'>⚠ Variable '" . htmlspecialchars($nk) . "' existiert bereits.</div>";
            } else {
                $nv = trim($_POST['new_value'] ?? '');
                $final_lines[] = $nk . " = " . $nv;
            }
        }
        
        if (empty($message)) {
            $message = "<div class='alert alert-success py-2 border-0 mb-3 mx-2'>✓ Konfiguration gespeichert.</div>";
        }

        // 4. Strompreise speichern
        if (isset($_POST['strompreise'])) {
            $price_file_path = $install_path . 'e3dc.strompreise.txt';
            file_put_contents($price_file_path, $_POST['strompreise'], LOCK_EX);
            // Berechtigungen setzen (Fehler werden ignoriert)
            @chown($price_file_path, posix_getpwnam($install_user)['uid']);
            @chgrp($price_file_path, posix_getgrnam('www-data')['gid']);
            @chmod($price_file_path, 0664);
        }

    } elseif (isset($_POST['delete_key'])) {
        $dk = strtolower($_POST['delete_key']); 
        foreach ($lines as $line) {
            $key_part = ltrim(trim($line), '# ');
            if (strpos($key_part, '=') !== false) {
                list($key, $_) = explode('=', $key_part, 2);
                if (strtolower(trim($key)) === $dk) {
                    // Zeile überspringen
                    continue;
                }
            }
            $final_lines[] = $line;
        }
        $message = "<div class='alert alert-info py-2 border-0 mb-3 mx-2'>Variable '" . htmlspecialchars($_POST['delete_key']) . "' gelöscht.</div>";
    
    } elseif (isset($_POST['stop_set'])) {
        $val = $_POST['stop_set'] === '1' ? '1' : '0';
        $stop_found = false;
        foreach ($lines as $line) {
            $key_part = ltrim(trim($line), '# ');
             if (preg_match('/^stop\s*=/i', $key_part)) {
                $final_lines[] = "stop = " . $val;
                $stop_found = true;
                continue;
            }
            $final_lines[] = $line;
        }
        if (!$stop_found) {
            $final_lines[] = "stop = " . $val;
        }
        $message = "<div class='alert alert-success py-2 border-0 mb-3 mx-2'>✓ Stop-Flag gesetzt.</div>";
    } elseif (isset($_POST['restore_key'])) {
        $rk = strtolower($_POST['restore_key']); 
        // Diese Logik ist komplexer mit der neuen Methode und wird vorerst nicht implementiert,
        // da sie im UI ohnehin nicht verwendet wird.
        unset($_SESSION['deleted'][$rk]);
    }

    // Datei mit dem finalen Inhalt schreiben, wenn eine Aktion stattgefunden hat
    if (!empty($final_lines) || isset($_POST['save_all'])) {
        file_put_contents($config_file_path, implode("\n", $final_lines) . "\n", LOCK_EX);
    }
    
    // Config neu laden für die Anzeige
    $config = readConfig($config_file_path);
}

/* --- DEINE INDIVIDUELLE GRUPPIERUNG --- */
$groups = [
    "Luxtronik Energy Manager" => ["luxtronik", "luxtronik_ip", "auto_mode", "grid_start_limit", "stop_delay_minutes", "min_soc", "at_limit", "wws", "www", "hz", "price_boost_enable", "price_limit", "price_hard_limit", "price_min_duration", "price_max_daily", "manual_boost_max_duration", "manual_boost_min_soc", "wq_min_temp", "rl_source", "pv_pause_enable", "pv_pause_soc", "pv_pause_watt", "pv_pause_timeout_minutes", "pv_pause_min_at", "morning_boost_enable", "morning_boost_prio", "morning_boost_wb_power", "morning_boost_deadline", "morning_boost_target_soc", "morning_boost_min_hours", "morning_boost_min_pv_pct", "super_intelligence_enable", "super_intelligence_deadline", "telegram_token", "telegram_chat_id"],
    "Wallbox" => ["wallbox","wbmode","wbminlade","wbminsoc","wbmaxladestrom","wbminladestrom","wbhour","wbvon","wbbis","wbtest"],
    "Speicher / Ladesteuerung" => ["speichergroesse","speicherev","speichereta","unload","wrleistung","einspeiselimit","ladeschwelle","ladeende","ladeende2","ladeende2rampe","maximumladeleistung","powerfaktor","rb","re","le"],
    "Awattar / Preise" => ["awattar","awmwst","awnebenkosten","awaufschlag","awland","awreserve","awsimulation"],
    "Wärmepumpe" => ["wp","wpheizlast","wpheizgrenze","wpleistung","wpmin","wpmax","wpehz","wpzwe","wpzwepvon","shellyem_ip"],
    "Standort / Wetter" => ["openmeteo","hoehe","laenge","forecast1","forecast2","forecast3","forecast4","forecast5","forecastsoc","forecastconsumption","forecastreserve"],
    "Webansicht / Dashboard" => ["show_forecast","wbcostpowers","darkmode","pvatmosphere"],
    "System & Updates" => ["check_updates", "auto_update_enable", "auto_update_time", "server_ip", "server_port", "e3dc_user", "e3dc_password", "aes_password", "debug", "logfile", "wurzelzaehler", "ext1", "ext2", "wrsteuerung"],
    "Sonstiges" => []
];
?>
<?php
// Tooltip-Map für case-insensitive Suche vorbereiten
$tooltipMap = array_change_key_case($tooltips, CASE_LOWER);
?>

<style>
    .config-card { border-radius: 16px; margin-bottom: 12px; overflow: hidden; }
    .config-header { color: #22d3ee; font-weight: bold; padding: 12px 15px; border-bottom: 1px solid var(--bs-border-color); cursor: pointer; display: flex; justify-content: space-between; align-items: center; text-decoration: none; }
    
    /* Verbesserte Tooltips für Mobile */
    .config-label { font-family: monospace; color: var(--bs-secondary-color); font-size: 0.8rem; margin-bottom: 4px; display: inline-block; border-bottom: 1px dotted var(--bs-secondary-color); cursor: help; position: relative; }
    .config-label[data-tooltip]:active::after, 
    .config-label[data-tooltip]:hover::after {
        content: attr(data-tooltip);
        position: absolute;
        bottom: 130%;
        left: 0;
        background: var(--bs-body-color);
        color: var(--bs-body-bg);
        padding: 8px 12px;
        border-radius: 8px;
        font-size: 0.75rem;
        width: 280px;
        max-width: 85vw;
        z-index: 1000;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
        white-space: pre-wrap;
        line-height: 1.4;
    }
    
    .config-input { border-radius: 8px; font-size: 0.9rem; padding: 6px 10px; }
    
    #configSearch { border-radius: 8px; padding: 8px 12px; width: 100%; margin-bottom: 10px; }
    .ctrl-btns { display: flex; gap: 5px; margin-bottom: 15px; }
</style>

<div class="px-2 pb-5">
    <h5 class="fw-bold mb-3 text-body px-1">Konfiguration Editor</h5>
    <?= $message ?>

    <div class="px-1">
        <input type="text" id="configSearch" class="form-control" placeholder="🔍 Variable suchen..." onkeyup="filterConfig()">
        <div class="ctrl-btns">
            <button type="button" class="btn btn-sm btn-outline-secondary rounded-pill flex-grow-1 border-2 fw-bold" onclick="toggleAllGroups(false)">Alle schließen</button>
            <button type="button" class="btn btn-sm btn-outline-secondary rounded-pill flex-grow-1 border-2 fw-bold" onclick="toggleAllGroups(true)">Alle öffnen</button>
        </div>
    </div>

    <form method="POST">
        <div class="d-flex justify-content-between align-items-center mb-3 px-1">
            <span class="text-muted small">Tippe Namen für Hilfe</span>
            <button type="submit" name="save_all" class="btn btn-sm btn-info rounded-pill px-3 fw-bold text-dark shadow">💾 Speichern</button>
        </div>

        <?php 
        // Alle Gruppen-Keys sammeln und normalisieren (lowercase) für Rest-Erkennung
        $allGroupKeys = array_map('strtolower', array_merge(...array_values($groups)));

        foreach ($groups as $title => $keys): 
            $items = [];
            foreach ($keys as $k) {
                $lk = strtolower($k);
                if (isset($config[$lk])) {
                    // Wert aus Config (Datei) hat Vorrang
                    $items[$k] = $config[$lk];
                } elseif (isset($defaults[$k])) {
                    // Variable existiert nicht in Datei, aber wir kennen den Default -> Anzeigen!
                    $items[$k] = ['value' => $defaults[$k], 'commented' => false];
                }
            }
            if (empty($items)) continue;
            
            // SPEZIAL-LAYOUT für Luxtronik Energy Manager
            if ($title === "Luxtronik Energy Manager"):
                // Helper für Checkbox-Status
                $isTrue = function($k) use ($config) {
                    $v = $config[$k]['value'] ?? '0';
                    return ($v === '1' || strtolower($v) === 'true');
                };
                // Helper für Value
                $val = function($k) use ($config) {
                    return htmlspecialchars($config[$k]['value'] ?? '');
                };
                // Helper für Comment-Status
                $isCom = function($k) use ($config) {
                    return $config[$k]['commented'] ?? false;
                };
                
                $isLuxEnabled = $isTrue('luxtronik');
                $groupTitle = $isLuxEnabled ? $title : "Intelligentes Lademanagement";
        ?>
        <details class="card config-card config-group-el" id="group-luxtronik">
            <summary class="config-header"><i class="fas <?= $isLuxEnabled ? 'fa-water' : 'fa-magic' ?> me-2"></i><?= $groupTitle ?> <i class="fas fa-chevron-down small"></i></summary>
            <div class="p-3">
                
                <h6 class="text-muted small fw-bold mt-1 mb-2 border-bottom pb-1">Allgemeine Einstellungen</h6>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <div class="form-check form-switch config-item border-0 p-0 ps-5 mb-2">
                            <input type="hidden" name="values[luxtronik]" value="0">
                            <input class="form-check-input" type="checkbox" name="values[luxtronik]" value="1" id="conf_lux" <?= $isTrue('luxtronik') ? 'checked' : '' ?> style="transform: scale(1.2); margin-left: -2.5em;">
                            <label class="form-check-label ms-2 config-label" for="conf_lux" data-tooltip="<?= htmlspecialchars($tooltipMap['luxtronik'] ?? '') ?>">Luxtronik Integration aktivieren</label>
                        </div>
                        <div class="form-check form-switch config-item border-0 p-0 ps-5">
                            <input type="hidden" name="values[auto_mode]" value="0">
                            <input class="form-check-input" type="checkbox" name="values[auto_mode]" value="1" id="conf_auto" <?= $isTrue('auto_mode') ? 'checked' : '' ?> style="transform: scale(1.2); margin-left: -2.5em;">
                            <label class="form-check-label ms-2 config-label" for="conf_auto" data-tooltip="<?= htmlspecialchars($tooltipMap['auto_mode'] ?? '') ?>">Automatik-Regelung (Energy Manager)</label>
                        </div>
                    </div>
                    <?php if ($isLuxEnabled): ?>
                    <div class="col-md-6">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['luxtronik_ip'] ?? '') ?>">IP-Adresse Wärmepumpe</label>
                        <input type="text" name="values[luxtronik_ip]" class="form-control config-input" value="<?= $val('luxtronik_ip') ?>">
                    </div>
                    <?php endif; ?>
                </div>

                <?php if ($isLuxEnabled): ?>
                <h6 class="text-muted small fw-bold mt-4 mb-2 border-bottom pb-1">PV-Überschuss-Boost</h6>
                <div class="row g-2 mb-2">
                    <div class="col-md-6">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['grid_start_limit'] ?? '') ?>">Start-Grenze (Watt, negativ=Einspeisung)</label>
                        <input type="number" name="values[GRID_START_LIMIT]" class="form-control config-input" value="<?= $val('grid_start_limit') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['stop_delay_minutes'] ?? '') ?>">Stop-Verzögerung (Minuten)</label>
                        <input type="number" name="values[stop_delay_minutes]" class="form-control config-input" value="<?= $val('stop_delay_minutes') ?>">
                    </div>
                </div>
                <div class="row g-2 mb-2">
                    <div class="col-6 col-md-3">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['min_soc'] ?? '') ?>">Min SoC (%)</label>
                        <input type="number" name="values[MIN_SOC]" class="form-control config-input" value="<?= $val('min_soc') ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['at_limit'] ?? '') ?>">Außentemp. Limit (°C)</label>
                        <input type="number" step="0.1" name="values[AT_LIMIT]" class="form-control config-input" value="<?= $val('at_limit') ?>">
                    </div>
                    <div class="col-4 col-md-2">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['wws'] ?? '') ?>">WW Sommer</label>
                        <input type="number" step="0.1" name="values[WWS]" class="form-control config-input" value="<?= $val('wws') ?>">
                    </div>
                    <div class="col-4 col-md-2">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['www'] ?? '') ?>">WW Winter</label>
                        <input type="number" step="0.1" name="values[WWW]" class="form-control config-input" value="<?= $val('www') ?>">
                    </div>
                    <div class="col-4 col-md-2">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['hz'] ?? '') ?>">Heizung Soll</label>
                        <input type="number" step="0.1" name="values[HZ]" class="form-control config-input" value="<?= $val('hz') ?>">
                    </div>
                </div>

                <h6 class="text-muted small fw-bold mt-4 mb-2 border-bottom pb-1">Prognose-Pause (Aushungern)</h6>
                <div class="form-check form-switch mb-2 config-item border-0 p-0 ps-5">
                    <input type="hidden" name="values[pv_pause_enable]" value="0">
                    <input class="form-check-input" type="checkbox" name="values[pv_pause_enable]" value="1" id="conf_pv_pause" <?= $isTrue('pv_pause_enable') ? 'checked' : '' ?> style="transform: scale(1.2); margin-left: -2.5em;">
                    <label class="form-check-label ms-2 config-label" for="conf_pv_pause" data-tooltip="<?= htmlspecialchars($tooltipMap['pv_pause_enable'] ?? '') ?>">Pause vor PV-Ertrag aktivieren</label>
                </div>
                <div class="row g-2 mb-2">
                    <div class="col-6 col-md-3">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['pv_pause_soc'] ?? '') ?>">Min SoC</label>
                        <input type="number" name="values[pv_pause_soc]" class="form-control config-input" value="<?= $val('pv_pause_soc') ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['pv_pause_timeout_minutes'] ?? '') ?>">Timeout (Min)</label>
                        <input type="number" name="values[pv_pause_timeout_minutes]" class="form-control config-input" value="<?= $val('pv_pause_timeout_minutes') ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['pv_pause_watt'] ?? '') ?>">Erwartung (W)</label>
                        <input type="number" name="values[pv_pause_watt]" class="form-control config-input" value="<?= $val('pv_pause_watt') ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="config-label text-info" data-tooltip="<?= htmlspecialchars($tooltipMap['pv_pause_min_at'] ?? '') ?>">Min AT (°C)</label>
                        <input type="number" step="0.1" name="values[pv_pause_min_at]" class="form-control config-input" value="<?= $val('pv_pause_min_at') ?>">
                    </div>
                </div>
                <?php endif; ?>

                <h6 class="text-muted small fw-bold mt-4 mb-2 border-bottom pb-1">Intelligente Speicher-Entladung (Morgen)</h6>
                <div class="form-check form-switch mb-2 config-item border-0 p-0 ps-5">
                    <input type="hidden" name="values[morning_boost_enable]" value="0">
                    <input class="form-check-input" type="checkbox" name="values[morning_boost_enable]" value="1" id="conf_mb" <?= $isTrue('morning_boost_enable') ? 'checked' : '' ?> style="transform: scale(1.2); margin-left: -2.5em;">
                    <label class="form-check-label ms-2 config-label" for="conf_mb" data-tooltip="<?= htmlspecialchars($tooltipMap['morning_boost_enable'] ?? '') ?>">Aktivieren (bei hoher PV-Prognose)</label>
                </div>
                <div class="row g-2 mb-2">
                    <div class="col-6 col-md-4">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['morning_boost_prio'] ?? '') ?>">Priorität</label>
                        <select class="form-select config-input" name="values[morning_boost_prio]">
                            <option value="wallbox" <?= ($val('morning_boost_prio') === 'wallbox') ? 'selected' : '' ?>>Wallbox (Auto laden)</option>
                            <option value="wallbox_only" <?= ($val('morning_boost_prio') === 'wallbox_only') ? 'selected' : '' ?>>Nur Wallbox (kein Fallback)</option>
                            <option value="heatpump" <?= ($val('morning_boost_prio') === 'heatpump') ? 'selected' : '' ?>>Wärmepumpe (Boost)</option>
                        </select>
                    </div>
                    <div class="col-6 col-md-4">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['morning_boost_wb_power'] ?? '') ?>">WB Leistung (kW)</label>
                        <input type="number" step="0.1" name="values[morning_boost_wb_power]" class="form-control config-input" value="<?= $val('morning_boost_wb_power') ?>">
                    </div>
                    <div class="col-6 col-md-4">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['morning_boost_deadline'] ?? '') ?>">Ziel-Zeit (Stunde)</label>
                        <input type="number" name="values[morning_boost_deadline]" class="form-control config-input" value="<?= $val('morning_boost_deadline') ?>">
                    </div>
                    <div class="col-6 col-md-4">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['morning_boost_target_soc'] ?? '') ?>">Ziel-SoC (%)</label>
                        <input type="number" name="values[morning_boost_target_soc]" class="form-control config-input" value="<?= $val('morning_boost_target_soc') ?>">
                    </div>
                    <div class="col-6 col-md-4">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['morning_boost_min_hours'] ?? '') ?>">Bedingung: Dauer 99% (h)</label>
                        <input type="number" name="values[morning_boost_min_hours]" class="form-control config-input" value="<?= $val('morning_boost_min_hours') ?>">
                    </div>
                    <div class="col-6 col-md-4">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['morning_boost_min_pv_pct'] ?? '') ?>">Bedingung: PV-Ertrag (%)</label>
                        <input type="number" step="0.1" name="values[morning_boost_min_pv_pct]" class="form-control config-input" value="<?= $val('morning_boost_min_pv_pct') ?>">
                    </div>
                </div>

                <h6 class="text-muted small fw-bold mt-4 mb-2 border-bottom pb-1">Superintelligenz <span class="badge bg-warning text-dark" style="font-size:0.6em">Beta</span></h6>
                <div class="form-check form-switch mb-2 config-item border-0 p-0 ps-5">
                    <input type="hidden" name="values[super_intelligence_enable]" value="0">
                    <input class="form-check-input" type="checkbox" name="values[super_intelligence_enable]" value="1" id="conf_si" <?= $isTrue('super_intelligence_enable') ? 'checked' : '' ?> style="transform: scale(1.2); margin-left: -2.5em;">
                    <label class="form-check-label ms-2 config-label" for="conf_si" data-tooltip="<?= htmlspecialchars($tooltipMap['super_intelligence_enable'] ?? '') ?>">Aktivieren (Dynamische Wallbox-Entladung)</label>
                </div>
                <div class="row g-2 mb-2">
                    <div class="col-6">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['super_intelligence_deadline'] ?? '') ?>">Ziel-Zeit (Stunde)</label>
                        <input type="number" name="values[super_intelligence_deadline]" class="form-control config-input" value="<?= $val('super_intelligence_deadline') ?>">
                    </div>
                </div>

                <?php if ($isLuxEnabled): ?>
                <h6 class="text-muted small fw-bold mt-4 mb-2 border-bottom pb-1">Strompreis-Boost (aWATTar/Tibber)</h6>
                <div class="form-check form-switch mb-2 config-item border-0 p-0 ps-5">
                    <input type="hidden" name="values[price_boost_enable]" value="0">
                    <input class="form-check-input" type="checkbox" name="values[price_boost_enable]" value="1" id="conf_pb" <?= $isTrue('price_boost_enable') ? 'checked' : '' ?> style="transform: scale(1.2); margin-left: -2.5em;">
                    <label class="form-check-label ms-2 config-label" for="conf_pb" data-tooltip="<?= htmlspecialchars($tooltipMap['price_boost_enable'] ?? '') ?>">Strompreis-Boost aktivieren</label>
                </div>
                <div class="row g-2 mb-2">
                    <div class="col-6 col-md-3">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['price_limit'] ?? '') ?>">Preis-Limit (ct)</label>
                        <input type="number" step="0.1" name="values[price_limit]" class="form-control config-input" value="<?= $val('price_limit') ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="config-label text-success" data-tooltip="<?= htmlspecialchars($tooltipMap['price_hard_limit'] ?? '') ?>">Zwangs-Limit (ct)</label>
                        <input type="number" step="0.1" name="values[price_hard_limit]" class="form-control config-input" value="<?= $val('price_hard_limit') ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['price_min_duration'] ?? '') ?>">Min. Dauer (Min)</label>
                        <input type="number" name="values[price_min_duration]" class="form-control config-input" value="<?= $val('price_min_duration') ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['price_max_daily'] ?? '') ?>">Max. pro Tag (Min)</label>
                        <input type="number" name="values[price_max_daily]" class="form-control config-input" value="<?= $val('price_max_daily') ?>">
                    </div>
                </div>
                <?php endif; ?>

                <h6 class="text-muted small fw-bold mt-4 mb-2 border-bottom pb-1">Manuelle Steuerung & Schutz</h6>
                <div class="row g-2 mb-2">
                    <div class="col-6">
                        <label class="config-label text-warning" data-tooltip="<?= htmlspecialchars($tooltipMap['manual_boost_min_soc'] ?? '') ?>">Min-SoC bei Entladung (%)</label>
                        <input type="number" name="values[manual_boost_min_soc]" class="form-control config-input" value="<?= $val('manual_boost_min_soc') ?>">
                    </div>
                    <?php if ($isLuxEnabled): ?>
                    <div class="col-6">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['manual_boost_max_duration'] ?? '') ?>">Man. Boost Dauer (Min)</label>
                        <input type="number" name="values[manual_boost_max_duration]" class="form-control config-input" value="<?= $val('manual_boost_max_duration') ?>">
                    </div>
                    <div class="col-6">
                        <label class="config-label text-danger" data-tooltip="<?= htmlspecialchars($tooltipMap['wq_min_temp'] ?? '') ?>">WQ Min-Temp (°C)</label>
                        <input type="number" step="0.1" name="values[wq_min_temp]" class="form-control config-input" value="<?= $val('wq_min_temp') ?>">
                    </div>
                    <div class="col-6">
                        <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['rl_source'] ?? '') ?>">Sensor Rücklauf</label>
                        <select class="form-select config-input" name="values[rl_source]">
                            <option value="internal" <?= ($val('rl_source') === 'internal') ? 'selected' : '' ?>>Intern (Ruecklauf_Ist)</option>
                            <option value="external" <?= ($val('rl_source') === 'external') ? 'selected' : '' ?>>Extern (Ruecklauf_Extern)</option>
                        </select>
                    </div>
                    <?php endif; ?>
                </div>

                <h6 class="text-muted small fw-bold mt-4 mb-2 border-bottom pb-1">Benachrichtigungen</h6>
                <?php if (file_exists('/usr/local/bin/boot_notify.sh')): ?>
                    <div class="alert alert-light border small py-2 mb-2 text-muted">
                        <i class="fas fa-shield-alt text-success me-2"></i>Verwende zentrale Watchdog-Konfiguration.
                        <div class="mt-1" style="font-size:0.75em">Änderungen bitte über den Installer (Menü 15) vornehmen.</div>
                    </div>
                <?php else: ?>
                <div class="mb-2">
                    <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['telegram_token'] ?? '') ?>">Telegram Bot Token</label>
                    <input type="text" name="values[telegram_token]" class="form-control config-input" value="<?= $val('telegram_token') ?>" placeholder="z.B. 123:ABC...">
                </div>
                <div class="mb-2">
                    <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap['telegram_chat_id'] ?? '') ?>">Telegram Chat ID</label>
                    <input type="text" name="values[telegram_chat_id]" class="form-control config-input" value="<?= $val('telegram_chat_id') ?>" placeholder="z.B. 123456789">
                </div>
                <?php endif; ?>

            </div>
        </details>
        <?php 
            continue; // Standard-Rendering für diese Gruppe überspringen
            endif; 
        ?>
        <details class="card config-card config-group-el">
            <summary class="config-header"><?= $title ?> <i class="fas fa-chevron-down small"></i></summary>
            <div class="p-3">
                <div class="row g-3">
                <?php foreach ($items as $key => $data): ?>
                    <div class="col-12 col-md-6 col-xl-4 config-item" data-search-key="<?= $key ?>">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap[$key] ?? 'Keine Beschreibung.') ?>"><?= $key ?></label>
                            <div class="d-flex align-items-center gap-2">
                                <input type="checkbox" name="comments[]" value="<?= $key ?>" class="form-check-input small" title="Auskommentieren" style="accent-color: #22d3ee;" <?= $data['commented'] ? 'checked':'' ?>>
                            </div>
                        </div>
                        <div class="input-group input-group-sm">
                            <input type="text" name="values[<?= $key ?>]" class="form-control config-input" 
                                   value="<?= htmlspecialchars($data['value']) ?>" 
                                   placeholder="Standard: <?= $defaults[$key] ?? '' ?>">
                            <button type="submit" name="delete_key" value="<?= $key ?>" class="btn btn-outline-secondary border-secondary-subtle" title="Löschen"><i class="fas fa-trash text-danger"></i></button>
                        </div>
                    </div>
                <?php endforeach; ?>
                </div>
            </div>
        </details>
        <?php endforeach; ?>

        <?php $rest = array_diff_key($config, array_flip($allGroupKeys), ['stop' => '']);
        if (!empty($rest)): ?>
        <details class="card config-card config-group-el">
            <summary class="config-header">Weitere Parameter <i class="fas fa-chevron-down small"></i></summary>
            <div class="p-3">
                <div class="row g-3">
                <?php foreach ($rest as $key => $data): ?>
                    <div class="col-12 col-md-6 col-xl-4 config-item" data-search-key="<?= strtolower($key) ?>">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap[strtolower($key)] ?? 'Keine Beschreibung.') ?>"><?= $key ?></label>
                            <input type="checkbox" name="comments[]" value="<?= $key ?>" class="form-check-input small" title="Auskommentieren" <?= $data['commented'] ? 'checked':'' ?>>
                        </div>
                        <div class="input-group input-group-sm">
                            <input type="text" name="values[<?= $key ?>]" class="form-control config-input" value="<?= htmlspecialchars($data['value']) ?>">
                            <button type="submit" name="delete_key" value="<?= $key ?>" class="btn btn-outline-secondary border-secondary-subtle" title="Löschen"><i class="fas fa-trash text-danger"></i></button>
                        </div>
                    </div>
                <?php endforeach; ?>
                </div>
            </div>
        </details>
        <?php endif; ?>

        <details class="card config-card config-group-el">
            <summary class="config-header">Strompreise (Manuell) <i class="fas fa-chevron-down small"></i></summary>
            <div class="p-3">
                <?php
                $price_file_path = $install_path . 'e3dc.strompreise.txt';
                $price_content = file_exists($price_file_path) ? file_get_contents($price_file_path) : '';
                ?>
                <label class="config-label" data-tooltip="Manuelle Strompreise für den Fall, dass aWATTar nicht genutzt wird. Format: 'Stunde Preis', z.B. '8 25.5'. Kommentare mit #.">e3dc.strompreise.txt</label>
                <textarea name="strompreise" class="form-control config-input" rows="10" placeholder="# Stunde Preis (ct/kWh)&#10;8 25.5&#10;18 30.2"><?= htmlspecialchars($price_content) ?></textarea>
                <div class="form-text text-muted small mt-2">
                    Diese Preise werden verwendet, wenn `awattar = 0` gesetzt ist. Der Strompreis-Wizard (Menü 9) bietet eine geführte Eingabe.
                </div>
            </div>
        </details>

        <details class="card config-card config-group-el">
            <summary class="config-header">Neue Variable hinzufügen <i class="fas fa-chevron-down small"></i></summary>
            <div class="p-3">
                <div class="mb-2">
                    <label for="new_key_input" class="config-label" data-tooltip="Name der neuen Variable. Wird in Kleinbuchstaben umgewandelt.">Variablenname</label>
                    <input type="text" id="new_key_input" name="new_key" class="form-control config-input" placeholder="z.B. meine_neue_variable">
                </div>
                <div class="mb-2">
                    <label for="new_value_input" class="config-label" data-tooltip="Wert der neuen Variable.">Wert</label>
                    <input type="text" id="new_value_input" name="new_value" class="form-control config-input" placeholder="z.B. true oder 123">
                </div>
                <div class="form-text text-muted small">
                    Die neue Variable wird beim Speichern hinzugefügt und erscheint danach in der Gruppe "Weitere Parameter". Um sie einer anderen Gruppe zuzuordnen, muss die Datei <code>config_editor.php</code> manuell bearbeitet werden.
                </div>
            </div>
        </details>

        <?php $isOn = (($config['stop']['value'] ?? '0') === '1'); $stopColor = $isOn ? "#f43f5e" : "#10b981"; ?>
        <div class="card config-card p-4 text-center">
            <h6 class="text-muted small mb-3 fw-bold">Screen stop</h6>
            <div class="d-flex flex-column flex-md-row justify-content-center align-items-center gap-4">
                <div style="width: 65px; height: 65px; border-radius: 50%; background: <?= $stopColor ?>; display: flex; flex-direction: column; align-items: center; justify-content: center; font-weight: bold; box-shadow: 0 0 15px <?= $stopColor ?>40;">
                    <span style="font-size: 0.6rem; text-transform: uppercase;">Status</span>
                    <span><?= $isOn ? 'EIN':'AUS' ?></span>
                </div>
                <button type="submit" name="stop_set" value="1" class="btn btn-outline-danger rounded-pill px-5 fw-bold border-2 shadow-sm">STOP AKTIVIEREN (EIN)</button>
                <button type="submit" name="stop_set" value="0" class="btn btn-outline-success rounded-pill px-5 fw-bold border-2 shadow-sm">STOP DEAKTIVIEREN (AUS)</button>
            </div>
        </div>

        <button type="submit" name="save_all" value="1" class="btn btn-info w-100 rounded-pill py-3 fw-bold text-dark mt-3 shadow">💾 ALLE ÄNDERUNGEN SPEICHERN</button>
    </form>
</div>

<script>
function filterConfig() {
    var input = document.getElementById('configSearch');
    var filter = input.value.toLowerCase();
    var groups = document.getElementsByClassName('config-group-el');

    for (var j = 0; j < groups.length; j++) {
        var groupTitle = groups[j].querySelector('.config-header').textContent.toLowerCase();
        var items = groups[j].querySelectorAll('.config-item');
        var groupMatches = groupTitle.includes(filter);
        
        for (var i = 0; i < items.length; i++) {
            var key = items[i].getAttribute('data-search-key');
            // Zeige Item, wenn Key ODER Gruppenname passt
            items[i].style.display = (key.includes(filter) || groupMatches) ? "" : "none";
        }

        var groupItems = groups[j].querySelectorAll('.config-item');
        var hasVisibleItems = false;
        for (var k = 0; k < groupItems.length; k++) {
            if (groupItems[k].style.display !== 'none') {
                hasVisibleItems = true;
                break;
            }
        }

        if (filter.length > 0) {
            groups[j].open = hasVisibleItems;
            groups[j].style.display = hasVisibleItems ? "" : "none";
        } else {
            groups[j].open = false;
            groups[j].style.display = "";
        }
    }
}

function toggleAllGroups(open) {
    var groups = document.getElementsByClassName('config-group-el');
    for (var i = 0; i < groups.length; i++) {
        groups[i].open = open;
    }
}

// Installer / Diagramm Update Logik
function checkInstallerUpdate() {
    fetch('index.php?action=check_self_update')
    .then(r => r.json())
    .then(data => {
        const badge = document.getElementById('update-badge-installer');
        const btn = document.getElementById('btn-update-installer');
        if (data.success && data.missing > 0) {
            if(badge) {
                badge.style.display = 'inline-block';
                badge.innerText = data.missing;
            }
            if(btn) {
                btn.classList.remove('btn-outline-info');
                btn.classList.add('btn-info', 'text-dark');
            }
        }
    });
}
// Beim Laden prüfen
document.addEventListener('DOMContentLoaded', checkInstallerUpdate);

function startInstallerUpdate() {
    if (!confirm("Möchtest du das Web-Interface & Diagramm-Skripte aktualisieren?")) return;
    
    const btn = document.getElementById('btn-update-installer');
    const origText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Starte...';
    btn.disabled = true;
    
    fetch('index.php?action=run_self_update')
    .then(r => r.json())
    .then(data => {
        alert(data.message + "\nBitte warte ca. 30 Sekunden und lade die Seite dann neu.");
        setTimeout(() => { location.reload(); }, 5000);
    })
    .catch(err => { alert("Fehler: " + err); btn.innerHTML = origText; btn.disabled = false; });
}

// startSystemUpdate() ist nun in solar.js verfügbar und kann direkt im onclick verwendet werden.
// Der Button #btn-update-config ruft es bereits auf.

// Auto-Open Group based on URL
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('expand') === 'luxtronik') {
        const el = document.getElementById('group-luxtronik');
        if (el) {
            el.open = true;
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
});
</script>
