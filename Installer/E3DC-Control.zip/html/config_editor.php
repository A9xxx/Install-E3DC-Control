<?php
session_start();

/* ------------------ INIT ------------------ */
if (!isset($_SESSION['deleted'])) {
    $_SESSION['deleted'] = [];
}

$config_file_path = '/home/pi/E3DC-Control/e3dc.config.txt';
$message = '';
$read_error = false;

// Prüfe Dateizugriff direkt
if (!is_readable($config_file_path)) {
    $file_status = is_file($config_file_path);
    $parent_writable = is_writable(dirname($config_file_path));
    
    echo "<div style='background: #1e1e1e; border: 1px solid #555; border-radius: 6px; padding: 20px; margin: 20px; color: #fff; max-width: 900px;'>";
    echo "<div style='padding: 15px; background: #3d1f1f; border-left: 4px solid #f44336; border-radius: 4px; margin-bottom: 20px;'>";
    echo "<strong style='color: #f44336; font-size: 18px;'>⚠ Schreibberechtigung fehlt</strong><br>";
    echo "Datei: <strong>" . htmlspecialchars($config_file_path) . "</strong><br>";
    echo "Datei existiert: " . ($file_status ? "<span style='color: #4caf50;'>✓ ja</span>" : "<span style='color: #f44336;'>✗ nein</span>") . "<br>";
    echo "Eltern-Verzeichnis schreibbar: " . ($parent_writable ? "<span style='color: #4caf50;'>✓ ja</span>" : "<span style='color: #f44336;'>✗ nein</span>");
    echo "</div>";
    
    echo "<strong style='display: block; margin-bottom: 15px; font-size: 16px;'>📋 Lösungsmöglichkeiten:</strong>";
    
    echo "<div style='margin-bottom: 15px;'>";
    echo "<strong>1. Berechtigungen für die Konfigurationsdatei reparieren:</strong><br>";
    echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
    echo "sudo chown www-data:www-data " . htmlspecialchars($config_file_path) . "<br>";
    echo "sudo chmod 644 " . htmlspecialchars($config_file_path);
    echo "</code>";
    echo "</div>";
    
    echo "<div style='margin-bottom: 15px;'>";
    echo "<strong>2. Oder gesamtes Verzeichnis reparieren:</strong><br>";
    echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
    echo "sudo chown -R www-data:www-data " . htmlspecialchars(dirname($config_file_path)) . "<br>";
    echo "sudo chmod -R 755 " . htmlspecialchars(dirname($config_file_path));
    echo "</code>";
    echo "</div>";
    
    echo "<div>";
    echo "<strong>3. Aktuelle Berechtigungen prüfen:</strong><br>";
    echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
    echo "ls -la " . htmlspecialchars(dirname($config_file_path));
    echo "</code>";
    echo "</div>";
    
    echo "</div>";
    exit;
}

/* ------------------ FUNKTIONEN ------------------ */
function readConfig($file_path) {
    if (!file_exists($file_path)) {
        return [];
    }

    $lines = file($file_path, FILE_IGNORE_NEW_LINES);
    $config = [];

    foreach ($lines as $line) {
        if (trim($line) === '') continue;

        $commented = false;

        if (strpos(ltrim($line), '#') === 0) {
            $commented = true;
            $line = ltrim($line, '#');
        }

        if (strpos($line, '//') !== false) {
            $line = substr($line, 0, strpos($line, '//'));
        }

        if (strpos($line, '=') === false) continue;

        list($key, $value) = explode('=', $line, 2);

        $config[trim($key)] = [
            'value'     => trim($value),
            'commented' => $commented
        ];
    }

    return $config;
}

function writeConfig($file_path, $config, $comments) {
    $file_exists = is_file($file_path);
    $file_writable = $file_exists ? is_writable($file_path) : false;
    $parent_dir = dirname($file_path);
    $parent_writable = is_writable($parent_dir);

    if (($file_exists && !$file_writable) || (!$file_exists && !$parent_writable)) {
        echo "<div style='background: #1e1e1e; border: 1px solid #555; border-radius: 6px; padding: 20px; margin: 20px; color: #fff; max-width: 900px;'>";
        echo "<div style='padding: 15px; background: #3d1f1f; border-left: 4px solid #f44336; border-radius: 4px; margin-bottom: 20px;'>";
        echo "<strong style='color: #f44336; font-size: 18px;'>⚠ Schreibberechtigung fehlt</strong><br>";
        echo "Datei: <strong>" . htmlspecialchars($file_path) . "</strong><br>";
        echo "Datei existiert: " . ($file_exists ? "<span style='color: #4caf50;'>✓ ja</span>" : "<span style='color: #f44336;'>✗ nein</span>") . "<br>";
        echo "Eltern-Verzeichnis schreibbar: " . ($parent_writable ? "<span style='color: #4caf50;'>✓ ja</span>" : "<span style='color: #f44336;'>✗ nein</span>");
        echo "</div>";

        echo "<strong style='display: block; margin-bottom: 15px; font-size: 16px;'>📋 Lösungsmöglichkeiten:</strong>";

        echo "<div style='margin-bottom: 15px;'>";
        echo "<strong>1. Berechtigungen für die Konfigurationsdatei reparieren:</strong><br>";
        echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        echo "sudo chown www-data:www-data " . htmlspecialchars($file_path) . "<br>";
        echo "sudo chmod 644 " . htmlspecialchars($file_path);
        echo "</code>";
        echo "</div>";

        echo "<div style='margin-bottom: 15px;'>";
        echo "<strong>2. Oder gesamtes Verzeichnis reparieren:</strong><br>";
        echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        echo "sudo chown -R www-data:www-data " . htmlspecialchars($parent_dir) . "<br>";
        echo "sudo chmod -R 755 " . htmlspecialchars($parent_dir);
        echo "</code>";
        echo "</div>";

        echo "<div>";
        echo "<strong>3. Aktuelle Berechtigungen prüfen:</strong><br>";
        echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        echo "ls -la " . htmlspecialchars($parent_dir);
        echo "</code>";
        echo "</div>";

        echo "</div>";
        exit;
    }

    $content = "";
    foreach ($config as $key => $attrs) {
        $line = $key . " = " . $attrs['value'];
        if (in_array($key, $comments)) {
            $line = "#" . $line;
        }
        $content .= $line . "\n";
    }
    
    if (@file_put_contents($file_path, $content, LOCK_EX) === false) {
        $parent_dir = dirname($file_path);
        $parent_writable = is_writable($parent_dir);
        
        echo "<div style='background: #1e1e1e; border: 1px solid #555; border-radius: 6px; padding: 20px; margin: 20px; color: #fff; max-width: 900px;'>";
        echo "<div style='padding: 15px; background: #3d1f1f; border-left: 4px solid #f44336; border-radius: 4px; margin-bottom: 20px;'>";
        echo "<strong style='color: #f44336; font-size: 18px;'>⚠ Schreibberechtigung fehlt</strong><br>";
        echo "Datei: <strong>" . htmlspecialchars($file_path) . "</strong><br>";
        echo "Eltern-Verzeichnis schreibbar: " . ($parent_writable ? "<span style='color: #4caf50;'>✓ ja</span>" : "<span style='color: #f44336;'>✗ nein</span>");
        echo "</div>";
        
        echo "<strong style='display: block; margin-bottom: 15px; font-size: 16px;'>📋 Lösungsmöglichkeiten:</strong>";
        
        echo "<div style='margin-bottom: 15px;'>";
        echo "<strong>1. Berechtigungen für die Konfigurationsdatei reparieren:</strong><br>";
        echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        echo "sudo chown www-data:www-data " . htmlspecialchars($file_path) . "<br>";
        echo "sudo chmod 644 " . htmlspecialchars($file_path);
        echo "</code>";
        echo "</div>";
        
        echo "<div style='margin-bottom: 15px;'>";
        echo "<strong>2. Oder gesamtes Verzeichnis reparieren:</strong><br>";
        echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        echo "sudo chown -R www-data:www-data " . htmlspecialchars(dirname($file_path)) . "<br>";
        echo "sudo chmod -R 755 " . htmlspecialchars(dirname($file_path));
        echo "</code>";
        echo "</div>";
        
        echo "<div>";
        echo "<strong>3. Aktuelle Berechtigungen prüfen:</strong><br>";
        echo "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        echo "ls -la " . htmlspecialchars(dirname($file_path));
        echo "</code>";
        echo "</div>";
        
        echo "</div>";
        exit;
    }
    
    return true; // Erfolg
}

/* ------------------ CONFIG LADEN ------------------ */
$config = [];
if (!$read_error) {
    $config = readConfig($config_file_path);
}

/* ------------------ POST ------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['restore_key'])) {
        $k = $_POST['restore_key'];
        if (isset($_SESSION['deleted'][$k])) {
            $config[$k] = $_SESSION['deleted'][$k];
            unset($_SESSION['deleted'][$k]);
        }
    }

    if (isset($_POST['delete_key'])) {
        $k = $_POST['delete_key'];
        if (isset($config[$k])) {
            $_SESSION['deleted'][$k] = $config[$k];
            unset($config[$k]);
        }
    }

    $comments = $_POST['comments'] ?? [];

    if (isset($_POST['values'])) {
        foreach ($_POST['values'] as $k => $v) {
            if (isset($config[$k])) {
                $config[$k]['value'] = $v;
                $config[$k]['commented'] = in_array($k, $comments);
            }
        }
    }

    if (!empty($_POST['new_key'])) {
        $k = trim($_POST['new_key']);
        $v = trim($_POST['new_value'] ?? '');
        if ($k !== '' && !isset($config[$k])) {
            $config[$k] = ['value' => $v, 'commented' => false];
        }
    }
    // Stop EIN/AUS Buttons
    if (isset($_POST['stop_set'])) {
        $val = $_POST['stop_set'] === '1' ? '1' : '0';

        if (!isset($config['stop'])) {
            $config['stop'] = [
                'value' => $val,
                'commented' => false
            ];
        } else {
            $config['stop']['value'] = $val;
        }
    }
    
    // Speichern mit Fehlerbehandlung
    $write_result = writeConfig($config_file_path, $config, $comments);
    if ($write_result === true) {
        $message = successMessage("✓ Konfiguration erfolgreich gespeichert!");
    } else {
        $message = $write_result; // HTML-Fehlermeldung
    }
}

// Gruppendefinitionen
$groups = [
    "Wallbox" => [
        "wallbox","wbmode","wbminlade","wbminSoC","wbmaxladestrom","wbminladestrom",
        "Wbhour","Wbvon","Wbbis","wbtest"
    ],
    "Speicher / Ladesteuerung" => [
        "speichergroesse","speicherEV","speicherETA","unload","wrleistung","einspeiselimit",
        "ladeschwelle","unload","ladeende","ladeende2","Ladeende2rampe","maximumLadeleistung",
        "powerfaktor","rb","re","le"
    ],
    "Awattar / Preise" => [
        "awattar","awmwst","awnebenkosten","awaufschlag","awland","awreserve","awsimulation"
    ],
    "Wärmepumpe" => [
        "WP","WPHeizlast","WPHeizgrenze","WPLeistung","WPMin","WPMax",
        "WPehz","WPZWE","WPZWEPVon","shellyem_ip"
    ],
    "Standort / Wetter" => [
        "openmeteo","hoehe","laenge","forecast1","ForecastSoc","ForecastConsumption","ForecastReserve"
    ],
    "System" => [
        "server_ip","server_port","e3dc_user","e3dc_password","aes_password","debug","logfile","ext1","ext2"
    ],
    "Sonstiges" => [] // wird automatisch gefüllt
];

$tooltips = [
    "wallbox" => "Aktiviert oder deaktiviert die Wallbox-Steuerung.",
    "wbmode" => "Lademodus der Wallbox (z. B. PV-Überschuss, Zeitfenster, etc.).",
           "wbminlade" => "Minimale Ladeleistung der Wallbox in Watt.",
           "wbminSoC" => "Unterer SoC-Grenzwert für Entladen über die Wallbox.",
           "wbmaxladestrom" => "Maximaler Ladestrom der Wallbox in Ampere.",
           "wbminladestrom" => "Minimaler Ladestrom der Wallbox in Ampere.",
    "Wbhour" => "Stunden, die im günstigsten Preisfenster geladen werden sollen.",
    "Wbvon" => "Startzeit des Ladefensters.",
    "Wbbis" => "Endzeit des Ladefensters.",

    "speichergroesse" => "Nutzbare Kapazität des Speichers in kWh.",
    "speicherEV" => "Eigenverbrauch des Wechselrichters in Watt.",
    "speicherETA" => "Wirkungsgrad des Speichers.",
    "unload" => "Bis zu diesem SoC wird morgens entladen.",
    "ladeschwelle" => "Bis zu diesem SoC wird morgens maximal geladen.",
    "ladeende" => "Erster Ladeendpunkt (SoC).",
    "ladeende2" => "Zweiter Ladeendpunkt (SoC).",
    "Ladeende2rampe" => "Beschleunigung der Ladung zwischen Ladeende1 und Ladeende2.",
    "maximumLadeleistung" => "Maximale Ladeleistung des Speichers in Watt.",

    "awattar" => "0 = aus, 1 = Netzladen aktiv, 2 = ohne Netzladen.",
    "awmwst" => "Mehrwertsteuer in Prozent.",
    "awnebenkosten" => "Nebenkosten pro kWh (brutto).",
    "awaufschlag" => "Prozentualer Aufschlag auf den Börsenpreis.",
    "awland" => "Land für Preisberechnung.",
    "awreserve" => "Reserve-SoC für Verbrauchsprognose.",
    "awsimulation" => "Zusätzliche PV-Spalte in Simulation aktivieren.",

    "WP" => "Wärmepumpe vorhanden = true.",
    "WPHeizlast" => "Heizlast der Wärmepumpe.",
    "WPHeizgrenze" => "Temperaturgrenze für Heizbetrieb.",
    "WPLeistung" => "Elektrische Leistung der WP.",
    "WPMin" => "Minimale elektrische Leistung.",
    "WPMax" => "Maximale elektrische Leistung.",
    "WPehz" => "Leistung der elektrischen Zusatzheizung.",
    "WPZWE" => "ZWE-Modus.",
    "WPZWEPVon" => "Temperaturgrenze für ZWE.",

    "hoehe" => "Geografische Höhe für Sonnenstandsberechnung.",
    "laenge" => "Geografische Länge für Sonnenstandsberechnung.",
    "forecast1" => "Dachneigung/Azimuth/kWp.",
    "ForecastSoc" => "Faktor für beschleunigtes Laden.",
    "ForecastConsumption" => "Faktor für Verbrauchsprognose.",
    "ForecastReserve" => "Reserve in Prozent.",

    "AWtest" => "Damit kann man das Akkuladen aus dem Netz einschalten = 3, anschließend wieder auf = 0 setzen oder auskommentieren =  4 wird die Speicherleistung auf 0 gesetzt"

];

$defaults = [
    "wallbox" => "true",
    "wbmode" => "4",
    "wbminlade" => "1200",
    "wbminSoC" => "70",
    "wbmaxladestrom" => "32",
    "wbminladestrom" => "6",
    "Wbhour" => "0",
    "Wbvon" => "20",
    "Wbbis" => "6",

    "speichergroesse" => "35",
    "speicherEV" => "80",
    "speicherETA" => "0.97",
    "unload" => "65",
    "ladeschwelle" => "70",
    "ladeende" => "85",
    "ladeende2" => "91",
    "Ladeende2rampe" => "2",
    "maximumLadeleistung" => "12500",

    "awattar" => "1",
    "awmwst" => "19",
    "awnebenkosten" => "15.915",
    "awaufschlag" => "12",
    "awland" => "DE",
    "awreserve" => "20",
    "awsimulation" => "1",

    "WP" => "true",
    "WPHeizlast" => "18",
    "WPHeizgrenze" => "13",
    "WPLeistung" => "20",
    "WPMin" => "0.5",
    "WPMax" => "4.7",
    "WPehz" => "12 kW",
    "WPZWE" => "-99",
    "WPZWEPVon" => "25",

    "wrleistung" => "11700",
    "hoehe" => "48.60442",
    "laenge" => "13.41513",
    "forecast1" => "40/-50/15.4",
    "ForecastSoc" => "1.2",
    "ForecastConsumption" => "1",
    "ForecastReserve" => "5",

    "stop" => "0"
];

// CSS nur für diese Seite
echo "

<script>
const DEFAULTS = <?= json_encode($defaults, JSON_UNESCAPED_UNICODE) ?>;
</script>

<style>
.config-container {
    width: 100%;
    max-width: 900px;
    margin: auto;
}

/* Suchfeld */
.config-search {
    width: 100%;
    padding: 12px;
    margin-bottom: 20px;
    border-radius: 6px;
    border: 1px solid #555;
    background-color: #1e1e1e;
    color: #fff;
    font-size: 16px;
}

/* Buttons oben */
.config-top-buttons {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
}

.config-small-button {
    flex: 1;
    padding: 10px;
    background-color: #444;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 15px;
}

.config-small-button:hover {
    background-color: #666;
}

/* Accordion */
.config-accordion details {
    background-color: #2e2e2e;
    border: 1px solid #444;
    border-radius: 6px;
    margin-bottom: 12px;
}

.config-accordion summary {
    cursor: pointer;
    padding: 12px;
    font-size: 18px;
    color: #4da3ff;
    font-weight: bold;
    list-style: none;
}

.config-accordion summary::-webkit-details-marker {
    display: none;
}

.config-accordion summary:after {
    content: '▸';
    float: right;
    transition: transform 0.2s ease;
}

.config-accordion details[open] summary:after {
    transform: rotate(90deg);
}

.config-item {
    padding: 12px;
    border-top: 1px solid #555;
    position: relative;
}

/* Tooltip */
.tooltip-icon {
    display: inline-block;
    background-color: #0073e6;
    color: white;
    border-radius: 50%;
    width: 18px;
    height: 18px;
    text-align: center;
    line-height: 18px;
    font-size: 12px;
    margin-left: 6px;
    cursor: pointer;
}

.tooltip-box {
    display: none;
    position: absolute;
    left: 10px;
    right: 10px;
    top: 45px;
    background-color: #1e1e1e;
    border: 1px solid #555;
    padding: 10px;
    border-radius: 6px;
    color: #fff;
    font-size: 14px;
    z-index: 10;
}

.tooltip-icon:hover + .tooltip-box {
    display: block;
}

@media (max-width: 600px) {
    .tooltip-box {
        top: auto;
        bottom: -10px;
    }
}

/* Highlight */
.highlight {
    background-color: #004a77 !important;
    border-color: #1e90ff !important;
}

/* Geänderte Felder */
.changed {
    background-color: #003366 !important;
    border-color: #1e90ff !important;
}

/* Reset-Button */
.reset-button {
    position: absolute;
    right: 10px;
    top: 45px;
    background-color: #555;
    color: white;
    border: none;
    border-radius: 4px;
    padding: 4px 8px;
    cursor: pointer;
    font-size: 12px;
}

.reset-button:hover {
    background-color: #777;
}

.config-input {
    width: 100%;
    padding: 10px;
    border-radius: 4px;
    border: 1px solid #555;
    background-color: #1e1e1e;
    color: #fff;
}

.config-checkbox {
    transform: scale(1.3);
    margin-right: 10px;
}

.config-button {
    padding: 12px 20px;
    background-color: #0073e6;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-top: 25px;
    width: 100%;
    font-size: 16px;
}

.config-button:hover {
    background-color: #005b8e;
}

.delete-button {
    position: absolute;
    right: 130px;
    top: 45px;
    background-color: #a00000;
    color: white;
    border: none;
    border-radius: 4px;
    padding: 4px 8px;
    cursor: pointer;
    font-size: 12px;
}

.delete-button:hover {
    background-color: #c00000;
}

.delete-confirm {
    display: none;
    background-color: #222;
    border: 1px solid #555;
    padding: 10px;
    border-radius: 6px;
    margin-top: 10px;
}

.confirm-yes {
    background-color: #a00000;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 4px;
    cursor: pointer;
    margin-right: 10px;
}

.confirm-no {
    background-color: #555;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 4px;
    cursor: pointer;
}
</style>

<script>
// Live-Suche
function filterConfig() {
    const query = document.getElementById('configSearch').value.toLowerCase();
    const groups = document.querySelectorAll('.config-group');

    groups.forEach(group => {
        let hasMatch = false;
        const items = group.querySelectorAll('.config-item');

        items.forEach(item => {
            const key = item.getAttribute('data-key').toLowerCase();

            if (key.includes(query)) {
                item.style.display = 'block';
                item.classList.add('highlight');
                hasMatch = true;
            } else {
                item.style.display = 'none';
                item.classList.remove('highlight');
            }
        });

        if (hasMatch) {
            group.open = true;
            group.style.display = 'block';
        } else {
            group.style.display = query ? 'none' : 'block';
        }
    });
}

function setDefault(btn, value) {
    const input = btn.parentElement.querySelector('.config-input');
    input.value = value;
    markChanged(input);
}

function setDefaultForNew() {
    const key = document.getElementById('new_key_field').value;
    if (DEFAULTS[key] !== undefined) {
        document.getElementById('new_value_field').value = DEFAULTS[key];
    }
}

function fillDefaultForNew(select) {
    const key = select.value;
    document.getElementById('new_value_field').value = DEFAULTS[key] ?? '';
}

// Alle Gruppen öffnen
function openAll() {
    document.querySelectorAll('.config-group').forEach(g => g.open = true);
}

// Alle Gruppen schließen
function closeAll() {
    document.querySelectorAll('.config-group').forEach(g => g.open = false);
}

// Änderungsmarkierung
function markChanged(input) {
    const original = input.getAttribute('data-original');
    if (input.value !== original) {
        input.classList.add('changed');
    } else {
        input.classList.remove('changed');
    }
}

function confirmDelete(btn) {
    const box = btn.nextElementSibling;
    box.style.display = 'block';
}

function cancelDelete(btn) {
    const box = btn.parentElement;
    box.style.display = 'none';
}

// Reset-Funktion
function resetValue(btn) {
    const input = btn.parentElement.querySelector('.config-input');
    const original = input.getAttribute('data-original');
    input.value = original;
    input.classList.remove('changed');
}

// Nur geänderte anzeigen
function showChanged() {
    document.querySelectorAll('.config-item').forEach(item => {
        const input = item.querySelector('.config-input');
        if (!input.classList.contains('changed')) {
            item.style.display = 'none';
        } else {
            item.style.display = 'block';
            item.closest('.config-group').open = true;
        }
    });
}

// Alle anzeigen
function showAll() {
    document.querySelectorAll('.config-item').forEach(item => {
        item.style.display = 'block';
    });
    document.querySelectorAll('.config-group').forEach(g => g.style.display = 'block');
}
</script>
";

echo "<div class='config-container'>";
echo "<h1>E3DC Config Editor</h1>";

if (!empty($message)) {
    echo $message;
}

echo "<input type='text' id='configSearch' class='config-search' placeholder='🔍 Parameter suchen...' onkeyup='filterConfig()'>";

echo "<div class='config-top-buttons'>
        <button type='button' class='config-small-button' onclick='openAll()'>Alle öffnen</button>
        <button type='button' class='config-small-button' onclick='closeAll()'>Alle schließen</button>
        <button type='button' class='config-small-button' onclick='showChanged()'>Nur geänderte</button>
        <button type='button' class='config-small-button' onclick='showAll()'>Alle anzeigen</button>
      </div>";

echo "<form method='POST'>";
echo "<div class='config-accordion'>";

// Alle Keys, die explizit in Gruppen stehen
$assigned_keys = array_merge(...array_values($groups));

// Sonstiges automatisch füllen
foreach ($config as $key => $attrs) {
    if (!in_array($key, $assigned_keys)) {
        $groups['Sonstiges'][] = $key;
    }
}

foreach ($groups as $title => $keys) {

    echo "<details class='config-group'>";
    echo "<summary>$title</summary>";

    foreach ($keys as $key) {
        if (!isset($config[$key])) continue;

        $attrs = $config[$key];
        $tip = $tooltips[$key] ?? "";

        echo "<div class='config-item' data-key='$key'>";

        echo "<div style='display:flex; align-items:center; gap:10px; margin-bottom:5px;'>
                <input class='config-checkbox' type='checkbox' name='comments[]' value='$key' " . ($attrs['commented'] ? "checked" : "") . ">
                <span>auskommentieren</span>
              </div>";

        echo "<label class='config-label'>$key";

        if ($tip !== "") {
            echo "<span class='tooltip-icon'>i</span>";
            echo "<div class='tooltip-box'>$tip</div>";
        }

        echo "</label>";

echo "<input class='config-input' type='text' name='values[$key]' value='" . htmlspecialchars($attrs['value']) . "' data-original='" . htmlspecialchars($attrs['value']) . "' oninput='markChanged(this)'>";

if (isset($defaults[$key])) {
    echo "<button type='button' class='reset-button' style='right:70px;' onclick='setDefault(this, \"" . htmlspecialchars($defaults[$key]) . "\")'>Standard</button>";
}

echo "<button type='button' class='reset-button' onclick='resetValue(this)'>Reset</button>";

echo "<button type='button' class='delete-button' onclick='confirmDelete(this)' style='right:130px;background:#a00000;'>Löschen</button>";

echo "<div class='delete-confirm' style='display:none; margin-top:10px;'>
        <p>Variable <b>$key</b> wirklich löschen?</p>
        <button type='submit' name='delete_key' value='$key' class='confirm-yes'>Ja</button>
        <button type='button' class='confirm-no' onclick='cancelDelete(this)'>Nein</button>
      </div>";

        echo "</div>";
    }

    echo "</details>";
}

// Gruppe: Neu hinzufügen
echo "<details class='config-group'>";
echo "<summary>Neu hinzufügen</summary>";

echo "<div class='config-item'>";

echo "<label class='config-label'>Neue Variable</label>";
echo "<input class='config-input' type='text' name='new_key' placeholder='Variablenname'>";

echo "<label class='config-label' style='margin-top:15px;'>Wert</label>";
echo "<input class='config-input' type='text' name='new_value' placeholder='Wert'>";

echo "<button type='submit' class='config-small-button' style='margin-top:15px;width:100%;background:#0073e6;'>Hinzufügen</button>";

echo "</div>";
echo "</details>";

// Stop EIN/AUS Bereich
$stopValue = isset($config['stop']['value']) ? $config['stop']['value'] : '0';
$isOn = ($stopValue === '1');
$stopColor = $isOn ? "#a00000" : "#008000";
$stopText  = $isOn ? "ein" : "aus";

echo "<details class='config-group' open>";
echo "<summary>Stop</summary>";

echo "<div class='config-item'>";
#echo "<label>Stop-Status</label>";

echo "<div style='display:flex; justify-content:center; align-items:center; gap:20px; margin-top:15px;'>";
echo "<button type='submit' name='stop_set' value='0' class='config-button' style='max-width:130px; background:#008000; margin-top:0; margin-left:10px;'>Stop AUS</button>";

echo "<div style='
    width: 70px;
    height: 70px;
    border-radius: 50%;
    background-color: $stopColor;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    color: white;
    font-weight: bold;
    font-size: 13px;
    text-align: center;
    line-height: 1.1;
    box-shadow: 0 0 12px " . ($isOn ? "rgba(255,0,0,0.7)" : "rgba(0,255,0,0.6)") . ";
'>
    <span>Status</span>
    <span>$stopText</span>
</div>";

echo "<button type='submit' name='stop_set' value='1' class='config-button' style='max-width:130px; background:#a00000; margin-top:0;'>Stop EIN</button>";


echo "</div>"; // flex
echo "</div>"; // config-item
echo "</details>";

// Undo-Liste anzeigen
if (!empty($_SESSION['deleted'])) {
    echo "<details class='config-group' open>";
    echo "<summary>Gelöschte Variablen (Undo)</summary>";

    foreach ($_SESSION['deleted'] as $k => $v) {
        echo "<div class='config-item'>";
        echo "<b>$k</b> = " . htmlspecialchars($v['value']);
        echo "<button type='submit' name='restore_key' value='$k' class='config-small-button' style='margin-left:20px;'>Wiederherstellen</button>";
        echo "</div>";
    }

    echo "</details>";
}

echo "</div>";
echo "<input type='submit' class='config-button' value='Speichern'>";
echo "</form>";
echo "</div>";
?>