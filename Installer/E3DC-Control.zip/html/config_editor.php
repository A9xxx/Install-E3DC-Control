<?php
session_start();

$paths = getInstallPaths();
$install_user = $paths['install_user'];
$install_path = rtrim($paths['install_path'], '/') . '/'; 

if (!isset($_SESSION['deleted'])) {
    $_SESSION['deleted'] = [];
}

$config_file_path = $install_path . 'e3dc.config.txt';
$message = '';

/* --- DEINE DEFAULTS & TOOLTIPS --- */
$defaults = [
    "wallbox" => "true", "wbmode" => "4", "wbminlade" => "1200", "wbminSoC" => "70",
    "wbmaxladestrom" => "32", "wbminladestrom" => "6", "Wbhour" => "0", "Wbvon" => "20", "Wbbis" => "6",
    "speichergroesse" => "35", "speicherEV" => "80", "speicherETA" => "0.97", "unload" => "65",
    "ladeschwelle" => "70", "ladeende" => "85", "ladeende2" => "91", "Ladeende2rampe" => "2",
    "maximumLadeleistung" => "12500", "awattar" => "1", "awmwst" => "19", "awnebenkosten" => "15.915",
    "awaufschlag" => "12", "awland" => "DE", "awreserve" => "20", "awsimulation" => "1",
    "WP" => "true", "WPHeizlast" => "18", "WPHeizgrenze" => "13", "WPLeistung" => "20",
    "WPMin" => "0.5", "WPMax" => "4.7", "WPehz" => "12 kW", "WPZWE" => "-99", "WPZWEPVon" => "25",
    "wrleistung" => "11700", "hoehe" => "48.60442", "laenge" => "13.41513", 
    "forecast1" => "40/-50/15.4", "ForecastSoc" => "1.2", "ForecastConsumption" => "1", "ForecastReserve" => "5",
    "stop" => "0"
];

$tooltips = [
    "wallbox" => "Aktiviert oder deaktiviert die Wallbox-Steuerung.",
    "wbmode" => "0 keine Steuerung\n1 Laden nur bei Abregelung\n2 Überschussladen\n3 Laden, Priorität Hausspeicher\n4 Hausspeicher bevorzugt laden\n5..8 Leitwert ist wbminlade\n9 Die Wallbox hat Prorität.",
    "wbminlade" => "Minimale Ladeleistung der Wallbox in Watt.",
    "wbminSoC" => "Unterer SoC-Grenzwert für Entladen über die Wallbox.",
    "wbmaxladestrom" => "Maximaler Ladestrom der Wallbox in Ampere.",
    "wbminladestrom" => "Minimaler Ladestrom der Wallbox in Ampere.",
    "Wbhour" => "Stunden, die im günstigsten Preisfenster geladen werden sollen.",
    "Wbvon" => "Startzeit des Ladefensters.",
    "Wbbis" => "Endzeit des Ladefensters.",
    "speichergroesse" => "Nutzbare Kapazität des Speichers in kWh.",
    "speicherEV" => "Eigenverbrauch des Wechselrichters in Watt.",
    "speicherETA" => "Wirkungsgrad des Speichers.",
    "unload" => "Bis zu diesem SoC wird morgens entladen.",
    "ladeschwelle" => "Bis zu diesem SoC wird morgens maximal geladen.",
    "ladeende" => "Erster Ladeendpunkt (SoC).",
    "ladeende2" => "Zweiter Ladeendpunkt (SoC).",
    "Ladeende2rampe" => "Beschleunigung der Ladung zwischen Ladeende1 und Ladeende2.",
    "maximumLadeleistung" => "Maximale Ladeleistung des Speichers in Watt.",
    "awattar" => "0 = aus, 1 = Netzladen aktiv, 2 = ohne Netzladen.",
    "awmwst" => "Mehrwertsteuer in Prozent.",
    "awnebenkosten" => "Nebenkosten pro kWh (brutto).",
    "awaufschlag" => "Prozentualer Aufschlag auf den Börsenpreis.",
    "awland" => "Land für Preisberechnung.",
    "awreserve" => "Reserve-SoC für Verbrauchsprognose.",
    "awsimulation" => "Zusätzliche PV-Spalte in Simulation aktivieren.",
    "WP" => "Wärmepumpe vorhanden = true.",
    "WPHeizlast" => "Heizlast der Wärmepumpe.",
    "WPHeizgrenze" => "Temperaturgrenze für Heizbetrieb.",
    "WPLeistung" => "Elektrische Leistung der WP.",
    "WPMin" => "Minimale elektrische Leistung.",
    "WPMax" => "Maximale elektrische Leistung.",
    "WPehz" => "Leistung der elektrischen Zusatzheizung.",
    "WPZWE" => "ZWE-Modus.",
    "WPZWEPVon" => "Temperaturgrenze für ZWE.",
    "hoehe" => "Geografische Höhe für Sonnenstandsberechnung.",
    "laenge" => "Geografische Länge für Sonnenstandsberechnung.",
    "forecast1" => "Dachneigung/Azimuth/kWp.",
    "forecast2" => "Dachneigung/Azimuth/kWp für den 2. PV-String.",
    "forecast3" => "Dachneigung/Azimuth/kWp für den 3. PV-String.",
    "forecast4" => "Dachneigung/Azimuth/kWp für den 4. PV-String.",
    "forecast5" => "Dachneigung/Azimuth/kWp für den 5. PV-String.",
    "ForecastSoc" => "Faktor für beschleunigtes Laden.",
    "ForecastConsumption" => "Faktor für Verbrauchsprognose.",
    "ForecastReserve" => "Reserve in Prozent.",
    "wbtest" => "Testmodus für die Wallbox-Kommunikation.",
    "wrleistung" => "Maximale Wechselrichterleistung in Watt.",
    "einspeiselimit" => "Maximal zulässige Netzeinspeisung in Watt.",
    "powerfaktor" => "Korrekturfaktor für die Leistungswerte.",
    "rb" => "Untere SoC-Schwelle für die Entladesperre.",
    "re" => "Obere SoC-Schwelle für die Entladesperre.",
    "le" => "Lade-Ende Schwelle (SoC).",
    "shellyem_ip" => "IP-Adresse des Shelly EM zur Leistungsmessung.",
    "openmeteo" => "Wetterprognose über Open-Meteo beziehen (true/false).",
    "server_ip" => "IP-Adresse des E3DC S10 Hauskraftwerks.",
    "server_port" => "Netzwerk-Port für RSCP (Standard: 5033).",
    "e3dc_user" => "E3DC-Portal Benutzername.",
    "e3dc_password" => "E3DC-Portal Passwort.",
    "aes_password" => "RSCP-Passwort (am Gerät vergeben).",
    "debug" => "Debug-Modus aktivieren (0=aus, true=ein).",
    "logfile" => "Pfad zur Logdatei.",
    "ext1" => "Externer Zähler 1.",
    "ext2" => "Externer Zähler 2.",
    "stop" => "Beendet die Bildschirmausgabe (0=aus, 1=ein)."
];

/* --- LOGIK (DATEI LESEN) --- */
function readConfig($file_path) {
    if (!file_exists($file_path)) return [];
    $lines = file($file_path, FILE_IGNORE_NEW_LINES);
    $config = [];
    foreach ($lines as $line) {
        if (trim($line) === '') continue;
        $commented = false;
        if (strpos(ltrim($line), '#') === 0) { $commented = true; $line = ltrim($line, '#'); }
        if (strpos($line, '=') === false) continue;
        list($key, $value) = explode('=', $line, 2);
        $config[trim($key)] = ['value' => trim($value), 'commented' => $commented];
    }
    return $config;
}

$config = readConfig($config_file_path);

/* --- POST LOGIK --- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['stop_set'])) {
        $val = $_POST['stop_set'] === '1' ? '1' : '0';
        $config['stop'] = ['value' => $val, 'commented' => false];
    }
    if (isset($_POST['save_all']) && isset($_POST['values'])) {
        $comments = $_POST['comments'] ?? [];
        foreach ($_POST['values'] as $k => $v) {
            if (isset($config[$k])) {
                $config[$k]['value'] = trim($v);
                $config[$k]['commented'] = in_array($k, $comments);
            }
        }
    }
    if (!empty($_POST['new_key'])) {
        $nk = trim($_POST['new_key']); $nv = trim($_POST['new_value'] ?? '');
        $config[$nk] = ['value' => $nv, 'commented' => false];
    }
    if (isset($_POST['delete_key'])) {
        $dk = $_POST['delete_key']; $_SESSION['deleted'][$dk] = $config[$dk]; unset($config[$dk]);
    }
    if (isset($_POST['restore_key'])) {
        $rk = $_POST['restore_key']; $config[$rk] = $_SESSION['deleted'][$rk]; unset($_SESSION['deleted'][$rk]);
    }

    $content = "";
    foreach ($config as $key => $data) {
        $content .= ($data['commented'] ? "# " : "") . $key . " = " . $data['value'] . "\n";
    }
    file_put_contents($config_file_path, $content, LOCK_EX);
    $message = "<div class='alert alert-success py-2 border-0 mb-3 mx-2'>✓ Konfiguration gespeichert.</div>";
    $config = readConfig($config_file_path);
}

/* --- DEINE INDIVIDUELLE GRUPPIERUNG --- */
$groups = [
    "Wallbox" => ["wallbox","wbmode","wbminlade","wbminSoC","wbmaxladestrom","wbminladestrom","Wbhour","Wbvon","Wbbis","wbtest"],
    "Speicher / Ladesteuerung" => ["speichergroesse","speicherEV","speicherETA","unload","wrleistung","einspeiselimit","ladeschwelle","ladeende","ladeende2","Ladeende2rampe","maximumLadeleistung","powerfaktor","rb","re","le"],
    "Awattar / Preise" => ["awattar","awmwst","awnebenkosten","awaufschlag","awland","awreserve","awsimulation"],
    "Wärmepumpe" => ["WP","WPHeizlast","WPHeizgrenze","WPLeistung","WPMin","WPMax","WPehz","WPZWE","WPZWEPVon","shellyem_ip"],
    "Standort / Wetter" => ["openmeteo","hoehe","laenge","forecast1","forecast2","forecast3","forecast4","forecast5","ForecastSoc","ForecastConsumption","ForecastReserve"],
    "System" => ["server_ip","server_port","e3dc_user","e3dc_password","aes_password","debug","logfile","wurzelzaehler","ext1","ext2","Wrsteuerung"],
    "Sonstiges" => [] 
];
?>
<?php
// Tooltip-Map für case-insensitive Suche vorbereiten
$tooltipMap = array_change_key_case($tooltips, CASE_LOWER);
?>

<style>
    .config-card { background: #1a1f29; border: 1px solid #2d3748; border-radius: 16px; margin-bottom: 12px; overflow: hidden; }
    .config-header { color: #22d3ee; font-weight: bold; padding: 12px 15px; border-bottom: 1px solid #2d3748; cursor: pointer; display: flex; justify-content: space-between; align-items: center; text-decoration: none; }
    .config-item { padding: 10px 15px; border-bottom: 1px solid #2d3748; }
    .config-item:last-child { border-bottom: none; }
    
    /* Verbesserte Tooltips für Mobile */
    .config-label { font-family: monospace; color: #94a3b8; font-size: 0.8rem; margin-bottom: 4px; display: inline-block; border-bottom: 1px dotted #555; cursor: help; position: relative; }
    .config-label[data-tooltip]:active::after, 
    .config-label[data-tooltip]:hover::after {
        content: attr(data-tooltip);
        position: absolute;
        bottom: 130%;
        left: 0;
        background: #334155;
        color: #fff;
        padding: 8px 12px;
        border-radius: 8px;
        font-size: 0.75rem;
        width: 280px;
        max-width: 85vw;
        z-index: 1000;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
        white-space: pre-wrap;
        line-height: 1.4;
    }
    
    /* Place-Holder Farbe anpassen (Hellgrau) */
    .config-input { background: #0b0e14 !important; border: 1px solid #2d3748 !important; color: #fff !important; border-radius: 8px; font-size: 0.9rem; padding: 6px 10px; }
    .config-input::placeholder { color: #555; opacity: 1; }

    #configSearch { background: #0b0e14; border: 1px solid #2d3748; color: #fff; border-radius: 8px; padding: 8px 12px; width: 100%; margin-bottom: 10px; }
    .ctrl-btns { display: flex; gap: 5px; margin-bottom: 15px; }
</style>

<div class="px-2 pb-5">
    <h5 class="fw-bold mb-3 text-white px-1">Konfiguration Editor</h5>
    <?= $message ?>

    <div class="px-1">
        <input type="text" id="configSearch" placeholder="🔍 Variable suchen..." onkeyup="filterConfig()">
        <div class="ctrl-btns">
            <button type="button" class="btn btn-sm btn-outline-secondary rounded-pill flex-grow-1" onclick="toggleAllGroups(false)">Alle schließen</button>
            <button type="button" class="btn btn-sm btn-outline-secondary rounded-pill flex-grow-1" onclick="toggleAllGroups(true)">Alle öffnen</button>
        </div>
    </div>

    <form method="POST">
        <div class="d-flex justify-content-between align-items-center mb-3 px-1">
            <span class="text-white-50 small">Tippe Namen für Hilfe</span>
            <button type="submit" name="save_all" class="btn btn-sm btn-info rounded-pill px-3 fw-bold text-dark shadow">💾 Speichern</button>
        </div>

        <?php 
        // Hilfsvariablen für case-insensitive Zuordnung
        $configKeys = array_keys($config);
        $lowerToOrig = array_combine(array_map('strtolower', $configKeys), $configKeys);
        $assigned = [];

        foreach ($groups as $title => $keys): 
            $items = [];
            foreach ($keys as $k) { 
                $lk = strtolower($k);
                if (isset($lowerToOrig[$lk])) { 
                    $origKey = $lowerToOrig[$lk];
                    $items[$origKey] = $config[$origKey]; 
                    $assigned[] = $origKey; 
                } 
            }
            if (empty($items)) continue;
        ?>
        <details class="config-card config-group-el">
            <summary class="config-header"><?= $title ?> <i class="fas fa-chevron-down small"></i></summary>
            <div class="p-1">
                <?php foreach ($items as $key => $data): ?>
                    <div class="config-item" data-search-key="<?= strtolower($key) ?>">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap[strtolower($key)] ?? 'Keine Beschreibung.') ?>"><?= $key ?></label>
                            <div class="d-flex align-items-center gap-2">
                                <span class="small text-white-50">#</span>
                                <input type="checkbox" name="comments[]" value="<?= $key ?>" class="form-check-input" style="accent-color: #22d3ee;" <?= $data['commented'] ? 'checked':'' ?>>
                            </div>
                        </div>
                        <div class="input-group input-group-sm">
                            <input type="text" name="values[<?= $key ?>]" class="form-control config-input" 
                                   value="<?= htmlspecialchars($data['value']) ?>" 
                                   placeholder="Standard: <?= $defaults[$key] ?? '' ?>">
                            <button type="submit" name="delete_key" value="<?= $key ?>" class="btn btn-outline-danger border-secondary"><i class="fas fa-trash"></i></button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </details>
        <?php endforeach; ?>

        <?php $rest = array_diff_key($config, array_flip($assigned), ['stop' => '']); 
        if (!empty($rest)): ?>
        <details class="config-card config-group-el">
            <summary class="config-header">Weitere Parameter <i class="fas fa-chevron-down small"></i></summary>
            <div class="p-1">
                <?php foreach ($rest as $key => $data): ?>
                    <div class="config-item" data-search-key="<?= strtolower($key) ?>">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <label class="config-label" data-tooltip="<?= htmlspecialchars($tooltipMap[strtolower($key)] ?? 'Keine Beschreibung.') ?>"><?= $key ?></label>
                            <input type="checkbox" name="comments[]" value="<?= $key ?>" class="form-check-input" <?= $data['commented'] ? 'checked':'' ?>>
                        </div>
                        <div class="input-group input-group-sm">
                            <input type="text" name="values[<?= $key ?>]" class="form-control config-input" value="<?= htmlspecialchars($data['value']) ?>">
                            <button type="submit" name="delete_key" value="<?= $key ?>" class="btn btn-outline-danger border-secondary"><i class="fas fa-trash"></i></button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </details>
        <?php endif; ?>

        <?php $isOn = (($config['stop']['value'] ?? '0') === '1'); $stopColor = $isOn ? "#f43f5e" : "#10b981"; ?>
        <div class="config-card p-4 text-center">
            <h6 class="text-white-50 small mb-3 fw-bold">Screen stop</h6>
            <div class="d-flex flex-column flex-md-row justify-content-center align-items-center gap-4">
                <div style="width: 65px; height: 65px; border-radius: 50%; background: <?= $stopColor ?>; display: flex; flex-direction: column; align-items: center; justify-content: center; font-weight: bold; box-shadow: 0 0 15px <?= $stopColor ?>40;">
                    <span style="font-size: 0.6rem; text-transform: uppercase;">Status</span>
                    <span><?= $isOn ? 'EIN':'AUS' ?></span>
                </div>
                <button type="submit" name="stop_set" value="1" class="btn btn-outline-danger rounded-pill px-5 fw-bold shadow-sm">STOP AKTIVIEREN (EIN)</button>
                <button type="submit" name="stop_set" value="0" class="btn btn-outline-success rounded-pill px-5 fw-bold shadow-sm">STOP DEAKTIVIEREN (AUS)</button>
            </div>
        </div>

        <button type="submit" name="save_all" value="1" class="btn btn-info w-100 rounded-pill py-3 fw-bold text-dark mt-3 shadow">💾 ALLE ÄNDERUNGEN SPEICHERN</button>
    </form>
</div>

<script>
function filterConfig() {
    var input = document.getElementById('configSearch');
    var filter = input.value.toLowerCase();
    var groups = document.getElementsByClassName('config-group-el');

    for (var j = 0; j < groups.length; j++) {
        var groupTitle = groups[j].querySelector('.config-header').textContent.toLowerCase();
        var items = groups[j].querySelectorAll('.config-item');
        var groupMatches = groupTitle.includes(filter);
        
        for (var i = 0; i < items.length; i++) {
            var key = items[i].getAttribute('data-search-key');
            // Zeige Item, wenn Key ODER Gruppenname passt
            items[i].style.display = (key.includes(filter) || groupMatches) ? "" : "none";
        }

        var groupItems = groups[j].querySelectorAll('.config-item');
        var hasVisibleItems = false;
        for (var k = 0; k < groupItems.length; k++) {
            if (groupItems[k].style.display !== 'none') {
                hasVisibleItems = true;
                break;
            }
        }

        if (filter.length > 0) {
            groups[j].open = hasVisibleItems;
            groups[j].style.display = hasVisibleItems ? "" : "none";
        } else {
            groups[j].open = false;
            groups[j].style.display = "";
        }
    }
}

function toggleAllGroups(open) {
    var groups = document.getElementsByClassName('config-group-el');
    for (var i = 0; i < groups.length; i++) {
        groups[i].open = open;
    }
}
</script>