<?php
// get_live_json.php
require_once 'helpers.php';
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
$liveFile = '/var/www/html/ramdisk/live.txt';
$liveHistoryFile = '/var/www/html/ramdisk/live_history.txt';
$liveHistoryHours = 48;
$data = [
    'pv' => 0,
    'bat' => 0,
    'home_raw' => 0,
    'grid' => 0,
    'soc' => 0,
    'wb' => 0,
    'wp' => 0,
    'price_ct' => null,
    'price_level' => 'unknown',
    'price_slot_gmt' => null,
    'price_target_slot_gmt' => null,
    'price_source' => null,
    'price_min_ct' => null,
    'price_min_slot' => null,
    'price_max_ct' => null,
    'price_max_slot' => null,
    'prices' => [],
    'price_start_hour' => null,
    'price_interval' => 1.0,
    'time' => '--:--',
    'ts' => 0
];

function classifyPrice($price, $minPrice, $maxPrice)
{
    if ($price === null || $minPrice === null || $maxPrice === null || $maxPrice <= $minPrice) {
        return 'unknown';
    }

    $range = $maxPrice - $minPrice;
    $avgBandWidth = 0.30 * $range;
    $lowerThreshold = $minPrice + (( $range - $avgBandWidth ) / 2.0);
    $upperThreshold = $maxPrice - (( $range - $avgBandWidth ) / 2.0);

    if ($price < $lowerThreshold) {
        return 'cheap';
    }
    if ($price > $upperThreshold) {
        return 'expensive';
    }
    return 'average';
}

function parseNumericConfigValue($value, $default)
{
    if (is_int($value) || is_float($value)) {
        return (float)$value;
    }
    if (!is_string($value)) {
        return (float)$default;
    }

    $cleaned = trim($value, " \t\n\r\0\x0B\"'");
    if ($cleaned === '') {
        return (float)$default;
    }

    $normalized = str_replace(',', '.', $cleaned);
    return is_numeric($normalized) ? (float)$normalized : (float)$default;
}

function loadPricingConfig($configFile)
{
    $awmwst = 19.0;
    $awnebenkosten = 0.0;

    if (!file_exists($configFile)) {
        return [$awmwst, $awnebenkosten];
    }

    $lines = @file($configFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!$lines) {
        return [$awmwst, $awnebenkosten];
    }

    foreach ($lines as $line) {
        if (strpos($line, '=') === false) {
            continue;
        }

        [$key, $value] = array_map('trim', explode('=', $line, 2));
        $keyLower = strtolower($key);

        if ($keyLower === 'awmwst') {
            $awmwst = parseNumericConfigValue($value, $awmwst);
        } elseif ($keyLower === 'awnebenkosten') {
            $awnebenkosten = parseNumericConfigValue($value, $awnebenkosten);
        }
    }

    return [$awmwst, $awnebenkosten];
}

function applyAwattarPriceLogic($priceRaw, $sourceTimestamp, $awmwst, $awnebenkosten)
{
    $multiplier = ($awmwst / 100.0) + 1.0;
    $switchTs = strtotime('2024-12-19 00:00:00');

    if ($sourceTimestamp > $switchTs) {
        return ($priceRaw * $multiplier) + $awnebenkosten;
    }

    return (($priceRaw / 10.0) * $multiplier) + $awnebenkosten;
}

function parseQuarterTimeToMinute($timeToken)
{
    if (!preg_match('/^(\d{1,2})\.(\d{2})$/', $timeToken, $tm)) {
        return null;
    }

    $hour = (int)$tm[1];
    $fractionPart = (int)$tm[2] / 100.0;
    $minute = (int)round($fractionPart * 60.0);

    if ($minute >= 60) {
        $hour += (int)floor($minute / 60);
        $minute = $minute % 60;
    }

    // $hour = $hour % 24; // Entfernt, um Tagestrennung zu erkennen
    return ($hour * 60) + $minute;
}

function minuteDistanceCircular($a, $b)
{
    $diff = abs($a - $b);
    return min($diff, 1440 - $diff);
}

function minuteToSlotLabel($minute)
{
    if (!is_int($minute) || $minute < 0) {
        return null;
    }

    // $minute = $minute % 1440; // Entfernt, um Stunden > 24 zuzulassen
    $hour = (int)floor($minute / 60);
    $min = $minute % 60;
    return sprintf('%d.%02d', $hour, (int)round(($min / 60) * 100));
}

function parsePricesFromAwattarDebug($debugFile, $awmwst, $awnebenkosten)
{
    if (!file_exists($debugFile)) {
        return [null, null, null, null, null, null, null, null, null, [], null, 1.0];
    }

    $lines = @file($debugFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!$lines) {
        return [null, null, null, null, null, null, null, null, null, [], null, 1.0];
    }

    $prices = [];
    $entries = [];
    $sourceTs = filemtime($debugFile) ?: time();
    $inDataBlock = false;
    $lastMinute = -1;
    $dayOffset = 0;
    $priceStartHour = null;
    $priceInterval = 1.0;

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }

        if (stripos($line, 'Data') === 0) {
            $inDataBlock = true;
            continue;
        }

        if (stripos($line, 'Simulation') === 0) {
            $inDataBlock = false;
            continue;
        }

        if (!$inDataBlock) {
            continue;
        }

        if (preg_match('/^\d{1,2}\.\d{2}\s+(-?\d+(?:\.\d+)?)(?:\s+(-?\d+(?:\.\d+)?)){3,5}$/', $line)) {
            $parts = preg_split('/\s+/', $line);
            if (count($parts) >= 2) {
                $minuteOfDay = parseQuarterTimeToMinute($parts[0]);
                
                // Tagestrennung erkennen (wenn Zeit zurückspringt, z.B. von 23.75 auf 0.00)
                if ($minuteOfDay !== null) {
                    if ($lastMinute !== -1 && $minuteOfDay < $lastMinute) {
                        $dayOffset += 1440;
                    }
                    $lastMinute = $minuteOfDay;
                    $minuteOfDay += $dayOffset;
                }

                $candidateRaw = (float)$parts[1];
                $candidate = applyAwattarPriceLogic($candidateRaw, $sourceTs, $awmwst, $awnebenkosten);
                if ($candidate >= 0 && $candidate <= 100) {
                    if ($priceStartHour === null) {
                        $priceStartHour = (float)$parts[0];
                    } elseif (count($prices) === 1) {
                        $intervalCandidate = (float)$parts[0] - $priceStartHour;
                        if ($intervalCandidate > 0) {
                            $priceInterval = $intervalCandidate;
                        }
                    }
                    $prices[] = $candidate;
                    if ($minuteOfDay !== null) {
                        $entries[] = ['minute' => $minuteOfDay, 'price' => $candidate];
                    }
                }
            }
        }
    }

    if (empty($prices)) {
        return [null, null, null, null, null, null, null, null, null, [], null, 1.0];
    }

    $current = $prices[0];
    $selectedMinute = null;
    $targetMinute = null;
    if (!empty($entries)) {
        $nowMinuteRaw = ((int)gmdate('G') * 60) + (int)gmdate('i');
        $targetMinute = (int)(round($nowMinuteRaw / 15) * 15);
        if ($targetMinute >= 1440) {
            $targetMinute -= 1440;
        }

        $bestEntry = $entries[0];
        // Hier modulo 1440 nutzen, um den aktuellen Preis im Tageszyklus zu finden
        $bestDistance = minuteDistanceCircular($bestEntry['minute'] % 1440, $targetMinute);

        foreach ($entries as $entry) {
            $distance = minuteDistanceCircular($entry['minute'] % 1440, $targetMinute);
            if ($distance < $bestDistance) {
                $bestDistance = $distance;
                $bestEntry = $entry;
            }
        }

        $current = $bestEntry['price'];
        $selectedMinute = $bestEntry['minute'];
    }

    $min = min($prices);
    $max = max($prices);
    // Min/Max Slot bestimmen
    $minSlot = null;
    $maxSlot = null;
    foreach ($entries as $entry) {
        if ($entry['price'] === $min && $minSlot === null) {
            $minSlot = minuteToSlotLabel($entry['minute']);
        }
        if ($entry['price'] === $max && $maxSlot === null) {
            $maxSlot = minuteToSlotLabel($entry['minute']);
        }
    }
    return [$current, $min, $max, minuteToSlotLabel($selectedMinute), minuteToSlotLabel($targetMinute), $min, $minSlot, $max, $maxSlot, $prices, $priceStartHour, $priceInterval];
}

$paths = getInstallPaths();
$configFile = rtrim($paths['install_path'], '/') . '/e3dc.config.txt';
[$awmwst, $awnebenkosten] = loadPricingConfig($configFile);

$wbOut = rtrim($paths['install_path'], '/') . '/e3dc.wallbox.out';
$data['wb_plan_hash'] = (file_exists($wbOut)) ? md5_file($wbOut) : '';

$currentPrice = null;

$currentPrice = null;
$minPrice = null;
$maxPrice = null;

// Min/Max Preis und Zeiten aus awattardebug extrahieren
$debugFile = rtrim($paths['install_path'], '/') . '/awattardebug.txt';
[$_unused, $minPrice, $maxPrice, $selectedSlot, $targetSlot, $minCt, $minSlot, $maxCt, $maxSlot, $prices, $priceStartHour, $priceInterval] = parsePricesFromAwattarDebug($debugFile, $awmwst, $awnebenkosten);
if ($minPrice !== null) {
    $data['price_min_ct'] = round($minCt, 2);
    $data['price_min_slot'] = $minSlot;
}
if ($maxPrice !== null) {
    $data['price_max_ct'] = round($maxCt, 2);
    $data['price_max_slot'] = $maxSlot;
}
$data['prices'] = $prices;
$data['price_start_hour'] = $priceStartHour;
$data['price_interval'] = $priceInterval;

// Aktueller Preis aus liveFile (RB-Zeile) extrahieren
if (file_exists($liveFile)) {
    $content = file_get_contents($liveFile);
    $mtime = filemtime($liveFile);
    $data['time'] = date("H:i:s", $mtime);
    $data['ts'] = $mtime;
    if (preg_match('/PV\s+\d+\+\d+=(\d+)\s+BAT\s+(-?\d+)\s+home\s+(\d+)\s+grid\s+(-?\d+)/', $content, $m)) {
        $data['pv'] = (int)$m[1];
        $data['bat'] = (int)$m[2];
        $data['home_raw'] = (int)$m[3];
        $data['grid'] = (int)$m[4];
    }
    if (preg_match('/SOC\s+(\d+\.?\d*)%/', $content, $m)) $data['soc'] = (float)$m[1];
    if (preg_match('/Total\s+([\d\.]+)\s+W/', $content, $m)) $data['wb'] = (float)$m[1] * 1;
    if (preg_match('/WP.*?([\d\.]+)\s*W/', $content, $m)) $data['wp'] = (float)$m[1] * 1000;

    // Aktueller Preis aus RB-Zeile extrahieren (Wert nach letztem Prozentzeichen)
    if (preg_match('/RB.*?%.*?%.*?%([^%\n]*)/', $content, $pm)) {
        $priceStr = trim($pm[1]);
        // Der Preis kann mehrere Werte enthalten, wir nehmen den ersten Float
        if (preg_match('/(-?\d+(?:\.\d+)?)/', $priceStr, $val)) {
            $currentPrice = (float)$val[1];
            $data['price_source'] = 'live_rb';
        }
    }

    // Fallback, falls der Preis nicht aus der RB-Zeile extrahiert werden konnte
    if ($currentPrice === null && preg_match('/RB\s+\d{1,2}:\d{2}\s+\d+\.?\d*%\s+RE\s+\d{1,2}:\d{2}\s+\d+\.?\d*%\s+LE\s+\d{1,2}:\d{2}\s+\d+\.?\d*%\s+(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)/', $content, $pm)) {
        $currentPrice = (float)$pm[1];
        $minPrice = min((float)$pm[2], (float)$pm[3]);
        $maxPrice = max((float)$pm[2], (float)$pm[3], $currentPrice);
        $data['price_source'] = 'live_fallback';
    }
}

if ($currentPrice !== null) {
    $data['price_ct'] = round($currentPrice, 2);
    $data['price_level'] = classifyPrice($currentPrice, $minPrice, $maxPrice);
}
else {
    $data['price_ct'] = null;
    $data['price_level'] = 'unknown';
}

// Live-History: letzte 48 Stunden in Ramdisk schreiben (ohne price min/max/slots, mit Haus ohne WP)
// PERFORMANCE-FIX: Nur alle 60 Sekunden schreiben, um Pi Zero zu entlasten
$lastWrite = file_exists($liveHistoryFile) ? filemtime($liveHistoryFile) : 0;
if ((time() - $lastWrite) >= 60) {
    $historyLine = [
        'ts' => date('c'),
        'pv' => $data['pv'],
        'bat' => $data['bat'],
        'home_raw' => $data['home_raw'],
        'home' => (float)$data['home_raw'] - (float)$data['wp'],  // Hausverbrauch ohne Wärmepumpe
        'grid' => $data['grid'],
        'soc' => $data['soc'],
        'wb' => $data['wb'],   // Wallbox
        'wp' => $data['wp'],   // Wärmepumpe
        'price_ct' => $data['price_ct'],
    ];
    $line = json_encode($historyLine) . "\n";
    // Immer versuchen zu schreiben (is_writable kann auf manchen Servern falsch sein)
    $appendOk = @file_put_contents($liveHistoryFile, $line, LOCK_EX | FILE_APPEND);
    if ($appendOk !== false) {
        $cutoff = time() - ($liveHistoryHours * 3600);
        $content = @file_get_contents($liveHistoryFile);
        if ($content !== false && $content !== '') {
            $lines = explode("\n", trim($content));
            $kept = [];
            foreach ($lines as $ln) {
                if (trim($ln) === '') continue;
                $dec = @json_decode($ln, true);
                
                // Strikte Prüfung: Behalte nur Zeilen, die gültiges JSON sind UND einen Zeitstempel haben.
                if (is_array($dec) && !empty($dec['ts'])) {
                    $t = strtotime($dec['ts']);
                    // Behalte die Zeile, wenn das Datum gültig ist UND nicht zu alt
                    if ($t !== false && $t >= $cutoff) {
                        $kept[] = $ln;
                    }
                }
                // Alle anderen Zeilen (ungültiges JSON, ohne 'ts', zu alt) werden automatisch verworfen.
            }
            // Nur kürzen wenn wir Zeilen entfernen und nicht alles löschen würden
            if (count($kept) < count($lines) && count($kept) > 0) {
                @file_put_contents($liveHistoryFile, implode("\n", $kept) . "\n", LOCK_EX);
            }
        }
    }
}

echo json_encode($data);