<?php
// get_live_json.php
require_once 'helpers.php';
header('Content-Type: application/json');
$liveFile = '/var/www/html/ramdisk/live.txt';
$data = ['pv' => 0, 'bat' => 0, 'home_raw' => 0, 'grid' => 0, 'soc' => 0, 'wb' => 0, 'wp' => 0, 'time' => '--:--'];

if (file_exists($liveFile)) {
    $content = file_get_contents($liveFile);
    $data['time'] = date("H:i:s", filemtime($liveFile));
    if (preg_match('/PV\s+\d+\+\d+=(\d+)\s+BAT\s+(-?\d+)\s+home\s+(\d+)\s+grid\s+(-?\d+)/', $content, $m)) {
        $data['pv'] = (int)$m[1];
        $data['bat'] = (int)$m[2];
        $data['home_raw'] = (int)$m[3];
        $data['grid'] = (int)$m[4];
    }
    if (preg_match('/SOC\s+(\d+\.?\d*)%/', $content, $m)) $data['soc'] = (float)$m[1];
    if (preg_match('/Total\s+([\d\.]+)\s+W/', $content, $m)) $data['wb'] = (float)$m[1] * 1;
    if (preg_match('/WP.*?([\d\.]+)\s*W/', $content, $m)) $data['wp'] = (float)$m[1] * 1000;
}
echo json_encode($data);