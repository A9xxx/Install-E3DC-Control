<?php
/**
 * helpers.php - Zentrale Utility-Funktionen für E3DC-Control Web-Interface
 */

date_default_timezone_set('Europe/Berlin');

// ==================== ERROR HANDLING ====================

/**
 * Prüft den Dateizugriff und zeigt eine benutzerfreundliche Fehlermeldung
 * 
 * @param string $path Dateipfad
 * @param string $operation 'read', 'write', or 'exists'
 * @return bool|string true bei Erfolg, oder HTML mit Fehlermeldung
 */
function checkFileAccess($path, $operation = 'read') {
    // Sicherheit: Nur absolute Pfade oder relative im bekannten Verzeichnis
    if (strpos($path, '..') !== false) {
        return errorMessage("Ungültiger Pfad: Pfad-Traversal erkannt.");
    }

    if (!file_exists($path)) {
        return errorMessage(
            "Datei nicht gefunden",
            "Der Zugriff auf <code>" . htmlspecialchars($path) . "</code> ist fehlgeschlagen. " .
            "Möglicherweise existiert die Datei nicht oder der Pfad ist falsch."
        );
    }

    if ($operation === 'read' && !is_readable($path)) {
        return errorMessage(
            "Leseberechtigung fehlt",
            "Die Datei <code>" . htmlspecialchars($path) . "</code> kann nicht gelesen werden. " .
            "Bitte prüfen Sie die Dateiberechtigungen (chmod 755 oder 644)."
        );
    }

    if ($operation === 'write' && !is_writable($path)) {
        $parent = dirname($path);
        $isParentWritable = is_writable($parent) ? "ja" : "nein";
        
        return errorMessage(
            "Schreibberechtigung fehlt",
            "Die Datei <code>" . htmlspecialchars($path) . "</code> kann nicht geschrieben werden. " .
            "Bitte prüfen Sie die Dateiberechtigungen. Eltern-Verzeichnis schreibbar: " . $isParentWritable
        );
    }

    if ($operation === 'mkdir' && !is_dir($path)) {
        if (!@mkdir($path, 0755, true)) {
            return errorMessage(
                "Verzeichnis konnte nicht erstellt werden",
                "Das Verzeichnis <code>" . htmlspecialchars($path) . 
                "</code> existiert nicht und konnte nicht erstellt werden."
            );
        }
    }

    return true;
}

/**
 * Formatiert eine Fehlermeldung als HTML-Box
 */
function errorMessage($title, $details = '') {
    $html = '<div class="error-box" style="background:#3a2f2f; border-left:4px solid #e74c3c; padding:20px; margin:20px 0; border-radius:4px;">';
    $html .= '<h3 style="color:#e74c3c; margin-top:0;">' . htmlspecialchars($title) . '</h3>';
    if ($details) {
        $html .= '<p style="margin:10px 0 0 0; color:#ccc; line-height:1.6;">' . $details . '</p>';
    }
    $html .= '</div>';
    return $html;
}

// ==================== INSTALL PATH ====================

/**
 * Liefert Installationspfade aus e3dc_paths.json oder Fallback.
 */
function getInstallPaths() {
    $defaultUser = 'pi';
    $defaultPath = '/home/pi/E3DC-Control/';
    $configFile = '/var/www/html/e3dc_paths.json';

    if (is_readable($configFile)) {
        $json = @file_get_contents($configFile);
        if ($json !== false) {
            $data = json_decode($json, true);
            if (is_array($data) && !empty($data['install_path'])) {
                $path = rtrim($data['install_path'], '/') . '/';
                return [
                    'install_user' => $data['install_user'] ?? $defaultUser,
                    'install_path' => $path
                ];
            }
        }
    }

    return [
        'install_user' => $defaultUser,
        'install_path' => $defaultPath
    ];
}

function getInstallPath() {
    $paths = getInstallPaths();
    return $paths['install_path'];
}

/**
 * Erzeugt eine Seiten-URL im aktuellen Kontext (mobile.php oder index.php).
 *
 * @param string $seite Zielseite
 * @param array $params Zusätzliche Query-Parameter
 * @return string
 */
function getContextPageUrl($seite, $params = []) {
    $script = basename($_SERVER['PHP_SELF'] ?? 'index.php');
    $entrypoint = ($script === 'mobile.php') ? 'mobile.php' : 'index.php';

    $query = array_merge(['seite' => $seite], $params);
    return $entrypoint . '?' . http_build_query($query);
}

/**
 * Prüft, ob ein Diagramm-Update gemäß der 15-Minuten-Regel fällig ist.
 * Regel: Maximal alle 15 Minuten, ca. 2 Minuten nach jeder Viertelstunde.
 */
function isDiagramUpdateDue($stampFile) {
    if (!file_exists($stampFile)) return true;
    
    $lastUpdate = filemtime($stampFile);
    $now = time();
    $minSinceLast = ($now - $lastUpdate) / 60;
    
    // Aktuelle Minute der Stunde
    $currentMin = (int)date('i', $now);
    
    // Bestimme den Start der aktuellen Viertelstunde (0, 15, 30, 45)
    $currentSlotStartMin = floor($currentMin / 15) * 15;
    
    // Der "Update-Zeitpunkt" ist 2 Minuten nach Slot-Start
    $updateThresholdMin = $currentSlotStartMin + 2;
    
    // Fall 1: Wir sind in der "Pufferzeit" (z.B. Minute 0-1) nach einer Viertelstunde.
    // Wir warten, bis Minute 2 erreicht ist. Damit weichen wir unnötigen Skriptläufen aus.
    if ($currentMin < $updateThresholdMin) {
        // Falls das letzte Update länger als 20 Minuten her ist (Sicherheitsnetz), trotzdem fällig
        return ($minSinceLast > 20);
    }
    
    // Fall 2: Wir sind nach Minute 2 (z.B. Minute 18). 
    // Wir schauen nach, ob das letzte Update heute schon nach Minute 17 (nach Slot-Start + 2) gelaufen ist.
    $fälligAb = strtotime(date('Y-m-d H:', $now) . sprintf('%02d', $updateThresholdMin) . ':00');
    
    return ($lastUpdate < $fälligAb);
}

/**
 * Gibt Erfolgs- oder Info-Meldung aus
 */
function successMessage($message) {
    return '<div class="success-box" style="background:#2d3d2a; border-left:4px solid #27ae60; padding:15px; margin:15px 0; border-radius:4px; color:#27ae60; font-weight:bold;">' 
           . htmlspecialchars($message) . '</div>';
}

// ==================== DATEIOPERATIONEN ====================

/**
 * Sichere Datei-Leseoperation mit Fehlerbehandlung
 * 
 * @param string $path Dateipfad
 * @param bool $asArray true = array, false = string
 * @return array|string|false Dateiinhalt oder false bei Fehler
 */
function safeReadFile($path, $asArray = false) {
    $check = checkFileAccess($path, 'read');
    if ($check !== true) {
        return false;
    }

    if ($asArray) {
        return file($path, FILE_IGNORE_NEW_LINES) ?: false;
    }
    return file_get_contents($path) ?: false;
}

/**
 * Sichere Datei-Schreiboperation mit Fehlerbehandlung
 */
function safeWriteFile($path, $content, $flags = LOCK_EX) {
    $check = checkFileAccess($path, 'write');
    if ($check !== true) {
        return false;
    }

    return @file_put_contents($path, $content, $flags) !== false;
}

// ==================== VALIDIERUNG ====================

/**
 * Validiert einen Dateinamen gegen Path-Traversal-Attacken
 */
function validateFilename($filename) {
    // Nur alphanumerisch, Punkte, Unterstriche, Bindestriche
    if (!preg_match('/^[a-zA-Z0-9._\-]+$/', $filename)) {
        return false;
    }
    // basename() entfernt Pfade
    if (basename($filename) !== $filename) {
        return false;
    }
    return true;
}

/**
 * Sanitiert Benutzereingaben
 */
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Prüft auf erforderliche POST-Parameter
 */
function requirePostParams($required = []) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return true;
    }

    foreach ($required as $param) {
        if (!isset($_POST[$param]) || $_POST[$param] === '') {
            die(errorMessage("Erforderlicher Parameter fehlt", "Parameter: " . htmlspecialchars($param)));
        }
    }
    return true;
}

// ==================== KONFIGURATION ====================

/**
 * Lädt die E3DC-Konfiguration mit Fehlerbehandlung
 */
function loadE3dcConfig($basePath = null) {
    if ($basePath === null) {
        $basePath = getInstallPath();
    }
    $configFile = $basePath . 'e3dc.config.txt';
    
    $check = checkFileAccess($configFile, 'read');
    if ($check !== true) {
        return ['error' => $check, 'config' => []];
    }

    $lines = file($configFile, FILE_IGNORE_NEW_LINES);
    $config = [];

    foreach ($lines as $line) {
        $line = trim($line);
        // Kommentare überspringen
        if (empty($line) || strpos($line, '#') === 0) {
            continue;
        }
        
        if (strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            if (!empty($key)) {
                $config[$key] = $value;
            }
        }
    }

    return ['error' => null, 'config' => $config];
}

// ==================== LOGGING ====================

/**
 * Optionales Logging (für Debugging)
 */
function debugLog($message, $data = null) {
    if (!defined('DEBUG_MODE') || !DEBUG_MODE) {
        return;
    }

    $logFile = '/var/www/html/tmp/debug.log';
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] " . $message;
    
    if ($data !== null) {
        $logMessage .= " | " . json_encode($data);
    }
    
    @error_log($logMessage . "\n", 3, $logFile);
}

// ==================== HTML UTILITIES ====================

/**
 * Formatiert einen Datetime-String
 */
function formatDateTime($timestamp, $format = 'd.m.Y H:i') {
    if (is_numeric($timestamp)) {
        return date($format, $timestamp);
    }
    return htmlspecialchars($timestamp);
}

/**
 * Erstellt ein sicheres Button-HTML-Element
 */
function createButton($label, $url = '', $class = 'form-button', $onclick = '') {
    if ($url) {
        return '<a href="' . htmlspecialchars($url) . '" class="' . $class . '">' 
               . htmlspecialchars($label) . '</a>';
    }
    return '<button type="button" class="' . $class . '" onclick="' . htmlspecialchars($onclick) . '">' 
           . htmlspecialchars($label) . '</button>';
}
?>
