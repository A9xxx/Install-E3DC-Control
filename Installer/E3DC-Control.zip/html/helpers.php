<?php
/**
 * helpers.php - Zentrale Utility-Funktionen für E3DC-Control Web-Interface
 */

date_default_timezone_set('Europe/Berlin');

// ==================== ERROR HANDLING ====================

/**
 * Prüft den Dateizugriff und zeigt eine benutzerfreundliche Fehlermeldung
 * 
 * @param string $path Dateipfad
 * @param string $operation 'read', 'write', or 'exists'
 * @return bool|string true bei Erfolg, oder HTML mit Fehlermeldung
 */
function checkFileAccess($path, $operation = 'read') {
    // Sicherheit: Nur absolute Pfade oder relative im bekannten Verzeichnis
    if (strpos($path, '..') !== false) {
        return errorMessage("Ungültiger Pfad: Pfad-Traversal erkannt.");
    }

    if (!file_exists($path)) {
        return errorMessage(
            "Datei nicht gefunden",
            "Der Zugriff auf <code>" . htmlspecialchars($path) . "</code> ist fehlgeschlagen. " .
            "Möglicherweise existiert die Datei nicht oder der Pfad ist falsch."
        );
    }

    if ($operation === 'read' && !is_readable($path)) {
        return errorMessage(
            "Leseberechtigung fehlt",
            "Die Datei <code>" . htmlspecialchars($path) . "</code> kann nicht gelesen werden. " .
            "Bitte prüfen Sie die Dateiberechtigungen (chmod 755 oder 644)."
        );
    }

    if ($operation === 'write' && !is_writable($path)) {
        $parent = dirname($path);
        $isParentWritable = is_writable($parent) ? "ja" : "nein";
        
        return errorMessage(
            "Schreibberechtigung fehlt",
            "Die Datei <code>" . htmlspecialchars($path) . "</code> kann nicht geschrieben werden. " .
            "Bitte prüfen Sie die Dateiberechtigungen. Eltern-Verzeichnis schreibbar: " . $isParentWritable
        );
    }

    if ($operation === 'mkdir' && !is_dir($path)) {
        if (!@mkdir($path, 0755, true)) {
            return errorMessage(
                "Verzeichnis konnte nicht erstellt werden",
                "Das Verzeichnis <code>" . htmlspecialchars($path) . 
                "</code> existiert nicht und konnte nicht erstellt werden."
            );
        }
    }

    return true;
}

/**
 * Formatiert eine Fehlermeldung als HTML-Box
 */
function errorMessage($title, $details = '') {
    $html = '<div class="error-box" style="background:#3a2f2f; border-left:4px solid #e74c3c; padding:20px; margin:20px 0; border-radius:4px;">';
    $html .= '<h3 style="color:#e74c3c; margin-top:0;">' . htmlspecialchars($title) . '</h3>';
    if ($details) {
        $html .= '<p style="margin:10px 0 0 0; color:#ccc; line-height:1.6;">' . $details . '</p>';
    }
    $html .= '</div>';
    return $html;
}

// ==================== INSTALL PATH ====================

/**
 * Liefert Installationspfade aus e3dc_paths.json oder Fallback.
 */
function getInstallPaths() {
    $defaultUser = 'pi';
    $defaultPath = '/home/pi/E3DC-Control/';
    $configFile = '/var/www/html/e3dc_paths.json';

    if (is_readable($configFile)) {
        $json = @file_get_contents($configFile);
        if ($json !== false) {
            $data = json_decode($json, true);
            if (is_array($data) && !empty($data['install_path'])) {
                $path = rtrim($data['install_path'], '/') . '/';
                return [
                    'install_user' => $data['install_user'] ?? $defaultUser,
                    'install_path' => $path,
                    'home_dir' => $data['home_dir'] ?? '/home/' . ($data['install_user'] ?? $defaultUser)
                ];
            }
        }
    }

    return [
        'install_user' => $defaultUser,
        'install_path' => $defaultPath,
        'home_dir' => '/home/' . $defaultUser
    ];
}

function getInstallPath() {
    $paths = getInstallPaths();
    return $paths['install_path'];
}

/**
 * Erzeugt eine Seiten-URL im aktuellen Kontext (mobile.php oder index.php).
 *
 * @param string $seite Zielseite
 * @param array $params Zusätzliche Query-Parameter
 * @return string
 */
function getContextPageUrl($seite, $params = []) {
    $script = basename($_SERVER['PHP_SELF'] ?? 'index.php');
    $entrypoint = ($script === 'mobile.php') ? 'mobile.php' : 'index.php';

    $query = array_merge(['seite' => $seite], $params);
    return $entrypoint . '?' . http_build_query($query);
}

/**
 * Prüft, ob ein Diagramm-Update gemäß der 15-Minuten-Regel fällig ist.
 * Regel: Maximal alle 15 Minuten, ca. 2 Minuten nach jeder Viertelstunde.
 */
function isDiagramUpdateDue($stampFile) {
    if (!file_exists($stampFile)) return true;
    
    $lastUpdate = filemtime($stampFile);
    $now = time();
    $minSinceLast = ($now - $lastUpdate) / 60;
    
    // Aktuelle Minute der Stunde
    $currentMin = (int)date('i', $now);
    
    // Bestimme den Start der aktuellen Viertelstunde (0, 15, 30, 45)
    $currentSlotStartMin = floor($currentMin / 15) * 15;
    
    // Der "Update-Zeitpunkt" ist 2 Minuten nach Slot-Start
    $updateThresholdMin = $currentSlotStartMin + 2;
    
    // Fall 1: Wir sind in der "Pufferzeit" (z.B. Minute 0-1) nach einer Viertelstunde.
    // Wir warten, bis Minute 2 erreicht ist. Damit weichen wir unnötigen Skriptläufen aus.
    if ($currentMin < $updateThresholdMin) {
        // Falls das letzte Update länger als 20 Minuten her ist (Sicherheitsnetz), trotzdem fällig
        return ($minSinceLast > 20);
    }
    
    // Fall 2: Wir sind nach Minute 2 (z.B. Minute 18). 
    // Wir schauen nach, ob das letzte Update heute schon nach Minute 17 (nach Slot-Start + 2) gelaufen ist.
    $fälligAb = strtotime(date('Y-m-d H:', $now) . sprintf('%02d', $updateThresholdMin) . ':00');
    
    return ($lastUpdate < $fälligAb);
}

/**
 * Gibt Erfolgs- oder Info-Meldung aus
 */
function successMessage($message) {
    return '<div class="success-box" style="background:#2d3d2a; border-left:4px solid #27ae60; padding:15px; margin:15px 0; border-radius:4px; color:#27ae60; font-weight:bold;">' 
           . htmlspecialchars($message) . '</div>';
}

// ==================== DATEIOPERATIONEN ====================

/**
 * Sichere Datei-Leseoperation mit Fehlerbehandlung
 * 
 * @param string $path Dateipfad
 * @param bool $asArray true = array, false = string
 * @return array|string|false Dateiinhalt oder false bei Fehler
 */
function safeReadFile($path, $asArray = false) {
    $check = checkFileAccess($path, 'read');
    if ($check !== true) {
        return false;
    }

    if ($asArray) {
        return file($path, FILE_IGNORE_NEW_LINES) ?: false;
    }
    return file_get_contents($path) ?: false;
}

/**
 * Sichere Datei-Schreiboperation mit Fehlerbehandlung
 */
function safeWriteFile($path, $content, $flags = LOCK_EX) {
    $check = checkFileAccess($path, 'write');
    if ($check !== true) {
        return false;
    }

    return @file_put_contents($path, $content, $flags) !== false;
}

// ==================== VALIDIERUNG ====================

/**
 * Validiert einen Dateinamen gegen Path-Traversal-Attacken
 */
function validateFilename($filename) {
    // Nur alphanumerisch, Punkte, Unterstriche, Bindestriche
    if (!preg_match('/^[a-zA-Z0-9._\-]+$/', $filename)) {
        return false;
    }
    // basename() entfernt Pfade
    if (basename($filename) !== $filename) {
        return false;
    }
    return true;
}

/**
 * Sanitiert Benutzereingaben
 */
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Prüft auf erforderliche POST-Parameter
 */
function requirePostParams($required = []) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return true;
    }

    foreach ($required as $param) {
        if (!isset($_POST[$param]) || $_POST[$param] === '') {
            die(errorMessage("Erforderlicher Parameter fehlt", "Parameter: " . htmlspecialchars($param)));
        }
    }
    return true;
}

// ==================== KONFIGURATION ====================

/**
 * Lädt die E3DC-Konfiguration mit Fehlerbehandlung
 */
function loadE3dcConfig($basePath = null) {
    if ($basePath === null) {
        $basePath = getInstallPath();
    }
    $configFile = $basePath . 'e3dc.config.txt';
    
    $check = checkFileAccess($configFile, 'read');
    if ($check !== true) {
        return ['error' => $check, 'config' => []];
    }

    $lines = file($configFile, FILE_IGNORE_NEW_LINES);
    $config = [];

    foreach ($lines as $line) {
        $line = trim($line);
        // Kommentare überspringen
        if (empty($line) || strpos($line, '#') === 0) {
            continue;
        }
        
        if (strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            if (!empty($key)) {
                $config[$key] = $value;
            }
        }
    }

    return ['error' => null, 'config' => $config];
}

// ==================== LOGGING ====================

/**
 * Optionales Logging (für Debugging)
 */
function debugLog($message, $data = null) {
    if (!defined('DEBUG_MODE') || !DEBUG_MODE) {
        return;
    }

    $logFile = '/var/www/html/tmp/debug.log';
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] " . $message;
    
    if ($data !== null) {
        $logMessage .= " | " . json_encode($data);
    }
    
    @error_log($logMessage . "\n", 3, $logFile);
}

// ==================== HTML UTILITIES ====================

/**
 * Formatiert einen Datetime-String
 */
function formatDateTime($timestamp, $format = 'd.m.Y H:i') {
    if (is_numeric($timestamp)) {
        return date($format, $timestamp);
    }
    return htmlspecialchars($timestamp);
}

/**
 * Erstellt ein sicheres Button-HTML-Element
 */
function createButton($label, $url = '', $class = 'form-button', $onclick = '') {
    if ($url) {
        return '<a href="' . htmlspecialchars($url) . '" class="' . $class . '">' 
               . htmlspecialchars($label) . '</a>';
    }
    return '<button type="button" class="' . $class . '" onclick="' . htmlspecialchars($onclick) . '">' 
           . htmlspecialchars($label) . '</button>';
}

/**
 * Behandelt die Vorbereitung des Updates (Flags setzen).
 * Sollte am Anfang von index.php und mobile.php aufgerufen werden.
 */
function handleUpdatePreparation() {
    if (isset($_GET['action']) && $_GET['action'] === 'prepare_update') {
        $force = isset($_GET['force']) && $_GET['force'] === 'true';
        $discard = isset($_GET['discard']) && $_GET['discard'] === 'true';
        $flagFile = '/tmp/e3dc_update_flags.json';
        // Flags speichern, damit Python sie lesen kann
        file_put_contents($flagFile, json_encode(['force' => $force, 'discard' => $discard]));
        @chmod($flagFile, 0666); // Lesbar für alle
        header('Content-Type: application/json');
        echo json_encode(['success' => true]);
        exit;
    }
}

/**
 * Prüft auf verfügbare Updates (Git Fetch).
 * Liefert JSON zurück. Cache-Dauer: 4 Stunden.
 */
function handleUpdateCheck() {
    if (isset($_GET['action']) && $_GET['action'] === 'check_update') {
        header('Content-Type: application/json');
        
        // Config prüfen: Wenn check_updates=0, dann abbrechen (außer force_check ist gesetzt)
        $confData = loadE3dcConfig();
        $checkUpdates = $confData['config']['check_updates'] ?? '1';
        if ($checkUpdates === '0' && !isset($_GET['force_check'])) {
            echo json_encode(['success' => true, 'missing' => 0, 'skipped' => true]);
            exit;
        }

        $cacheFile = '/tmp/e3dc_update_status.json';
        
        // Cache nutzen (4 Stunden = 14400 Sekunden)
        // Mit ?force_check=1 kann der Cache umgangen werden
        if (!isset($_GET['force_check']) && file_exists($cacheFile) && (time() - filemtime($cacheFile) < 14400)) {
            echo file_get_contents($cacheFile);
            exit;
        }
        
        $paths = getInstallPaths();
        $cmd = "timeout 15s sudo -u " . escapeshellarg($paths['install_user']) . " git -C " . escapeshellarg($paths['install_path']) . " fetch origin master 2>&1";
        exec($cmd, $out, $ret);
        
        $missing = ($ret === 0) ? (int)shell_exec("sudo -u " . escapeshellarg($paths['install_user']) . " git -C " . escapeshellarg($paths['install_path']) . " rev-list --count HEAD..origin/master") : 0;
        $res = ['success' => ($ret === 0), 'missing' => $missing];
        if ($ret !== 0) {
            $res['error'] = implode("\n", $out);
        }
        
        file_put_contents($cacheFile, json_encode($res));
        echo json_encode($res);
        exit;
    }
}

/**
 * Führt den Neustart des E3DC-Services aus.
 */
function handleServiceRestart() {
    if (isset($_GET['action']) && $_GET['action'] === 'restart_service') {
        header('Content-Type: application/json');
        exec("sudo /bin/systemctl restart e3dc 2>&1", $out, $ret);
        if ($ret === 0) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => implode("\n", $out)]);
        }
        exit;
    }
}

/**
 * Prüft den Status des Watchdog-Services (piguard).
 * Liefert JSON zurück: {installed: bool, active: bool, warning: bool, message: string}
 */
function handleWatchdogStatus() {
    if (isset($_GET['action']) && $_GET['action'] === 'watchdog_status') {
        header('Content-Type: application/json');
        
        $scriptPath = '/usr/local/bin/pi_guard.sh';
        if (!file_exists($scriptPath)) {
            echo json_encode(['installed' => false]);
            exit;
        }
        
        // Status prüfen (systemctl is-active gibt 'active' oder 'inactive' zurück)
        exec("systemctl is-active piguard 2>&1", $out, $ret);
        $isActive = (trim(implode('', $out)) === 'active');
        
        $warning = false;
        $message = $isActive ? 'Watchdog aktiv' : 'Watchdog inaktiv';

        // Warnung prüfen (Datei-Alter)
        // Wir lesen MONITOR_FILE aus dem Skript, um die Logik synchron zu halten
        $content = @file_get_contents($scriptPath);
        if ($content && preg_match('/MONITOR_FILE="([^"]*)"/', $content, $m)) {
            $monFile = trim($m[1]);
            if ($monFile) {
                // Platzhalter {{day}} auflösen (wie im Bash-Skript)
                if (strpos($monFile, '{{day}}') !== false) {
                    $pattern = str_replace('{{day}}', '*', $monFile);
                    $files = glob($pattern);
                    if ($files) {
                        // Neueste Datei zuerst (analog zu ls -t)
                        usort($files, function($a, $b) { return filemtime($b) - filemtime($a); });
                        $monFile = $files[0];
                    } else {
                        // Fallback auf Wochentag
                        $days = [1=>'Mo', 2=>'Di', 3=>'Mi', 4=>'Do', 5=>'Fr', 6=>'Sa', 7=>'So'];
                        $monFile = str_replace('{{day}}', $days[date('N')], $monFile);
                    }
                }
                
                if (file_exists($monFile)) {
                    $age = time() - filemtime($monFile);
                    if ($age > 900) { // > 15 Min (900 Sek)
                        $warning = true;
                        $min = floor($age / 60);
                        $message = "Warnung: Protokoll seit {$min} Min. nicht aktualisiert!";
                    }
                }
            }
        }
        
        echo json_encode([
            'installed' => true, 
            'active' => $isActive, 
            'warning' => $warning, 
            'message' => $message
        ]);
        exit;
    }
}

/**
 * Liefert das Watchdog-Log (journalctl) zurück.
 */
function handleWatchdogLog() {
    if (isset($_GET['action']) && $_GET['action'] === 'watchdog_log') {
        header('Content-Type: text/plain');
        // Letzte 50 Einträge, neueste zuerst
        passthru("journalctl -t PIGUARD -n 50 --no-pager --reverse 2>&1");
        exit;
    }
}

/**
 * Erzeugt das HTML für das Verbindungs-Badge (Online/Offline).
 * Einheitlich für Desktop und Mobile.
 */
function renderConnectionBadge() {
    return '<span id="connection-status" class="badge bg-secondary rounded-pill" style="cursor:pointer;" onclick="handleConnectionClick()" title="Status: Klicken zum Aktualisieren">Verbinde...</span>';
}

/**
 * Prüft auf Versions-Anfrage (?check_version) und gibt den Zeitstempel zurück.
 * Beendet das Skript, falls zutreffend.
 */
function handleVersionCheck($file) {
    if (isset($_GET['check_version'])) {
        header('Content-Type: text/plain');
        echo filemtime($file);
        exit;
    }
}

/**
 * Generiert das HTML für das Watchdog-Protokoll Modal.
 */
function renderWatchdogModal($dialogClass = 'modal-lg modal-dialog-scrollable') {
    return '
    <div class="modal fade" id="watchdogModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog ' . $dialogClass . '">
            <div class="modal-content bg-dark text-light border-secondary">
                <div class="modal-header border-secondary">
                    <h5 class="modal-title"><i class="fas fa-shield-alt me-2"></i>Watchdog Protokoll</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body bg-black p-2">
                    <pre id="watchdog-log-content" style="font-family: monospace; font-size: 0.8rem; color: #ccc; white-space: pre-wrap;">Lade...</pre>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal">Schließen</button>
                </div>
            </div>
        </div>
    </div>';
}

/**
 * Generiert das HTML für das System-Update Modal.
 */
function renderUpdateModal($dialogClass = 'modal-lg modal-dialog-scrollable') {
    return '
    <div class="modal fade" id="updateModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog ' . $dialogClass . '">
            <div class="modal-content bg-dark text-light border-secondary">
                <div class="modal-header border-secondary">
                    <h5 class="modal-title"><i class="fas fa-sync fa-spin me-2" id="update-spinner"></i>System Update</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close" id="update-close-btn" style="display:none;"></button>
                </div>
                <div class="modal-body bg-black p-2">
                    <pre id="update-log" style="font-family: monospace; font-size: 0.8rem; color: #0f0; white-space: pre-wrap;">Starte Update-Prozess...</pre>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal" id="update-finish-btn" disabled>Schließen</button>
                </div>
            </div>
        </div>
    </div>';
}

/**
 * Generiert das HTML für das Changelog Modal.
 */
function renderChangelogModal($dialogClass = 'modal-lg modal-dialog-scrollable') {
    $logFile = 'CHANGELOG.md';
    $content = "Kein Changelog verfügbar.";
    if (file_exists($logFile)) {
        $content = htmlspecialchars(file_get_contents($logFile));
    }
    
    return '
    <div class="modal fade" id="changelogModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog ' . $dialogClass . '">
            <div class="modal-content bg-dark text-light border-secondary">
                <div class="modal-header border-secondary">
                    <h5 class="modal-title">Changelog</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <pre style="white-space: pre-wrap; font-family: monospace; font-size: 0.85rem; color: #ccc;">' . $content . '</pre>
                </div>
            </div>
        </div>
    </div>';
}

/**
 * Lädt Preisdaten aus einer statischen Datei (z.B. awattardebug.23.txt),
 * um einen stabilen Tagesgraphen zu ermöglichen.
 */
function loadStaticPriceData($vat = 0) {
    $paths = getInstallPaths();
    $basePath = $paths['install_path'];
    
    // Zeitabhängige Priorisierung:
    // 18:00 - 06:00: Bevorzuge Mittags-Datei (11/12/13 Uhr), um Vorschau auf morgen zu haben.
    // 06:00 - 18:00: Bevorzuge Nacht-Datei (23/00 Uhr) für stabilen Tagesverlauf.
    $hour = (int)date('G');
    if ($hour >= 18 || $hour < 6) {
        $candidates = ['awattardebug.13.txt', 'awattardebug.14.txt', 'awattardebug.23.txt', 'awattardebug.0.txt'];
    } else {
        $candidates = ['awattardebug.23.txt', 'awattardebug.0.txt', 'awattardebug.12.txt', 'awattardebug.13.txt'];
    }
    
    $lines = false;
    $loadedFile = '';

    foreach ($candidates as $f) {
        if (file_exists($basePath . $f)) {
            $lines = @file($basePath . $f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if ($lines === false) {
                // Fallback: Versuch via cat (falls PHP-Leserechte klemmen)
                exec("cat " . escapeshellarg($basePath . $f), $out, $ret);
                if ($ret === 0 && !empty($out)) $lines = $out;
            }
            
            if ($lines) {
                $loadedFile = $f;
                break;
            }
        }
    }
    
    if (!$lines) return false;

    $prices = [];
    $startHour = null;
    $interval = null;
    $lastH = null;
    
    foreach ($lines as $line) {
        // BOM entfernen (UTF-8)
        $line = preg_replace('/^\xEF\xBB\xBF/', '', $line);
        $line = trim($line);
        
        // Header überspringen
        if (empty($line) || (!is_numeric(substr($line, 0, 1)) && substr($line, 0, 1) !== '-')) {
            if (!empty($prices)) break; // Stop bei neuem Block (z.B. "Data")
            continue;
        }

        // Trenner erkennen (Semikolon oder Whitespace)
        $parts = (strpos($line, ';') !== false) ? explode(';', $line) : preg_split('/\s+/', $line);

        if (count($parts) >= 2 && is_numeric($parts[0])) {
            $rawT = (float)str_replace(',', '.', trim($parts[0]));
            $val = (float)str_replace(',', '.', trim($parts[1]));
            
            // Timestamp (> 48) zu Stunde (0-23.99) konvertieren
            if ($rawT > 48) {
                $h = (float)gmdate('G', (int)$rawT) + ((int)gmdate('i', (int)$rawT)/60);
            } else {
                $h = $rawT;
            }

            
            // Duplikat-Check: Wenn wir wieder beim Start sind (z.B. neuer Block)
            if ($startHour !== null && abs($h - $startHour) < 0.001 && count($prices) > 0) break;

            if ($vat > 0) $val = $val * (1 + ($vat / 100));
            $prices[] = $val;
            
            if ($startHour === null) {
                $startHour = $h;
            } elseif ($interval === null) {
                $diff = $h - $lastH;
                if ($diff < 0) $diff += 24; // Tageswechsel
                if ($diff > 0.001) $interval = $diff;
            }
            $lastH = $h;
        }
    }
    
    return empty($prices) ? false : [
        'prices' => $prices, 
        'start_hour' => $startHour, 
        'interval' => ($interval ?: 1),
        'source' => $loadedFile
    ];
}

/**
 * Liest verfügbare History-Backup-Dateien aus dem Backup-Verzeichnis.
 * Liefert ein Array mit 'file' (Dateiname) und 'label' (formatiertes Datum).
 */
function getHistoryBackupFiles($backupDir = '/var/www/html/tmp/history_backups/') {
    $historyFiles = [];
    if (is_dir($backupDir)) {
        $files = glob($backupDir . 'history_*.txt');
        if ($files) {
            rsort($files); // Neueste zuerst
            foreach ($files as $file) {
                $basename = basename($file);
                if (preg_match('/history_(\d{4}-\d{2}-\d{2})\.txt/', $basename, $m)) {
                    $label = date('d.m.Y', strtotime($m[1]));
                    $historyFiles[] = ['file' => $basename, 'label' => $label];
                }
            }
        }
    }
    return $historyFiles;
}

/**
 * Hilfsfunktion zum Parsen von Kommazahlen aus Config-Dateien.
 */
function parseConfigFloat($val) {
    return (float)str_replace(',', '.', $val);
}

/**
 * Berechnet 24h Mittelwerte aus der History-Datei (Cache 1 Std).
 */
function get24hAverages($filePath) {
    $cacheFile = '/tmp/e3dc_avgs.json';
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 3600) {
        return json_decode(file_get_contents($cacheFile), true);
    }

    $avgs = ['home' => 800, 'grid' => 1000, 'wb' => 4000];
    if (file_exists($filePath)) {
        $lines = @file($filePath);
        if ($lines) {
            $lines = array_slice($lines, -1000); // Letzte Einträge
            $sums = ['h' => 0, 'g' => 0, 'w' => 0]; $c = 0;
            foreach ($lines as $l) {
                $d = json_decode($l, true);
                if ($d) { $sums['h'] += abs($d['home_raw']??0); $sums['g'] += abs($d['grid']??0); $sums['w'] += ($d['wb']??0); $c++; }
            }
            if ($c > 0) $avgs = ['home' => $sums['h']/$c, 'grid' => $sums['g']/$c, 'wb' => $sums['w']/$c];
        }
    }
    file_put_contents($cacheFile, json_encode($avgs));
    return $avgs;
}

/**
 * Sucht nach archivierten awattardebug-Dateien.
 */
function getArchivedDebugFiles($basePath) {
    $files = [];
    if (is_dir($basePath)) {
        foreach (glob(rtrim($basePath, '/') . '/awattardebug.*.txt') as $f) {
            if (preg_match('/awattardebug\.(\d+)\.txt$/', $f, $m)) {
                $ts = filemtime($f);
                $files[] = [
                    'file' => basename($f),
                    'ts' => $ts,
                    'label' => date('d.m. H:i', $ts) . " (Run {$m[1]})"
                ];
            }
        }
        usort($files, fn($a, $b) => $b['ts'] <=> $a['ts']);
    }
    return $files;
}

/**
 * Speichert eine Einstellung in der e3dc.config.txt (AJAX).
 */
function handleSaveSetting() {
    if (isset($_POST['action']) && $_POST['action'] === 'save_setting') {
        if (!isset($_POST['key'], $_POST['value'])) exit;
        
        $paths = getInstallPaths();
        $configFile = rtrim($paths['install_path'], '/') . '/e3dc.config.txt';
        $key = trim($_POST['key']);
        $val = trim($_POST['value']);
        
        if (!preg_match('/^[a-z0-9_]+$/i', $key)) { http_response_code(400); exit; }

        $lines = file_exists($configFile) ? file($configFile, FILE_IGNORE_NEW_LINES) : [];
        $newLines = [];
        $found = false;

        foreach ($lines as $line) {
            if (preg_match('/^\s*' . preg_quote($key, '/') . '\s*=/i', $line)) {
                $newLines[] = "$key = $val";
                $found = true;
            } else {
                $newLines[] = $line;
            }
        }
        if (!$found) $newLines[] = "$key = $val";

        if (file_put_contents($configFile, implode("\n", $newLines) . "\n", LOCK_EX) !== false) echo "ok";
        else { http_response_code(500); echo "error"; }
        exit;
    }
}

/**
 * Liefert den Status der Diagramm-Erstellung (AJAX).
 */
function handleStatus() {
    if (isset($_GET['action']) && $_GET['action'] === 'status') {
        header('Content-Type: application/json');
        $mode = $_GET['mode'] ?? 'normal';
        $suffix = ($mode == 'mobile') ? '_mobile' : (($mode == 'archiv') ? '_archiv' : '');
        
        $lock = "/var/www/html/tmp/plot_soc_running" . $suffix;
        $error = "/var/www/html/tmp/plot_soc_error" . $suffix;
        $diagramm = "/var/www/html/" . (($mode == 'mobile') ? 'diagramm_mobile.html' : (($mode == 'archiv') ? 'archiv_diagramm.html' : 'diagramm.html'));

        $status = [
            'running' => file_exists($lock),
            'error' => file_exists($error),
            'error_message' => file_exists($error) ? file_get_contents($error) : null,
            'last_update' => file_exists($diagramm) ? date('H:i:s', filemtime($diagramm)) : null
        ];
        echo json_encode($status);
        exit;
    }
}

/**
 * Startet die Diagramm-Erstellung (AJAX).
 */
function handleRunNow() {
    if (isset($_GET['action']) && $_GET['action'] === 'run_now') {
        header('Content-Type: text/plain');
        $mode = $_GET['mode'] ?? 'normal';
        $suffix = ($mode == 'mobile') ? '_mobile' : (($mode == 'archiv') ? '_archiv' : '');
        
        $lock = "/var/www/html/tmp/plot_soc_running" . $suffix;
        $error = "/var/www/html/tmp/plot_soc_error" . $suffix;
        
        // Auto-Check
        if (isset($_GET['auto']) && $_GET['auto'] == '1') {
            $stamp = "/var/www/html/tmp/plot_soc_last_run"; // Globaler Stamp
            if (!isDiagramUpdateDue($stamp)) { echo "skipped"; exit; }
        }

        if (file_exists($lock)) {
            if (time() - filemtime($lock) > 300) @unlink($lock); // Selbstheilung
            else { echo "running"; exit; }
        }

        @unlink($error);
        @mkdir(dirname($lock), 0755, true);
        touch($lock);

        $paths = getInstallPaths();
        $script = rtrim($paths['install_path'], '/') . '/plot_soc_changes.py';
        $cmd = "nohup /usr/bin/python3 " . escapeshellarg($script) . " " . escapeshellarg($paths['install_path'].'awattardebug.txt') . " " . escapeshellarg($mode) . " > /dev/null 2>&1 &";
        @shell_exec($cmd);
        
        echo "started";
        exit;
    }
}

/**
 * Startet die Live-History Diagramm-Erstellung (AJAX).
 */
function handleRunLiveHistory() {
    if (isset($_GET['action']) && $_GET['action'] === 'run_live_history') {
        header('Content-Type: application/json');
        
        // Status-Abfrage
        if (isset($_GET['mode']) && $_GET['mode'] === 'status') {
            $lock = '/var/www/html/tmp/plot_live_history_running';
            $html = '/var/www/html/live_diagramm.html';
            echo json_encode([
                'running' => file_exists($lock),
                'last_update' => file_exists($html) ? date('d.m.Y H:i', filemtime($html)) : null
            ]);
            exit;
        }

        $paths = getInstallPaths();
        $script = rtrim($paths['install_path'], '/') . '/plot_live_history.py';
        $hours = isset($_GET['hours']) ? (int)$_GET['hours'] : 6;
        $fileParam = '';

        if (!empty($_GET['file'])) {
            $f = basename($_GET['file']);
            $fp = '/var/www/html/tmp/history_backups/' . $f;
            if (file_exists($fp)) { $fileParam = ' --file ' . escapeshellarg($fp); $hours = 24; }
        }

        $cmd = 'python3 ' . escapeshellarg($script) . ' --hours ' . escapeshellarg($hours) . $fileParam . ' 2>/dev/null &';
        @shell_exec($cmd);
        echo json_encode(['ok' => true, 'status' => 'started']);
        exit;
    }
}

/**
 * Führt das System-Update aus (AJAX).
 * Ersetzt run_update.php
 */
function handleRunUpdate() {
    if (isset($_GET['action']) && $_GET['action'] === 'run_update') {
        header('Content-Type: application/json');
        $paths = getInstallPaths();
        
        // Installer suchen
        $candidates = [
            rtrim($paths['install_path'], '/') . '/../Install/installer_main.py',
            $paths['home_dir'] . '/Install/installer_main.py'
        ];
        $installer_main = false;
        foreach ($candidates as $candidate) {
            if (file_exists($candidate)) { $installer_main = realpath($candidate); break; }
        }
        
        if (!$installer_main) {
            echo json_encode(['status' => 'error', 'message' => "Installer nicht gefunden."]);
            exit;
        }

        $logFile = '/var/www/html/tmp/update.log';
        $pidFile = '/var/www/html/tmp/update.pid';
        $mode = $_GET['mode'] ?? 'start';

        if ($mode === 'start') {
            if (file_exists($pidFile)) {
                $pid = (int)trim(file_get_contents($pidFile));
                if (file_exists("/proc/$pid")) { echo json_encode(['status' => 'running', 'message' => 'Update läuft bereits.']); exit; }
                @unlink($pidFile);
            }
            file_put_contents($logFile, "Initialisiere Update-Prozess...\n");
            chmod($logFile, 0666);
            
            $cmd = "sudo /usr/bin/python3 " . escapeshellarg($installer_main) . " --update-e3dc";
            $fullCmd = sprintf("nohup %s > %s 2>&1 & echo $!", $cmd, escapeshellarg($logFile));
            $pid = exec($fullCmd);
            
            if ($pid) { file_put_contents($pidFile, $pid); echo json_encode(['status' => 'started', 'pid' => $pid]); }
            else { echo json_encode(['status' => 'error', 'message' => 'Konnte Prozess nicht starten.']); }
        } elseif ($mode === 'poll') {
            $log = file_exists($logFile) ? file_get_contents($logFile) : '';
            $running = false;
            if (file_exists($pidFile)) {
                $pid = (int)trim(file_get_contents($pidFile));
                if (file_exists("/proc/$pid")) $running = true; else @unlink($pidFile);
            }
            echo json_encode(['running' => $running, 'log' => $log]);
        }
        exit;
    }
}

/**
 * Generiert das Archiv-Diagramm (AJAX/Iframe).
 * Ersetzt archiv_diagramm.php
 */
function handleArchivDiagram() {
    if (isset($_GET['action']) && $_GET['action'] === 'archiv_diagram') {
        $paths = getInstallPaths();
        $base_path = rtrim($paths['install_path'], '/') . '/';
        
        if (!isset($_GET['file'])) die(errorMessage("Fehler", "Keine Datei angegeben."));
        $file = basename($_GET['file']);
        if (!validateFilename($file)) die(errorMessage("Sicherheitsfehler", "Ungültiger Dateiname."));
        
        $fullpath = $base_path . $file;
        $check = checkFileAccess($fullpath, 'read');
        if ($check !== true) die($check);
        
        $tmp_dir = "/var/www/html/tmp";
        if (!is_dir($tmp_dir)) @mkdir($tmp_dir, 0755, true);
        
        $doneFile = "/var/www/html/tmp/plot_soc_done_archiv";
        @unlink($doneFile);
        
        $cmd = "/usr/bin/python3 " . $base_path . "plot_soc_changes.py " . escapeshellarg($fullpath) . " archiv 2>&1";
        exec($cmd, $output, $returnCode);
        
        if ($returnCode !== 0) die(errorMessage("Fehler", "Python-Skript fehlgeschlagen: " . implode("\n", $output)));
        
        // Warte auf Done-Datei (max 10s)
        $timeout = 10; $start = time();
        while (!file_exists($doneFile) && (time() - $start) < $timeout) usleep(200000);
        
        if (!file_exists($doneFile)) die(errorMessage("Timeout", "Diagramm wurde nicht rechtzeitig erstellt."));
        
        $diagramm_file = "/var/www/html/archiv_diagramm.html";
        if (file_exists($diagramm_file)) readfile($diagramm_file);
        else die(errorMessage("Fehler", "Ausgabedatei nicht gefunden."));
        exit;
    }
}
?>
