<?php
/**
 * helpers.php - Zentrale Utility-Funktionen für E3DC-Control Web-Interface
 */

date_default_timezone_set('Europe/Berlin');

// ==================== ERROR HANDLING ====================

/**
 * Prüft den Dateizugriff und zeigt eine benutzerfreundliche Fehlermeldung
 * 
 * @param string $path Dateipfad
 * @param string $operation 'read', 'write', or 'exists'
 * @return bool|string true bei Erfolg, oder HTML mit Fehlermeldung
 */
function checkFileAccess($path, $operation = 'read') {
    // Sicherheit: Nur absolute Pfade oder relative im bekannten Verzeichnis
    if (strpos($path, '..') !== false) {
        return errorMessage("Ungültiger Pfad: Pfad-Traversal erkannt.");
    }

    if (!file_exists($path)) {
        return errorMessage(
            "Datei nicht gefunden",
            "Der Zugriff auf <code>" . htmlspecialchars($path) . "</code> ist fehlgeschlagen. " .
            "Möglicherweise existiert die Datei nicht oder der Pfad ist falsch."
        );
    }

    if ($operation === 'read' && !is_readable($path)) {
        return errorMessage(
            "Leseberechtigung fehlt",
            "Die Datei <code>" . htmlspecialchars($path) . "</code> kann nicht gelesen werden. " .
            "Bitte prüfen Sie die Dateiberechtigungen (chmod 755 oder 644)."
        );
    }

    if ($operation === 'write' && !is_writable($path)) {
        $parent = dirname($path);
        $isParentWritable = is_writable($parent) ? "ja" : "nein";
        
        return errorMessage(
            "Schreibberechtigung fehlt",
            "Die Datei <code>" . htmlspecialchars($path) . "</code> kann nicht geschrieben werden. " .
            "Bitte prüfen Sie die Dateiberechtigungen. Eltern-Verzeichnis schreibbar: " . $isParentWritable
        );
    }

    if ($operation === 'mkdir' && !is_dir($path)) {
        if (!@mkdir($path, 0755, true)) {
            return errorMessage(
                "Verzeichnis konnte nicht erstellt werden",
                "Das Verzeichnis <code>" . htmlspecialchars($path) . 
                "</code> existiert nicht und konnte nicht erstellt werden."
            );
        }
    }

    return true;
}

/**
 * Formatiert eine Fehlermeldung als HTML-Box
 */
function errorMessage($title, $details = '') {
    $html = '<div class="error-box" style="background:#3a2f2f; border-left:4px solid #e74c3c; padding:20px; margin:20px 0; border-radius:4px;">';
    $html .= '<h3 style="color:#e74c3c; margin-top:0;">' . htmlspecialchars($title) . '</h3>';
    if ($details) {
        $html .= '<p style="margin:10px 0 0 0; color:#ccc; line-height:1.6;">' . $details . '</p>';
    }
    $html .= '</div>';
    return $html;
}

// ==================== INSTALL PATH ====================

/**
 * Liefert Installationspfade aus e3dc_paths.json oder Fallback.
 */
function getInstallPaths() {
    $defaultUser = 'pi';
    $defaultPath = '/home/pi/E3DC-Control/';
    $configFile = '/var/www/html/e3dc_paths.json';

    if (is_readable($configFile)) {
        $json = @file_get_contents($configFile);
        if ($json !== false) {
            $data = json_decode($json, true);
            if (is_array($data) && !empty($data['install_path'])) {
                $path = rtrim($data['install_path'], '/') . '/';
                return [
                    'install_user' => $data['install_user'] ?? $defaultUser,
                    'install_path' => $path,
                    'home_dir' => $data['home_dir'] ?? '/home/' . ($data['install_user'] ?? $defaultUser)
                ];
            }
        }
    }

    return [
        'install_user' => $defaultUser,
        'install_path' => $defaultPath,
        'home_dir' => '/home/' . $defaultUser
    ];
}

function getInstallPath() {
    $paths = getInstallPaths();
    return $paths['install_path'];
}

/**
 * Ermittelt den korrekten Python-Interpreter (venv oder system).
 */
function getPythonInterpreter() {
    $paths = getInstallPaths();
    // Lese venv_name aus e3dc_paths.json (wird dort von installer_main.py hinterlegt)
    $json = @json_decode(@file_get_contents('/var/www/html/e3dc_paths.json'), true);
    $venvName = $json['venv_name'] ?? '.venv_e3dc';
    
    // 1. Expliziter Pfad aus Config (neu)
    if (!empty($json['venv_path']) && file_exists($json['venv_path'] . '/bin/python3')) {
        return $json['venv_path'] . '/bin/python3';
    }

    // 2. Standard Pfad (Home)
    $venvPython = rtrim($paths['home_dir'], '/') . '/' . $venvName . '/bin/python3';
    if (file_exists($venvPython) && is_executable($venvPython)) {
        return $venvPython;
    }
    
    // 3. Legacy Pfad (Install Dir) - Fallback
    $legacyPython = rtrim($paths['install_path'], '/') . '/' . $venvName . '/bin/python3';
    if (file_exists($legacyPython) && is_executable($legacyPython)) {
        return $legacyPython;
    }

    return '/usr/bin/python3';
}

/**
 * Erzeugt eine Seiten-URL im aktuellen Kontext (mobile.php oder index.php).
 *
 * @param string $seite Zielseite
 * @param array $params Zusätzliche Query-Parameter
 * @return string
 */
function getContextPageUrl($seite, $params = []) {
    $script = basename($_SERVER['PHP_SELF'] ?? 'index.php');
    $entrypoint = ($script === 'mobile.php') ? 'mobile.php' : 'index.php';

    $query = array_merge(['seite' => $seite], $params);
    return $entrypoint . '?' . http_build_query($query);
}

/**
 * Prüft, ob ein Diagramm-Update gemäß der 15-Minuten-Regel fällig ist.
 * Regel: Maximal alle 15 Minuten, ca. 2 Minuten nach jeder Viertelstunde.
 */
function isDiagramUpdateDue($stampFile) {
    if (!file_exists($stampFile)) return true;
    
    $lastUpdate = filemtime($stampFile);
    $now = time();
    $minSinceLast = ($now - $lastUpdate) / 60;
    
    // Aktuelle Minute der Stunde
    $currentMin = (int)date('i', $now);
    
    // Bestimme den Start der aktuellen Viertelstunde (0, 15, 30, 45)
    $currentSlotStartMin = floor($currentMin / 15) * 15;
    
    // Der "Update-Zeitpunkt" ist 2 Minuten nach Slot-Start
    $updateThresholdMin = $currentSlotStartMin + 2;
    
    // Fall 1: Wir sind in der "Pufferzeit" (z.B. Minute 0-1) nach einer Viertelstunde.
    // Wir warten, bis Minute 2 erreicht ist. Damit weichen wir unnötigen Skriptläufen aus.
    if ($currentMin < $updateThresholdMin) {
        // Falls das letzte Update länger als 20 Minuten her ist (Sicherheitsnetz), trotzdem fällig
        return ($minSinceLast > 20);
    }
    
    // Fall 2: Wir sind nach Minute 2 (z.B. Minute 18). 
    // Wir schauen nach, ob das letzte Update heute schon nach Minute 17 (nach Slot-Start + 2) gelaufen ist.
    $fälligAb = strtotime(date('Y-m-d H:', $now) . sprintf('%02d', $updateThresholdMin) . ':00');
    
    return ($lastUpdate < $fälligAb);
}

/**
 * Gibt Erfolgs- oder Info-Meldung aus
 */
function successMessage($message) {
    return '<div class="success-box" style="background:#2d3d2a; border-left:4px solid #27ae60; padding:15px; margin:15px 0; border-radius:4px; color:#27ae60; font-weight:bold;">' 
           . htmlspecialchars($message) . '</div>';
}

// ==================== DATEIOPERATIONEN ====================

/**
 * Sichere Datei-Leseoperation mit Fehlerbehandlung
 * 
 * @param string $path Dateipfad
 * @param bool $asArray true = array, false = string
 * @return array|string|false Dateiinhalt oder false bei Fehler
 */
function safeReadFile($path, $asArray = false) {
    $check = checkFileAccess($path, 'read');
    if ($check !== true) {
        return false;
    }

    if ($asArray) {
        return file($path, FILE_IGNORE_NEW_LINES) ?: false;
    }
    return file_get_contents($path) ?: false;
}

/**
 * Sichere Datei-Schreiboperation mit Fehlerbehandlung
 */
function safeWriteFile($path, $content, $flags = LOCK_EX) {
    $check = checkFileAccess($path, 'write');
    if ($check !== true) {
        return false;
    }

    return @file_put_contents($path, $content, $flags) !== false;
}

// ==================== VALIDIERUNG ====================

/**
 * Validiert einen Dateinamen gegen Path-Traversal-Attacken
 */
function validateFilename($filename) {
    // Nur alphanumerisch, Punkte, Unterstriche, Bindestriche
    if (!preg_match('/^[a-zA-Z0-9._\-]+$/', $filename)) {
        return false;
    }
    // basename() entfernt Pfade
    if (basename($filename) !== $filename) {
        return false;
    }
    return true;
}

/**
 * Sanitiert Benutzereingaben
 */
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Prüft auf erforderliche POST-Parameter
 */
function requirePostParams($required = []) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return true;
    }

    foreach ($required as $param) {
        if (!isset($_POST[$param]) || $_POST[$param] === '') {
            die(errorMessage("Erforderlicher Parameter fehlt", "Parameter: " . htmlspecialchars($param)));
        }
    }
    return true;
}

// ==================== KONFIGURATION ====================

/**
 * Lädt die E3DC-Konfiguration mit Fehlerbehandlung
 */
function loadE3dcConfig($basePath = null) {
    if ($basePath === null) {
        $basePath = getInstallPath();
    }
    $configFile = $basePath . 'e3dc.config.txt';
    
    $check = checkFileAccess($configFile, 'read');
    if ($check !== true) {
        return ['error' => $check, 'config' => []];
    }

    // --- NEU: RAM-Disk Caching für e3dc.config.txt ---
    $cacheFile = '/var/www/html/ramdisk/e3dc_config_cache.json';
    $mtime = filemtime($configFile);
    
    if (file_exists($cacheFile)) {
        $cache = @json_decode(file_get_contents($cacheFile), true);
        if ($cache && isset($cache['mtime']) && $cache['mtime'] === $mtime) {
            return ['error' => null, 'config' => $cache['config']];
        }
    }

    $lines = file($configFile, FILE_IGNORE_NEW_LINES);
    $config = [];

    foreach ($lines as $line) {
        $line = trim($line);
        // Kommentare überspringen
        if (empty($line) || strpos($line, '#') === 0) {
            continue;
        }
        
        if (strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            if (!empty($key)) {
                $config[strtolower($key)] = $value;
            }
        }
    }

    // Im RAM zwischenspeichern
    @file_put_contents($cacheFile, json_encode(['mtime' => $mtime, 'config' => $config]));

    return ['error' => null, 'config' => $config];
}

// ==================== LOGGING ====================

/**
 * Optionales Logging (für Debugging)
 */
function debugLog($message, $data = null) {
    if (!defined('DEBUG_MODE') || !DEBUG_MODE) {
        return;
    }

    $logFile = '/var/www/html/tmp/debug.log';
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] " . $message;
    
    if ($data !== null) {
        $logMessage .= " | " . json_encode($data);
    }
    
    @error_log($logMessage . "\n", 3, $logFile);
}

// ==================== HTML UTILITIES ====================

/**
 * Formatiert einen Datetime-String
 */
function formatDateTime($timestamp, $format = 'd.m.Y H:i') {
    if (is_numeric($timestamp)) {
        return date($format, $timestamp);
    }
    return htmlspecialchars($timestamp);
}

/**
 * Erstellt ein sicheres Button-HTML-Element
 */
function createButton($label, $url = '', $class = 'form-button', $onclick = '') {
    if ($url) {
        return '<a href="' . htmlspecialchars($url) . '" class="' . $class . '">' 
               . htmlspecialchars($label) . '</a>';
    }
    return '<button type="button" class="' . $class . '" onclick="' . htmlspecialchars($onclick) . '">' 
           . htmlspecialchars($label) . '</button>';
}

/**
 * Liest den Update-Status aus dem Cache (für PHP-Rendering).
 */
function getUpdateStatusFromCache() {
    $cacheFile = '/tmp/e3dc_update_status.json';
    if (file_exists($cacheFile)) {
        $content = @file_get_contents($cacheFile);
        if ($content) {
            $data = json_decode($content, true);
            if (is_array($data) && isset($data['success']) && $data['success'] && isset($data['missing'])) {
                return (int)$data['missing'];
            }
        }
    }
    return 0;
}

/**
 * Behandelt die Vorbereitung des Updates (Flags setzen).
 * Sollte am Anfang von index.php und mobile.php aufgerufen werden.
 */
function handleUpdatePreparation() {
    if (isset($_GET['action']) && $_GET['action'] === 'prepare_update') {
        $force = isset($_GET['force']) && $_GET['force'] === 'true';
        $discard = isset($_GET['discard']) && $_GET['discard'] === 'true';
        $flagFile = '/tmp/e3dc_update_flags.json';
        // Flags speichern, damit Python sie lesen kann
        file_put_contents($flagFile, json_encode(['force' => $force, 'discard' => $discard]));
        @chmod($flagFile, 0666); // Lesbar für alle
        header('Content-Type: application/json');
        echo json_encode(['success' => true]);
        exit;
    }
}

/**
 * Prüft auf verfügbare Updates (Git Fetch).
 * Liefert JSON zurück. Cache-Dauer: 4 Stunden.
 */
function handleUpdateCheck() {
    if (isset($_GET['action']) && $_GET['action'] === 'check_update') {
        // Caching verhindern (Wichtig für Cloudflare/Browser)
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
        header('Content-Type: application/json');
        
        // Config prüfen: Wenn check_updates=0, dann abbrechen (außer force_check ist gesetzt)
        $confData = loadE3dcConfig();
        $checkUpdates = $confData['config']['check_updates'] ?? '1';
        if ($checkUpdates === '0' && !isset($_GET['force_check'])) {
            echo json_encode(['success' => true, 'missing' => 0, 'skipped' => true]);
            exit;
        }

        $cacheFile = '/tmp/e3dc_update_status.json';
        
        // Cache nutzen (4 Stunden = 14400 Sekunden)
        // Mit ?force_check=1 kann der Cache umgangen werden
        if (!isset($_GET['force_check']) && file_exists($cacheFile) && (time() - filemtime($cacheFile) < 840)) { // Cache auf 14 Minuten reduziert
            echo file_get_contents($cacheFile);
            exit;
        }
        
        $paths = getInstallPaths();
        $user = escapeshellarg($paths['install_user']);
        $path = escapeshellarg($paths['install_path']);

        // 1. Fetch updates directly from Eba-M/E3DC-Control
        $repoUrl = 'https://github.com/Eba-M/E3DC-Control.git';
        $cmd = "timeout 20s sudo -u $user git -C $path fetch $repoUrl master 2>&1";
        exec($cmd, $out, $ret);
        
        $missing = 0;
        if ($ret === 0) {
            // 2. Commits zählen (HEAD gegen FETCH_HEAD)
            $gitBase = "sudo -u $user git -C $path";
            $countCmd = "$gitBase rev-list --count HEAD..FETCH_HEAD 2>/dev/null";
            $count = shell_exec($countCmd);
            
            if (is_numeric(trim($count))) {
                $missing = (int)$count;
            }
        }

        $res = ['success' => ($ret === 0), 'missing' => $missing];
        if ($ret !== 0) {
            $res['error'] = implode("\n", $out);
        }
        
        file_put_contents($cacheFile, json_encode($res));
        echo json_encode($res);
        exit;
    }
}

/**
 * Prüft auf Updates für den Installer/Diagramme (A9xxx).
 * Cache-Dauer: 4 Stunden.
 */
function handleSelfUpdateCheck() {
    if (isset($_GET['action']) && $_GET['action'] === 'check_self_update') {
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Content-Type: application/json');
        
        $cacheFile = '/tmp/e3dc_self_update_status.json';
        if (!isset($_GET['force']) && file_exists($cacheFile) && (time() - filemtime($cacheFile) < 14400)) {
            echo file_get_contents($cacheFile);
            exit;
        }

        $paths = getInstallPaths();
        $home = $paths['home_dir']; // z.B. /home/pi
        $installDir = $home . '/Install'; // Standard Pfad für A9xxx Installer
        
        $missing = 0;
        
        // Git Prüfung
        if (is_dir($installDir . '/.git')) {
            $cmd = "sudo -u " . escapeshellarg($paths['install_user']) . " git -C " . escapeshellarg($installDir) . " fetch origin 2>&1";
            exec($cmd);
            
            $countCmd = "sudo -u " . escapeshellarg($paths['install_user']) . " git -C " . escapeshellarg($installDir) . " rev-list --count HEAD..@{u} 2>/dev/null";
            $count = shell_exec($countCmd);
            if (is_numeric(trim($count))) {
                $missing = (int)$count;
            }
        } else {
            // Fallback: Wenn kein Git, prüfen wir über Python Skript (Release Methode)
            // Das ist langsamer, daher nur wenn nötig.
            // Wir geben hier einfach 0 zurück, da Web-Update ohne Git komplex ist oder nehmen an "aktuell".
        }

        $res = ['success' => true, 'missing' => $missing];
        file_put_contents($cacheFile, json_encode($res));
        echo json_encode($res);
        exit;
    }
}

/**
 * Führt das Installer-Update (Diagramme) aus.
 */
function handleRunSelfUpdate() {
    if (isset($_GET['action']) && $_GET['action'] === 'run_self_update') {
        header('Content-Type: application/json');
        
        $paths = getInstallPaths();
        // Pfad zum self_update.py ermitteln
        $candidates = [
            $paths['home_dir'] . '/Install/Installer/self_update.py',
            rtrim($paths['install_path'], '/') . '/../Install/Installer/self_update.py'
        ];
        
        $script = false;
        foreach ($candidates as $c) {
            if (file_exists($c)) { $script = $c; break; }
        }

        if (!$script) {
            echo json_encode(['success' => false, 'message' => 'Update-Skript nicht gefunden.']);
            exit;
        }

        // Starte das Skript via sudo als der Installationsbenutzer
        // Wir nutzen --silent, damit es durchläuft
        // Wir setzen PYTHONPATH damit relative Importe funktionieren
        // Wir leiten die Ausgabe in eine Log-Datei um für Debugging
        $baseDir = dirname(dirname($script)); // .../Install
        $logFile = '/var/www/html/logs/self_update_php.log';
        
        // Log-Datei vorbereiten und bei jedem Lauf leeren
        @file_put_contents($logFile, "=== Starting Diagram Update at ".date('Y-m-d H:i:s')." ===\n\n");
        @chmod($logFile, 0664);

        // Aufruf via sudo als root (erfordert sudoers Eintrag durch diagrammphp.py)
        // Wir nutzen --silent und leiten Ausgaben in das Logfile
        $cmd = "sudo /usr/bin/python3 " . escapeshellarg($script) . " --silent >> " . escapeshellarg($logFile) . " 2>&1 &";
        exec($cmd);
        
        echo json_encode(['success' => true, 'message' => 'Update gestartet. Bei Problemen, siehe /logs/self_update_php.log']);
        exit;
    }
}

/**
 * Führt den Neustart des E3DC-Services aus.
 */
function handleServiceRestart() {
    if (isset($_GET['action']) && $_GET['action'] === 'restart_service') {
        header('Content-Type: application/json');
        exec("sudo /bin/systemctl restart e3dc 2>&1", $out, $ret);
        if ($ret === 0) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => implode("\n", $out)]);
        }
        exit;
    }
}

/**
 * Prüft den Status des Watchdog-Services (piguard).
 * Liefert JSON zurück: {installed: bool, active: bool, warning: bool, message: string}
 */
function handleWatchdogStatus() {
    if (isset($_GET['action']) && $_GET['action'] === 'watchdog_status') {
        header('Content-Type: application/json');
        
        $scriptPath = '/usr/local/bin/pi_guard.sh';
        if (!file_exists($scriptPath)) {
            echo json_encode(['installed' => false]);
            exit;
        }
        
        // Status prüfen (systemctl is-active gibt 'active' oder 'inactive' zurück)
        exec("systemctl is-active piguard 2>&1", $out, $ret);
        $isActive = (trim(implode('', $out)) === 'active');
        
        $warning = false;
        $message = $isActive ? 'Watchdog aktiv' : 'Watchdog inaktiv';

        // Warnung prüfen (Datei-Alter)
        // Wir lesen MONITOR_FILE aus dem Skript, um die Logik synchron zu halten
        $content = @file_get_contents($scriptPath);
        if ($content && preg_match('/MONITOR_FILE="([^"]*)"/', $content, $m)) {
            $monFile = trim($m[1]);
            if ($monFile) {
                // Platzhalter {{day}} auflösen (wie im Bash-Skript)
                if (strpos($monFile, '{{day}}') !== false) {
                    $pattern = str_replace('{{day}}', '*', $monFile);
                    $files = glob($pattern);
                    if ($files) {
                        // Neueste Datei zuerst (analog zu ls -t)
                        usort($files, function($a, $b) { return filemtime($b) - filemtime($a); });
                        $monFile = $files[0];
                    } else {
                        // Fallback auf Wochentag
                        $days = [1=>'Mo', 2=>'Di', 3=>'Mi', 4=>'Do', 5=>'Fr', 6=>'Sa', 7=>'So'];
                        $monFile = str_replace('{{day}}', $days[date('N')], $monFile);
                    }
                }
                
                if (file_exists($monFile)) {
                    $age = time() - filemtime($monFile);
                    if ($age > 900) { // > 15 Min (900 Sek)
                        $warning = true;
                        $min = floor($age / 60);
                        $message = "Warnung: Protokoll seit {$min} Min. nicht aktualisiert!";
                    }
                }
            }
        }
        
        echo json_encode([
            'installed' => true, 
            'active' => $isActive, 
            'warning' => $warning, 
            'message' => $message
        ]);
        exit;
    }
}

/**
 * Liefert das Watchdog-Log (journalctl) zurück.
 */
function handleWatchdogLog() {
    if (isset($_GET['action']) && $_GET['action'] === 'watchdog_log') {
        header('Content-Type: text/plain');
        // Letzte 50 Einträge, neueste zuerst
        passthru("journalctl -t PIGUARD -n 50 --no-pager --reverse 2>&1");
        exit;
    }
}

/**
 * Liefert das Log des Energy Managers (AJAX).
 */
function handleEnergyManagerLog() {
    if (isset($_GET['action']) && $_GET['action'] === 'get_energy_manager_log') {
        header('Content-Type: text/plain; charset=utf-8');
        $logFile = '/var/www/html/logs/energy_manager.log';
        if (file_exists($logFile) && is_readable($logFile)) {
            $lines = file($logFile);
            // Letzte 150 Zeilen für bessere Übersicht
            $last_lines = array_slice($lines, -150);
            echo "--- Letzte 150 Einträge aus energy_manager.log ---\n\n";
            echo implode("", $last_lines);
        } else {
            echo "Log-Datei nicht gefunden oder nicht lesbar unter: " . htmlspecialchars($logFile);
        }
        exit;
    }
}
/**
 * Erzeugt das HTML für das Verbindungs-Badge (Online/Offline).
 * Einheitlich für Desktop und Mobile.
 */
function renderConnectionBadge() {
    return '<span id="connection-status" class="badge bg-secondary rounded-pill" style="cursor:pointer;" onclick="handleConnectionClick()" title="Status: Klicken zum Aktualisieren">Verbinde...</span>';
}

/**
 * Prüft auf Versions-Anfrage (?check_version) und gibt den Zeitstempel zurück.
 * Beendet das Skript, falls zutreffend.
 */
function handleVersionCheck($file) {
    if (isset($_GET['check_version'])) {
        header('Content-Type: text/plain');
        echo filemtime($file);
        exit;
    }
}

/**
 * Generiert das HTML für das Watchdog-Protokoll Modal.
 */
function renderWatchdogModal($dialogClass = 'modal-lg modal-dialog-scrollable') {
    return '
    <div class="modal fade" id="watchdogModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog ' . $dialogClass . '">
            <div class="modal-content bg-dark text-light border-secondary">
                <div class="modal-header border-secondary">
                    <h5 class="modal-title"><i class="fas fa-shield-alt me-2"></i>Watchdog Protokoll</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body bg-black p-2">
                    <pre id="watchdog-log-content" style="font-family: monospace; font-size: 0.8rem; color: #ccc; white-space: pre-wrap;">Lade...</pre>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal">Schließen</button>
                </div>
            </div>
        </div>
    </div>';
}

/**
 * Generiert das HTML für das System-Update Modal.
 */
function renderUpdateModal($dialogClass = 'modal-lg modal-dialog-scrollable') {
    return '
    <div class="modal fade" id="updateModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog ' . $dialogClass . '">
            <div class="modal-content bg-dark text-light border-secondary">
                <div class="modal-header border-secondary">
                    <h5 class="modal-title"><i class="fas fa-sync fa-spin me-2" id="update-spinner"></i>System Update</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close" id="update-close-btn" style="display:none;"></button>
                </div>
                <div class="modal-body bg-black p-2">
                    <pre id="update-log" style="font-family: monospace; font-size: 0.8rem; color: #0f0; white-space: pre-wrap;">Starte Update-Prozess...</pre>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal" id="update-finish-btn" disabled>Schließen</button>
                </div>
            </div>
        </div>
    </div>';
}

/**
 * Generiert das HTML für das Changelog Modal.
 */
function renderChangelogModal($dialogClass = 'modal-lg modal-dialog-scrollable') {
    $logFile = 'CHANGELOG.md';
    $content = "Kein Changelog verfügbar.";
    if (file_exists($logFile)) {
        $content = htmlspecialchars(file_get_contents($logFile));
    }
    
    return '
    <div class="modal fade" id="changelogModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog ' . $dialogClass . '">
            <div class="modal-content bg-dark text-light border-secondary">
                <div class="modal-header border-secondary">
                    <h5 class="modal-title">Changelog</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <pre style="white-space: pre-wrap; font-family: monospace; font-size: 0.85rem; color: #ccc;">' . $content . '</pre>
                </div>
            </div>
        </div>
    </div>';
}

/**
 * Lädt Preisdaten aus einer statischen Datei (z.B. awattardebug.23.txt),
 * um einen stabilen Tagesgraphen zu ermöglichen.
 */
function loadStaticPriceData($vat = 0) {
    $paths = getInstallPaths();
    $basePath = $paths['install_path'];
    
    // Zeitabhängige Priorisierung:
    // 18:00 - 06:00: Bevorzuge Mittags-Datei (11/12/13 Uhr), um Vorschau auf morgen zu haben.
    // 06:00 - 18:00: Bevorzuge Nacht-Datei (23/00 Uhr) für stabilen Tagesverlauf.
    $hour = (int)date('G');
    if ($hour >= 18 || $hour < 6) {
        $candidates = ['awattardebug.13.txt', 'awattardebug.14.txt', 'awattardebug.23.txt', 'awattardebug.0.txt'];
    } else {
        $candidates = ['awattardebug.23.txt', 'awattardebug.0.txt', 'awattardebug.12.txt', 'awattardebug.13.txt'];
    }
    
    $lines = false;
    $loadedFile = '';

    foreach ($candidates as $f) {
        if (file_exists($basePath . $f)) {
            $lines = @file($basePath . $f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if ($lines === false) {
                // Fallback: Versuch via cat (falls PHP-Leserechte klemmen)
                exec("cat " . escapeshellarg($basePath . $f), $out, $ret);
                if ($ret === 0 && !empty($out)) $lines = $out;
            }
            
            if ($lines) {
                $loadedFile = $f;
                break;
            }
        }
    }
    
    if (!$lines) return false;

    $prices = [];
    $startHour = null;
    $interval = null;
    $lastH = null;
    
    foreach ($lines as $line) {
        // BOM entfernen (UTF-8)
        $line = preg_replace('/^\xEF\xBB\xBF/', '', $line);
        $line = trim($line);
        
        // Header überspringen
        if (empty($line) || (!is_numeric(substr($line, 0, 1)) && substr($line, 0, 1) !== '-')) {
            if (!empty($prices)) break; // Stop bei neuem Block (z.B. "Data")
            continue;
        }

        // Trenner erkennen (Semikolon oder Whitespace)
        $parts = (strpos($line, ';') !== false) ? explode(';', $line) : preg_split('/\s+/', $line);

        if (count($parts) >= 2 && is_numeric($parts[0])) {
            $rawT = (float)str_replace(',', '.', trim($parts[0]));
            $val = (float)str_replace(',', '.', trim($parts[1]));
            
            // Timestamp (> 48) zu Stunde (0-23.99) konvertieren
            if ($rawT > 48) {
                $h = (float)gmdate('G', (int)$rawT) + ((int)gmdate('i', (int)$rawT)/60);
            } else {
                $h = $rawT;
            }

            
            // Duplikat-Check: Wenn wir wieder beim Start sind (z.B. neuer Block)
            if ($startHour !== null && abs($h - $startHour) < 0.001 && count($prices) > 0) break;

            if ($vat > 0) $val = $val * (1 + ($vat / 100));
            $prices[] = $val;
            
            if ($startHour === null) {
                $startHour = $h;
            } elseif ($interval === null) {
                $diff = $h - $lastH;
                if ($diff < 0) $diff += 24; // Tageswechsel
                if ($diff > 0.001) $interval = $diff;
            }
            $lastH = $h;
        }
    }
    
    return empty($prices) ? false : [
        'prices' => $prices, 
        'start_hour' => $startHour, 
        'interval' => ($interval ?: 1),
        'source' => $loadedFile
    ];
}

/**
 * Liest verfügbare History-Backup-Dateien aus dem Backup-Verzeichnis.
 * Liefert ein Array mit 'file' (Dateiname) und 'label' (formatiertes Datum).
 */
function getHistoryBackupFiles($backupDir = '/var/www/html/tmp/history_backups/') {
    $historyFiles = [];
    if (is_dir($backupDir)) {
        $files = glob($backupDir . 'history_*.txt');
        if ($files) {
            rsort($files); // Neueste zuerst
            foreach ($files as $file) {
                $basename = basename($file);
                if (preg_match('/history_(\d{4}-\d{2}-\d{2})\.txt/', $basename, $m)) {
                    $label = date('d.m.Y', strtotime($m[1]));
                    $historyFiles[] = ['file' => $basename, 'label' => $label];
                }
            }
        }
    }
    return $historyFiles;
}

/**
 * Hilfsfunktion zum Parsen von Kommazahlen aus Config-Dateien.
 */
function parseConfigFloat($val) {
    return (float)str_replace(',', '.', $val);
}

/**
 * Berechnet 24h Mittelwerte aus der History-Datei (Cache 1 Std).
 */
function get24hAverages($filePath) {
    $cacheFile = '/tmp/e3dc_avgs.json';
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 3600) {
        return json_decode(file_get_contents($cacheFile), true);
    }

    $avgs = ['home' => 800, 'grid' => 1000, 'wb' => 4000];
    if (file_exists($filePath)) {
        $lines = @file($filePath);
        if ($lines) {
            $lines = array_slice($lines, -1000); // Letzte Einträge
            $sums = ['h' => 0, 'g' => 0, 'w' => 0]; $c = 0;
            foreach ($lines as $l) {
                $d = json_decode($l, true);
                if ($d) { $sums['h'] += abs($d['home_raw']??0); $sums['g'] += abs($d['grid']??0); $sums['w'] += ($d['wb']??0); $c++; }
            }
            if ($c > 0) $avgs = ['home' => $sums['h']/$c, 'grid' => $sums['g']/$c, 'wb' => $sums['w']/$c];
        }
    }
    file_put_contents($cacheFile, json_encode($avgs));
    return $avgs;
}

/**
 * Sucht nach archivierten awattardebug-Dateien.
 */
function getArchivedDebugFiles($basePath) {
    $files = [];
    if (is_dir($basePath)) {
        foreach (glob(rtrim($basePath, '/') . '/awattardebug.*.txt') as $f) {
            if (preg_match('/awattardebug\.(\d+)\.txt$/', $f, $m)) {
                $ts = filemtime($f);
                $files[] = [
                    'file' => basename($f),
                    'ts' => $ts,
                    'label' => date('d.m. H:i', $ts) . " (Run {$m[1]})"
                ];
            }
        }
        usort($files, fn($a, $b) => $b['ts'] <=> $a['ts']);
    }
    return $files;
}

/**
 * Speichert eine Einstellung in der e3dc.config.txt (AJAX).
 */
function handleSaveSetting() {
    if (isset($_POST['action']) && $_POST['action'] === 'save_setting') {
        if (!isset($_POST['key'], $_POST['value'])) exit;
        
        $paths = getInstallPaths();
        $configFile = rtrim($paths['install_path'], '/') . '/e3dc.config.txt';
        $key = trim($_POST['key']);
        $val = trim($_POST['value']);
        
        if (!preg_match('/^[a-z0-9_]+$/i', $key)) { http_response_code(400); exit; }

        $lines = file_exists($configFile) ? file($configFile, FILE_IGNORE_NEW_LINES) : [];
        $newLines = [];
        $found = false;

        foreach ($lines as $line) {
            if (preg_match('/^\s*' . preg_quote($key, '/') . '\s*=/i', $line)) {
                $newLines[] = "$key = $val";
                $found = true;
            } else {
                $newLines[] = $line;
            }
        }
        if (!$found) $newLines[] = "$key = $val";

        if (file_put_contents($configFile, implode("\n", $newLines) . "\n", LOCK_EX) !== false) echo "ok";
        else { http_response_code(500); echo "error"; }
        exit;
    }
}

/**
 * Liefert den Status der Diagramm-Erstellung (AJAX).
 */
function handleStatus() {
    if (isset($_GET['action']) && $_GET['action'] === 'status') {
        header('Content-Type: application/json');
        $mode = $_GET['mode'] ?? 'normal';
        $suffix = ($mode == 'mobile') ? '_mobile' : (($mode == 'archiv') ? '_archiv' : '');
        
        $lock = "/var/www/html/tmp/plot_soc_running" . $suffix;
        $error = "/var/www/html/tmp/plot_soc_error" . $suffix;
        $diagramm = "/var/www/html/" . (($mode == 'mobile') ? 'diagramm_mobile.html' : (($mode == 'archiv') ? 'archiv_diagramm.html' : 'diagramm.html'));

        $status = [
            'running' => file_exists($lock),
            'error' => file_exists($error),
            'error_message' => file_exists($error) ? file_get_contents($error) : null,
            'last_update' => file_exists($diagramm) ? date('H:i:s', filemtime($diagramm)) : null
        ];
        echo json_encode($status);
        exit;
    }
}

/**
 * Startet die Diagramm-Erstellung (AJAX).
 */
function handleRunNow() {
    if (isset($_GET['action']) && $_GET['action'] === 'run_now') {
        header('Content-Type: text/plain');
        $mode = $_GET['mode'] ?? 'normal';
        $suffix = ($mode == 'mobile') ? '_mobile' : (($mode == 'archiv') ? '_archiv' : '');
        
        $lock = "/var/www/html/tmp/plot_soc_running" . $suffix;
        $error = "/var/www/html/tmp/plot_soc_error" . $suffix;
        
        // Auto-Check
        if (isset($_GET['auto']) && $_GET['auto'] == '1') {
            $stamp = "/var/www/html/tmp/plot_soc_last_run"; // Globaler Stamp
            if (!isDiagramUpdateDue($stamp)) { echo "skipped"; exit; }
        }

        if (file_exists($lock)) {
            if (time() - filemtime($lock) > 300) @unlink($lock); // Selbstheilung
            else { echo "running"; exit; }
        }

        @unlink($error);
        @mkdir(dirname($lock), 0755, true);
        touch($lock);

        $paths = getInstallPaths();
        $script = rtrim($paths['install_path'], '/') . '/plot_soc_changes.py';
        $python = getPythonInterpreter();
        $themeArg = '';
        if (isset($_GET['dark'])) {
            $themeArg = ($_GET['dark'] === '1') ? ' dark' : ' light';
        }
        $cmd = "nohup " . escapeshellarg($python) . " " . escapeshellarg($script) . " " . escapeshellarg($paths['install_path'].'awattardebug.txt') . " " . escapeshellarg($mode) . $themeArg . " > /dev/null 2>&1 &";
        @shell_exec($cmd);
        
        echo "started";
        exit;
    }
}

/**
 * Startet die Live-History Diagramm-Erstellung (AJAX).
 */
function handleRunLiveHistory() {
    if (isset($_GET['action']) && $_GET['action'] === 'run_live_history') {
        header('Content-Type: application/json');
        
        $lock = '/var/www/html/tmp/plot_live_history_running';

        // Status-Abfrage
        if (isset($_GET['mode']) && $_GET['mode'] === 'status') {
            $lock = '/var/www/html/tmp/plot_live_history_running';
            $html = '/var/www/html/live_diagramm.html';
            echo json_encode([
                'running' => file_exists($lock),
                'last_update' => file_exists($html) ? date('d.m.Y H:i', filemtime($html)) : null
            ]);
            exit;
        }

        $paths = getInstallPaths();
        $script = rtrim($paths['install_path'], '/') . '/plot_live_history.py';
        $hours = isset($_GET['hours']) ? (int)$_GET['hours'] : 6;
        $view = isset($_GET['view']) ? preg_replace('/[^a-z0-9_]/', '', $_GET['view']) : 'normal';
        $fileParam = '';

        if (!empty($_GET['file'])) {
            $f = basename($_GET['file']);
            $fp = '/var/www/html/tmp/history_backups/' . $f;
            if (file_exists($fp)) { $fileParam = ' --file ' . escapeshellarg($fp); $hours = 24; }
        }

        $python = getPythonInterpreter();
        $darkParam = '';
        if (isset($_GET['dark'])) {
            $darkParam = ($_GET['dark'] === '1') ? ' --dark' : ' --light';
        }
        
        // FIX: Lock-Datei entfernen, um Neustart zu erzwingen (z.B. bei Theme-Wechsel)
        @unlink($lock);

        // Lock-Datei erstellen (reservieren)
        @mkdir(dirname($lock), 0755, true);
        @touch($lock);
        @chmod($lock, 0666);

        // Skript starten (mit nohup für Unabhängigkeit)
        $cmd = "nohup " . escapeshellarg($python) . ' ' . escapeshellarg($script) . ' --hours ' . escapeshellarg($hours) . ' --view ' . escapeshellarg($view) . $fileParam . $darkParam . " > /dev/null 2>&1 &";
        @shell_exec($cmd);
        
        echo json_encode(['ok' => true, 'status' => 'started']);
        exit;
    }
}

/**
 * Führt das System-Update aus (AJAX).
 * Ersetzt run_update.php
 */
function handleRunUpdate() {
    if (isset($_GET['action']) && $_GET['action'] === 'run_update') {
        // Caching verhindern (Wichtig für Cloudflare/Browser)
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
        header('Content-Type: application/json');
        $paths = getInstallPaths();
        
        // Installer suchen
        $candidates = [
            rtrim($paths['install_path'], '/') . '/../Install/installer_main.py',
            $paths['home_dir'] . '/Install/installer_main.py'
        ];
        $installer_main = false;
        foreach ($candidates as $candidate) {
            if (file_exists($candidate)) { $installer_main = realpath($candidate); break; }
        }
        
        if (!$installer_main) {
            echo json_encode(['status' => 'error', 'message' => "Installer nicht gefunden."]);
            exit;
        }

        $logFile = '/var/www/html/tmp/update.log';
        $pidFile = '/var/www/html/tmp/update.pid';
        $mode = $_GET['mode'] ?? 'start';

        if ($mode === 'start') {
            if (file_exists($pidFile)) {
                $pid = (int)trim(file_get_contents($pidFile));
                if (file_exists("/proc/$pid")) { echo json_encode(['status' => 'running', 'message' => 'Update läuft bereits.']); exit; }
                @unlink($pidFile);
            }
            
            // 1. Log-Datei vorbereiten & Rechte prüfen
            if (file_put_contents($logFile, "=== UPDATE DIAGNOSE START ===\n") === false) {
                echo json_encode(['status' => 'error', 'message' => 'PHP kann Log-Datei nicht schreiben.']);
                exit;
            }
            chmod($logFile, 0666);
            
            // 2. Pfad-Check
            if (!$installer_main) {
                file_put_contents($logFile, "FEHLER: installer_main.py konnte nicht gefunden werden.\n", FILE_APPEND);
                echo json_encode(['status' => 'error', 'message' => 'Installer nicht gefunden.']);
                exit;
            }
            file_put_contents($logFile, "Installer-Pfad: $installer_main\n", FILE_APPEND);

            // 3. Shell-Test (Kann www-data überhaupt schreiben?)
            exec("echo 'Shell-Write-Test: OK' >> " . escapeshellarg($logFile));
            
            // 4. Sudo-Test (Darf www-data sudo nutzen?)
            // (Entfernt, da 'true' nicht zwingend in sudoers steht und zu falschen Fehlern führt)

            $cmd = "sudo -n /usr/bin/python3 " . escapeshellarg($installer_main) . " --update-e3dc";
            
            file_put_contents($logFile, "Start-Befehl: $cmd\n--------------------------------\n", FILE_APPEND);
            
            // Wir nutzen 'nohup' ohne Pfad (verlässt sich auf PATH), das ist robuster
            $fullCmd = sprintf("nohup %s >> %s 2>&1 & echo $!", $cmd, escapeshellarg($logFile));
            $pid = exec($fullCmd);
            
            if ($pid) { 
                file_put_contents($pidFile, $pid); 
                file_put_contents($logFile, "Prozess gestartet mit PID: $pid\n", FILE_APPEND);
                echo json_encode(['status' => 'started', 'pid' => $pid]); 
            }
            else { echo json_encode(['status' => 'error', 'message' => 'Konnte Prozess nicht starten.']); }
        } elseif ($mode === 'poll') {
            clearstatcache(true, $logFile);
            $log = '';
            $debugInfo = "";
            
            if (file_exists($logFile)) {
                $size = filesize($logFile);
                $content = file_get_contents($logFile);
                
                if ($content === false) {
                    $log = "FEHLER: Log-Datei existiert, kann aber nicht gelesen werden (Rechte?).";
                } elseif (empty($content)) {
                    $log = "Status: Warte auf Start... (Log-Datei ist leer, Größe: $size Bytes)";
                } else {
                    $log = $content;
                }
            } else {
                $log = "Status: Initialisiere... (Log-Datei noch nicht erstellt)";
            }
            $running = false;
            if (file_exists($pidFile)) {
                $pid = (int)trim(file_get_contents($pidFile));
                if (file_exists("/proc/$pid")) $running = true; else @unlink($pidFile);
            }
            
            // JSON Flags für Robustheit (verhindert Absturz bei Emojis/Sonderzeichen)
            $flags = 0;
            if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
            if (defined('JSON_PARTIAL_OUTPUT_ON_ERROR')) $flags |= JSON_PARTIAL_OUTPUT_ON_ERROR;

            $json = json_encode(['running' => $running, 'log' => $log], $flags);
            
            if ($json === false) {
                echo json_encode(['running' => $running, 'log' => "JSON-Fehler: " . json_last_error_msg()]);
            } else {
                echo $json;
            }
        }
        exit;
    }
}

/**
 * Generiert das Archiv-Diagramm (AJAX/Iframe).
 * Ersetzt archiv_diagramm.php
 */
function handleArchivDiagram() {
    if (isset($_GET['action']) && $_GET['action'] === 'archiv_diagram') {
        $paths = getInstallPaths();
        $base_path = rtrim($paths['install_path'], '/') . '/';
        
        if (!isset($_GET['file'])) die(errorMessage("Fehler", "Keine Datei angegeben."));
        $file = basename($_GET['file']);
        if (!validateFilename($file)) die(errorMessage("Sicherheitsfehler", "Ungültiger Dateiname."));
        
        $fullpath = $base_path . $file;
        $check = checkFileAccess($fullpath, 'read');
        if ($check !== true) die($check);
        
        $tmp_dir = "/var/www/html/tmp";
        if (!is_dir($tmp_dir)) @mkdir($tmp_dir, 0755, true);
        
        $doneFile = "/var/www/html/tmp/plot_soc_done_archiv";
        @unlink($doneFile);
        
        $python = getPythonInterpreter();
        $themeArg = '';
        if (isset($_GET['dark'])) {
            $themeArg = ($_GET['dark'] === '1') ? ' dark' : ' light';
        }
        $cmd = escapeshellarg($python) . " " . $base_path . "plot_soc_changes.py " . escapeshellarg($fullpath) . " archiv" . $themeArg . " 2>&1";
        exec($cmd, $output, $returnCode);
        
        if ($returnCode !== 0) die(errorMessage("Fehler", "Python-Skript fehlgeschlagen: " . implode("\n", $output)));
        
        // Warte auf Done-Datei (max 10s)
        $timeout = 10; $start = time();
        while (!file_exists($doneFile) && (time() - $start) < $timeout) usleep(200000);
        
        if (!file_exists($doneFile)) die(errorMessage("Timeout", "Diagramm wurde nicht rechtzeitig erstellt."));

        // Rechte korrigieren, da die Datei von www-data (PHP) erstellt/getriggert wird
        @chmod($doneFile, 0666);
        
        $diagramm_file = "/var/www/html/archiv_diagramm.html";
        if (file_exists($diagramm_file)) {
            $content = file_get_contents($diagramm_file);
            echo $content;
        }
        else die(errorMessage("Fehler", "Ausgabedatei nicht gefunden."));
        exit;
    }
}

/**
 * Gibt die Tagesstatistik für ein bestimmtes Datum zurück (AJAX)
 */
function handleDailyStats() {
    if (isset($_GET['action']) && $_GET['action'] === 'get_daily_stats') {
        header('Content-Type: application/json');
        $file = $_GET['file'] ?? '';
        if ($file === 'today' || empty($file)) {
            $statsFile = '/var/www/html/ramdisk/daily_stats.json';
            if (file_exists($statsFile)) echo file_get_contents($statsFile);
            else echo json_encode(['error' => 'No live data']);
        } else {
            if (!preg_match('/^history_\d{4}-\d{2}-\d{2}\.txt$/', $file)) { echo json_encode(['error' => 'Invalid']); exit; }
            $path = '/var/www/html/tmp/history_backups/' . $file;
            if (file_exists($path)) {
                $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                echo json_encode(calculateDailyEnergyStats($lines));
            } else {
                echo json_encode(['error' => 'Not found']);
            }
        }
        exit;
    }
}

// ==================== AWATTAR & PROGNOSE PARSING ====================

/**
 * Konvertiert Config-Werte robust in Float (behandelt Komma/Punkt).
 */
function parseNumericConfigValue($value, $default) {
    if (is_int($value) || is_float($value)) return (float)$value;
    if (!is_string($value)) return (float)$default;
    $cleaned = trim($value, " \t\n\r\0\x0B\"'");
    if ($cleaned === '') return (float)$default;
    $normalized = str_replace(',', '.', $cleaned);
    return is_numeric($normalized) ? (float)$normalized : (float)$default;
}

/**
 * Berechnet den Endpreis basierend auf Rohdaten und Zeitstempel (Formatwechsel 19.12.2024).
 */
function calculateAwattarPrice($priceRaw, $sourceTimestamp, $awmwst, $awnebenkosten) {
    $multiplier = ($awmwst / 100.0) + 1.0;
    $switchTs = strtotime('2024-12-19 00:00:00');
    if ($sourceTimestamp > $switchTs) {
        return ($priceRaw * $multiplier) + $awnebenkosten;
    }
    return (($priceRaw / 10.0) * $multiplier) + $awnebenkosten;
}

/**
 * Klassifiziert einen Preis (günstig/teuer) relativ zu Min/Max.
 */
function classifyPriceLevel($price, $minPrice, $maxPrice) {
    if ($price === null || $minPrice === null || $maxPrice === null || $maxPrice <= $minPrice) return 'unknown';
    $range = $maxPrice - $minPrice;
    $avgBandWidth = 0.30 * $range;
    $lowerThreshold = $minPrice + (($range - $avgBandWidth) / 2.0);
    $upperThreshold = $maxPrice - (($range - $avgBandWidth) / 2.0);
    if ($price < $lowerThreshold) return 'cheap';
    if ($price > $upperThreshold) return 'expensive';
    return 'average';
}

/**
 * Hilfsfunktion: Wandelt "12.45" (Viertelstunden) in Minuten des Tages um.
 */
function parseQuarterTimeToMinute($timeToken) {
    if (!preg_match('/^(\d{1,2})\.(\d{2})$/', $timeToken, $tm)) return null;
    $hour = (int)$tm[1];
    $fractionPart = (int)$tm[2] / 100.0;
    $minute = (int)round($fractionPart * 60.0);
    if ($minute >= 60) { $hour += (int)floor($minute / 60); $minute = $minute % 60; }
    return ($hour * 60) + $minute;
}

/**
 * Hilfsfunktion: Formatiert Minuten des Tages zurück in "12.45" Format.
 */
function minuteToSlotLabel($minute) {
    if (!is_int($minute) || $minute < 0) return null;
    $hour = (int)floor($minute / 60);
    $min = $minute % 60;
    return sprintf('%d.%02d', $hour, (int)round(($min / 60) * 100));
}

/**
 * Parst die awattardebug.txt und extrahiert Preise sowie Prognosedaten.
 */
function parsePricesFromAwattarDebug($debugFile, $awmwst, $awnebenkosten, $speichergroesse) {
    if (!file_exists($debugFile)) return [null, null, null, null, null, null, null, null, null, [], null, 1.0, []];
    
    $lines = @file($debugFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!$lines) return [null, null, null, null, null, null, null, null, null, [], null, 1.0, []];

    $prices = [];
    $forecast = [];
    $entries = [];
    $sourceTs = filemtime($debugFile) ?: time();
    $inDataBlock = false;
    $lastMinute = -1;
    $dayOffset = 0;
    $priceStartHour = null;
    $priceInterval = 1.0;

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') continue;
        if (stripos($line, 'Data') === 0) { $inDataBlock = true; continue; }
        if (stripos($line, 'Simulation') === 0) { $inDataBlock = false; continue; }
        if (!$inDataBlock) continue;

        if (preg_match('/^\d{1,2}\.\d{2}\s+(-?\d+(?:\.\d+)?)(?:\s+(-?\d+(?:\.\d+)?)){3,5}$/', $line)) {
            $parts = preg_split('/\s+/', $line);
            if (count($parts) >= 2) {
                $minuteOfDay = parseQuarterTimeToMinute($parts[0]);
                if ($minuteOfDay !== null) {
                    if ($lastMinute !== -1 && $minuteOfDay < $lastMinute) $dayOffset += 1440;
                    $lastMinute = $minuteOfDay;
                    $minuteOfDay += $dayOffset;
                }
                $candidateRaw = (float)$parts[1];
                $candidate = calculateAwattarPrice($candidateRaw, $sourceTs, $awmwst, $awnebenkosten);
                
                if ($candidate >= 0 && $candidate <= 100) {
                    if ($priceStartHour === null) $priceStartHour = (float)$parts[0];
                    elseif (count($prices) === 1) {
                        $iv = (float)$parts[0] - $priceStartHour;
                        if ($iv > 0) $priceInterval = $iv;
                    }
                    $prices[] = $candidate;
                    if ($minuteOfDay !== null) $entries[] = ['minute' => $minuteOfDay, 'price' => $candidate];
                    
                    // Prognose (Spalte 4)
                    if (count($parts) >= 5) {
                        $pvRaw = (float)$parts[4];
                        $pvVal = $pvRaw * $speichergroesse * 40;
                        $h = (float)$parts[0] + ($dayOffset / 60.0);
                        $forecast[] = ['h' => $h, 'w' => $pvVal];
                    }
                }
            }
        }
    }

    if (empty($prices)) return [null, null, null, null, null, null, null, null, null, [], null, 1.0, []];

    $current = $prices[0];
    $selectedMinute = null; $targetMinute = null;
    if (!empty($entries)) {
        $nowMinuteRaw = ((int)gmdate('G') * 60) + (int)gmdate('i');
        $targetMinute = (int)(round($nowMinuteRaw / 15) * 15);
        if ($targetMinute >= 1440) $targetMinute -= 1440;
        $bestEntry = $entries[0];
        $bestDist = abs(($bestEntry['minute'] % 1440) - $targetMinute);
        $bestDist = min($bestDist, 1440 - $bestDist);
        foreach ($entries as $entry) {
            $dist = abs(($entry['minute'] % 1440) - $targetMinute);
            $dist = min($dist, 1440 - $dist);
            if ($dist < $bestDist) { $bestDist = $dist; $bestEntry = $entry; }
        }
        $current = $bestEntry['price']; $selectedMinute = $bestEntry['minute'];
    }
    $min = min($prices); $max = max($prices);
    $minSlot = null; $maxSlot = null;
    foreach ($entries as $entry) {
        if ($entry['price'] === $min && $minSlot === null) $minSlot = minuteToSlotLabel($entry['minute']);
        if ($entry['price'] === $max && $maxSlot === null) $maxSlot = minuteToSlotLabel($entry['minute']);
    }
    return [$current, $min, $max, minuteToSlotLabel($selectedMinute), minuteToSlotLabel($targetMinute), $min, $minSlot, $max, $maxSlot, $prices, $priceStartHour, $priceInterval, $forecast];
}

/**
 * Generiert das HTML für den Energiefluss (SVG).
 * Zentralisiert für index.php und mobile.php.
 */
function renderEnergyFlow($layout = 'mobile', $extraClass = '', $extraAttributes = '') {
    // Koordinaten basierend auf Layout
    if ($layout === 'desktop') {
        $homeX = '72%'; $homeY = '30%'; // Weiter rechts (72%) und tiefer (30%)
        $wpX = '72%'; $wpY = '70%';     // Weiter rechts (72%) und höher (70%)
        $wbX = '85%'; $wbY = '50%';
    } else {
        // Mobile Standard (Rechts untereinander)
        $homeX = '80%'; $homeY = '25%';
        $wpX = '80%'; $wpY = '50%';
        $wbX = '80%'; $wbY = '75%';
    }

    return '
    <div id="flow-view" class="flow-container ' . $extraClass . '" ' . $extraAttributes . '>
        <svg class="flow-svg">
            <line x1="20%" y1="25%" x2="50%" y2="50%" class="flow-line" stroke="#ffc107" />
            <line x1="20%" y1="25%" x2="50%" y2="50%" class="flow-dots" id="flow-dot-pv" stroke="#ffc107" />
            
            <line x1="20%" y1="75%" x2="50%" y2="50%" class="flow-line" stroke="#6c757d" />
            <line x1="20%" y1="75%" x2="50%" y2="50%" class="flow-dots" id="flow-dot-grid" stroke="#6c757d" />
            
            <line x1="50%" y1="15%" x2="50%" y2="50%" class="flow-line" stroke="#dc3545" id="flow-line-bat" />
            <line x1="50%" y1="15%" x2="50%" y2="50%" class="flow-dots" id="flow-dot-bat" stroke="#dc3545" />

            <line x1="50%" y1="50%" x2="' . $homeX . '" y2="' . $homeY . '" class="flow-line" stroke="#0dcaf0" />
            <line x1="50%" y1="50%" x2="' . $homeX . '" y2="' . $homeY . '" class="flow-dots" id="flow-dot-home" stroke="#0dcaf0" />

            <line x1="50%" y1="50%" x2="' . $wpX . '" y2="' . $wpY . '" class="flow-line" stroke="#22d3ee" id="flow-line-wp" />
            <line x1="50%" y1="50%" x2="' . $wpX . '" y2="' . $wpY . '" class="flow-dots" id="flow-dot-wp" stroke="#22d3ee" />

            <line x1="50%" y1="50%" x2="' . $wbX . '" y2="' . $wbY . '" class="flow-line" stroke="#2ecc71" />
            <line x1="50%" y1="50%" x2="' . $wbX . '" y2="' . $wbY . '" class="flow-dots" id="flow-dot-wb" stroke="#2ecc71" />
        </svg>

        <!-- Hintergrund-Kreis für Batterie (verdeckt die Linie) -->
        <div class="flow-node-back" id="f-node-bat-back"></div>

        <div class="flow-node node-pv"><i class="fas fa-sun fa-icon"></i><div class="val" id="f-val-pv">0W</div><div class="label">Sonne</div><div class="price-tag" id="f-val-pv-yield" style="display:none;"></div></div>
        <div class="flow-node node-grid"><i class="fas fa-network-wired fa-icon"></i><div class="val" id="f-val-grid">0W</div><div class="label">Netz</div><div class="price-tag" id="f-val-price" style="display:none;"></div></div>
        <div class="flow-node node-bat" id="f-node-bat"><i class="fas fa-battery-half fa-icon"></i><div class="val" id="f-val-bat">0W</div><div class="label" id="f-lbl-soc">0%</div></div>
        <div class="flow-node node-home"><i class="fas fa-home fa-icon"></i><div class="val" id="f-val-home">0W</div><div class="label">Haus</div></div>
        <div class="flow-node node-wp"><i class="fas fa-fan fa-icon"></i><div class="val" id="f-val-wp">0W</div><div class="label">WP</div></div>
        <div class="flow-node node-wb"><i class="fas fa-car fa-icon"></i><div class="val" id="f-val-wb">0W</div><div class="label">Wallbox</div><i class="fas fa-lock" id="f-wb-lock" style="display:none; position:absolute; top:12%; right:22%; font-size:0.7rem; color:#ffc107;"></i><div class="price-tag" id="f-val-wb-session" style="display:none;"></div></div>
        
        <div class="flow-node node-center"><img src="app-icon-512.png" alt="Hub"></div>
    </div>';
}

/**
 * Berechnet die kumulierte Energieverteilung (kWh und %) für den aktuellen Tag
 * basierend auf den Einträgen der live_history.txt.
 */
function calculateDailyEnergyStats($historyLines) {
    $lastTs = null;
    $lastRow = null;
    $activeDate = null;

    // Wir lesen das Datum aus dem aktuellsten Eintrag (ganz unten),
    // damit bei der 48h-Historie der heutige Tag gewertet wird.
    for ($i = count($historyLines) - 1; $i >= 0; $i--) {
        $d = @json_decode($historyLines[$i], true);
        if ($d && isset($d['ts'])) {
            $activeDate = substr($d['ts'], 0, 10);
            break;
        }
    }
    if (!$activeDate) $activeDate = date('Y-m-d');

    $stats = [
        'pv_home_kwh' => 0, 'pv_bat_kwh' => 0, 'pv_wb_kwh' => 0, 'pv_wp_kwh' => 0, 'pv_grid_kwh' => 0,
        'grid_home_kwh' => 0, 'grid_bat_kwh' => 0, 'grid_wb_kwh' => 0, 'grid_wp_kwh' => 0,
        'total_consumption' => 0, 'total_pv' => 0, 'total_grid_in' => 0, 'total_grid_out' => 0
    ];

    foreach ($historyLines as $ln) {
        $d = json_decode($ln, true);
        if (!$d || !isset($d['ts']) || strpos($d['ts'], $activeDate) !== 0) continue;

        $ts = strtotime($d['ts']);
        if ($lastTs !== null) {
            $dt = $ts - $lastTs; // in Sekunden
            if ($dt > 0 && $dt < 3600) {
                $dtHours = $dt / 3600;

                // Mittelwerte für das Intervall
                $pv = max(0, (($d['pv'] ?? 0) + ($lastRow['pv'] ?? 0)) / 2);
                $grid = (($d['grid'] ?? 0) + ($lastRow['grid'] ?? 0)) / 2;
                $bat = (($d['bat'] ?? 0) + ($lastRow['bat'] ?? 0)) / 2;
                $home = max(0, (($d['home'] ?? 0) + ($lastRow['home'] ?? 0)) / 2);
                $wb = max(0, (($d['wb'] ?? 0) + ($lastRow['wb'] ?? 0)) / 2);
                $wp = max(0, (($d['wp'] ?? 0) + ($lastRow['wp'] ?? 0)) / 2);

                $grid_in = max(0, $grid); $grid_out = max(0, -$grid);
                $bat_in = max(0, $bat);
                $loads = $home + $wb + $wp;

                $stats['total_consumption'] += ($loads * $dtHours) / 1000;
                $stats['total_pv'] += ($pv * $dtHours) / 1000;
                $stats['total_grid_in'] += ($grid_in * $dtHours) / 1000;
                $stats['total_grid_out'] += ($grid_out * $dtHours) / 1000;

                // Verteilung Sonnenenergie (PV)
                // Physische Priorität: 1. Haus/Verbraucher, 2. Batterie, 3. Netz
                $pv_to_loads = min($pv, $loads);
                $pv_to_bat = min($pv - $pv_to_loads, $bat_in);
                $pv_to_grid = max(0, $pv - $pv_to_loads - $pv_to_bat);

                $stats['pv_bat_kwh'] += ($pv_to_bat * $dtHours) / 1000;
                $stats['pv_grid_kwh'] += ($pv_to_grid * $dtHours) / 1000;
                if ($loads > 0) {
                    $stats['pv_home_kwh'] += ($pv_to_loads * ($home / $loads) * $dtHours) / 1000;
                    $stats['pv_wb_kwh'] += ($pv_to_loads * ($wb / $loads) * $dtHours) / 1000;
                    $stats['pv_wp_kwh'] += ($pv_to_loads * ($wp / $loads) * $dtHours) / 1000;
                }

                // Verteilung Netzbezug
                $grid_to_bat = max(0, $bat_in - $pv);
                $grid_to_loads = max(0, $grid_in - $grid_to_bat);

                $stats['grid_bat_kwh'] += ($grid_to_bat * $dtHours) / 1000;
                if ($loads > 0) {
                    $stats['grid_home_kwh'] += ($grid_to_loads * ($home / $loads) * $dtHours) / 1000;
                    $stats['grid_wb_kwh'] += ($grid_to_loads * ($wb / $loads) * $dtHours) / 1000;
                    $stats['grid_wp_kwh'] += ($grid_to_loads * ($wp / $loads) * $dtHours) / 1000;
                }
            }
        }
        $lastTs = $ts; $lastRow = $d;
    }

    // Autarkie & Eigenverbrauch
    $totalPv = max(0.001, $stats['total_pv']);
    $totalGridIn = $stats['total_grid_in'];
    $totalGridOut = $stats['total_grid_out'];
    $totalCons = max(0.001, $stats['total_consumption']);

    $res = [
        'pv_today_kwh' => round($stats['total_pv'], 2),
        'autarky_day' => round(max(0, min(100, (($totalCons - $totalGridIn) / $totalCons) * 100)), 1),
        'selfcon_day' => round(max(0, min(100, (($totalPv - $totalGridOut) / $totalPv) * 100)), 1),
        'stats' => []
    ];

    $res['stats']['total_pv_kwh'] = round($totalPv, 2);
    $res['stats']['total_grid_in_kwh'] = round($totalGridIn, 2);

    // %-Werte berechnen
    foreach (['home', 'bat', 'wb', 'wp', 'grid'] as $key) {
        $val = $stats["pv_{$key}_kwh"];
        $res['stats']["pv_{$key}_kwh"] = round($val, 2);
        $res['stats']["pv_{$key}_pct"] = round(($val / $totalPv) * 100);
    }
    $totalGridInSafe = max(0.001, $totalGridIn);
    foreach (['home', 'bat', 'wb', 'wp'] as $key) {
        $val = $stats["grid_{$key}_kwh"];
        $res['stats']["grid_{$key}_kwh"] = round($val, 2);
        $res['stats']["grid_{$key}_pct"] = round(($val / $totalGridInSafe) * 100);
    }
    return $res;
}
?>
