<?php
if (isset($_GET['check_version'])) {
    header('Content-Type: text/plain');
    echo filemtime(__FILE__);
    exit;
}
session_start();
require_once 'helpers.php';
require_once 'logic.php';
$seite = $_GET['seite'] ?? 'dashboard';

// Archiv-Dateien für das Dropdown laden
$archivFiles = [];
$historyFiles = [];
if ($seite === 'dashboard') {
    $paths = getInstallPaths();
    $base_path = rtrim($paths['install_path'], '/') . '/';
    $archivFiles = getArchivedDebugFiles($base_path);

    $backupDir = '/var/www/html/tmp/history_backups/';
    if (is_dir($backupDir)) {
        $files = glob($backupDir . 'history_*.txt');
        if ($files) {
            rsort($files); // Neueste zuerst
            foreach ($files as $file) {
                $basename = basename($file);
                if (preg_match('/history_(\d{4}-\d{2}-\d{2})\.txt/', $basename, $m)) {
                    $label = date('d.m.Y', strtotime($m[1]));
                    $historyFiles[] = ['file' => $basename, 'label' => $label];
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="de" data-bs-theme="<?= $darkMode ? 'dark' : 'light' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E3DC Control Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <style>
        /* Dark Mode Defaults (Bootstrap handles most via data-bs-theme="dark") */
        [data-bs-theme="dark"] body { background-color: #121212; color: #e0e0e0; }
        [data-bs-theme="dark"] .card { background-color: #1e1e1e; border-color: #333; box-shadow: 0 4px 10px rgba(0,0,0,0.3); }
        
        /* Light Mode Overrides */
        [data-bs-theme="light"] body { background-color: #f8f9fa; color: #212529; }
        [data-bs-theme="light"] .card { background-color: #ffffff; border-color: #dee2e6; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }

        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .card { border-radius: 12px; transition: transform 0.2s; }
        /* Hover-Effekt nur für Dashboard-Cards, nicht für Container in Unterseiten */
        .dashboard-view .card:hover { transform: translateY(-2px); border-color: #444; }
        .icon-box { width: 56px; height: 56px; display: flex; align-items: center; justify-content: center; border-radius: 16px; font-size: 1.75rem; }
        .val-large { font-size: 2.2rem; font-weight: 700; letter-spacing: -1px; }
        .val-unit { font-size: 1rem; color: #888; font-weight: 400; margin-left: 4px; }
        .pulsating { animation: pulse 2s infinite ease-in-out; }
        @keyframes pulse {
            0% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.6; transform: scale(0.92); }
            100% { opacity: 1; transform: scale(1); }
        }
        .chart-container { height: 500px; width: 100%; overflow: hidden; border-radius: 0 0 12px 12px; }
        iframe { border: none; width: 100%; height: 100%; }
        .btn-group-custom .btn { border-color: #444; color: #aaa; }
        .btn-group-custom .btn:hover, .btn-group-custom .btn.active { background-color: #333; color: #fff; border-color: #555; }
        .status-badge { font-size: 0.8rem; padding: 0.35em 0.65em; }
        
        /* Anpassungen für inkludierte Seiten */
        .container-fluid { max-width: 1920px; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary border-bottom border-secondary mb-3 py-2">
        <div class="container-fluid px-4">
            <a class="navbar-brand fw-bold" href="index.php"><i class="fas fa-solar-panel text-warning me-2"></i>E3DC Control</a>
            <div class="d-flex align-items-center gap-3">
                <div class="text-end d-none d-md-block">
                    <div id="clock" class="fw-bold text-light" style="font-size: 1.1rem;">--:--</div>
                    <div class="small text-muted" id="date">--.--.----</div>
                </div>
                <button class="btn btn-link text-secondary p-0" onclick="toggleDarkMode()" title="Dark Mode umschalten">
                    <i class="fas fa-<?= $darkMode ? 'moon' : 'sun' ?>" id="darkmode-icon"></i>
                </button>
                <a href="index.php?seite=config" class="text-secondary" title="Konfiguration">
                    <i class="fas fa-cog fa-lg"></i>
                </a>
                <span id="connection-status" class="badge bg-secondary rounded-pill">Verbinde...</span>
            </div>
        </div>
    </nav>

    <div class="container-fluid px-4 pb-5">
        <?php if ($seite === 'dashboard'): ?>
        <div class="dashboard-view">
        <!-- Status Cards -->
        <div class="row g-2 mb-3">
            <!-- PV -->
            <div class="col-md-6 col-xl-3">
                <div class="card h-100">
                    <div class="card-body d-flex align-items-center">
                        <div class="icon-box bg-warning bg-opacity-10 text-warning me-3" id="icon-pv-box">
                            <i class="fas fa-sun" id="icon-pv"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <h6 class="card-subtitle text-muted text-uppercase small fw-bold m-0">PV Leistung</h6>
                                <i class="fas fa-eye<?= $showForecast ? '' : '-slash' ?> text-muted" style="cursor:pointer; font-size:0.8rem;" onclick="toggleForecast(this)" title="Prognose an/aus"></i>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="val-large text-warning" id="val-pv">--<span class="val-unit">W</span></div>
                                <div class="text-end text-muted" id="val-pv-details" style="display:none;">
                                    <div class="mb-2">Prog: <span id="val-pv-forecast" class="fw-bold" style="font-size: 1.1rem;">--</span></div>
                                    <div>Soll: <span id="val-pv-soll" class="fw-bold" style="font-size: 1.1rem;">--</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Battery -->
            <div class="col-md-6 col-xl-3">
                <div class="card h-100">
                    <div class="card-body d-flex align-items-center">
                        <div class="icon-box bg-success bg-opacity-10 text-success me-3" id="icon-bat">
                            <i class="fas fa-battery-half"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="d-flex justify-content-between align-items-baseline mb-1">
                                <h6 class="card-subtitle text-muted text-uppercase small fw-bold m-0">Batterie <span id="val-soc" class="ms-1">--%</span></h6>
                                <span id="val-bat-time" class="text-muted" style="font-size: 1.1rem;"></span>
                            </div>
                            <div class="val-large text-success" id="val-bat-container">--<span class="val-unit">W</span></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Home -->
            <div class="col-md-6 col-xl-3">
                <div class="card h-100">
                    <div class="card-body d-flex align-items-center">
                        <div class="icon-box bg-info bg-opacity-10 text-info me-3">
                            <i class="fas fa-home"></i>
                        </div>
                        <div class="flex-grow-1">
                            <h6 class="card-subtitle text-muted mb-1 text-uppercase small fw-bold">Hausverbrauch</h6>
                            <div class="val-large text-info" id="val-home">--<span class="val-unit">W</span></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Grid -->
            <div class="col-md-6 col-xl-3">
                <div class="card h-100">
                    <div class="card-body d-flex align-items-center">
                        <div class="icon-box bg-secondary bg-opacity-10 text-secondary me-3" id="icon-grid">
                            <i class="fas fa-network-wired"></i>
                        </div>
                        <div class="flex-grow-1">
                            <h6 class="card-subtitle text-muted mb-1 text-uppercase small fw-bold">Netz</h6>
                            <div class="val-large text-body" id="val-grid-container">--<span class="val-unit">W</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="row g-2">
            <!-- Left Column: Chart -->
            <div class="col-xl-9 col-lg-8">
                <div class="card h-100">
                    <div class="card-header bg-transparent border-secondary d-flex justify-content-between align-items-center py-3">
                        <div class="d-flex align-items-center gap-3">
                            <h6 class="mb-0 fw-bold text-nowrap" id="chart-title"><i class="fas fa-chart-line me-2 text-secondary"></i>SoC Prognose</h6>
                        </div>
                        <div class="d-flex gap-2 align-items-center">
                            <!-- Ansicht Auswahl -->
                            <select class="form-select form-select-sm border-secondary d-none" id="chart-mode-select" style="width: auto; min-width: 120px;" onchange="switchChartMode(this.value)">
                                <option value="forecast" selected>Prognose</option>
                                <option value="live">Live-Verlauf</option>
                                <option value="archive">Archiv</option>
                            </select>

                            <!-- Live Controls -->
                            <div class="gap-2" id="live-controls" style="display:none;">
                                <div class="btn-group btn-group-sm btn-group-custom" role="group">
                                    <button type="button" class="btn btn-outline-secondary active" onclick="updateChart(6, this)">6h</button>
                                    <button type="button" class="btn btn-outline-secondary" onclick="updateChart(12, this)">12h</button>
                                    <button type="button" class="btn btn-outline-secondary" onclick="updateChart(24, this)">24h</button>
                                    <button type="button" class="btn btn-outline-secondary" onclick="updateChart(48, this)">48h</button>
                                </div>
                                <select class="form-select form-select-sm border-secondary" style="max-width: 130px;" onchange="updateChartHistory(this.value)">
                                    <option value="" selected>Live</option>
                                    <?php foreach ($historyFiles as $hf): ?>
                                        <option value="<?= htmlspecialchars($hf['file']) ?>"><?= htmlspecialchars($hf['label']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Archiv Controls -->
                            <select class="form-select form-select-sm border-secondary" id="archive-select" style="display:none; max-width: 200px;" onchange="loadArchive(this.value)">
                                <option value="" disabled selected>Datei wählen...</option>
                                <?php foreach ($archivFiles as $af): ?>
                                    <option value="<?= htmlspecialchars($af['file']) ?>"><?= htmlspecialchars($af['label']) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button class="btn btn-sm btn-outline-secondary" onclick="refreshData()" id="main-refresh-btn" title="Aktualisieren">
                                <i class="fas fa-sync-alt"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body p-0 chart-container">
                        <iframe id="chart-frame" src="diagramm.html?t=<?= time() ?>" scrolling="no"></iframe>
                    </div>
                </div>
            </div>

            <!-- Right Column: Details & Controls -->
            <div class="col-xl-3 col-lg-4">
                <div class="row g-2" id="right-column-cards">
                    <!-- Price Card -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h6 class="card-title text-muted text-uppercase small fw-bold"><i class="fas fa-tags me-2"></i>Strompreis</h6>
                                    <span class="badge bg-body-tertiary border border-secondary text-body-secondary" id="price-trend"><i class="fas fa-minus"></i></span>
                                </div>
                                <div class="d-flex align-items-baseline mb-3">
                                    <div class="val-large text-body" id="val-price">--<span class="val-unit">ct/kWh</span></div>
                                </div>
                                <div class="progress bg-secondary-subtle" style="height: 6px;">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: 50%" id="price-bar"></div>
                                </div>
                                <div class="d-flex justify-content-between mt-2 small text-muted">
                                    <span>Min: <span id="val-price-min" class="text-success fw-bold">--</span></span>
                                    <span>Max: <span id="val-price-max" class="text-danger fw-bold">--</span></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Wallbox Card -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h6 class="card-title text-muted text-uppercase small fw-bold mb-0"><i class="fas fa-charging-station me-2"></i>Wallbox</h6>
                                    <a href="index.php?seite=wallbox" class="text-secondary" title="Steuern"><i class="fas fa-cog"></i></a>
                                </div>
                                <div class="d-flex align-items-center">
                                    <div class="icon-box bg-secondary bg-opacity-10 text-secondary me-3" id="icon-wb" style="width: 48px; height: 48px; font-size: 1.25rem;">
                                        <i class="fas fa-car"></i>
                                    </div>
                                    <div>
                                        <div class="fs-4 fw-bold" id="val-wb">0<span class="fs-6 text-muted ms-1">W</span></div>
                                        <div class="small text-muted" id="wb-status">Bereit</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Heatpump Card -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h6 class="card-title text-muted text-uppercase small fw-bold mb-0"><i class="fas fa-water me-2"></i>Wärmepumpe</h6>
                                </div>
                                <div class="d-flex align-items-center">
                                    <div class="icon-box bg-info bg-opacity-10 text-info me-3" id="icon-wp" style="width: 48px; height: 48px; font-size: 1.25rem;">
                                        <i class="fas fa-fan"></i>
                                    </div>
                                    <div>
                                        <div class="fs-4 fw-bold" id="val-wp">0<span class="fs-6 text-muted ms-1">W</span></div>
                                        <div class="small text-muted">Leistung</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h6 class="card-title text-muted text-uppercase small fw-bold mb-3">Schnellzugriff</h6>
                                <div class="d-grid gap-2">
                                    <button class="btn btn-outline-secondary text-start" onclick="switchChartMode('forecast')">
                                        <i class="fas fa-chart-line me-2 w-25px"></i>SoC Prognose
                                    </button>
                                    <button class="btn btn-outline-secondary text-start" onclick="switchChartMode('live')">
                                        <i class="fas fa-chart-area me-2 w-25px"></i>Leistungsverlauf
                                    </button>
                                    <button class="btn btn-outline-secondary text-start" onclick="switchChartMode('archive')">
                                        <i class="fas fa-history me-2 w-25px"></i>Archiv
                                    </button>
                                    <button class="btn btn-outline-warning text-start" onclick="startSystemUpdate()">
                                        <i class="fas fa-cloud-download-alt me-2 w-25px"></i>System Update
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <script>
                    // Verschiebe Preis-Karte nach der Wärmepumpe-Karte
                    document.addEventListener('DOMContentLoaded', function() {
                        const parent = document.getElementById('right-column-cards');
                        if (parent) {
                            const priceCard = parent.querySelector('.col-12:nth-child(1)');
                            const heatpumpCard = parent.querySelector('.col-12:nth-child(3)');
                            if (priceCard && heatpumpCard) {
                                // Füge die Preiskarte nach der Wärmepumpenkarte ein
                                heatpumpCard.after(priceCard);
                            }
                        }
                    });
                </script>
            </div>
        </div>
        </div>
        <?php elseif ($seite === 'wallbox'): ?>
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10 col-xl-8">
                    <div class="mb-3">
                        <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left me-2"></i>Zurück zum Dashboard</a>
                    </div>
                    <?php include 'Wallbox.php'; ?>
                </div>
            </div>
        <?php elseif ($seite === 'archiv'): ?>
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10 col-xl-8">
                    <div class="mb-3">
                        <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left me-2"></i>Zurück zum Dashboard</a>
                    </div>
                    <?php include 'archiv.php'; ?>
                </div>
            </div>
        <?php elseif ($seite === 'config'): ?>
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10 col-xl-8">
                    <div class="mb-3">
                        <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left me-2"></i>Zurück zum Dashboard</a>
                    </div>
                    <?php include 'config_editor.php'; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Footer -->
        <footer class="text-center text-muted mt-5 pt-3 border-top border-secondary">
            <small>
                E3DC Control &copy; <?= date('Y') ?> | 
                <a href="#" class="text-decoration-none text-secondary" data-bs-toggle="modal" data-bs-target="#changelogModal">Changelog</a>
                <?php
                if (file_exists('VERSION')) {
                    echo ' | v' . htmlspecialchars(trim(file_get_contents('VERSION')));
                }
                ?>
            </small>
        </footer>
    </div>

    <!-- Changelog Modal -->
    <div class="modal fade" id="changelogModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content bg-dark text-light border-secondary">
                <div class="modal-header border-secondary">
                    <h5 class="modal-title">Changelog</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <pre style="white-space: pre-wrap; font-family: monospace; font-size: 0.85rem; color: #ccc;"><?php
                        $logFile = 'CHANGELOG.md';
                        if (file_exists($logFile)) {
                            echo htmlspecialchars(file_get_contents($logFile));
                        } else {
                            echo "Kein Changelog verfügbar.";
                        }
                    ?></pre>
                </div>
            </div>
        </div>
    </div>

    <!-- Update Modal -->
    <div class="modal fade" id="updateModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content bg-dark text-light border-secondary">
                <div class="modal-header border-secondary">
                    <h5 class="modal-title"><i class="fas fa-sync fa-spin me-2" id="update-spinner"></i>System Update</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close" id="update-close-btn" style="display:none;"></button>
                </div>
                <div class="modal-body bg-black">
                    <pre id="update-log" style="font-family: monospace; font-size: 0.85rem; color: #0f0; white-space: pre-wrap;">Starte Update-Prozess...</pre>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="update-finish-btn" disabled>Schließen</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="solar.js?v=<?= file_exists('solar.js') ? filemtime('solar.js') : time() ?>"></script>
    <script>
        function updateTime() {
            const now = new Date();
            document.getElementById('clock').innerText = now.toLocaleTimeString('de-DE', {hour: '2-digit', minute:'2-digit'});
            document.getElementById('date').innerText = now.toLocaleDateString('de-DE');
        }
        setInterval(updateTime, 1000);
        updateTime();

        // Konstanten aus logic.php für JS verfügbar machen
        const FORECAST_DATA = <?= json_encode($forecastData) ?>;
        const PV_STRINGS = <?= json_encode($pvStrings) ?>;
        const LAT = <?= json_encode($lat) ?>;
        const LON = <?= json_encode($lon) ?>;
        const BAT_CAPACITY = <?= json_encode($batteryCapacity) ?>;
        const PV_ATMOSPHERE = <?= json_encode($pvAtmosphere) ?>;
        let SHOW_FORECAST = <?= $showForecast ? 'true' : 'false' ?>;
        let DARK_MODE = <?= $darkMode ? 'true' : 'false' ?>;

        function formatWatts(w) {
            w = parseFloat(w);
            if (isNaN(w)) return '--';
            if (Math.abs(w) > 4000) {
                return (w / 1000).toLocaleString('de-DE', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + '<span class="val-unit">kW</span>';
            }
            return Math.round(w).toLocaleString('de-DE') + '<span class="val-unit">W</span>';
        }

        function toggleForecast(el) {
            SHOW_FORECAST = !SHOW_FORECAST;
            // Icon umschalten
            if (SHOW_FORECAST) el.classList.replace('fa-eye-slash', 'fa-eye');
            else el.classList.replace('fa-eye', 'fa-eye-slash');
            
            // Speichern
            $.post('save_setting.php', {
                key: 'show_forecast', 
                value: SHOW_FORECAST ? '1' : '0'
            });
            
            fetchData(); // Sofort aktualisieren
        }

        function toggleDarkMode() {
            DARK_MODE = !DARK_MODE;
            const html = document.documentElement;
            const icon = document.getElementById('darkmode-icon');
            
            html.setAttribute('data-bs-theme', DARK_MODE ? 'dark' : 'light');
            icon.className = DARK_MODE ? 'fas fa-moon' : 'fas fa-sun';
            
            $.post('save_setting.php', {
                key: 'darkmode', 
                value: DARK_MODE ? '1' : '0'
            });
            
            // Diagramme aktualisieren (damit Python das neue Theme lädt)
            refreshData(false); // Manuelles Umschalten erzwingt Update
        }

        function fetchData() {
            $.getJSON('get_live_json.php', function(data) {
                if (!data) return;

                const now = Math.floor(Date.now() / 1000);
                const dataTs = data.ts || 0;
                const age = now - dataTs;
                const statusBadge = $('#connection-status');

                if (age > 300) { // 5 Minuten
                    statusBadge.removeClass('bg-secondary bg-success bg-danger').addClass('bg-warning text-dark').text('Veraltet (' + Math.floor(age/60) + 'm)');
                } else {
                    statusBadge.removeClass('bg-secondary bg-danger bg-warning text-dark').addClass('bg-success text-white').text('Online');
                }

                if (document.getElementById('val-pv')) {
                // Berechnungen
                let homeVal = (data.home_raw || 0);
                if (data.wp > 0) homeVal -= data.wp;
                if (homeVal < 0) homeVal = 0;

                // Basic Values
                $('#val-pv').html(formatWatts(data.pv));
                $('#val-home').html(formatWatts(homeVal));
                $('#val-soc').text(Math.round(data.soc) + '%');

                // --- Tag/Nacht Icon Logik ---
                const isDay = (typeof isDaytime === 'function') ? isDaytime() : true;
                const iconPvBox = $('#icon-pv-box');
                const iconPv = $('#icon-pv');
                
                if (isDay) {
                    if (iconPv.hasClass('fa-moon')) {
                        iconPv.removeClass('fa-moon').addClass('fa-sun');
                        iconPvBox.removeClass('bg-secondary text-secondary').addClass('bg-warning text-warning');
                    }
                } else {
                    if (iconPv.hasClass('fa-sun')) {
                        iconPv.removeClass('fa-sun').addClass('fa-moon');
                        iconPvBox.removeClass('bg-warning text-warning').addClass('bg-secondary text-secondary');
                    }
                }

                // --- PV Prognose & Soll Logik ---
                const now = new Date();
                const curGmt = now.getUTCHours() + (now.getUTCMinutes() / 60);
                let bestForecast = null; let minDiff = 100;
                for (let d of FORECAST_DATA) {
                    let diff = Math.abs(d.h - curGmt);
                    if (diff < minDiff) { minDiff = diff; bestForecast = d; }
                }

                const sollVal = (typeof getTheoreticalPower === 'function') ? getTheoreticalPower() : 0;
                const pvDetails = $('#val-pv-details');
                
                // Nur anzeigen wenn Tag (Soll > 0) oder Prognose relevant
                if (SHOW_FORECAST && (sollVal > 10 || (bestForecast && bestForecast.w > 10))) {
                    let fVal = (bestForecast && minDiff < 0.5) ? bestForecast.w : 0;
                    
                    // Formatierung für kleine Anzeige
                    const fmtSmall = (v) => (v >= 1000) ? (v/1000).toFixed(2) + 'k' : Math.round(v);
                    
                    let ratio = (fVal > 0) ? (data.pv / fVal) : 0;
                    let pctStr = (fVal > 0) ? Math.round(ratio * 100) + '%' : '';
                    
                    let fText = fmtSmall(fVal);
                    if (pctStr) fText += ` <span style="font-size:0.7em; opacity:0.7;">(${pctStr})</span>`;

                    $('#val-pv-forecast').html(fText);
                    $('#val-pv-soll').text(fmtSmall(sollVal));
                    
                    // Farb-Logik für Prognose (wie Mobile)
                    if (fVal > 0 && ratio < 0.75) $('#val-pv-forecast').css('color', '#ef4444');
                    else if (fVal > 0 && ratio > 1.25) $('#val-pv-forecast').css('color', '#10b981');
                    else $('#val-pv-forecast').css('color', 'inherit');

                    pvDetails.show();
                } else {
                    pvDetails.hide();
                }
                
                // Wallbox Logic (NEU)
                const wbVal = parseFloat(data.wb) || 0;
                $('#val-wb').html(formatWatts(wbVal));

                const wbIcon = $('#icon-wb');
                if (wbVal > 0) {
                    // Wenn Leistung > 0: Blau leuchten (wie Wärmepumpe)
                    wbIcon.removeClass('bg-secondary text-secondary').addClass('bg-info text-info pulsating');
                } else {
                    // Wenn 0: Grau/Standard
                    wbIcon.removeClass('bg-info text-info pulsating').addClass('bg-secondary text-secondary');
                }

                // Optional: Status-Text Update
                if (wbVal > 0) {
                    $('#wb-status').text('Lädt...');
                } else {
                    $('#wb-status').text('Bereit');
                }
                // Heatpump Logic
                const wpVal = parseFloat(data.wp) || 0;
                $('#val-wp').html(formatWatts(wpVal));
                if (wpVal < 100) {
                    $('#icon-wp').removeClass('bg-info text-info').addClass('bg-secondary text-muted');
                } else {
                    $('#icon-wp').removeClass('bg-secondary text-muted').addClass('bg-info text-info');
                }

                // Battery Logic
                const batVal = Math.round(data.bat);
                const batAbs = Math.abs(batVal);
                $('#val-bat-container').html(formatWatts(batAbs));

                // --- Batterie Zeit-Logik ---
                let batTimeText = '';
                if (BAT_CAPACITY > 0 && batAbs > 50) {
                    let hours = 0;
                    let soc = parseFloat(data.soc) || 0;
                    if (batVal > 0 && soc < 100) { // Laden
                        hours = ((100 - soc) / 100 * BAT_CAPACITY * 1000) / batVal;
                        if (hours > 0 && hours < 48) {
                            let h = Math.floor(hours); let m = Math.round((hours - h) * 60);
                            batTimeText = `(voll: ${h}:${m.toString().padStart(2, '0')}h)`;
                        }
                    } else if (batVal < 0 && soc > 0) { // Entladen
                        hours = (soc / 100 * BAT_CAPACITY * 1000) / batAbs;
                        if (hours > 0 && hours < 48) {
                            let h = Math.floor(hours); let m = Math.round((hours - h) * 60);
                            batTimeText = `(leer: ${h}:${m.toString().padStart(2, '0')}h)`;
                        }
                    }
                }
                $('#val-bat-time').text(batTimeText);
                
                const batIcon = $('#icon-bat');
                const batContainer = $('#val-bat-container');
                
                if (batVal > 0) { // Charging
                    batIcon.removeClass('text-success text-danger text-muted').addClass('text-success pulsating');
                    batContainer.removeClass('text-success text-danger text-muted').addClass('text-success');
                } else if (batVal < 0) { // Discharging
                    batIcon.removeClass('text-success text-danger text-muted').addClass('text-danger pulsating');
                    batContainer.removeClass('text-success text-danger text-muted').addClass('text-danger');
                } else {
                    batIcon.removeClass('text-success text-danger pulsating').addClass('text-muted');
                    batContainer.removeClass('text-success text-danger').addClass('text-muted');
                }

                // Grid Logic
                const gridVal = Math.round(data.grid);
                const gridAbs = Math.abs(gridVal);
                $('#val-grid-container').html(formatWatts(gridAbs));
                
                const gridIcon = $('#icon-grid');
                const gridContainer = $('#val-grid-container');

                if (gridVal > 0) { // Import (Bezug) -> Rot
                    gridIcon.removeClass('text-secondary text-success text-danger').addClass('text-danger');
                    gridContainer.removeClass('text-body text-success text-danger').addClass('text-danger');
                } else if (gridVal < 0) { // Export (Einspeisung) -> Grün
                    gridIcon.removeClass('text-secondary text-success text-danger').addClass('text-success');
                    gridContainer.removeClass('text-body text-success text-danger').addClass('text-success');
                } else {
                    gridIcon.removeClass('text-success text-danger').addClass('text-secondary');
                    gridContainer.removeClass('text-success text-danger').addClass('text-body');
                }

                // Price Logic
                if (data.price_ct !== undefined && data.price_ct !== null) {
                    $('#val-price').html(data.price_ct.toLocaleString('de-DE', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + '<span class="val-unit">ct/kWh</span>');
                    
                    if (data.price_min_ct !== undefined && data.price_min_ct !== null) {
                        $('#val-price-min').text(data.price_min_ct.toLocaleString('de-DE', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
                    }
                    if (data.price_max_ct !== undefined && data.price_max_ct !== null) {
                        $('#val-price-max').text(data.price_max_ct.toLocaleString('de-DE', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
                    }

                    // Dynamic bar visualization (Min-Max range)
                    let min = (data.price_min_ct !== undefined && data.price_min_ct !== null) ? data.price_min_ct : 0;
                    let max = (data.price_max_ct !== undefined && data.price_max_ct !== null) ? data.price_max_ct : 50;
                    let current = data.price_ct;
                    let pct = 50; // Default Mitte
                    
                    if (max > min) pct = ((current - min) / (max - min)) * 100;
                    
                    if (pct < 0) pct = 0; if (pct > 100) pct = 100;
                    
                    const bar = $('#price-bar');
                    bar.css('width', pct + '%');
                    
                    bar.removeClass('bg-info bg-success bg-warning bg-danger');
                    if (data.price_level === 'cheap') {
                        bar.addClass('bg-success');
                    } else if (data.price_level === 'expensive') {
                        bar.addClass('bg-danger');
                    } else {
                        bar.addClass('bg-warning');
                    }

                    // Price Trend Logic
                    const prices = data.prices || [];
                    const priceStartHour = data.price_start_hour;
                    const priceInterval = data.price_interval || 1.0;
                    let trendIcon = '<i class="fas fa-minus"></i>';

                    if (prices.length > 1 && priceStartHour !== null) {
                        const now = new Date();
                        const curGmtDec = now.getUTCHours() + (now.getUTCMinutes() / 60);
                        let hourDiff = curGmtDec - priceStartHour;
                        if (hourDiff < 0) hourDiff += 24; // Handle day change
                        
                        let idx = Math.floor(hourDiff / priceInterval);
                        
                        if (prices[idx] !== undefined && prices[idx+1] !== undefined) {
                            const diff = prices[idx+1] - prices[idx];
                            if (diff > 0.1) {
                                trendIcon = '<i class="fas fa-arrow-trend-up text-danger" title="Preis steigend"></i>';
                            } else if (diff < -0.1) {
                                trendIcon = '<i class="fas fa-arrow-trend-down text-success" title="Preis fallend"></i>';
                            } else {
                                trendIcon = '<i class="fas fa-arrow-right text-info" title="Preis stabil"></i>';
                            }
                        }
                    }
                    $('#price-trend').html(trendIcon);
                }
                }

            }).fail(function() {
                $('#connection-status').removeClass('bg-secondary bg-success').addClass('bg-danger').text('Offline');
            });
        }

        function updateChart(hours, btn) {
            if(btn) {
                $('.btn-group-custom .btn').removeClass('active');
                $(btn).addClass('active');
                // Reset Dropdown
                $('#live-controls select').val('');
            }
            
            const iframe = document.getElementById('chart-frame');
            if(iframe) iframe.style.opacity = '0.5';

            // Call PHP to generate new chart
            $.get('run_live_history.php?hours=' + hours, function() {
                // Poll for completion
                const checkInterval = setInterval(function() {
                    $.getJSON('run_live_history.php?mode=status', function(status) {
                        if (!status.running) {
                            clearInterval(checkInterval);
                            if(iframe) {
                                iframe.src = 'live_diagramm.html?t=' + new Date().getTime();
                                iframe.style.opacity = '1';
                            }
                        }
                    });
                }, 1000);
            });
        }

        function updateChartHistory(file) {
            if (!file) {
                // Zurück zu Live (Standard 6h)
                updateChart(6, document.querySelector('.btn-group-custom .btn:first-child'));
                return;
            }
            
            // Buttons deaktivieren
            $('.btn-group-custom .btn').removeClass('active');
            
            const iframe = document.getElementById('chart-frame');
            if(iframe) iframe.style.opacity = '0.5';

            $.get('run_live_history.php?file=' + encodeURIComponent(file), function() {
                const checkInterval = setInterval(function() {
                    $.getJSON('run_live_history.php?mode=status', function(status) {
                        if (!status.running) {
                            clearInterval(checkInterval);
                            if(iframe) {
                                iframe.src = 'live_diagramm.html?t=' + new Date().getTime();
                                iframe.style.opacity = '1';
                            }
                        }
                    });
                }, 1000);
            });
        }

        function switchChartMode(mode) {
            // Dropdown synchronisieren (falls Aufruf über Button kam)
            document.getElementById('chart-mode-select').value = mode;

            const iframe = document.getElementById('chart-frame');
            const title = document.getElementById('chart-title');
            const liveControls = document.getElementById('live-controls');
            const archiveSelect = document.getElementById('archive-select');

            if (mode === 'forecast') {
                title.innerHTML = '<i class="fas fa-chart-line me-2 text-secondary"></i>SoC Prognose';
                if (liveControls) liveControls.style.display = 'none';
                archiveSelect.style.display = 'none';
                iframe.src = 'diagramm.html?t=' + new Date().getTime();
                // Trigger update check
                $.get('run_now.php');
            } else if (mode === 'live') {
                title.innerHTML = '<i class="fas fa-chart-area me-2 text-secondary"></i>Leistungsverlauf';
                if (liveControls) liveControls.style.display = 'flex';
                archiveSelect.style.display = 'none';
                iframe.src = 'live_diagramm.html?t=' + new Date().getTime();
            } else if (mode === 'archive') {
                title.innerHTML = '<i class="fas fa-history me-2 text-secondary"></i>Archiv';
                if (liveControls) liveControls.style.display = 'none';
                archiveSelect.style.display = 'inline-block';
                // Wenn noch keine Datei gewählt, erste wählen oder leer lassen
                if (archiveSelect.options.length > 1 && archiveSelect.selectedIndex <= 0) {
                   archiveSelect.selectedIndex = 1; // Erste echte Datei wählen
                   loadArchive(archiveSelect.value);
                } else if (archiveSelect.value) {
                   loadArchive(archiveSelect.value);
                }
            }
        }

        function loadArchive(file) {
            const iframe = document.getElementById('chart-frame');
            iframe.src = 'archiv_diagramm.php?file=' + encodeURIComponent(file) + '&ts=' + new Date().getTime();
        }

        /* Veraltet, ersetzt durch switchChartMode
        function toggleForecast(btn) {
            const iframe = document.getElementById('chart-frame');
            const title = document.getElementById('chart-title');
            const controls = document.getElementById('chart-controls');
            const btnText = document.getElementById('btn-forecast-text');
            
            if (iframe.src.includes('live_diagramm.html')) {
                // Switch to Forecast
                iframe.src = 'diagramm.html?t=' + new Date().getTime();
                title.innerHTML = '<i class="fas fa-chart-line me-2 text-secondary"></i>SoC Prognose';
                controls.style.display = 'none';
                btnText.innerText = 'Leistungsverlauf';
                // Trigger update for forecast if needed
                $.get('run_now.php'); 
            } else {
                // Switch back to History
                iframe.src = 'live_diagramm.html?t=' + new Date().getTime();
                title.innerHTML = '<i class="fas fa-chart-area me-2 text-secondary"></i>Leistungsverlauf';
                controls.style.display = 'inline-flex';
                btnText.innerText = 'SoC Prognose';
            }
        }
        */

        function refreshData(isAuto = false) {
            fetchData();
            const iframe = document.getElementById('chart-frame');
            if (!iframe) return;

            const btn = document.getElementById('main-refresh-btn');
            // Speichere Originaltext, falls noch nicht geschehen
            if (!btn.dataset.originalHtml) {
                btn.dataset.originalHtml = btn.innerHTML;
            }
            const originalHtml = btn.dataset.originalHtml;

            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

            const startTime = Date.now();
            const timeoutMs = 30000; // 30 Sekunden Timeout

            const handleTimeout = (interval) => {
                if (Date.now() - startTime > timeoutMs) {
                    clearInterval(interval);
                    btn.innerHTML = '<i class="fas fa-exclamation-triangle text-danger"></i>';
                    if (iframe) iframe.style.opacity = '1'; // Restore opacity on timeout
                    setTimeout(() => {
                        btn.disabled = false;
                        btn.innerHTML = originalHtml;
                    }, 3000);
                    return true;
                }
                return false;
            };

            if (iframe.src.includes('diagramm.html') || document.getElementById('chart-mode-select').value === 'forecast') {
                // SoC Prognose aktualisieren
                let url = 'run_now.php';
                if (isAuto) url += '?auto=1';

                $.get(url, function(response) {
                    if (response.trim() === 'skipped') {
                        // Update nicht nötig -> Spinner weg, fertig.
                        btn.disabled = false;
                        btn.innerHTML = originalHtml;
                        return;
                    }

                    const checkInterval = setInterval(function() {
                        if (handleTimeout(checkInterval)) return;

                        $.getJSON('status.php', function(status) {
                            if (!status.running) {
                                clearInterval(checkInterval);
                                iframe.src = iframe.src.split('?')[0] + '?t=' + new Date().getTime();
                                btn.disabled = false;
                                btn.innerHTML = originalHtml;
                            }
                        });
                    }, 1000);
                });
            } else if (document.getElementById('chart-mode-select').value === 'live') {
                // Leistungsverlauf aktualisieren (FIXED)
                iframe.style.opacity = '0.5';
                
                // Leistungsverlauf aktualisieren
                // Aktuelle Stunden auslesen
                let hours = 6;
                const activeBtn = document.querySelector('#live-controls .btn.active');
                if (activeBtn) hours = parseInt(activeBtn.innerText);

                $.get('run_live_history.php?hours=' + hours, function() {
                    const checkInterval = setInterval(function() {
                        if (handleTimeout(checkInterval)) return; // Timeout handler already restores opacity

                        $.getJSON('run_live_history.php?mode=status', function(status) {
                            if (!status.running) {
                                clearInterval(checkInterval);
                                iframe.src = 'live_diagramm.html?t=' + new Date().getTime();
                                iframe.style.opacity = '1';
                                btn.disabled = false;
                                btn.innerHTML = originalHtml;
                            }
                        });
                    }, 1000);
                });
            } else {
                // Archiv Modus - hier macht "Aktualisieren" weniger Sinn, aber wir können das Iframe neu laden
                iframe.src = iframe.src;
                btn.disabled = false;
                btn.innerHTML = originalHtml;
            }
        }

        function startSystemUpdate() {
            if (!confirm('Möchtest du E3DC-Control wirklich aktualisieren? Das System wird dabei neu gestartet.')) return;
            
            const modal = new bootstrap.Modal(document.getElementById('updateModal'));
            modal.show();
            
            const log = document.getElementById('update-log');
            const spinner = document.getElementById('update-spinner');
            const closeBtn = document.getElementById('update-close-btn');
            const finishBtn = document.getElementById('update-finish-btn');
            
            // Reset UI
            log.innerText = "Starte Anfrage...\n";
            spinner.className = "fas fa-sync fa-spin me-2";
            closeBtn.style.display = 'none';
            finishBtn.disabled = true;
            finishBtn.innerText = "Schließen";
            
            // Start Request
            fetch('run_update.php?action=start')
                .then(r => r.json())
                .then(data => {
                    if (data.status === 'started' || data.status === 'running') {
                        log.innerText = "Update gestartet. Warte auf Ausgabe...\n";
                        pollUpdate();
                    } else {
                        log.innerText = "Fehler: " + (data.message || "Unbekannter Fehler");
                        finishBtn.disabled = false;
                    }
                })
                .catch(err => {
                    log.innerText = "Netzwerkfehler beim Starten: " + err;
                    finishBtn.disabled = false;
                });

            function pollUpdate() {
                const interval = setInterval(() => {
                    fetch('run_update.php?action=poll')
                        .then(r => r.json())
                        .then(data => {
                            log.innerText = data.log;
                            const modalBody = log.parentElement;
                            modalBody.scrollTop = modalBody.scrollHeight;

                            if (!data.running) {
                                clearInterval(interval);
                                finalize(data.log);
                            }
                        })
                        .catch(err => console.error("Poll error:", err));
                }, 1000);
            }

            function finalize(logText) {
                spinner.classList.remove('fa-spin', 'fa-sync');
                
                if (logText.includes("Update erfolgreich abgeschlossen") || logText.includes("Du bist auf dem neuesten Stand")) {
                    spinner.classList.add('fa-check-circle', 'text-success');
                    log.innerText += "\n\n✓ Vorgang erfolgreich beendet.";
                } else {
                    spinner.classList.add('fa-times-circle', 'text-danger');
                    log.innerText += "\n\n✗ Update fehlgeschlagen oder unvollständig.";
                }

                closeBtn.style.display = 'block';
                finishBtn.disabled = false;
            }
        }

        // Init
        fetchData();
        setInterval(fetchData, 5000);
        
        // Diagramm beim Laden aktualisieren, um veraltete Daten/falschen Modus zu vermeiden
        $(document).ready(function() { refreshData(true); });

        // Auto-Reload bei neuer Version
        const APP_VERSION_TS = <?= filemtime(__FILE__) ?>;
        setInterval(() => {
            fetch('index.php?check_version=1')
                .then(r => r.text())
                .then(ts => {
                    if (parseInt(ts) > APP_VERSION_TS) location.reload();
                })
                .catch(e => {});
        }, 30000); // Alle 30 Sekunden prüfen
    </script>
</body>
</html>