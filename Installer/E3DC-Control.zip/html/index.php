<?php
/* =====================================================================
   E3DC-Control - index.php (Überarbeitete Version)
   
   - helpers.php und style.css eingebunden
   - Konsistente Dark-Mode Farbgebung
   - Verbesserte Fehlerbehandlung
   ===================================================================== */

include 'helpers.php';

/* Sicheres Routing */
$allowed = ['start','wallbox','config','auto','archiv'];
$seite = $_GET['seite'] ?? 'start';
if (!in_array($seite, $allowed)) {
    $seite = 'start';
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#005b8e">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

    <title>E3DC Control</title>

    <!-- PWA -->
    <link rel="manifest" href="/manifest.json">
    <link rel="apple-touch-icon" href="/icons/icon-192.png">
    
    <!-- Zentrale Dark-Mode CSS -->
    <link rel="stylesheet" href="style.css">

</head>

<body>

    <!-- Mobile Menü -->
    <input type="checkbox" id="menu-toggle">
    <label for="menu-toggle" class="menu-icon">&#9776;</label>

    <nav class="mobile-menu">
        <a href="?seite=start">Startseite</a>
        <a href="?seite=wallbox">Wallbox</a>
        <a href="?seite=config">Config</a>
        <a href="?seite=auto">Auto</a>
        <a href="?seite=archiv">Archiv</a>
    </nav>

    <div class="container">
        <h1>E3DC-Control Anzeige & Steuerung</h1>

        <!-- Desktop Navigation -->
        <nav style="margin-bottom: 20px;">
            <a class="button" href="?seite=start">Startseite</a>
            <a class="button" href="?seite=wallbox">Wallbox</a>
            <a class="button" href="?seite=config">Config</a>
            <a class="button" href="?seite=auto">Auto</a>
            <a class="button" href="?seite=archiv">Archiv</a>
        </nav>

        <main id="content">
            <?php
            switch ($seite) {
                case 'wallbox':
                    include 'Wallbox.php';
                    break;
                case 'config':
                    include 'config_editor.php';
                    break;
                case 'auto':
                    include 'auto.php';
                    break;
                case 'archiv':
                    include 'archiv.php';
                    break;
                case 'start':
                default:
                    include 'start_content.php';
                    break;
            }
            ?>
        </main>
    </div>

    <footer id="fussnoten">
        <h3>Das Projekt</h3>
        <p>
            <a href="https://github.com/Eba-M/E3DC-Control" target="_blank">GitHub</a> |
            <a href="https://www.photovoltaikforum.com" target="_blank">Photovoltaikforum</a>
        </p>
    </footer>

    <!-- Service Worker -->
    <script>
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('/service-worker.js')
                .catch(err => console.error('SW Fehler:', err));
        });
    }
    </script>

</body>
</html>
