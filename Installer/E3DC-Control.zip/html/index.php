<?php
session_start();
require_once 'helpers.php';
handleVersionCheck(__FILE__);
handleUpdatePreparation();
handleUpdateCheck();
handleServiceRestart();
handleWatchdogStatus();
handleWatchdogLog();
handleSelfUpdateCheck();
handleRunSelfUpdate();
handleEnergyManagerLog();
handleSaveSetting();
handleStatus();
handleRunNow();
handleRunLiveHistory();
handleRunUpdate();
handleArchivDiagram();
handleDailyStats();
require_once 'logic.php';

// Luxtronik Global Toggle Handler
if (isset($_POST['save_lux_global'])) {
    $paths = getInstallPaths();
    $configFile = rtrim($paths['install_path'], '/') . '/e3dc.config.txt';
    $key = 'luxtronik';
    $val = isset($_POST['lux_active']) ? '1' : '0';

    if (file_exists($configFile)) {
        $lines = file($configFile, FILE_IGNORE_NEW_LINES);
        $newLines = [];
        $found = false;

        foreach ($lines as $line) {
            if (preg_match('/^\s*' . preg_quote($key, '/') . '\s*=/i', $line)) {
                $newLines[] = "$key = $val";
                $found = true;
            } else {
                $newLines[] = $line;
            }
        }
        if (!$found) {
            $newLines[] = "\n# Luxtronik-Integration\n$key = $val";
        }
        file_put_contents($configFile, implode("\n", $newLines) . "\n", LOCK_EX);
    }
    
    shell_exec("sudo systemctl restart energy_manager > /dev/null 2>&1 &");
    header("Location: index.php?seite=config");
    exit;
}

$seite = $_GET['seite'] ?? 'dashboard';

// Archiv-Dateien für das Dropdown laden
$archivFiles = [];
$historyFiles = [];
$diagramMode = 'manual'; // Default
$diagramInterval = 5; // Default Intervall in Minuten

if ($seite === 'dashboard') {
    $paths = getInstallPaths();
    $base_path = rtrim($paths['install_path'], '/') . '/';
    $archivFiles = getArchivedDebugFiles($base_path);
    $historyFiles = getHistoryBackupFiles();

    // Diagramm-Intervall aus Config laden
    $diagConf = $base_path . 'diagram_config.json';
    if (file_exists($diagConf)) {
        $dc = @json_decode(file_get_contents($diagConf), true);
        if (isset($dc['auto_interval_minutes'])) $diagramInterval = (int)$dc['auto_interval_minutes'];
        if (isset($dc['diagram_mode'])) $diagramMode = $dc['diagram_mode'];
    }
    
    // Luxtronik History Files scannen
    $luxtronikFiles = [];
    $luxPath = '/var/www/html/tmp/luxtronik_archive/';
    if (is_dir($luxPath)) {
        $files = glob($luxPath . 'luxtronik_*.json');
        if($files) {
            rsort($files);
            foreach ($files as $f) {
                if (preg_match('/luxtronik_(\d{4}-\d{2}-\d{2})\.json/', basename($f), $m)) {
                    $date = $m[1];
                    // Dummy-Dateiname für plot_live_history.py
                    $luxtronikFiles[] = ['file' => 'history_' . $date . '.txt', 'label' => date('d.m.Y', strtotime($date))];
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="de" data-bs-theme="<?= $darkMode ? 'dark' : 'light' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E3DC Control Dashboard</title>

    <link rel="manifest" href="manifest.json">

    <link rel="preconnect" href="https://cdn.jsdelivr.net">
    <link rel="preconnect" href="https://cdnjs.cloudflare.com">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <style>
        /* Dark Mode Defaults (Bootstrap handles most via data-bs-theme="dark") */
        [data-bs-theme="dark"] body { background-color: #121212; color: #e0e0e0; }
        [data-bs-theme="dark"] .card { background-color: #1e1e1e; border-color: #333; box-shadow: 0 4px 10px rgba(0,0,0,0.3); }
        
        /* Light Mode Overrides */
        [data-bs-theme="light"] body { background-color: #f8f9fa; color: #212529; }
        [data-bs-theme="light"] .card { background-color: #ffffff; border-color: #dee2e6; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }

        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .card { border-radius: 12px; transition: transform 0.2s; }
        /* Hover-Effekt nur für Dashboard-Cards, nicht für Container in Unterseiten */
        .dashboard-view .card:hover { transform: translateY(-2px); border-color: #444; cursor: pointer; }
        .icon-box { width: 56px; height: 56px; display: flex; align-items: center; justify-content: center; border-radius: 16px; font-size: 1.75rem; }
        .val-large { font-size: 2.2rem; font-weight: 700; letter-spacing: -1px; }
        .val-unit { font-size: 1rem; color: #888; font-weight: 400; margin-left: 4px; }
        .pulsating { animation: pulse 2s infinite ease-in-out; }
        @keyframes pulse {
            0% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.6; transform: scale(0.92); }
            100% { opacity: 1; transform: scale(1); }
        }
        .chart-container { height: 500px; width: 100%; overflow: hidden; border-radius: 0 0 12px 12px; }
        iframe { border: none; width: 100%; height: 100%; }
        .btn-group-custom .btn { border-color: #444; color: #aaa; }
        .btn-group-custom .btn:hover, .btn-group-custom .btn.active { background-color: #333; color: #fff; border-color: #555; }
        .status-badge { font-size: 0.8rem; padding: 0.35em 0.65em; }
        
        /* Anpassungen für inkludierte Seiten */
        .container-fluid { max-width: 1920px; }
        /* --- Energiefluss Ansicht --- */
    .flow-container { background-color: #1e1e1e; color: #fff; border-radius: 0 0 12px 12px; position: relative; width: 100%; height: 100%; overflow: hidden; font-family: sans-serif; }
    .flow-svg { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 1; pointer-events: none; }
    .flow-line { fill: none; stroke-width: 4; opacity: 0.2; }
    .flow-dots { fill: none; stroke-width: 6; stroke-dasharray: 0 20; animation: flowAnim 1s linear infinite; stroke-linecap: round; }
    @keyframes flowAnim { to { stroke-dashoffset: -60; } }
    .flow-dots.reverse { animation-direction: reverse; }
    .flow-dots.stopped { animation-play-state: paused; opacity: 0; }

    .flow-node { position: absolute; transform: translate(-50%, -50%); border-radius: 50%; display: flex; flex-direction: column; align-items: center; justify-content: center; z-index: 10; background: #1e1e1e; border: 4px solid; width: 130px; height: 130px; text-align: center; }
    .flow-node .fa-icon { font-size: 2.2rem; margin-bottom: 4px; }
    .flow-node .val { font-size: 1.3rem; font-weight: bold; }
    .flow-node .label { font-size: 0.7rem; color: #aaa; text-transform: uppercase; }
    .flow-node .price-tag { position: absolute; bottom: -20px; background: #222; padding: 2px 6px; border-radius: 8px; font-size: 0.7rem; font-weight: bold; border: 1px solid #444; white-space: nowrap; }

    /* Backing Circle für Batterie */
    .flow-node-back {
        position: absolute; transform: translate(-50%, -50%); border-radius: 50%;
        z-index: 5; background-color: #1e1e1e;
        width: 130px; height: 130px;
        top: 15%; left: 50%;
    }

    /* Node Farben / Glow */
    .node-pv { border-color: #ffc107; color: #ffc107; box-shadow: 0 0 20px rgba(255,193,7,0.4); top: 25%; left: 20%; }
    .node-grid { border-color: #6c757d; color: #ced4da; box-shadow: 0 0 20px rgba(108,117,125,0.4); top: 75%; left: 20%; }
    .node-bat { border-color: #dc3545; color: #dc3545; box-shadow: 0 0 20px rgba(220,53,69,0.4); top: 15%; left: 50%; }
    .node-bat.charging { border-color: #2ecc71; color: #2ecc71; box-shadow: 0 0 20px rgba(46,204,113,0.4); }
    .node-home { border-color: #0dcaf0; color: #0dcaf0; box-shadow: 0 0 20px rgba(13,202,240,0.4); top: 30%; left: 72%; }
    .node-wb { border-color: #2ecc71; color: #2ecc71; box-shadow: 0 0 20px rgba(46,204,113,0.4); top: 50%; left: 85%; }
    .node-wp { border-color: #22d3ee; color: #22d3ee; box-shadow: 0 0 20px rgba(34,211,238,0.4); top: 70%; left: 72%; }
    .node-wp.boost { border-color: #dc3545; color: #dc3545; box-shadow: 0 0 25px rgba(220,53,69,0.8); }
    .node-center { background: transparent; border: none; box-shadow: none; width: 90px; height: 90px; top: 50%; left: 50%; padding: 0; }
    .node-center img { width: 100%; height: 100%; border-radius: 50%; box-shadow: 0 0 30px #0d6efd; }

    /* Light Mode Flow Overrides */
    [data-bs-theme="light"] .flow-container { background-color: #ffffff; color: #212529; }
    [data-bs-theme="light"] .flow-node { background-color: #f8f9fa; }
    [data-bs-theme="light"] .flow-node .label { color: #6c757d; }
    [data-bs-theme="light"] .flow-node .price-tag { background-color: #f8f9fa; border-color: #dee2e6; }
    [data-bs-theme="light"] .flow-node-back { background-color: #f8f9fa; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary border-bottom border-secondary mb-3 py-2">
        <div class="container-fluid px-4">
            <a class="navbar-brand fw-bold" href="index.php"><i class="fas fa-solar-panel text-warning me-2"></i>E3DC Control</a>
            <?php if ($seite !== 'dashboard'): ?>
            <div class="d-none d-lg-flex gap-3 mx-auto align-items-center bg-body-secondary px-3 py-1 rounded-pill border border-secondary-subtle shadow-sm small" id="header-live-values">
                <div title="PV Leistung"><i class="fas fa-sun text-warning"></i> <span id="head-pv" class="fw-bold">--</span></div>
                <div title="Batterie"><i class="fas fa-battery-half text-muted" id="head-icon-bat"></i> <span id="head-bat" class="fw-bold">--</span> <span id="head-soc" class="text-muted" style="font-size:0.85em">--%</span></div>
                <div title="Hausverbrauch"><i class="fas fa-home text-info"></i> <span id="head-home" class="fw-bold">--</span></div>
                <div title="Netz"><i class="fas fa-network-wired text-secondary" id="head-icon-grid"></i> <span id="head-grid" class="fw-bold">--</span></div>
                <div title="Wallbox"><i class="fas fa-charging-station text-secondary" id="head-icon-wb"></i> <span id="head-wb" class="fw-bold">--</span></div>
                <div title="Strompreis"><i class="fas fa-tag text-secondary" id="head-icon-price"></i> <span id="head-price" class="fw-bold">--</span></div>
                <?php if($luxtronikEnabled): ?>
                <div title="Wärmepumpe"><i class="fas fa-water text-info" id="head-icon-wp"></i> <span id="head-wp" class="fw-bold">--</span></div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <div class="d-flex align-items-center gap-3">
                <div class="text-end d-none d-md-block">
                    <div id="clock" class="fw-bold text-light" style="font-size: 1.1rem;">--:--</div>
                    <div class="small text-muted" id="date">--.--.----</div>
                </div>
                <button class="btn btn-link text-secondary p-0" onclick="toggleDarkMode()" title="Dark Mode umschalten">
                    <i class="fas fa-<?= $darkMode ? 'moon' : 'sun' ?>" id="darkmode-icon"></i>
                </button>
                <a href="index.php?seite=wallbox" class="text-secondary" title="Wallbox">
                    <i class="fas fa-charging-station fa-lg"></i>
                </a>
                <?php if($luxtronikEnabled): ?>
                <a href="index.php?seite=luxtronik" class="text-secondary" title="Wärmepumpe">
                    <i class="fas fa-water fa-lg"></i>
                </a>
                <?php else: ?>
                <a href="index.php?seite=charging" class="text-secondary" title="Smart Charging">
                    <i class="fas fa-magic fa-lg"></i>
                </a>
                <?php endif; ?>
                <a href="index.php?seite=config" class="text-secondary position-relative" title="Konfiguration">
                    <i class="fas fa-cog fa-lg"></i>
                    <span id="update-badge-nav" class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle" style="display:<?= getUpdateStatusFromCache() > 0 ? 'inline-block' : 'none' ?>;">
                        <span class="visually-hidden">Update</span>
                    </span>
                </a>
                <span id="cpu-badge" class="badge bg-dark text-secondary border border-secondary" style="font-family:monospace; display:none; font-size: 0.75rem;" title="CPU Load (1min) / Temperatur">CPU: --</span>
                <span id="watchdog-badge" class="badge rounded-pill bg-secondary" style="display:none; cursor:pointer;" onclick="showWatchdogLog()" title="Watchdog Status">
                    <i class="fas fa-shield-alt"></i>
                </span>
                <?= renderConnectionBadge() ?>
            </div>
        </div>
    </nav>

    <div class="container-fluid px-4 pb-5">
        <?php if ($seite === 'dashboard'): ?>
        <div class="dashboard-view">
        <!-- Status Cards -->
        <div class="row g-2 mb-3">
            <!-- PV -->
            <div class="col-md-6 col-xl-3">
                <div class="card h-100" onclick="switchChartMode('live', 'pv')">
                    <div class="card-body d-flex align-items-center">
                        <div class="icon-box bg-warning bg-opacity-10 text-warning me-3" id="icon-pv-box">
                            <i class="fas fa-sun" id="icon-pv"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <h6 class="card-subtitle text-muted text-uppercase small fw-bold m-0">PV Leistung</h6>
                                <div class="d-flex align-items-center gap-2">
                                    <span id="pv-yield-today" class="badge bg-light text-dark border" style="display:none; font-size: 0.7rem;"></span>
                                    <i class="fas fa-eye<?= $showForecast ? '' : '-slash' ?> text-muted" style="cursor:pointer; font-size:0.8rem;" onclick="event.stopPropagation(); toggleForecast(this)" title="Prognose an/aus"></i>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="val-large text-warning" id="val-pv">--<span class="val-unit">W</span></div>
                                <div class="text-end text-muted" id="val-pv-details" style="display:none;">
                                    <div class="mb-1">Prog: <span id="val-pv-forecast" class="fw-bold" style="font-size: 1.1rem;">--</span></div>
                                    <div class="small">Soll: <span id="val-pv-soll" class="fw-bold">--</span></div>
                                </div>
                            </div>
                            <!-- Hidden Details -->
                            <div class="small text-muted mt-1" id="pv-strings-detail" style="display:none;"></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Battery -->
            <div class="col-md-6 col-xl-3">
                <div class="card h-100" onclick="switchChartMode('live', 'bat')">
                    <div class="card-body d-flex align-items-center">
                        <div class="icon-box bg-success bg-opacity-10 text-success me-3" id="icon-bat">
                            <i class="fas fa-battery-half"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="d-flex justify-content-between align-items-baseline mb-1">
                                <h6 class="card-subtitle text-muted text-uppercase small fw-bold m-0">Batterie <span id="val-soc" class="ms-1">--%</span></h6>
                                <span id="val-bat-time" class="text-muted" style="font-size: 1.1rem;"></span>
                            </div>
                            <div class="val-large text-success" id="val-bat-container">--<span class="val-unit">W</span></div>
                            <div class="small text-muted mt-1" id="bat-details" style="display:none;"></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Home -->
            <div class="col-md-6 col-xl-3">
                <div class="card h-100" onclick="toggleStatsView('desktop')" style="cursor: pointer;" title="Tagesstatistiken öffnen">
                    <div class="card-body d-flex align-items-center">
                        <div class="icon-box bg-info bg-opacity-10 text-info me-3">
                            <i class="fas fa-home"></i>
                        </div>
                        <div class="flex-grow-1">
                            <h6 class="card-subtitle text-muted mb-1 text-uppercase small fw-bold">Hausverbrauch</h6>
                            <div class="d-flex justify-content-between align-items-end">
                                <div class="val-large text-info" id="val-home">--<span class="val-unit">W</span></div>
                                <div class="text-end text-muted" style="line-height: 1.2;">
                                    <div title="Autarkie (Live / Heute)"><i class="fas fa-leaf text-success me-1"></i><span id="val-autarky-live" class="fw-bold text-body" style="font-size: 1.1rem;">--%</span> <span class="small">| <span id="val-autarky-day">--%</span></span></div>
                                    <div class="mt-1" title="Eigenverbrauch (Heute)"><i class="fas fa-recycle text-warning me-1"></i><span id="val-selfcon-day" class="fw-bold text-body" style="font-size: 1.1rem;">--%</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Grid -->
            <div class="col-md-6 col-xl-3">
                <div class="card h-100" onclick="switchChartMode('live', 'grid')">
                    <div class="card-body d-flex align-items-center">
                        <div class="icon-box bg-secondary bg-opacity-10 text-secondary me-3" id="icon-grid">
                            <i class="fas fa-network-wired"></i>
                        </div>
                        <div class="flex-grow-1">
                            <h6 class="card-subtitle text-muted mb-1 text-uppercase small fw-bold">Netz</h6>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="val-large text-body" id="val-grid-container">--<span class="val-unit">W</span></div>
                                <div class="text-end text-muted small" id="grid-details" style="display:none; line-height: 1.2;"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="row g-2">
            <!-- Left Column: Chart -->
            <div class="col-xl-9 col-lg-8">
                <div class="card h-100">
                    <div class="card-header bg-transparent border-secondary d-flex justify-content-between align-items-center py-3">
                        <div class="d-flex align-items-center gap-3">
                            <h6 class="mb-0 fw-bold text-nowrap" id="chart-title"><i class="fas fa-chart-line me-2 text-secondary"></i>SoC Prognose</h6>
                        </div>
                        <div class="d-flex gap-2 align-items-center">
                            <!-- Ansicht Auswahl -->
                            <select class="form-select form-select-sm border-secondary d-none" id="chart-mode-select" style="width: auto; min-width: 120px;" onchange="switchChartMode(this.value)">
                                <option value="forecast" selected>Prognose</option>
                                <option value="live">Live-Verlauf</option>
                                <option value="archive">Archiv</option>
                            </select>

                            <!-- Live Controls -->
                            <div class="gap-2" id="live-controls" style="display:none;">
                                <div class="btn-group btn-group-sm btn-group-custom" role="group">
                                    <button type="button" class="btn btn-outline-secondary active" onclick="updateChart(6, this)">6h</button>
                                    <button type="button" class="btn btn-outline-secondary" onclick="updateChart(12, this)">12h</button>
                                    <button type="button" class="btn btn-outline-secondary" onclick="updateChart(24, this)">24h</button>
                                    <button type="button" class="btn btn-outline-secondary" onclick="updateChart(48, this)">48h</button>
                                </div>
                                <select class="form-select form-select-sm border-secondary" id="history-select-normal" style="max-width: 130px;" onchange="updateChartHistory(this.value)">
                                    <option value="" selected>Live</option>
                                    <?php foreach ($historyFiles as $hf): ?>
                                        <option value="<?= htmlspecialchars($hf['file']) ?>"><?= htmlspecialchars($hf['label']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <select class="form-select form-select-sm border-secondary" id="history-select-wp" style="max-width: 130px; display:none;" onchange="updateChartHistory(this.value)">
                                    <option value="" selected>Live</option>
                                    <?php foreach ($luxtronikFiles as $lf): ?>
                                        <option value="<?= htmlspecialchars($lf['file']) ?>"><?= htmlspecialchars($lf['label']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Archiv Controls -->
                            <select class="form-select form-select-sm border-secondary" id="archive-select" style="display:none; max-width: 200px;" onchange="loadArchive(this.value)">
                                <option value="" disabled selected>Datei wählen...</option>
                                <?php foreach ($archivFiles as $af): ?>
                                    <option value="<?= htmlspecialchars($af['file']) ?>"><?= htmlspecialchars($af['label']) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button class="btn btn-sm btn-outline-secondary" onclick="refreshData()" id="main-refresh-btn" title="Aktualisieren">
                                <i class="fas fa-sync-alt"></i>
                            </button>
                        </div>
                    </div>
                    <div id="diagramDetails" class="px-3 pb-2 text-info small fw-bold" style="display:none;"></div>
                    <div class="card-body p-0 chart-container position-relative">
                        <iframe id="chart-frame" src="diagramm.html?t=<?= time() ?>" scrolling="no"></iframe>
                        
                        <!-- Live Energiefluss (Desktop Layout) -->
                        <?= renderEnergyFlow('desktop', '', 'style="display: none;"') ?>
                        
                        <!-- Statistics View Overlay -->
                        <div id="stats-view" class="w-100 h-100 position-absolute top-0 start-0 p-4" style="display: none; background-color: var(--bs-card-bg); overflow-y: auto; z-index: 20;">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="fw-bold m-0"><i class="fas fa-chart-pie text-secondary me-2"></i>Tagesstatistik</h5>
                                <div class="d-flex gap-2">
                                    <select class="form-select form-select-sm border-secondary" id="stats-history-select" onchange="loadStatsForDate(this.value, 'desktop')">
                                        <option value="today">Heute (Live)</option>
                                        <?php foreach ($historyFiles as $hf): ?>
                                            <option value="<?= htmlspecialchars($hf['file']) ?>"><?= htmlspecialchars($hf['label']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button class="btn btn-sm btn-outline-secondary" onclick="toggleStatsView('desktop')"><i class="fas fa-times"></i></button>
                                </div>
                            </div>
                            <div class="d-flex justify-content-around mb-3 pb-3 border-bottom border-secondary">
                                <div class="text-center">
                                    <div class="small text-muted">Autarkie</div>
                                    <div class="fw-bold text-success fs-5" id="stat-overlay-autarky">--%</div>
                                </div>
                                <div class="text-center">
                                    <div class="small text-muted">Eigenverbrauch</div>
                                    <div class="fw-bold text-warning fs-5" id="stat-overlay-selfcon">--%</div>
                                </div>
                            </div>
                            <div class="row g-4">
                                <div class="col-md-4">
                                    <div class="card bg-body-tertiary border-0 h-100">
                                        <div class="card-body">
                                            <h6 class="fw-bold text-warning border-bottom border-warning pb-2 mb-3 d-flex justify-content-between align-items-center">
                                                <span><i class="fas fa-sun me-2"></i>Sonne (PV)</span>
                                                <span id="stat-pv-total" class="badge bg-warning text-dark fs-6">-- kWh</span>
                                            </h6>
                                            <div class="d-flex justify-content-between small mb-2"><span>In Haus:</span> <span id="stat-pv-home" class="fw-bold">-- kWh (--%)</span></div>
                                            <div class="d-flex justify-content-between small mb-2"><span>In Batterie:</span> <span id="stat-pv-bat" class="fw-bold">-- kWh (--%)</span></div>
                                            <div class="d-flex justify-content-between small mb-2"><span>In Wallbox:</span> <span id="stat-pv-wb" class="fw-bold">-- kWh (--%)</span></div>
                                            <div class="d-flex justify-content-between small mb-2"><span>In Wärmepumpe:</span> <span id="stat-pv-wp" class="fw-bold">-- kWh (--%)</span></div>
                                            <div class="d-flex justify-content-between small mb-2"><span>Ins Netz:</span> <span id="stat-pv-grid" class="fw-bold">-- kWh (--%)</span></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card bg-body-tertiary border-0 h-100">
                                        <div class="card-body">
                                            <h6 class="fw-bold text-success border-bottom border-success pb-2 mb-3 d-flex justify-content-between align-items-center">
                                                <span><i class="fas fa-battery-full me-2"></i>Batterie (Out)</span>
                                                <span id="stat-bat-total" class="badge bg-success text-white fs-6">-- kWh</span>
                                            </h6>
                                            <div class="d-flex justify-content-between small mb-2"><span>In Haus:</span> <span id="stat-bat-home" class="fw-bold">-- kWh (--%)</span></div>
                                            <div class="d-flex justify-content-between small mb-2"><span>In Wallbox:</span> <span id="stat-bat-wb" class="fw-bold">-- kWh (--%)</span></div>
                                            <div class="d-flex justify-content-between small mb-2"><span>In Wärmepumpe:</span> <span id="stat-bat-wp" class="fw-bold">-- kWh (--%)</span></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card bg-body-tertiary border-0 h-100">
                                        <div class="card-body">
                                            <h6 class="fw-bold text-danger border-bottom border-danger pb-2 mb-3 d-flex justify-content-between align-items-center">
                                                <span><i class="fas fa-network-wired me-2"></i>Netzbezug</span>
                                                <span id="stat-grid-total" class="badge bg-danger fs-6">-- kWh</span>
                                            </h6>
                                            <div class="d-flex justify-content-between small mb-2"><span>In Haus:</span> <span id="stat-grid-home" class="fw-bold">-- kWh (--%)</span></div>
                                            <div class="d-flex justify-content-between small mb-2"><span>In Batterie:</span> <span id="stat-grid-bat" class="fw-bold">-- kWh (--%)</span></div>
                                            <div class="d-flex justify-content-between small mb-2"><span>In Wallbox:</span> <span id="stat-grid-wb" class="fw-bold">-- kWh (--%)</span></div>
                                            <div class="d-flex justify-content-between small mb-2"><span>In Wärmepumpe:</span> <span id="stat-grid-wp" class="fw-bold">-- kWh (--%)</span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column: Details & Controls -->
            <div class="col-xl-3 col-lg-4">
                <div class="row g-2" id="right-column-cards">
                    <!-- Price Card -->
                    <div class="col-12" id="card-price-container">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h6 class="card-title text-muted text-uppercase small fw-bold"><i class="fas fa-tags me-2"></i>Strompreis</h6>
                                    <span class="badge bg-body-tertiary border border-secondary text-body-secondary" id="price-trend"><i class="fas fa-minus"></i></span>
                                </div>
                                <div class="d-flex align-items-baseline mb-3">
                                    <div class="val-large text-body" id="val-price">--<span class="val-unit">ct/kWh</span></div>
                                </div>
                                <div class="progress bg-secondary-subtle" style="height: 6px;">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: 50%" id="price-bar"></div>
                                </div>
                                <div class="d-flex justify-content-between mt-2 small text-muted">
                                    <span>Min: <span id="val-price-min" class="text-success fw-bold">--</span></span>
                                    <span>Max: <span id="val-price-max" class="text-danger fw-bold">--</span></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Wallbox Card -->
                    <div class="col-12">
                        <div class="card" onclick="switchChartMode('live', 'wb')">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h6 class="card-title text-muted text-uppercase small fw-bold mb-0"><i class="fas fa-charging-station me-2"></i>Wallbox</h6>
                                    <div class="d-flex align-items-center gap-2">
                                        <span id="wb-session" class="badge bg-light text-dark border" style="display:none; font-size: 0.7rem;"></span>
                                        <?php if(!$luxtronikEnabled): ?>
                                            <a href="index.php?seite=charging" class="text-secondary" title="Smart Charging" onclick="event.stopPropagation();"><i class="fas fa-magic"></i></a>
                                        <?php endif; ?>
                                        <a href="index.php?seite=wallbox" class="text-secondary" title="Steuern" onclick="event.stopPropagation();"><i class="fas fa-sliders-h"></i></a>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center">
                                    <div class="icon-box bg-secondary bg-opacity-10 text-secondary me-3 position-relative" id="icon-wb" style="width: 48px; height: 48px; font-size: 1.25rem;">
                                        <i class="fas fa-car"></i>
                                        <i class="fas fa-lock position-absolute text-warning" id="wb-lock-overlay" style="font-size: 0.6rem; bottom: 6px; right: 6px; display: none;"></i>
                                    </div>
                                    <div>
                                        <div class="fs-4 fw-bold" id="val-wb">0<span class="fs-6 text-muted ms-1">W</span></div>
                                        <div class="small text-muted" id="wb-status">Bereit</div>
                                        <div class="small text-muted mt-1" id="wb-details" style="display:none;"></div>
                                        <div class="small text-info fw-bold mt-1" id="wb-session" style="display:none;"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Heatpump Card -->
                    <div class="col-12">
                        <div class="card" <?php if($luxtronikEnabled): ?>onclick="switchChartMode('live', 'wp')" style="cursor:pointer;"<?php endif; ?>>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h6 class="card-title text-muted text-uppercase small fw-bold mb-0"><i class="fas fa-water me-2"></i>Wärmepumpe</h6>
                                    <div class="d-flex align-items-center gap-2">
                                        <?php if(file_exists('/var/www/html/ramdisk/manual_boost.flag')): ?>
                                            <span class="badge bg-warning text-dark pulsating" title="Batterie leeren aktiv"><i class="fas fa-bolt"></i> Boost</span>
                                        <?php endif; ?>
                                        <span id="wp-morning-boost" class="badge bg-warning text-dark pulsating" style="display:none;" title="Morning Boost aktiv"></span>
                                        <span id="wp-status-badge" class="badge" style="display:none;<?= $luxtronikEnabled ? ' cursor:pointer;' : '' ?>" <?= $luxtronikEnabled ? 'onclick="event.stopPropagation(); window.location.href=\'index.php?seite=luxtronik\'"' : '' ?>></span>
                                        <span id="wp-auto-boost" class="badge bg-info text-dark pulsating" style="display:none;<?= $luxtronikEnabled ? ' cursor:pointer;' : '' ?>" title="Energie-Manager regelt aktiv" <?= $luxtronikEnabled ? 'onclick="event.stopPropagation(); window.location.href=\'index.php?seite=luxtronik\'"' : '' ?>><i class="fas fa-magic"></i> Auto</span>
                                        <?php if($luxtronikEnabled): ?>
                                        <a href="index.php?seite=luxtronik" class="text-secondary" title="Steuern" onclick="event.stopPropagation();"><i class="fas fa-sliders-h"></i></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center">
                                    <div class="icon-box bg-info bg-opacity-10 text-info me-3" id="icon-wp" style="width: 48px; height: 48px; font-size: 1.25rem;">
                                        <i class="fas fa-fan"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <div class="fs-4 fw-bold" id="val-wp">0<span class="fs-6 text-muted ms-1">W</span></div>
                                                <div class="small text-muted">Leistung</div>
                                            </div>
                                            <div class="text-end small text-muted" id="wp-temps" style="display:none; line-height: 1.3;">
                                                <div>WW: <span id="val-wp-ww" class="fw-bold text-body">--</span>°C</div>
                                                <div id="wp-rl-container"><span id="wp-rl-label">RL:</span> <span id="val-wp-rl" class="fw-bold text-body">--</span>°C</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h6 class="card-title text-muted text-uppercase small fw-bold mb-3">Schnellzugriff</h6>
                                <div class="row g-2">
                                    <div class="col-12">
                                        <button class="btn btn-outline-info w-100 text-start" onclick="switchChartMode('flow')">
                                            <i class="fas fa-project-diagram me-2"></i>Live Energiefluss
                                        </button>
                                    </div>
                                    <div class="col-6">
                                        <button class="btn btn-outline-secondary w-100 text-start text-truncate" onclick="switchChartMode('forecast')">
                                            <i class="fas fa-chart-line me-2"></i>Prognose
                                        </button>
                                    </div>
                                    <div class="col-6">
                                        <button class="btn btn-outline-secondary w-100 text-start text-truncate" onclick="switchChartMode('live')">
                                            <i class="fas fa-chart-area me-2"></i>Verlauf
                                        </button>
                                    </div>
                                    <div class="col-6">
                                        <button class="btn btn-outline-secondary w-100 text-start text-truncate" onclick="switchChartMode('archive')">
                                            <i class="fas fa-history me-2"></i>Archiv
                                        </button>
                                    </div>
                                    <div class="col-6">
                                        <button class="btn btn-outline-warning w-100 text-start position-relative text-truncate" onclick="startSystemUpdate()">
                                            <i class="fas fa-cloud-download-alt me-2"></i>Update
                                            <span id="update-badge-btn" class="badge bg-danger position-absolute top-0 start-100 translate-middle rounded-pill" style="display:<?= getUpdateStatusFromCache() > 0 ? 'inline-block' : 'none' ?>; font-size: 0.65rem;">!</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <script>
                    // Verschiebe Preis-Karte nach der Wärmepumpe-Karte
                    document.addEventListener('DOMContentLoaded', function() {
                        const parent = document.getElementById('right-column-cards');
                        if (parent) {
                            const priceCard = parent.querySelector('.col-12:nth-child(1)');
                            const heatpumpCard = parent.querySelector('.col-12:nth-child(3)');
                            if (priceCard && heatpumpCard) {
                                // Füge die Preiskarte nach der Wärmepumpenkarte ein
                                heatpumpCard.after(priceCard);
                            }
                        }
                    });
                </script>
            </div>
        </div>
        </div>
        <?php elseif ($seite === 'wallbox'): ?>
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10 col-xl-8">
                    <div class="mb-3">
                        <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left me-2"></i>Zurück zum Dashboard</a>
                    </div>
                    <?php include 'Wallbox.php'; ?>
                </div>
            </div>
        <?php elseif ($seite === 'luxtronik' && $luxtronikEnabled): ?>
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10 col-xl-8">
                    <div class="mb-3">
                        <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left me-2"></i>Zurück zum Dashboard</a>
                    </div>
                    <?php include 'luxtronik.php'; ?>
                </div>
            </div>
        <?php elseif ($seite === 'charging'): ?>
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10 col-xl-8">
                    <div class="mb-3">
                        <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left me-2"></i>Zurück zum Dashboard</a>
                    </div>
                    <?php include 'luxtronik.php'; ?>
                </div>
            </div>
        <?php elseif ($seite === 'archiv'): ?>
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10 col-xl-8">
                    <div class="mb-3">
                        <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left me-2"></i>Zurück zum Dashboard</a>
                    </div>
                    <?php include 'archiv.php'; ?>
                </div>
            </div>
        <?php elseif ($seite === 'config'): ?>
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10 col-xl-8">
                    <div class="mb-3 d-flex justify-content-between align-items-center">
                        <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left me-2"></i>Zurück</a>
                        <div>
                            <!-- Installer / Diagramm Update -->
                            <button id="btn-update-installer" class="btn btn-outline-info btn-sm me-2" onclick="startInstallerUpdate()">
                                <i class="fas fa-magic me-2"></i>Diagramm Update <span id="update-badge-installer" class="badge bg-danger ms-1" style="display:none;">!</span>
                            </button>
                            <button id="btn-update-config" class="btn btn-outline-warning btn-sm me-2" onclick="startSystemUpdate()">
                                <i class="fas fa-cloud-download-alt me-2"></i>Update <span id="update-badge-config" class="badge bg-danger ms-1" style="display:<?= getUpdateStatusFromCache() > 0 ? 'inline-block' : 'none' ?>;"><?= getUpdateStatusFromCache() ?></span>
                            </button>
                            <button class="btn btn-outline-danger btn-sm" onclick="restartService()"><i class="fas fa-power-off me-2"></i>E3DC-Control Neustart</button>
                        </div>
                    </div>
                    
                    <?php
                        // Die Variable $luxtronikEnabled wird in logic.php aus der e3dc.config.txt geladen.
                        // Wir prüfen, ob der energy_manager service existiert, um die Karte anzuzeigen.
                        $energyManagerServiceExists = file_exists('/etc/systemd/system/energy_manager.service');
                    ?>
                    <?php if ($energyManagerServiceExists): ?>
                        <div class="card mb-4 shadow-sm">
                            <div class="card-body d-flex align-items-center justify-content-between py-3">
                                <div>
                                    <h6 class="mb-0 fw-bold text-info"><i class="fas fa-robot me-2"></i>Energy Manager</h6>
                                    <div class="small text-muted">Aktiviert den Dienst für WP-Steuerung & intelligentes Laden.</div>
                                </div>
                                <form method="post">
                                    <input type="hidden" name="save_lux_global" value="1">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" name="lux_active" value="1" <?= $luxtronikEnabled ? 'checked' : '' ?> onchange="this.form.submit()" style="transform: scale(1.3);">
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php include 'config_editor.php'; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Footer -->
        <footer class="text-center text-muted mt-5 pt-3 border-top border-secondary">
            <small>
                E3DC Control &copy; <?= date('Y') ?> | 
                <a href="#" class="text-decoration-none text-secondary" data-bs-toggle="modal" data-bs-target="#changelogModal">Changelog</a>
                <?php
                // A9xxx Version (Web Interface)
                if (file_exists('VERSION')) {
                    $ver = trim(file_get_contents('VERSION'));
                    echo ' | <a href="https://github.com/A9xxx/Install-E3DC-Control" target="_blank" class="text-decoration-none text-secondary">A9xxx v' . htmlspecialchars($ver) . '</a>';
                }

                // Eba-M Version (Core) - Commit Hash & Datum
                $paths = getInstallPaths();
                $iUser = $paths['install_user'] ?? 'pi';
                $iPath = $paths['install_path'] ?? '/home/pi/E3DC-Control/';
                $gitCmd = "sudo -u " . escapeshellarg($iUser) . " git -C " . escapeshellarg($iPath) . " show -s --format='%h|%cd' --date=format:'%d.%m. %H:%M' 2>/dev/null";
                $gitOutput = shell_exec($gitCmd);
                if ($gitOutput && strpos($gitOutput, '|') !== false) {
                    list($hash, $date) = explode('|', trim($gitOutput));
                    echo ' | <a href="https://github.com/Eba-M/E3DC-Control" target="_blank" class="text-decoration-none text-secondary" title="Commit vom ' . htmlspecialchars($date) . '">Eba-M ' . htmlspecialchars($hash) . ' (' . htmlspecialchars($date) . ')</a>';
                }
                ?>
            </small>
        </footer>
    </div>

    <!-- Modals -->
    <?= renderChangelogModal('modal-lg modal-dialog-scrollable') ?>
    <?= renderUpdateModal('modal-lg modal-dialog-scrollable') ?>
    <?= renderWatchdogModal('modal-lg modal-dialog-scrollable') ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="solar.js?v=<?= file_exists('solar.js') ? filemtime('solar.js') : time() ?>"></script>
    <script>
        function updateTime() {
            const now = new Date();
            document.getElementById('clock').innerText = now.toLocaleTimeString('de-DE', {hour: '2-digit', minute:'2-digit'});
            document.getElementById('date').innerText = now.toLocaleDateString('de-DE');
        }
        setInterval(updateTime, 1000);
        updateTime();

        // Konstanten aus logic.php für JS verfügbar machen
        let FORECAST_DATA = <?= json_encode($forecastData) ?>;
        const PV_STRINGS = <?= json_encode($pvStrings) ?>;
        const LAT = <?= json_encode($lat) ?>;
        const LON = <?= json_encode($lon) ?>;
        const BAT_CAPACITY = <?= json_encode($batteryCapacity) ?>;
        const PV_ATMOSPHERE = <?= json_encode($pvAtmosphere) ?>;
        let SHOW_FORECAST = <?= $showForecast ? 'true' : 'false' ?>;
        let DARK_MODE = <?= $darkMode ? 'true' : 'false' ?>;
        let CURRENT_VIEW = 'normal';
        let flowAnimationCache = {};

        function formatWatts(w) {
            w = parseFloat(w);
            if (isNaN(w)) return '--';
            if (Math.abs(w) > 4000) {
                return (w / 1000).toLocaleString('de-DE', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + '<span class="val-unit">kW</span>';
            }
            return Math.round(w).toLocaleString('de-DE') + '<span class="val-unit">W</span>';
        }

        // toggleForecast und toggleDarkMode entfernt -> jetzt in solar.js

        function fetchData() {
            $.getJSON('get_live_json.php', function(data) {
                if (!data) return;
                
                // Prognose-Daten aktualisieren, falls vorhanden
                if (data.forecast && data.forecast.length > 0) {
                    FORECAST_DATA = data.forecast;
                }

                const now = Math.floor(Date.now() / 1000);
                const dataTs = data.ts || 0;
                const age = now - dataTs;
                const statusBadge = $('#connection-status');

                if (age > 300) { // 5 Minuten
                    statusBadge.removeClass('bg-secondary bg-success bg-danger').addClass('bg-warning text-dark').text('Veraltet (' + Math.floor(age/60) + 'm)');
                } else {
                    statusBadge.removeClass('bg-secondary bg-danger bg-warning text-dark').addClass('bg-success text-white').text('Online');
                }

                // CPU Load & Temp
                if (data.cpu_load !== undefined) {
                    const cpuVal = parseFloat(data.cpu_load);
                    let tempText = '--°C';
                    let tempVal = null;
                    if (data.cpu_temp !== undefined && data.cpu_temp !== null) {
                        tempVal = parseFloat(data.cpu_temp);
                        tempText = tempVal.toFixed(1) + '°C';
                    }
                    $('#cpu-badge').html('CPU: ' + cpuVal.toFixed(2) + ' | ' + tempText).show();
                    $('#cpu-badge').attr('title', 'CPU Load (1min) / Temperatur');
                    $('#cpu-badge').removeClass('text-secondary text-warning text-danger');
                    if (cpuVal > 2.0 || (tempVal && tempVal > 70)) {
                        $('#cpu-badge').addClass('text-danger');
                    } else if (cpuVal > 1.0 || (tempVal && tempVal > 60)) {
                        $('#cpu-badge').addClass('text-warning');
                    } else {
                        $('#cpu-badge').addClass('text-secondary');
                    }
                }

                // Berechnungen (Global für Callback)
                let homeVal = (data.home_raw || 0);
                if (data.wp > 0) homeVal -= data.wp;
                if (homeVal < 0) homeVal = 0;

                const wbVal = parseFloat(data.wb) || 0;
                const batVal = Math.round(data.bat);
                const batAbs = Math.abs(batVal);
                const gridVal = Math.round(data.grid);
                const gridAbs = Math.abs(gridVal);
                const wpVal = parseFloat(data.wp) || 0;
                
                // Live Autarkie
                let autarkieLive = calculateLiveAutarky(homeVal, wbVal, wpVal, gridVal);
                if (document.getElementById('val-autarky-live')) $('#val-autarky-live').text(autarkieLive.toFixed(0) + '%');

                // Header Values Update (für Unterseiten)
                if (document.getElementById('head-pv')) {
                    const fmtHead = (v) => formatWatts(v).replace(/<[^>]*>?/gm, '');
                    $('#head-pv').text(fmtHead(data.pv));
                    $('#head-bat').text(fmtHead(batAbs));
                    $('#head-soc').text(Math.round(data.soc) + '%');
                    $('#head-home').text(fmtHead(homeVal));
                    $('#head-grid').text(fmtHead(gridAbs));
                    $('#head-wb').text(fmtHead(wbVal));
                    if(document.getElementById('head-wp')) $('#head-wp').text(fmtHead(wpVal));

                    // Icons/Farben im Header
                    const hGridIcon = $('#head-icon-grid');
                    hGridIcon.removeClass('text-secondary text-success text-danger');
                    if (gridVal > 0) hGridIcon.addClass('text-danger');
                    else if (gridVal < 0) hGridIcon.addClass('text-success');
                    else hGridIcon.addClass('text-secondary');

                    const hBatIcon = $('#head-icon-bat');
                    hBatIcon.removeClass('text-success text-danger text-muted');
                    if (batVal > 0) hBatIcon.addClass('text-success');
                    else if (batVal < 0) hBatIcon.addClass('text-danger');
                    else hBatIcon.addClass('text-muted');

                    const hWbIcon = $('#head-icon-wb');
                    if (wbVal > 0) hWbIcon.removeClass('text-secondary').addClass('text-info pulsating');
                    else hWbIcon.removeClass('text-info pulsating').addClass('text-secondary');

                    // Price in Header
                    if (data.price_ct !== undefined && data.price_ct !== null) {
                        $('#head-price').text(data.price_ct.toLocaleString('de-DE', {minimumFractionDigits: 1, maximumFractionDigits: 1}) + ' ct');
                        const hPriceIcon = $('#head-icon-price');
                        hPriceIcon.removeClass('text-secondary text-success text-danger text-warning');
                        if (data.price_level === 'cheap') hPriceIcon.addClass('text-success');
                        else if (data.price_level === 'expensive') hPriceIcon.addClass('text-danger');
                        else hPriceIcon.addClass('text-warning');
                    }
                }

                if (document.getElementById('val-pv')) {

                // Basic Values
                $('#val-pv').html(formatWatts(data.pv));
                $('#val-home').html(formatWatts(homeVal));
                $('#val-soc').text(Math.round(data.soc) + '%');

                // Tagesertrag PV
                const yieldEl = $('#pv-yield-today');
                if (data.pv_today_kwh != null && data.pv_today_kwh > 0) {
                    yieldEl.html('<i class="fas fa-sun me-1"></i>' + data.pv_today_kwh.toLocaleString('de-DE', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + ' kWh').show();
                } else {
                    yieldEl.hide();
                }
            
            // Tages-Statistiken
            if (data.autarky_day !== undefined) $('#val-autarky-day').text(Math.round(data.autarky_day) + '%');
            if (data.selfcon_day !== undefined) $('#val-selfcon-day').text(Math.round(data.selfcon_day) + '%');

            if (currentStatsDate === 'today' && data.stats) {
                updateStatsUI(data, 'desktop');
            }

                // --- Details (Strings, Phasen) ---
                if (data.dc0_w !== undefined) {
                    $('#pv-strings-detail').html(`String 1: ${data.dc0_w}W | String 2: ${data.dc1_w}W`).show();
                }
                if (data.ac0_w !== undefined || data.grid_p1 !== undefined) {
                    let details = '';
                    if (data.grid_p1 !== undefined) {
                        details += `<div style="white-space:nowrap; font-size:0.9rem; font-weight:bold; margin-bottom:3px;">${Math.round(data.grid_p1)} | ${Math.round(data.grid_p2)} | ${Math.round(data.grid_p3)} W</div>`;
                    }
                    if (data.ac0_w !== undefined) {
                        details += `<div style="white-space:nowrap; font-size:0.8rem; opacity:0.8;">WR: ${data.ac0_w} | ${data.ac1_w} | ${data.ac2_w} W</div>`;
                    }
                    $('#grid-details').html(details).show();
                } else {
                    $('#grid-details').hide();
                }
                if (data.wb_p1 !== undefined && data.wb > 0) {
                    $('#wb-details').html(`L1: ${data.wb_p1}W | L2: ${data.wb_p2}W | L3: ${data.wb_p3}W`).show();
                } else { $('#wb-details').hide(); }

                // --- Tag/Nacht Icon Logik ---
                const isDay = (typeof isDaytime === 'function') ? isDaytime() : true;
                const iconPvBox = $('#icon-pv-box');
                const iconPv = $('#icon-pv');
                
                if (isDay) {
                    if (iconPv.hasClass('fa-moon')) {
                        iconPv.removeClass('fa-moon').addClass('fa-sun');
                        iconPvBox.removeClass('bg-secondary text-secondary').addClass('bg-warning text-warning');
                    }
                } else {
                    if (iconPv.hasClass('fa-sun')) {
                        iconPv.removeClass('fa-sun').addClass('fa-moon');
                        iconPvBox.removeClass('bg-warning text-warning').addClass('bg-secondary text-secondary');
                    }
                }

                // --- PV Prognose & Soll Logik ---
                const now = new Date();
                const curGmt = now.getUTCHours() + (now.getUTCMinutes() / 60);
                let bestForecast = null; let minDiff = 100;
                if (Array.isArray(FORECAST_DATA)) {
                    for (let d of FORECAST_DATA) {
                        let diff = Math.abs(d.h - curGmt);
                        if (diff < minDiff) { minDiff = diff; bestForecast = d; }
                    }
                }

                const sollVal = (typeof getTheoreticalPower === 'function') ? getTheoreticalPower() : 0;
                const pvDetails = $('#val-pv-details');
                
                // Nur anzeigen wenn Tag (Soll > 0) oder Prognose relevant
                if (SHOW_FORECAST && (sollVal > 10 || (bestForecast && bestForecast.w > 10))) {
                    let fVal = (bestForecast && minDiff < 0.5) ? bestForecast.w : 0;
                    
                    // Formatierung für kleine Anzeige
                    const fmtSmall = (v) => (v >= 1000) ? (v/1000).toFixed(2) + 'k' : Math.round(v);
                    
                    let ratio = (fVal > 0) ? (data.pv / fVal) : 0;
                    let pctStr = (fVal > 0) ? Math.round(ratio * 100) + '%' : '';
                    
                    let fText = fmtSmall(fVal);
                    if (pctStr) fText += ` <span style="font-size:0.7em; opacity:0.7;">(${pctStr})</span>`;

                    $('#val-pv-forecast').html(fText);
                    $('#val-pv-soll').text(fmtSmall(sollVal));
                    
                    // Farb-Logik für Prognose (wie Mobile)
                    if (fVal > 0 && ratio < 0.75) $('#val-pv-forecast').css('color', '#ef4444');
                    else if (fVal > 0 && ratio > 1.25) $('#val-pv-forecast').css('color', '#10b981');
                    else $('#val-pv-forecast').css('color', 'inherit');

                    pvDetails.show();
                } else {
                    pvDetails.hide();
                }
                
                // Wallbox Logic (NEU)
                const wbLocked = data.wb_locked === true;
                const wbMode = data.wb_mode !== undefined ? data.wb_mode : '-';

                $('#val-wb').html(formatWatts(wbVal));

                const wbIcon = $('#icon-wb');
                const wbLockOverlay = $('#wb-lock-overlay');

                if (wbVal > 0) {
                    // Wenn Leistung > 0: Blau leuchten (wie Wärmepumpe)
                    wbIcon.removeClass('bg-secondary text-secondary bg-warning text-warning').addClass('bg-info text-info pulsating');
                    // Schloss anzeigen wenn geladen wird? Meistens ja.
                    if (wbLocked) wbLockOverlay.show(); else wbLockOverlay.hide();
                } else if (wbLocked) {
                    // Angesteckt & Verriegelt, aber lädt nicht: Gelb
                    wbIcon.removeClass('bg-secondary text-secondary bg-info text-info pulsating').addClass('bg-warning text-warning');
                    wbLockOverlay.show();
                } else {
                    // Wenn 0: Grau/Standard
                    wbIcon.removeClass('bg-info text-info bg-warning text-warning pulsating').addClass('bg-secondary text-secondary');
                    wbLockOverlay.hide();
                }

                // Phasen ermitteln (Annahme: >10W auf einer Phase bedeutet aktiv)
                let activePhases = 0;
                if (data.wb_p1 > 10) activePhases++;
                if (data.wb_p2 > 10) activePhases++;
                if (data.wb_p3 > 10) activePhases++;
                // Fallback: Wenn Gesamtleistung da ist, aber Phasen 0 (Messfehler?), nimm 1 an
                if (wbVal > 0 && activePhases === 0) activePhases = 1;

                // Status-Text Update
                if (wbVal > 0) {
                    $('#wb-status').text(`Lädt (${activePhases}-ph) | Mode ${wbMode}`);
                } else if (wbLocked) {
                    $('#wb-status').text(`Verbunden | Mode ${wbMode}`);
                } else {
                    $('#wb-status').text('Bereit');
                }

                // Wallbox Session Energy
                if (data.wb_session_kwh !== undefined && data.wb_session_kwh !== null && (data.wb_session_kwh > 0 || wbLocked)) {
                    $('#wb-session').html('<i class="fas fa-charging-station me-1"></i>' + data.wb_session_kwh.toLocaleString('de-DE', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + ' kWh').show();
                } else {
                    $('#wb-session').hide();
                }

                // Heatpump Logic
                $('#val-wp').html(formatWatts(wpVal));
                if (wpVal < 100) {
                    $('#icon-wp').removeClass('bg-info text-info').addClass('bg-secondary text-muted');
                } else {
                    $('#icon-wp').removeClass('bg-secondary text-muted').addClass('bg-info text-info');
                }
                
                // WP Status Badge (Betriebsart)
                const wpStatusBadge = $('#wp-status-badge');
                if (data.wp_mode !== undefined && data.wp_mode !== null) {
                    wpStatusBadge.show();
                    wpStatusBadge.removeClass('bg-secondary bg-warning bg-danger bg-primary bg-info text-dark text-white');
                    
                    switch(data.wp_mode) {
                        case 0: // Heizen
                            wpStatusBadge.addClass('bg-warning text-dark').html('<i class="fas fa-fire"></i> Heizen');
                            break;
                        case 1: // WW
                            wpStatusBadge.addClass('bg-danger text-white').html('<i class="fas fa-hot-tub"></i> WW');
                            break;
                        case 3: // EVU
                            wpStatusBadge.addClass('bg-primary text-white').text('EVU');
                            break;
                        case 4: // Abtauen
                            wpStatusBadge.addClass('bg-info text-white').html('<i class="fas fa-snowflake"></i> Abtauen');
                            break;
                        case 5: // Aus
                            wpStatusBadge.addClass('bg-secondary text-white').text('Aus');
                            break;
                        default:
                            wpStatusBadge.hide();
                    }
                } else {
                    wpStatusBadge.hide();
                }

                // Auto-Boost Badge
                if (data.wp_boost_active === true) {
                    const badge = $('#wp-auto-boost');
                    badge.show();
                    if (data.wp_pause_active === true) {
                        badge.html('<i class="fas fa-hourglass-half"></i> Auto ⏸');
                        badge.attr('title', 'Regenerations-Pause aktiv');
                    } else if (data.wp_price_boost === true) {
                        badge.html('<i class="fas fa-magic"></i> Auto €');
                        badge.attr('title', 'Preis-Boost aktiv');
                    } else {
                        badge.html('<i class="fas fa-magic"></i> Auto PV');
                        badge.attr('title', 'PV-Boost aktiv');
                    }
                } else {
                    $('#wp-auto-boost').hide();
                }

                // Morning Boost Badge
                const mbBadge = $('#wp-morning-boost');
                if (data.mb_state === 'RUNNING') {
                    let icon = 'fa-battery-bolt'; // Default
                    let text = 'Morgen-Boost';
                    if (data.mb_prio === 'wallbox') {
                        icon = 'fa-car-battery';
                        text = 'WB Boost';
                    } else if (data.mb_prio === 'heatpump') {
                        icon = 'fa-fan';
                        text = 'WP Boost';
                    }
                    mbBadge.html(`<i class="fas ${icon} me-1"></i> ${text}`).show();
                } else {
                    mbBadge.hide();
                }

                // Temperaturen anzeigen (wenn vorhanden)
                if (data.wp_ww_temp != null) {
                    $('#val-wp-ww').text(data.wp_ww_temp.toFixed(1));
                    $('#wp-temps').show();
                }
                if (data.wp_rl_temp != null) {
                    $('#wp-rl-label').text(data.wp_rl_source === 'external' ? 'RL-Ext:' : 'RL:');
                    $('#val-wp-rl').text(data.wp_rl_temp.toFixed(1));
                    $('#wp-rl-container').show();
                    $('#wp-temps').show();
                } else {
                    $('#wp-temps').hide();
                }

                // Battery Logic
                $('#val-bat-container').html(formatWatts(batAbs));

                // --- Batterie Zeit-Logik ---
                let batTimeText = '';
                if (BAT_CAPACITY > 0 && batAbs > 50) {
                    let hours = 0;
                    let soc = parseFloat(data.soc) || 0;
                    if (batVal > 0 && soc < 100) { // Laden
                        hours = ((100 - soc) / 100 * BAT_CAPACITY * 1000) / batVal;
                        if (hours > 0 && hours < 48) {
                            let h = Math.floor(hours); let m = Math.round((hours - h) * 60);
                            batTimeText = `(voll: ${h}:${m.toString().padStart(2, '0')}h)`;
                        }
                    } else if (batVal < 0 && soc > 0) { // Entladen
                        hours = (soc / 100 * BAT_CAPACITY * 1000) / batAbs;
                        if (hours > 0 && hours < 48) {
                            let h = Math.floor(hours); let m = Math.round((hours - h) * 60);
                            batTimeText = `(leer: ${h}:${m.toString().padStart(2, '0')}h)`;
                        }
                    }
                }
                $('#val-bat-time').text(batTimeText);
                
                const batIcon = $('#icon-bat');
                const batContainer = $('#val-bat-container');
                
                if (batVal > 0) { // Charging
                    batIcon.removeClass('text-success text-danger text-muted').addClass('text-success pulsating');
                    batContainer.removeClass('text-success text-danger text-muted').addClass('text-success');
                } else if (batVal < 0) { // Discharging
                    batIcon.removeClass('text-success text-danger text-muted').addClass('text-danger pulsating');
                    batContainer.removeClass('text-success text-danger text-muted').addClass('text-danger');
                } else {
                    batIcon.removeClass('text-success text-danger pulsating').addClass('text-muted');
                    batContainer.removeClass('text-success text-danger').addClass('text-muted');
                }

                // Grid Logic
                $('#val-grid-container').html(formatWatts(gridAbs));
                
                const gridIcon = $('#icon-grid');
                const gridContainer = $('#val-grid-container');

                if (gridVal > 0) { // Import (Bezug) -> Rot
                    gridIcon.removeClass('text-secondary text-success text-danger').addClass('text-danger');
                    gridContainer.removeClass('text-body text-success text-danger').addClass('text-danger');
                } else if (gridVal < 0) { // Export (Einspeisung) -> Grün
                    gridIcon.removeClass('text-secondary text-success text-danger').addClass('text-success');
                    gridContainer.removeClass('text-body text-success text-danger').addClass('text-success');
                } else {
                    gridIcon.removeClass('text-success text-danger').addClass('text-secondary');
                    gridContainer.removeClass('text-success text-danger').addClass('text-body');
                }

                // Price Logic
                if (data.price_ct !== undefined && data.price_ct !== null) {
                    $('#val-price').html(data.price_ct.toLocaleString('de-DE', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + '<span class="val-unit">ct/kWh</span>');
                    
                    if (data.price_min_ct !== undefined && data.price_min_ct !== null) {
                        $('#val-price-min').text(data.price_min_ct.toLocaleString('de-DE', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
                    }
                    if (data.price_max_ct !== undefined && data.price_max_ct !== null) {
                        $('#val-price-max').text(data.price_max_ct.toLocaleString('de-DE', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
                    }

                    // Dynamic bar visualization (Min-Max range)
                    let min = (data.price_min_ct !== undefined && data.price_min_ct !== null) ? data.price_min_ct : 0;
                    let max = (data.price_max_ct !== undefined && data.price_max_ct !== null) ? data.price_max_ct : 50;
                    let current = data.price_ct;
                    
                    // Flat-Tariff Check: Wenn Preisspanne < 0.1ct, Karte ausblenden
                    if ((max - min) < 0.1) {
                        $('#card-price-container').hide();
                    } else {
                        $('#card-price-container').show();
                    }

                    let pct = 50; // Default Mitte
                    
                    if (max > min) pct = ((current - min) / (max - min)) * 100;
                    
                    if (pct < 0) pct = 0; if (pct > 100) pct = 100;
                    
                    const bar = $('#price-bar');
                    bar.css('width', pct + '%');
                    
                    bar.removeClass('bg-info bg-success bg-warning bg-danger');
                    if (data.price_level === 'cheap') {
                        bar.addClass('bg-success');
                    } else if (data.price_level === 'expensive') {
                        bar.addClass('bg-danger');
                    } else {
                        bar.addClass('bg-warning');
                    }

                    // Price Trend Logic
                    const prices = data.prices || [];
                    const priceStartHour = data.price_start_hour;
                    const priceInterval = data.price_interval || 1.0;
                    let trendIcon = '<i class="fas fa-minus"></i>';

                    if (prices.length > 1 && priceStartHour !== null) {
                        const now = new Date();
                        const curGmtDec = now.getUTCHours() + (now.getUTCMinutes() / 60);
                        let hourDiff = curGmtDec - priceStartHour;
                        if (hourDiff < 0) hourDiff += 24; // Handle day change
                        
                        let idx = Math.floor(hourDiff / priceInterval);
                        
                        if (prices[idx] !== undefined && prices[idx+1] !== undefined) {
                            const diff = prices[idx+1] - prices[idx];
                            if (diff > 0.1) {
                                trendIcon = '<i class="fas fa-arrow-trend-up text-danger" title="Preis steigend"></i>';
                            } else if (diff < -0.1) {
                                trendIcon = '<i class="fas fa-arrow-trend-down text-success" title="Preis fallend"></i>';
                            } else {
                                trendIcon = '<i class="fas fa-arrow-right text-info" title="Preis stabil"></i>';
                            }
                        }
                    }
                    $('#price-trend').html(trendIcon);
                }

                // Diagramm-Details aktualisieren (analog zu mobile.php)
                const detailsEl = document.getElementById('diagramDetails');
                if (detailsEl) {
                    let content = '';
                    if (CURRENT_VIEW === 'pv') {
                        if (data.dc0_w !== undefined) content = `Gesamt: ${data.pv}W | String 1: ${data.dc0_w}W (${data.dc0_v}V) | String 2: ${data.dc1_w}W (${data.dc1_v}V)`;
                    } else if (CURRENT_VIEW === 'grid') {
                        if (data.grid_p1 !== undefined) content = `Netz: ${data.grid}W (L1: ${data.grid_p1} | L2: ${data.grid_p2} | L3: ${data.grid_p3})`;
                        if (data.ac0_w !== undefined) {
                            const wrTotal = (data.ac0_w || 0) + (data.ac1_w || 0) + (data.ac2_w || 0);
                            content += ` | WR: ${wrTotal}W (L1: ${data.ac0_w} | L2: ${data.ac1_w} | L3: ${data.ac2_w})`;
                        }
                    } else if (CURRENT_VIEW === 'wb') {
                        if (data.wb_p1 !== undefined) content = `Wallbox L1: ${data.wb_p1}W | L2: ${data.wb_p2}W | L3: ${data.wb_p3}W`;
                    } else if (CURRENT_VIEW === 'wp') {
                        if (data.wp !== undefined) content = `Wärmepumpe: ${data.wp}W`;
                    } else if (CURRENT_VIEW === 'bat') {
                        if (data.bat_v !== undefined) content = `Spannung: ${data.bat_v}V | Strom: ${data.bat_a}A`;
                    }
                    
                    if (content) {
                        detailsEl.innerHTML = content;
                        detailsEl.style.display = 'block';
                    } else {
                        detailsEl.style.display = 'none';
                    }
                }
                }

                // --- LIVE ENERGIEFLUSS ANIMATION ---
                const flowView = document.getElementById('flow-view');
                if (flowView && flowView.style.display === 'block') {
                    // Helper-Funktion für die Linien-Animation
                    const updateFlow = (id, val, reverse) => {
                        const el = document.getElementById(id);
                        if (!el) return;

                        if (!flowAnimationCache[id]) {
                            flowAnimationCache[id] = { speed: null, gap: null, reverse: null, stopped: false };
                        }
                        const cache = flowAnimationCache[id];

                        if (Math.abs(val) < 15) {
                            if (!cache.stopped) {
                                el.classList.add('stopped');
                                cache.stopped = true;
                            }
                            return;
                        }

                        const absVal = Math.abs(val);
                        let newGap = 30; // 30 ist Teiler von 60 (CSS Offset) -> flüssiger Loop
                        if (absVal > 6000) newGap = 10;
                        else if (absVal > 3000) newGap = 15;
                        else if (absVal > 1000) newGap = 20;

                        // Geschwindigkeit in Stufen, um "Hüpfen" zu vermeiden
                        let newSpeed;
                        if (absVal < 500) newSpeed = 6.0;
                        else if (absVal < 2000) newSpeed = 5.0;
                        else if (absVal < 4500) newSpeed = 4.0;
                        else if (absVal < 9000) newSpeed = 3.0;
                        else newSpeed = 2.0; // >= 9000W

                        if (cache.stopped) {
                            el.classList.remove('stopped');
                            cache.stopped = false;
                        }

                        if (cache.reverse !== reverse) {
                            if (reverse) el.classList.add('reverse');
                            else el.classList.remove('reverse');
                            cache.reverse = reverse;
                        }

                        if (cache.gap !== newGap) { el.style.strokeDasharray = `0 ${newGap}`; cache.gap = newGap; }
                        if (cache.speed !== newSpeed) { el.style.animationDuration = newSpeed + 's'; cache.speed = newSpeed; }
                    };

                    // Werte eintragen
                    $('#f-val-pv').text(formatWatts(data.pv).replace(/<[^>]*>?/gm, '')); // HTML-Tags für Einheit entfernen
                    $('#f-val-home').text(formatWatts(homeVal).replace(/<[^>]*>?/gm, ''));
                    $('#f-val-wb').text(formatWatts(wbVal).replace(/<[^>]*>?/gm, ''));
                    $('#f-val-wp').text(formatWatts(wpVal).replace(/<[^>]*>?/gm, ''));
                    $('#f-val-grid').text(formatWatts(gridVal).replace(/<[^>]*>?/gm, ''));
                    $('#f-val-bat').text(formatWatts(batAbs).replace(/<[^>]*>?/gm, ''));
                    $('#f-lbl-soc').text(Math.round(data.soc) + '% SoC');

                    // Batterie-Farbe anpassen (Laden = Grün, Entladen = Rot)
                    if (batVal > 0) {
                        $('#f-node-bat').addClass('charging');
                        $('#flow-line-bat, #flow-dot-bat').attr('stroke', '#2ecc71');
                    } else {
                        $('#f-node-bat').removeClass('charging');
                        $('#flow-line-bat, #flow-dot-bat').attr('stroke', '#dc3545');
                    }
                    
                    // SoC Fill (Hintergrund füllen)
                    let socPct = Math.round(data.soc);
                    let fillCol = (batVal > 0) ? 'rgba(46, 204, 113, 0.3)' : 'rgba(220, 53, 69, 0.2)';
                    let bgCol = DARK_MODE ? '#1e1e1e' : '#f8f9fa';
                    // Weicherer Übergang (Blur), damit die Kante nicht so hart wirkt
                    $('#f-node-bat').css('background', `linear-gradient(to top, ${fillCol} ${socPct}%, ${bgCol} ${Math.min(100, socPct + 10)}%)`);
                    
                    // WP Boost Farbe
                    if (data.wp_boost_active === true) {
                        $('.node-wp').addClass('boost');
                        $('#flow-line-wp, #flow-dot-wp').attr('stroke', '#dc3545');
                    } else {
                        $('.node-wp').removeClass('boost');
                        $('#flow-line-wp, #flow-dot-wp').attr('stroke', '#22d3ee');
                    }
                    
                    // Netz Farbe (Einspeisung = Grün, Bezug = Grau)
                    if (gridVal < 0) {
                        $('#flow-dot-grid').attr('stroke', '#2ecc71');
                    } else {
                        $('#flow-dot-grid').attr('stroke', '#6c757d');
                    }
                    
                    // Wallbox Lock Icon
                    if (data.wb_locked === true) {
                        $('#f-wb-lock').show();
                    } else {
                        $('#f-wb-lock').hide();
                    }

                    // Animationen steuern (Richtung)
                    // PV fließt IMMER zum Center (vorwärts)
                    updateFlow('flow-dot-pv', data.pv, false);
                    // Haus konsumiert IMMER vom Center (vorwärts)
                    updateFlow('flow-dot-home', homeVal, false);
                    // Wallbox konsumiert IMMER vom Center (vorwärts)
                    updateFlow('flow-dot-wb', wbVal, false);
                    // WP konsumiert IMMER vom Center (vorwärts)
                    updateFlow('flow-dot-wp', wpVal, false);
                    
                    // Netz: Grid > 0 (Bezug) -> vorwärts (zum Center) | Grid < 0 (Einspeisung) -> rückwärts (vom Center)
                    updateFlow('flow-dot-grid', gridVal, gridVal < 0);
                    
                    // Batterie: Bat > 0 (Laden) -> rückwärts (Center zur Bat) | Bat < 0 (Entladen) -> vorwärts (Bat zum Center)
                    updateFlow('flow-dot-bat', batVal, batVal > 0);
                }

            }).fail(function() {
                $('#connection-status').removeClass('bg-secondary bg-success').addClass('bg-danger').text('Offline');
            });
        }

        // updateChart, updateChartHistory, switchChartMode, loadArchive, refreshData entfernt -> jetzt in solar.js

        // startSystemUpdate(), pollUpdate() entfernt -> jetzt in solar.js (nutze Button ID 'btn-update-config')

        // Init
        fetchData();
        setInterval(fetchData, 2000);
        
        // Diagramm beim Laden aktualisieren, um veraltete Daten/falschen Modus zu vermeiden
        $(document).ready(function() { 
            switchChartMode('flow');
            refreshData(true); 
        });

        // NEU: Automatisches Diagramm-Update (Intervall aus Config)
        const DIAGRAM_MODE = '<?= $diagramMode ?>';
        if (DIAGRAM_MODE !== 'manual') {
            const DIAGRAM_INTERVAL = <?= max(60000, $diagramInterval * 60 * 1000) ?>;
            setInterval(function() { refreshData(true); }, DIAGRAM_INTERVAL);
        }

        // Update Check (Initial + Periodisch)
        setTimeout(() => {
            fetch('index.php?action=check_update').then(r=>r.json()).then(d => {
                if(d.success && d.missing > 0) {
                    const bNav = document.getElementById('update-badge-nav');
                    const bBtn = document.getElementById('update-badge-btn');
                    const bConf = document.getElementById('update-badge-config');
                    const btnConf = document.getElementById('btn-update-config');

                    if(bNav) bNav.style.display = 'inline-block';
                    if(bBtn) { bBtn.style.display = 'inline-block'; bBtn.innerText = d.missing > 0 ? '!' : ''; }
                    if(bConf) { bConf.style.display = 'inline-block'; bConf.innerText = d.missing; }
                    if(btnConf) {
                        btnConf.classList.remove('btn-outline-warning');
                        btnConf.classList.add('btn-warning');
                    }
                }
            });
        }, 2000);
        
        // Periodische Prüfung alle 15 Minuten
        setInterval(() => {
            fetch('index.php?action=check_update').then(r=>r.json()).then(d => {
                const bNav = document.getElementById('update-badge-nav');
                const bBtn = document.getElementById('update-badge-btn');
                const bConf = document.getElementById('update-badge-config');
                
                if(d.success && d.missing > 0) {
                    if(bNav) bNav.style.display = 'inline-block';
                    if(bBtn) { bBtn.style.display = 'inline-block'; bBtn.innerText = d.missing > 0 ? '!' : ''; }
                    if(bConf) { bConf.style.display = 'inline-block'; bConf.innerText = d.missing; }
                } else {
                    if(bNav) bNav.style.display = 'none';
                    if(bBtn) bBtn.style.display = 'none';
                    if(bConf) bConf.style.display = 'none';
                }
            });
        }, 900000); // 15 Minuten

        // Watchdog Status prüfen
        function checkWatchdog() {
            $.getJSON('index.php?action=watchdog_status', function(data) {
                const badge = $('#watchdog-badge');
                if (data.installed) {
                    badge.show();
                    badge.attr('title', data.message);
                    if (data.warning) {
                        badge.removeClass('bg-secondary bg-success bg-danger').addClass('bg-warning text-dark');
                    } else if (data.active) {
                        badge.removeClass('bg-secondary bg-danger bg-warning text-dark').addClass('bg-success text-white');
                    } else {
                        badge.removeClass('bg-secondary bg-success bg-warning text-dark').addClass('bg-danger text-white');
                    }
                } else {
                    badge.hide();
                }
            });
        }
        setInterval(checkWatchdog, 10000); // Alle 10 Sek prüfen
        checkWatchdog();

        // showWatchdogLog() entfernt -> jetzt in solar.js

        // handleConnectionClick() entfernt -> jetzt in solar.js
    </script>
    <script>
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', function() {
            navigator.serviceWorker.register('./sw.js')
                .then(reg => console.log('Service Worker erfolgreich registriert!', reg))
                .catch(err => console.error('Service Worker Registrierung fehlgeschlagen:', err));
            });
        } else {
            console.log('Service Worker wird von diesem Browser nicht unterstützt.');
        }
    </script>
</body>
</html>