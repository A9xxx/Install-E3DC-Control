<?php
/* =====================================================================
   E3DC-Control - index.php (Überarbeitete Version)
   
   - helpers.php und style.css eingebunden
   - Konsistente Dark-Mode Farbgebung
   - Verbesserte Fehlerbehandlung
   ===================================================================== */

include 'helpers.php';

/* Sicheres Routing */
$allowed = ['start','live','wallbox','config','archiv'];
$seite = $_GET['seite'] ?? 'start';
if ($seite === 'auto') {
    $seite = 'wallbox';
}
if (!in_array($seite, $allowed)) {
    $seite = 'start';
}

$startUrl = getContextPageUrl('start');
$liveUrl = getContextPageUrl('live');
$wallboxUrl = getContextPageUrl('wallbox');
$configUrl = getContextPageUrl('config');
$archivUrl = getContextPageUrl('archiv');
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#005b8e">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

    <title>E3DC Control</title>

    <!-- PWA -->
    <link rel="manifest" href="manifest.json">
    <link rel="apple-touch-icon" href="icons/icon-192.png">
    
    <!-- Service Worker Registration -->
    <script>
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
             navigator.serviceWorker.register('sw.js')
                .then(() => console.log("Service Worker registered"))
                .catch(err => console.error('SW Error:', err));
        });
    }
    </script>
    <!-- Zentrale Dark-Mode CSS -->
    <link rel="stylesheet" href="style.css">

</head>

<body>

    <!-- Mobile Menü -->
    <input type="checkbox" id="menu-toggle">
    <label for="menu-toggle" class="menu-icon">&#9776;</label>

    <nav class="mobile-menu">
        <a href="<?= htmlspecialchars($startUrl) ?>">Startseite</a>
        <a href="<?= htmlspecialchars($liveUrl) ?>">Live</a>
        <a href="<?= htmlspecialchars($wallboxUrl) ?>">Wallbox</a>
        <a href="<?= htmlspecialchars($configUrl) ?>">Config</a>
        <a href="<?= htmlspecialchars($archivUrl) ?>">Archiv</a>
    </nav>

    <div class="container">
        <h1>E3DC-Control Anzeige & Steuerung</h1>

        <!-- Desktop Navigation -->
        <nav style="margin-bottom: 20px;">
            <a class="button" href="<?= htmlspecialchars($startUrl) ?>">Startseite</a>
            <a class="button" href="<?= htmlspecialchars($liveUrl) ?>">Live</a>
            <a class="button" href="<?= htmlspecialchars($wallboxUrl) ?>">Wallbox</a>
            <a class="button" href="<?= htmlspecialchars($configUrl) ?>">Config</a>
            <a class="button" href="<?= htmlspecialchars($archivUrl) ?>">Archiv</a>
        </nav>

        <main id="content">
            <?php
            switch ($seite) {
                case 'live':
                    include 'live_content.php';
                    break;
                case 'wallbox':
                    include 'Wallbox.php';
                    break;
                case 'config':
                    include 'config_editor.php';
                    break;
                case 'archiv':
                    include 'archiv.php';
                    break;
                case 'start':
                default:
                    include 'start_content.php';
                    break;
            }
            ?>
        </main>
    </div>

    <footer id="fussnoten">
        <h3>Das Projekt</h3>
        <p>
            <a href="https://github.com/Eba-M/E3DC-Control" target="_blank">GitHub</a> |
            <a href="https://www.photovoltaikforum.com" target="_blank">Photovoltaikforum</a>
        </p>
    </footer>

</body>
</html>
