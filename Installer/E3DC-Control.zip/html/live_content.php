<?php
/* =====================================================================
   live_content.php - Live-Werte für Desktop-Index
   ===================================================================== */
?>

<h1>Live-Werte</h1>

<div class="config-box live-container">
    <div class="live-grid">
        <div class="live-card">
            <div class="live-fill" id="fill-pv"></div>
            <div class="live-label">PV</div>
            <div class="live-value" id="live-pv">0 W</div>
        </div>
        <div class="live-card">
            <div class="live-fill" id="fill-bat"></div>
            <div class="live-label">Batterie / SOC</div>
            <div class="live-value" id="live-bat">0 W</div>
            <div class="live-subvalue" id="live-soc">SOC 0,0 %</div>
        </div>
        <div class="live-card">
            <div class="live-fill" id="fill-home"></div>
            <div class="live-label">Haus ohne WP</div>
            <div class="live-value" id="live-home">0 W</div>
        </div>
        <div class="live-card">
            <div class="live-fill" id="fill-grid"></div>
            <div class="live-label">Netz</div>
            <div class="live-value" id="live-grid">0 W</div>
        </div>
        <div class="live-card">
            <div class="live-fill" id="fill-wb"></div>
            <div class="live-label">Wallbox</div>
            <div class="live-value" id="live-wb">0 W</div>
        </div>
        <div class="live-card">
            <div class="live-fill" id="fill-wp"></div>
            <div class="live-label">Wärmepumpe</div>
            <div class="live-value" id="live-wp">0 W</div>
        </div>
        <div class="live-card">
            <div class="live-fill" id="fill-price"></div>
            <div class="live-label">Strompreis</div>
            <div class="live-value" id="live-price">-- ct/kWh</div>
        </div>
        <div class="live-card live-time-card">
            <div class="live-label">Zeit</div>
            <div class="live-value" id="live-time">--:--:--</div>
        </div>
    </div>
</div>

<div class="config-box" style="margin-top: 20px;">
    <h2 style="margin-bottom: 10px;">Live-Diagramm (48h)</h2>
    <p style="color: #aaa; font-size: 0.9em; margin-bottom: 10px;">SoC (Fläche), PV, BAT, Home, Grid, Wärmepumpe, Wallbox und Strompreis aus der Ramdisk-History.</p>
    <?php
    $paths = function_exists('getInstallPaths') ? getInstallPaths() : ['install_path' => '/home/pi/E3DC-Control/'];
    $live_diagramm = '/var/www/html/live_diagramm.html';
    $live_history_script = rtrim($paths['install_path'], '/') . '/plot_live_history.py';
    $live_diagramm_stamp = '/var/www/html/tmp/plot_live_history_last_run';
    $needs_live_update = !file_exists($live_diagramm) || (file_exists($live_diagramm_stamp) && (time() - filemtime($live_diagramm_stamp)) > 300);
    if ($needs_live_update && file_exists($live_history_script) && !file_exists('/var/www/html/tmp/plot_live_history_running')) {
        @touch('/var/www/html/tmp/plot_live_history_running');
        @shell_exec('python3 ' . escapeshellarg($live_history_script) . ' 2>/dev/null &');
    }
    $diagramm_zeit = file_exists($live_diagramm) ? date('d.m.Y H:i', filemtime($live_diagramm)) : null;
    ?>
    <p style="color: #888; font-size: 0.85em; margin-bottom: 8px;">
        <?php if ($diagramm_zeit): ?>
        Zuletzt aktualisiert: <strong style="color: #aaa;"><?= htmlspecialchars($diagramm_zeit) ?> Uhr</strong>
        <?php endif; ?>
        <button type="button" id="liveHistoryUpdateBtn" class="form-button" style="margin-left: 12px; padding: 6px 14px; font-size: 0.9em;">⟳ Live-Diagramm aktualisieren</button>
        <span id="liveHistoryStatus" style="margin-left: 8px; color: #0073e6;"></span>
    </p>
    <iframe id="liveHistoryFrame" src="live_diagramm.html?t=<?= file_exists($live_diagramm) ? filemtime($live_diagramm) : time() ?>" style="width:100%; height:520px; border:1px solid #555; border-radius:6px; background:#1a1a1a;" title="Live 48h Diagramm"></iframe>
</div>
<script>
(function(){
    var btn = document.getElementById('liveHistoryUpdateBtn');
    var status = document.getElementById('liveHistoryStatus');
    var frame = document.getElementById('liveHistoryFrame');
    if (!btn || !frame) return;
    btn.addEventListener('click', function(){
        btn.disabled = true;
        status.textContent = 'Starte…';
        fetch('run_live_history.php').then(function(r){ return r.json(); }).then(function(d){
            if (!d.ok) { status.textContent = d.error || 'Fehler'; btn.disabled = false; return; }
            status.textContent = 'Aktualisiere…';
            var check = setInterval(function(){
                fetch('run_live_history.php?mode=status').then(function(r){ return r.json(); }).then(function(s){
                    if (!s.running) {
                        clearInterval(check);
                        status.textContent = 'Fertig';
                        frame.src = 'live_diagramm.html?t=' + Date.now();
                        btn.disabled = false;
                        setTimeout(function(){ status.textContent = ''; }, 2000);
                    }
                });
            }, 1500);
        }).catch(function(){ status.textContent = 'Fehler'; btn.disabled = false; });
    });
})();
</script>

<style>
.live-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 14px;
    height: 100%;
}

.live-card {
    position: relative;
    overflow: hidden;
    background: #333333;
    border: 1px solid #555555;
    border-radius: 6px;
    padding: 14px;
    min-height: 140px;
}

.live-container {
    min-height: calc(100vh - 260px);
}

.live-fill {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 0%;
    background: rgba(0, 115, 230, 0.2);
    transition: width 1.2s ease-in-out;
    z-index: 1;
}

.live-label {
    position: relative;
    z-index: 2;
    color: #aaaaaa;
    font-size: 0.85em;
    margin-bottom: 6px;
}

.live-value {
    position: relative;
    z-index: 2;
    color: #ffffff;
    font-size: 1.75em;
    font-weight: 700;
}

.live-subvalue {
    position: relative;
    z-index: 2;
    color: #aaaaaa;
    font-size: 1.0em;
    font-weight: 600;
    margin-top: 4px;
}

.live-time-card {
    grid-column: 2;
    min-height: 88px;
    text-align: center;
}

@media (max-width: 1200px) {
    .live-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .live-time-card {
        grid-column: 1 / -1;
    }
}

@media (max-width: 768px) {
    .live-grid {
        grid-template-columns: 1fr;
    }

    .live-time-card {
        grid-column: 1;
    }
}
</style>

<script>
(function () {
    const PV_MAX_W = 15400;
    const PV_RED_THRESHOLD_W = 12000;
    const BAT_MAX_W = 12000;
    const HOME_MAX_W = 24200;
    const GRID_MAX_W = 24200;
    const WB_MAX_W = 22000;
    const WP_MAX_W = 5500;

    const endpoints = {
        pv: document.getElementById('live-pv'),
        bat: document.getElementById('live-bat'),
        home: document.getElementById('live-home'),
        grid: document.getElementById('live-grid'),
        soc: document.getElementById('live-soc'),
        wb: document.getElementById('live-wb'),
        wp: document.getElementById('live-wp'),
        price: document.getElementById('live-price'),
        // priceDebug: document.getElementById('live-price-debug'),
        time: document.getElementById('live-time')
    };

    const fills = {
        pv: document.getElementById('fill-pv'),
        bat: document.getElementById('fill-bat'),
        home: document.getElementById('fill-home'),
        grid: document.getElementById('fill-grid'),
        wb: document.getElementById('fill-wb'),
        wp: document.getElementById('fill-wp'),
        price: document.getElementById('fill-price')
    };

    function formatWatt(value) {
        const num = Number(value) || 0;
        return num.toLocaleString('de-DE') + ' W';
    }

    function formatSoc(value) {
        const num = Number(value) || 0;
        return num.toLocaleString('de-DE', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
    }

    function formatPrice(value) {
        const num = Number(value);
        if (!Number.isFinite(num)) {
            return '--';
        }
        return num.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    function toPercent(value, max) {
        const num = Math.abs(Number(value) || 0);
        return Math.max(0, Math.min(100, (num / max) * 100));
    }

    function updateLiveValues() {
        fetch('get_live_json.php', { cache: 'no-store' })
            .then(function (response) { return response.json(); })
            .then(function (data) {
                const pvValue = Number(data.pv) || 0;
                const batValue = Number(data.bat) || 0;
                const homeRawValue = Number(data.home_raw) || 0;
                const gridValue = Number(data.grid) || 0;
                const socValue = Number(data.soc) || 0;
                const wbValue = Number(data.wb) || 0;
                const wpValue = Number(data.wp) || 0;
                const priceValue = Number(data.price_ct);
                const homeValue = homeRawValue - wpValue;

                endpoints.pv.textContent = formatWatt(data.pv);
                endpoints.bat.textContent = formatWatt(data.bat);
                endpoints.home.textContent = formatWatt(homeValue);
                endpoints.grid.textContent = formatWatt(data.grid);
                endpoints.soc.textContent = 'SOC ' + formatSoc(data.soc) + ' %';
                endpoints.wb.textContent = formatWatt(data.wb);
                endpoints.wp.textContent = formatWatt(data.wp);
                function gmtToLocal(slot) {
                    if (!slot || !/^[0-9]+\.[0-9]{2}$/.test(slot)) return '--:--';
                    const [h, m] = slot.split('.');
                    let gmtHour = parseInt(h);
                    let gmtMin = Math.round((parseInt(m) / 100) * 60);
                    let date = new Date();
                    date.setUTCHours(gmtHour, gmtMin, 0, 0);
                    let localHour = date.getHours();
                    let localMin = date.getMinutes();
                    return String(localHour).padStart(2, '0') + ':' + String(localMin).padStart(2, '0');
                }

                let minPrice = '--';
                let minTime = '--:--';
                let maxPrice = '--';
                let maxTime = '--:--';
                if (typeof data.price_min_ct === 'number') {
                    minPrice = data.price_min_ct.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                }
                if (typeof data.price_max_ct === 'number') {
                    maxPrice = data.price_max_ct.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                }
                minTime = gmtToLocal(data.price_min_slot);
                maxTime = gmtToLocal(data.price_max_slot);

                let priceText = '<div style="display:flex;flex-direction:column;align-items:center;margin-top:8px;">';
                priceText += '<span style="font-size:1.5em;font-weight:700;text-align:center">' + formatPrice(data.price_ct) + '<span class="unit" style="font-size:0.7em;margin-left:6px">ct/kWh</span></span>';
                priceText += '<div style="display:flex;justify-content:space-between;width:100%;margin-top:8px;">';
                priceText += '<span style="font-size:1em;font-weight:600;text-align:left;color:#10b981!important">' + minPrice + '<span class="unit" style="font-size:0.7em;margin-left:4px">ct/kWh</span><br><span style="font-size:0.9em;color:#aaa">um ' + minTime + '</span></span>';
                priceText += '<span style="font-size:1em;font-weight:600;text-align:right;color:#f43f5e!important">' + maxPrice + '<span class="unit" style="font-size:0.7em;margin-left:4px">ct/kWh</span><br><span style="font-size:0.9em;color:#aaa">um ' + maxTime + '</span></span>';
                priceText += '</div>';
                priceText += '</div>';
                endpoints.price.innerHTML = priceText;
                endpoints.time.textContent = data.time || '--:--:--';

                endpoints.bat.style.color = batValue < 0 ? '#f43f5e' : '#10b981';
                endpoints.grid.style.color = gridValue > 0 ? '#f43f5e' : '#10b981';

                if (pvValue >= PV_RED_THRESHOLD_W) {
                    fills.pv.style.background = 'rgba(244, 63, 94, 0.28)';
                    endpoints.pv.style.color = '#f43f5e';
                } else {
                    fills.pv.style.background = 'rgba(251, 191, 36, 0.24)';
                    endpoints.pv.style.color = '#fbbf24';
                }

                fills.bat.style.background = 'rgba(16, 185, 129, 0.22)';
                fills.home.style.background = 'rgba(244, 63, 94, 0.22)';
                fills.grid.style.background = 'rgba(148, 163, 184, 0.2)';
                fills.wb.style.background = 'rgba(59, 130, 246, 0.22)';
                fills.wp.style.background = 'rgba(34, 211, 238, 0.2)';

                if (data.price_level === 'cheap') {
                    fills.price.style.background = 'rgba(16, 185, 129, 0.2)';
                    endpoints.price.style.color = '#10b981';
                } else if (data.price_level === 'expensive') {
                    fills.price.style.background = 'rgba(244, 63, 94, 0.22)';
                    endpoints.price.style.color = '#f43f5e';
                } else {
                    fills.price.style.background = 'rgba(251, 191, 36, 0.2)';
                    endpoints.price.style.color = '#fbbf24';
                }

                fills.pv.style.width = toPercent(pvValue, PV_MAX_W) + '%';
                fills.bat.style.width = Math.max(Math.max(0, Math.min(100, socValue)), toPercent(batValue, BAT_MAX_W)) + '%';
                fills.home.style.width = toPercent(homeValue, HOME_MAX_W) + '%';
                fills.grid.style.width = toPercent(gridValue, GRID_MAX_W) + '%';
                fills.wb.style.width = toPercent(wbValue, WB_MAX_W) + '%';
                fills.wp.style.width = toPercent(wpValue, WP_MAX_W) + '%';
                fills.price.style.width = Number.isFinite(priceValue) ? '100%' : '0%';
            })
            .catch(function () {
                endpoints.time.textContent = 'Keine Verbindung';
            });
    }

    updateLiveValues();
    setInterval(updateLiveValues, 4000);
})();
</script>
