<?php
/* =====================================================================
   live_content.php - Live-Werte für Desktop-Index
   ===================================================================== */
?>

<h1>Live-Werte</h1>

<div class="config-box live-container">
    <div class="live-grid">
        <div class="live-card">
            <div class="live-fill" id="fill-pv"></div>
            <div class="live-label">PV</div>
            <div class="live-value" id="live-pv">0 W</div>
        </div>
        <div class="live-card">
            <div class="live-fill" id="fill-bat"></div>
            <div class="live-label">Batterie / SOC</div>
            <div class="live-value" id="live-bat">0 W</div>
            <div class="live-subvalue" id="live-soc">SOC 0,0 %</div>
        </div>
        <div class="live-card">
            <div class="live-fill" id="fill-home"></div>
            <div class="live-label">Haus ohne WP</div>
            <div class="live-value" id="live-home">0 W</div>
        </div>
        <div class="live-card">
            <div class="live-fill" id="fill-grid"></div>
            <div class="live-label">Netz</div>
            <div class="live-value" id="live-grid">0 W</div>
        </div>
        <div class="live-card">
            <div class="live-fill" id="fill-wb"></div>
            <div class="live-label">Wallbox</div>
            <div class="live-value" id="live-wb">0 W</div>
        </div>
        <div class="live-card">
            <div class="live-fill" id="fill-wp"></div>
            <div class="live-label">Wärmepumpe</div>
            <div class="live-value" id="live-wp">0 W</div>
        </div>
        <div class="live-card live-time-card">
            <div class="live-label">Zeit</div>
            <div class="live-value" id="live-time">--:--:--</div>
        </div>
    </div>
</div>

<style>
.live-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 14px;
    height: 100%;
}

.live-card {
    position: relative;
    overflow: hidden;
    background: #333333;
    border: 1px solid #555555;
    border-radius: 6px;
    padding: 14px;
    min-height: 140px;
}

.live-container {
    min-height: calc(100vh - 260px);
}

.live-fill {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 0%;
    background: rgba(0, 115, 230, 0.2);
    transition: width 1.2s ease-in-out;
    z-index: 1;
}

.live-label {
    position: relative;
    z-index: 2;
    color: #aaaaaa;
    font-size: 0.85em;
    margin-bottom: 6px;
}

.live-value {
    position: relative;
    z-index: 2;
    color: #ffffff;
    font-size: 1.75em;
    font-weight: 700;
}

.live-subvalue {
    position: relative;
    z-index: 2;
    color: #aaaaaa;
    font-size: 1.0em;
    font-weight: 600;
    margin-top: 4px;
}

.live-time-card {
    grid-column: 2;
    min-height: 88px;
    text-align: center;
}

@media (max-width: 1200px) {
    .live-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .live-time-card {
        grid-column: 1 / -1;
    }
}

@media (max-width: 768px) {
    .live-grid {
        grid-template-columns: 1fr;
    }

    .live-time-card {
        grid-column: 1;
    }
}
</style>

<script>
(function () {
    const PV_MAX_W = 15400;
    const PV_RED_THRESHOLD_W = 12000;
    const BAT_MAX_W = 12000;
    const HOME_MAX_W = 24200;
    const GRID_MAX_W = 24200;
    const WB_MAX_W = 22000;
    const WP_MAX_W = 5500;

    const endpoints = {
        pv: document.getElementById('live-pv'),
        bat: document.getElementById('live-bat'),
        home: document.getElementById('live-home'),
        grid: document.getElementById('live-grid'),
        soc: document.getElementById('live-soc'),
        wb: document.getElementById('live-wb'),
        wp: document.getElementById('live-wp'),
        time: document.getElementById('live-time')
    };

    const fills = {
        pv: document.getElementById('fill-pv'),
        bat: document.getElementById('fill-bat'),
        home: document.getElementById('fill-home'),
        grid: document.getElementById('fill-grid'),
        wb: document.getElementById('fill-wb'),
        wp: document.getElementById('fill-wp')
    };

    function formatWatt(value) {
        const num = Number(value) || 0;
        return num.toLocaleString('de-DE') + ' W';
    }

    function formatSoc(value) {
        const num = Number(value) || 0;
        return num.toLocaleString('de-DE', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
    }

    function toPercent(value, max) {
        const num = Math.abs(Number(value) || 0);
        return Math.max(0, Math.min(100, (num / max) * 100));
    }

    function updateLiveValues() {
        fetch('get_live_json.php', { cache: 'no-store' })
            .then(function (response) { return response.json(); })
            .then(function (data) {
                const pvValue = Number(data.pv) || 0;
                const batValue = Number(data.bat) || 0;
                const homeRawValue = Number(data.home_raw) || 0;
                const gridValue = Number(data.grid) || 0;
                const socValue = Number(data.soc) || 0;
                const wbValue = Number(data.wb) || 0;
                const wpValue = Number(data.wp) || 0;
                const homeValue = homeRawValue - wpValue;

                endpoints.pv.textContent = formatWatt(data.pv);
                endpoints.bat.textContent = formatWatt(data.bat);
                endpoints.home.textContent = formatWatt(homeValue);
                endpoints.grid.textContent = formatWatt(data.grid);
                endpoints.soc.textContent = 'SOC ' + formatSoc(data.soc) + ' %';
                endpoints.wb.textContent = formatWatt(data.wb);
                endpoints.wp.textContent = formatWatt(data.wp);
                endpoints.time.textContent = data.time || '--:--:--';

                endpoints.bat.style.color = batValue < 0 ? '#f43f5e' : '#10b981';
                endpoints.grid.style.color = gridValue > 0 ? '#f43f5e' : '#10b981';

                if (pvValue >= PV_RED_THRESHOLD_W) {
                    fills.pv.style.background = 'rgba(244, 63, 94, 0.28)';
                    endpoints.pv.style.color = '#f43f5e';
                } else {
                    fills.pv.style.background = 'rgba(251, 191, 36, 0.24)';
                    endpoints.pv.style.color = '#fbbf24';
                }

                fills.bat.style.background = 'rgba(16, 185, 129, 0.22)';
                fills.home.style.background = 'rgba(244, 63, 94, 0.22)';
                fills.grid.style.background = 'rgba(148, 163, 184, 0.2)';
                fills.wb.style.background = 'rgba(59, 130, 246, 0.22)';
                fills.wp.style.background = 'rgba(34, 211, 238, 0.2)';

                fills.pv.style.width = toPercent(pvValue, PV_MAX_W) + '%';
                fills.bat.style.width = Math.max(Math.max(0, Math.min(100, socValue)), toPercent(batValue, BAT_MAX_W)) + '%';
                fills.home.style.width = toPercent(homeValue, HOME_MAX_W) + '%';
                fills.grid.style.width = toPercent(gridValue, GRID_MAX_W) + '%';
                fills.wb.style.width = toPercent(wbValue, WB_MAX_W) + '%';
                fills.wp.style.width = toPercent(wpValue, WP_MAX_W) + '%';
            })
            .catch(function () {
                endpoints.time.textContent = 'Keine Verbindung';
            });
    }

    updateLiveValues();
    setInterval(updateLiveValues, 4000);
})();
</script>
