<?php
/**
 * logic.php - Zentrale Datenaufbereitung für Mobile & Desktop Dashboard
 * Liest Konfiguration, History-Mittelwerte und aWATTar-Prognosen.
 * Setzt voraus, dass helpers.php bereits eingebunden wurde.
 */

$paths = getInstallPaths();
$configFile = rtrim($paths['install_path'], '/') . '/e3dc.config.txt';
$historyFile = rtrim($paths['install_path'], '/') . '/live_history.txt';

// 1. Auslesen der Config (WP_MAX und PV_MAX aus forecast1)
$wpMax = 5000; 
$pvMax = 10000; // Fallback
$maxBatPower = 3000; // Fallback
$batteryCapacity = 0; // Fallback
$lat = 51.16; $lon = 10.45; // Default (Mitte DE)
$pvStrings = [];
$showForecast = true; // Default an
$darkMode = true; // Default an
$pvAtmosphere = 0.7; // Default atmosphärische Transmission

function parseConfigFloat($val) {
    return (float)str_replace(',', '.', $val);
}

if (file_exists($configFile)) {
    $conf = file_get_contents($configFile);
    if (preg_match('/wpmax\s*=\s*([\d\.,]+)/i', $conf, $m)) { $wpMax = parseConfigFloat($m[1]) * 1000; }
    if (preg_match('/maximumLadeleistung\s*=\s*([\d\.,]+)/i', $conf, $m)) { $maxBatPower = parseConfigFloat($m[1]); }
    if (preg_match('/speichergroesse\s*=\s*([\d\.,]+)/i', $conf, $m)) { $batteryCapacity = parseConfigFloat($m[1]); }
    if (preg_match('/hoehe\s*=\s*([\d\.,]+)/i', $conf, $m)) { $lat = parseConfigFloat($m[1]); }
    if (preg_match('/laenge\s*=\s*([\d\.,]+)/i', $conf, $m)) { $lon = parseConfigFloat($m[1]); }
    if (preg_match('/show_forecast\s*=\s*([01]|true|false)/i', $conf, $m)) {
        $v = strtolower($m[1]);
        $showForecast = ($v === '1' || $v === 'true');
    }
    if (preg_match('/darkmode\s*=\s*([01]|true|false)/i', $conf, $m)) {
        $v = strtolower($m[1]);
        $darkMode = ($v === '1' || $v === 'true');
    }
    if (preg_match('/pvatmosphere\s*=\s*([\d\.,]+)/i', $conf, $m)) { $pvAtmosphere = parseConfigFloat($m[1]); }

    // Alle Forecast-Strings einlesen (z.B. forecast1 = 40/-50/15.4)
    if (preg_match_all('/forecast(\d+)\s*=\s*([\d\.,\-]+)\/([\d\.,\-]+)\/([\d\.,]+)/i', $conf, $matches, PREG_SET_ORDER)) {
        $totalPv = 0;
        foreach ($matches as $m) {
            $p = parseConfigFloat($m[4]) * 1000;
            $pvStrings[] = ['tilt' => parseConfigFloat($m[2]), 'azimuth' => parseConfigFloat($m[3]), 'power' => $p];
            $totalPv += $p;
        }
        if ($totalPv > 0) $pvMax = $totalPv;
    } elseif (preg_match('/forecast1\s*=\s*[^=]+\/([\d\.]+)/i', $conf, $m)) { 
        $pvMax = $m[1] * 1000; // Fallback alte Logik
    }
}

// 2. 24h Mittelwerte berechnen (Cache 1 Std)
function get24hAverages($filePath) {
    $cacheFile = '/tmp/e3dc_avgs.json';
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 3600) return json_decode(file_get_contents($cacheFile), true);

    $avgs = ['home' => 800, 'grid' => 1000, 'wb' => 4000];
    if (file_exists($filePath)) {
        $lines = array_slice(file($filePath), -1000); // Letzte Einträge
        $sums = ['h' => 0, 'g' => 0, 'w' => 0]; $c = 0;
        foreach ($lines as $l) {
            $d = json_decode($l, true);
            if ($d) { $sums['h'] += abs($d['home_raw']??0); $sums['g'] += abs($d['grid']??0); $sums['w'] += ($d['wb']??0); $c++; }
        }
        if ($c > 0) $avgs = ['home' => $sums['h']/$c, 'grid' => $sums['g']/$c, 'wb' => $sums['w']/$c];
    }
    file_put_contents($cacheFile, json_encode($avgs));
    return $avgs;
}
$avgs = get24hAverages($historyFile);

// 3. Strompreise & Prognose aus awattardebug.txt laden
$priceHistory = [];
$forecastData = [];
$priceStartHour = 0;
$priceInterval = 1.0;
$currentHour = (int)date('H');

// Intelligente Dateiauswahl & Merge (0.txt/12.txt + live debug.txt)
$baseFile = 'awattardebug.0.txt';
if ($currentHour >= 22 || $currentHour < 10) {
    $baseFile = 'awattardebug.12.txt';
}

$filesToRead = [];
$fBase = rtrim($paths['install_path'], '/') . '/' . $baseFile;
if (file_exists($fBase)) $filesToRead[] = $fBase;
elseif ($baseFile === 'awattardebug.12.txt') {
    $f0 = rtrim($paths['install_path'], '/') . '/awattardebug.0.txt';
    if (file_exists($f0)) $filesToRead[] = $f0;
}
$fLive = rtrim($paths['install_path'], '/') . '/awattardebug.txt';
if (file_exists($fLive)) $filesToRead[] = $fLive;

$chartDataMap = [];
$forecastDataMap = [];

foreach ($filesToRead as $file) {
    $readingData = false; $lastTime = -1; $dayOffset = 0;
    foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $trimmed = trim($line);
        if ($trimmed === 'Data') { $readingData = true; $lastTime = -1; $dayOffset = 0; continue; }
        
        $cols = preg_split('/\s+/', $trimmed);
        if (count($cols) < 1 || !is_numeric($cols[0])) continue;

        $rawTime = (float)$cols[0];
        if ($lastTime !== -1 && $rawTime < $lastTime) { $dayOffset += 24; }
        $lastTime = $rawTime;
        $h = sprintf('%.2f', $rawTime + $dayOffset);

        if (!$readingData) {
            if (count($cols) >= 2 && is_numeric($cols[1])) $chartDataMap[$h] = (float)$cols[1];
        } else {
            if (count($cols) >= 5 && is_numeric($cols[4])) $forecastDataMap[$h] = (float)$cols[4] * $batteryCapacity * 40;
        }
    }
}

uksort($chartDataMap, function($a, $b) { return (float)$a <=> (float)$b; });
uksort($forecastDataMap, function($a, $b) { return (float)$a <=> (float)$b; });

foreach ($chartDataMap as $h => $val) { if (empty($priceHistory)) $priceStartHour = (float)$h; elseif (count($priceHistory) === 1) $priceInterval = max(0.25, (float)$h - $priceStartHour); $priceHistory[] = $val; }
foreach ($forecastDataMap as $h => $val) { $forecastData[] = ['h' => (float)$h, 'w' => $val]; }

// 4. Helper für Archiv-Dateien
function getArchivedDebugFiles($basePath) {
    $files = [];
    if (is_dir($basePath)) {
        foreach (glob(rtrim($basePath, '/') . '/awattardebug.*.txt') as $f) {
            if (preg_match('/awattardebug\.(\d+)\.txt$/', $f, $m)) {
                $ts = filemtime($f);
                $files[] = [
                    'file' => basename($f),
                    'ts' => $ts,
                    'label' => date('d.m. H:i', $ts) . " (Run {$m[1]})"
                ];
            }
        }
        usort($files, fn($a, $b) => $b['ts'] <=> $a['ts']);
    }
    return $files;
}
?>