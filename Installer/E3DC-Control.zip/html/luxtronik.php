<?php
// luxtronik.php - Optimierte Anzeige mit Wärmequelle und Soll-Werten

if (!isset($base_path) || !isset($paths)) {
    $paths = getInstallPaths();
    $base_path = rtrim($paths['install_path'], '/') . '/';
}

// Versuche zuerst, die Ramdisk-Datei zu lesen (viel schneller!)
// ... Pfade laden wie gehabt ...

$ramdiskFile = '/var/www/html/ramdisk/luxtronik.json';
$json = null;

// Konfigurations-Pfad (im Installationsverzeichnis)
$luxInstallDir = rtrim($paths['home_dir'], '/') . '/Install/Installer/luxtronik/';
$configFile = $luxInstallDir . 'config.lux.json';
$serviceName = 'energy_manager'; // Name des Systemd-Services

// Speichern der Konfiguration
if (isset($_POST['save_config'])) {
    $newConf = [
        'luxtronik' => isset($_POST['luxtronik_active']) ? 1 : 0,
        'auto_mode' => isset($_POST['auto_mode']) ? 1 : 0,
        'luxtronik_ip' => $_POST['luxtronik_ip'] ?? '',
        'GRID_START_LIMIT' => (int)($_POST['GRID_START_LIMIT'] ?? -3500),
        'MIN_SOC' => (int)($_POST['MIN_SOC'] ?? 80),
        'AT_LIMIT' => (float)($_POST['AT_LIMIT'] ?? 10.0),
        'WWS' => (float)($_POST['WWS'] ?? 50.0),
        'WWW' => (float)($_POST['WWW'] ?? 48.0),
        'HZ' => (float)($_POST['HZ'] ?? 50.0),
    ];

    // JSON speichern
    file_put_contents($configFile, json_encode($newConf, JSON_PRETTY_PRINT));
    
    // Wenn manueller Boost aktiv ist, müssen die neuen Werte sofort an die WP gesendet werden
    if (file_exists('/var/www/html/ramdisk/manual_boost.flag')) {
        $python = getPythonInterpreter();
        $boostScript = rtrim($paths['home_dir'], '/') . '/Install/Installer/luxtronik/set_manual_boost.py';
        shell_exec(escapeshellarg($python) . " " . escapeshellarg($boostScript) . " on > /dev/null 2>&1");
    }
    
    // Dienst neu starten
    shell_exec("sudo systemctl restart $serviceName > /dev/null 2>&1 &");
    
    // Seite neu laden (JS Redirect um POST-Daten loszuwerden)
    echo "<script>window.location.href = window.location.href;</script>";
    exit;
}

// Dienst-Status prüfen
$serviceStatus = trim(shell_exec("sudo systemctl is-active $serviceName"));
$isServiceRunning = ($serviceStatus === 'active');

if (file_exists($ramdiskFile)) {
    $json = json_decode(file_get_contents($ramdiskFile), true);
} 

// FALLBACK NUR NUTZEN, WENN DER DIENST AUSGESCHALTET IST
if (!$json && !$isServiceRunning) {
    $python = getPythonInterpreter();
    $script = rtrim($paths['home_dir'], '/') . '/Install/Installer/luxtronik/get_luxtronik.py';
    // Der $configFile (e3dc.config.txt) wird nicht mehr übergeben. Das Python-Skript
    // liest seine Konfiguration nun direkt aus der 'config.lux.json' im selben Verzeichnis.
    $cmd = escapeshellarg($python) . " " . escapeshellarg($script);
    $output = shell_exec($cmd);
    $json = json_decode($output, true);
}

// Falls immer noch kein JSON da ist, ein leeres Objekt erstellen
if (!$json) {
    $json = ['success' => false, 'error' => 'Warte auf Daten vom Hintergrunddienst...', 'data' => [], 'status' => []];
}

$data = $json['data'] ?? [];
$status = $json['status'] ?? [];
$success = $json['success'] ?? false;
$error = $json['error'] ?? ($json['error'] ?? '');

// Neustart auslösen (Absturzsicher)
if (isset($_POST['restart_manager'])) {
    // Dienst im Hintergrund neu starten
    shell_exec("sudo systemctl restart $serviceName > /dev/null 2>&1 &");
    
    // JS-Redirect nutzen, da PHP header() hier crasht (Headers already sent)
    echo "<script>window.location.href = window.location.href;</script>";
    exit;
}

// Zeitstempel der Dateien für die Anzeige
$configMtime = file_exists($configFile) ? date("H:i:s d.m.", filemtime($configFile)) : '--';
$pyMtime = file_exists($luxInstallDir . 'energy_manager.py') ? date("H:i:s d.m.", filemtime($luxInstallDir . 'energy_manager.py')) : '--';

// NEU: WP-Verbrauch Logik (Präzise vs. Live-Fallback)
$wp_power_w = 0;
$wp_source = 'live';

if (isset($data['Leistung_Verdichter_W'])) {
    $wp_power_w = $data['Leistung_Verdichter_W'] ?? 0;

    // Fix: Wenn Verdichter aus ist, Verbrauch auf 0 setzen (verhindert "eingefrorene" Werte)
    if (empty($data['Verdichter_Ein'])) {
        $wp_power_w = 0;
    }
    $wp_source = 'luxtronik';
} else {
    $liveFile = '/var/www/html/ramdisk/live.txt';
    if (file_exists($liveFile)) {
        $content = file_get_contents($liveFile);
        if (preg_match('/WP.*?([\d\.]+)\s*W/', $content, $m)) {
            $wp_power_w = (float)$m[1] * 1000;
        }
    }
}

$cop = 0;
if ($wp_power_w > 0 && !empty($data['Leistung_Heiz_kW'])) {
    $cop = ($data['Leistung_Heiz_kW'] * 1000) / $wp_power_w;
}

// Frequenz Berechnung (Näherung)
// Frequenz Berechnung (Neu - 2D-Interpolation nach Vorlauf- und Quellentemperatur)
$calc_freq = 0;
if ($wp_power_w > 0) {
    // Basis-Grenzwerte der Frequenz (laut SWCV 122 Datenblatt)
    $f_min = 20.0;
    $f_max = 94.0;
    $delta_f = $f_max - $f_min; // 74.0 Hz

    // Aktuelle Sensordaten abgreifen (mit Fallbacks für Stabilität)
    $T_quelle = $data['Sole_Ein'] ?? 0.0; 
    $T_vl = $data['Vorlauf_Ist'] ?? 35.0; 
    $P_e = $wp_power_w / 1000.0; // W in kW
    $Q_h = $data['Leistung_Heiz_kW'] ?? 0.0;

    // --- 1. Elektrische Leistungsgrenzen (f1) ---
    // Aus Pe-Diagramm (SWCV 122): 
    // Pe_max steigt um ca. 0.045 kW pro °C Vorlauf über 35°C und ca. 0.02 kW pro °C Quelle.
    // Pe_min steigt um ca. 0.025 kW pro °C Vorlauf über 35°C.
    $P_e_min = 0.5 + 0.025 * ($T_vl - 35.0);
    $P_e_max = 3.2 + 0.045 * ($T_vl - 35.0) + 0.02 * $T_quelle;
    
    // Clamping & Berechnung f1
    $P_e_clamped = max($P_e_min, min($P_e_max, $P_e));
    $f1 = $f_min;
    $p_diff = $P_e_max - $P_e_min;
    if ($p_diff > 0) {
        $f1 = $f_min + (($P_e_clamped - $P_e_min) / $p_diff) * $delta_f;
    }

    // --- 2. Thermische Leistungsgrenzen (f2) ---
    // Aus Qh-Diagramm:
    // Qh_max sinkt bei höherem Vorlauf (-0.05 kW/°C), steigt stark mit Quelle (+0.35 kW/°C).
    // Qh_min steigt leicht mit Vorlauf (+0.04 kW/°C) und Quelle (+0.08 kW/°C).
    $Q_h_min = 2.2 + 0.04 * ($T_vl - 35.0) + 0.08 * $T_quelle;
    $Q_h_max = 13.0 - 0.05 * ($T_vl - 35.0) + 0.35 * $T_quelle;
    
    // Clamping & Berechnung f2
    $Q_h_clamped = max($Q_h_min, min($Q_h_max, $Q_h));
    $f2 = $f_min;
    $q_diff = $Q_h_max - $Q_h_min;
    if ($q_diff > 0) {
        $f2 = $f_min + (($Q_h_clamped - $Q_h_min) / $q_diff) * $delta_f;
    }

    // --- 3. Kombinierte Formel ---
    // Gewichtung bleibt bei 60% Elektrisch, 40% Thermisch
    $calc_freq_raw = (0.6 * $f1) + (0.4 * $f2);
    
    // Finaler Sanity Check: Frequenz hart auf 20-94 Hz begrenzen
    $calc_freq = max($f_min, min($f_max, $calc_freq_raw));
}

// Neue, feinere COP-Farblogik
$copColor = 'text-secondary'; // Grau, wenn aus
if ($cop > 0) {
    if ($cop >= 4.8) {
        $copColor = 'text-success fw-bolder';   // Grün & extra fett: Überragend!
    } elseif ($cop >= 3.8) {
        $copColor = 'text-info';                // Blau: Sehr guter Normalbetrieb
    } elseif ($cop >= 2.8) {
        $copColor = 'text-warning';             // Gelb: Akzeptabel (z.B. bei extremer Kälte oder hoher WW-Temp)
    } else {
        $copColor = 'text-danger';              // Rot: Unterdurchschnittlich (evtl. Abtau-Phase)
    }
}

// Stats Logic (Min/Max Tracking für den Tag)
$statsFile = '/var/www/html/ramdisk/luxtronik_stats.json';
$historyFile = '/var/www/html/ramdisk/luxtronik_history.json';
$today = date('Y-m-d');
$stats = ['date' => $today, 'p_min' => null, 'p_max' => 0, 'cop_min' => null, 'cop_max' => 0];

// Versuch: Stats aus History berechnen (genauer)
$historyUsed = false;
if (file_exists($historyFile)) {
    $lines = @file($historyFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines !== false) {
        $historyUsed = true;
        foreach ($lines as $line) {
            $row = json_decode($line, true);
            if (!$row || !isset($row['ts']) || strpos($row['ts'], $today) !== 0) continue;

            $d = $row['data'] ?? [];
            $p = floatval($d['Leistung_Heiz_kW'] ?? 0);
            $cons = floatval($d['Leistung_Verdichter_W'] ?? 0);
            
            $c = ($cons > 0 && $p > 0) ? ($p * 1000) / $cons : 0;

            if ($p > 0) {
                if ($stats['p_min'] === null || $p < $stats['p_min']) $stats['p_min'] = $p;
                if ($p > $stats['p_max']) $stats['p_max'] = $p;
            }
            if ($c > 0) {
                if ($stats['cop_min'] === null || $c < $stats['cop_min']) $stats['cop_min'] = $c;
                if ($c > $stats['cop_max']) $stats['cop_max'] = $c;
            }
        }
    }
}

// Fallback auf einfache Stats-Datei
if (!$historyUsed && file_exists($statsFile)) {
    $tmp = json_decode(file_get_contents($statsFile), true);
    if ($tmp && isset($tmp['date']) && $tmp['date'] === $today) $stats = $tmp;
}

// Boost
if (isset($_POST['manual_boost'])) {
    $action = $_POST['manual_boost'] == 'on' ? 'on' : 'off';
    $python = getPythonInterpreter();
    $boostScript = rtrim($paths['home_dir'], '/') . '/Install/Installer/luxtronik/set_manual_boost.py';
    shell_exec(escapeshellarg($python) . " " . escapeshellarg($boostScript) . " " . $action);
}

// Prüfen, ob Flag existiert
$manualBoostActive = file_exists('/var/www/html/ramdisk/manual_boost.flag');
if ($success) {
    $currP = $data['Leistung_Heiz_kW'] ?? 0;
    if ($currP > 0) {
        if ($stats['p_min'] === null || $currP < $stats['p_min']) $stats['p_min'] = $currP;
        if ($currP > $stats['p_max']) $stats['p_max'] = $currP;
    }
    
    if ($cop > 0) {
        if ($stats['cop_min'] === null || $cop < $stats['cop_min']) $stats['cop_min'] = $cop;
        if ($cop > $stats['cop_max']) $stats['cop_max'] = $cop;
    }
    if (!$historyUsed) file_put_contents($statsFile, json_encode($stats));
}

$p_min_disp = ($stats['p_min'] !== null) ? number_format($stats['p_min'], 1, ',', '.') : '--';
$p_max_disp = number_format($stats['p_max'], 1, ',', '.');
$cop_min_disp = ($stats['cop_min'] !== null) ? number_format($stats['cop_min'], 2, ',', '.') : '--';
$cop_max_disp = number_format($stats['cop_max'], 2, ',', '.');

function fmtVal($val, $unit='') {
    if (!isset($val) || $val === '--') return '--';
    return number_format((float)$val, 1, ',', '.') . $unit;
}

$jaz = 0;
if (!empty($data['Energie_Elek_kWh']) && $data['Energie_Elek_kWh'] > 0) {
    $jaz = $data['Energie_Waerme_kWh'] / $data['Energie_Elek_kWh'];
}

function getModeText($val) {
    if (!isset($val)) return '--';
    $modes = [0 => 'Aus', 1 => 'Setpoint', 2 => 'Offset', 3 => 'Level'];
    return $modes[$val] ?? '--';
}

// Config laden für Editor
$conf = [];
if (file_exists($configFile)) {
    $conf = json_decode(file_get_contents($configFile), true);
}
// Defaults falls Werte fehlen
$conf['luxtronik'] = $conf['luxtronik'] ?? 1;
$conf['auto_mode'] = $conf['auto_mode'] ?? 1;
$conf['luxtronik_ip'] = $conf['luxtronik_ip'] ?? '192.168.178.88';
$conf['GRID_START_LIMIT'] = $conf['GRID_START_LIMIT'] ?? -3500;
$conf['MIN_SOC'] = $conf['MIN_SOC'] ?? 80;
$conf['AT_LIMIT'] = $conf['AT_LIMIT'] ?? 10.0;
$conf['WWS'] = $conf['WWS'] ?? 50.0;
$conf['WWW'] = $conf['WWW'] ?? 48.0;
$conf['HZ'] = $conf['HZ'] ?? 50.0;

$autoMode = $json['auto_mode'] ?? $conf['auto_mode'];
?>

<div id="luxtronik-card" class="card shadow-sm mb-4" style="border-radius: 16px;">
    <div class="card-body p-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="card-title text-info fw-bold m-0"><i class="fas fa-water me-2"></i>Luxtronik Status</h5>
            <div>
                <?php if($success): ?>
                    <span class="badge bg-success">Verbunden</span>
                    <?php if($autoMode == 0): ?>
                        <span class="badge bg-secondary ms-1">Automatik Aus</span>
                    <?php endif; ?>
                <?php else: ?>
                    <span class="badge bg-danger">Fehler</span>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!$success): ?>
            <?php if (strpos($error, 'Dienst startet gerade') !== false): ?>
                <div class="alert alert-info d-flex align-items-center shadow-sm">
                    <i class="fas fa-spinner fa-spin me-3 fs-3 text-info"></i>
                    <div>
                        <strong>Wärmepumpe wird abgefragt...</strong><br>
                        <small>Der Hintergrunddienst sammelt die ersten Daten. Bitte kurzen Moment Geduld.</small>
                    </div>
                </div>
                <script>
                    setTimeout(function() {
                        window.location.href = window.location.href;
                    }, 3000);
                </script>
            <?php else: ?>
                <div class="alert alert-danger shadow-sm">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Verbindung fehlgeschlagen: <small><?= htmlspecialchars($error) ?></small>
                </div>
            <?php endif; ?>
        <?php else: ?>

        <?php if (isset($data['Fehler_Nr']) && $data['Fehler_Nr'] > 0): ?>
            <div class="alert alert-danger d-flex align-items-center mb-3">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <div>
                    <strong>Störung!</strong> Fehlercode: <strong><?= $data['Fehler_Nr'] ?></strong>
                </div>
            </div>
        <?php endif; ?>

        <div class="mb-3">
            <form method="post" class="d-inline">
                <?php if ($manualBoostActive): ?>
                    <button type="submit" name="manual_boost" value="off" class="btn btn-danger w-100 fw-bold shadow-sm">
                        <i class="fas fa-bolt-lightning me-2"></i> MORGEN-BOOST STOPPEN
                    </button>
                <?php else: ?>
                    <button type="submit" name="manual_boost" value="on" class="btn btn-outline-warning w-100 fw-bold shadow-sm">
                        <i class="fas fa-battery-empty me-2"></i> BATTERIE LEEREN (FULL POWER)
                    </button>
                <?php endif; ?>
            </form>
        </div>

        <h6 class="text-muted text-uppercase small fw-bold mb-2">Effizienz & Leistung</h6>
        <div class="row g-2 mb-3">
            <div class="col-6 col-md-3">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle text-center h-100 d-flex flex-column justify-content-center">
                    <div class="small text-muted">Akt. Heizleistung</div>
                    <div class="fs-5 fw-bold"><?= fmtVal($data['Leistung_Heiz_kW'] ?? 0, ' kW') ?></div>
                    <div class="d-flex justify-content-center gap-2 text-muted" style="font-size:0.7rem;">
                        <span class="text-nowrap">Min: <?= $p_min_disp ?></span>
                        <span class="text-nowrap">Max: <?= $p_max_disp ?></span>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle text-center h-100 d-flex flex-column justify-content-center">
                    <div class="small text-muted" title="Datenquelle: <?= $wp_source ?>">Akt. Verbrauch<?= $wp_source !== 'luxtronik' ? ' <i class="fas fa-info-circle small text-muted"></i>' : '' ?></div>
                    <div class="fs-5 fw-bold text-warning"><?= number_format($wp_power_w / 1000, 2, ',', '.') ?> kW</div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle text-center h-100 d-flex flex-column justify-content-center">
                    <div class="small text-muted">COP</div>
                    <div class="fs-5 fw-bold <?= $copColor ?>"><?= ($cop > 0) ? number_format($cop, 2, ',', '.') : '--' ?></div>
                    <div class="d-flex justify-content-center gap-2 text-muted" style="font-size:0.7rem;">
                        <span class="text-nowrap">Min: <?= $cop_min_disp ?></span>
                        <span class="text-nowrap">Max: <?= $cop_max_disp ?></span>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle text-center h-100 d-flex flex-column justify-content-center">
                    <div class="small text-muted">JAZ (Gesamt)</div>
                    <div class="fs-5 fw-bold text-success"><?= number_format($jaz, 2, ',', '.') ?></div>
                </div>
            </div>
            <div class="col-12 mt-2">
                <div class="d-flex justify-content-around align-items-center p-2 bg-body-tertiary rounded border border-secondary-subtle">
                    <span class="small">∑ Wärme: <b><?= fmtVal($data['Energie_Waerme_kWh'], ' kWh') ?></b></span>
                    <span class="small">∑ Strom: <b><?= fmtVal($data['Energie_Elek_kWh'], ' kWh') ?></b></span>
                </div>
            </div>
        </div>

        <h6 class="text-muted text-uppercase small fw-bold mb-2">Status & Wärmequelle (Sole)</h6>
        <div class="row g-2 mb-3">
            <div class="col-12">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle d-flex justify-content-between align-items-center">
                    <div>
                        <span class="small text-muted me-2">Status:</span>
                        <?php if(!empty($data['Verdichter_Ein'])): ?>
                            <span class="badge bg-warning text-dark"><i class="fas fa-sync fa-spin me-1"></i> Verdichter läuft</span>
                            <?php if($calc_freq > 0): ?>
                                <span class="badge bg-info text-dark ms-1" title="Berechnet aus P_el"><?= number_format($calc_freq, 1, ',', '.') ?> Hz</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="badge bg-secondary">Bereit / Aus</span>
                        <?php endif; ?>
                    </div>
                    <div class="text-center">
                        <?php 
                            $ba = $data['Betriebsart'] ?? -1;
                            $baClass = 'bg-secondary';
                            $baText = '--';
                            if ($ba == 0) { $baClass = 'bg-warning text-dark'; $baText = 'Heizen'; }
                            elseif ($ba == 1) { $baClass = 'bg-danger'; $baText = 'Warmwasser'; }
                            elseif ($ba == 3) { $baClass = 'bg-primary'; $baText = 'EVU-Sperre'; }
                            elseif ($ba == 5) { $baClass = 'bg-secondary'; $baText = 'Aus'; }
                        ?>
                        <span class="badge <?= $baClass ?>"><?= $baText ?></span>
                    </div>
                    <div class="text-end">
                        <span class="small text-info">Ein: <?= fmtVal($data['Sole_Ein'] ?? '--', '°C') ?></span>
                        <span class="small text-primary ms-3">Aus: <?= fmtVal($data['Sole_Aus'] ?? '--', '°C') ?></span>
                    </div>
                </div>
            </div>
        </div>

        <h6 class="text-muted text-uppercase small fw-bold mb-2">Temperaturen</h6>
        <div class="row g-2 mb-3">
            <div class="col-6 col-md-3 text-center">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle">
                    <div class="small text-muted">Außen</div>
                    <div class="fs-5 fw-bold"><?= fmtVal($data['Aussentemp'], '°C') ?></div>
                    <div class="text-muted" style="font-size:0.75rem">Mittel: <?= fmtVal($data['Aussentemp_Mittel'] ?? '--', '°C') ?></div>
                </div>
            </div>
            <div class="col-6 col-md-3 text-center">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle">
                    <div class="small text-muted">Warmwasser</div>
                    <div class="fs-5 fw-bold text-warning"><?= fmtVal($data['Warmwasser_Ist'], '°C') ?></div>
                    <div class="text-muted" style="font-size:0.75rem">Soll: <?= fmtVal($data['Warmwasser_Soll'] ?? '--', '°C') ?></div>
                </div>
            </div>
            <div class="col-6 col-md-3 text-center">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle">
                    <div class="small text-muted">Vorlauf</div>
                    <div class="fs-5 fw-bold text-danger"><?= fmtVal($data['Vorlauf_Ist'], '°C') ?></div>
                    <div class="text-muted" style="font-size:0.75rem">Istwert</div>
                </div>
            </div>
            <div class="col-6 col-md-3 text-center">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle">
                    <div class="small text-muted">Rücklauf</div>
                    <div class="fs-5 fw-bold text-info"><?= fmtVal($data['Ruecklauf_Ist'], '°C') ?></div>
                    <div class="d-flex justify-content-center gap-2 text-muted" style="font-size:0.7rem;">
                        <span class="text-nowrap">Soll: <?= fmtVal($data['Ruecklauf_Soll']) ?></span>
                        <span class="text-nowrap">Ext: <?= fmtVal($data['Ruecklauf_Extern'] ?? '--') ?></span>
                    </div>
                </div>
            </div>
        </div>

        <h6 class="text-muted text-uppercase small fw-bold mb-2">Smart Home Interface Status</h6>
        <div class="row g-2">
            <div class="col-6">
                <div class="p-2 bg-dark-subtle rounded border border-secondary-subtle">
                    <div class="small text-muted">Modus Heizung</div>
                    <span class="badge bg-primary"><?= getModeText($status['HZ_Mode'] ?? null) ?></span>
                    <span class="small ms-2">SHI-Soll: <?= fmtVal($status['HZ_Setpoint'] ?? '--', '°C') ?></span>
                </div>
            </div>
            <div class="col-6">
                <div class="p-2 bg-dark-subtle rounded border border-secondary-subtle">
                    <div class="small text-muted">Modus WW</div>
                    <span class="badge bg-warning text-dark"><?= getModeText($status['WW_Mode'] ?? null) ?></span>
                    <span class="small ms-2">SHI-Soll: <?= fmtVal($status['WW_Setpoint'] ?? '--', '°C') ?></span>
                </div>
            </div>
        </div>

        <h6 class="text-muted text-uppercase small fw-bold mb-2">Service-Steuerung & Updates</h6>
        <div class="row g-2 mb-3">
            <div class="col-12">
                <div class="p-3 bg-body-tertiary rounded border border-secondary-subtle">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div>
                            <span class="small text-muted me-2">Energy-Manager:</span>
                            <span class="badge <?= $isServiceRunning ? 'bg-success' : 'bg-danger' ?>">
                                <?= strtoupper($serviceStatus) ?>
                            </span>
                        </div>
                        <div class="d-flex gap-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="toggleLuxConfig()">
                                <i class="fas fa-cog"></i> Einstellungen
                            </button>
                            <form method="post" class="d-inline">
                            <button type="submit" name="restart_manager" class="btn btn-sm btn-outline-info">
                                <i class="fas fa-sync-alt"></i> Neustart
                            </button>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Config Editor (Hidden by default) -->
                    <div id="lux-config-form" style="display:none;" class="mt-3 border-top pt-3">
                        <form method="post">
                            <div class="form-check form-switch mb-3">
                                <input class="form-check-input" type="checkbox" name="luxtronik_active" id="luxActive" <?= $conf['luxtronik'] ? 'checked' : '' ?>>
                                <label class="form-check-label" for="luxActive">Luxtronik Integration (UI & Dienst)</label>
                            </div>
                            
                            <div class="form-check form-switch mb-3">
                                <input class="form-check-input" type="checkbox" name="auto_mode" id="luxAuto" <?= $conf['auto_mode'] ? 'checked' : '' ?>>
                                <label class="form-check-label" for="luxAuto">Automatik-Regelung (Energy Manager)</label>
                            </div>
                            
                            <div class="row g-2 mb-2">
                                <div class="col-md-6">
                                    <label class="form-label small">IP-Adresse</label>
                                    <input type="text" class="form-control form-control-sm" name="luxtronik_ip" value="<?= htmlspecialchars($conf['luxtronik_ip']) ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small">Start-Grenze (Watt, negativ=Einspeisung)</label>
                                    <input type="number" class="form-control form-control-sm" name="GRID_START_LIMIT" value="<?= $conf['GRID_START_LIMIT'] ?>">
                                </div>
                            </div>
                            
                            <div class="row g-2 mb-2">
                                <div class="col-6 col-md-3">
                                    <label class="form-label small">Min SoC (%)</label>
                                    <input type="number" class="form-control form-control-sm" name="MIN_SOC" value="<?= $conf['MIN_SOC'] ?>">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small">Außentemp. Limit (°C)</label>
                                    <input type="number" step="0.1" class="form-control form-control-sm" name="AT_LIMIT" value="<?= $conf['AT_LIMIT'] ?>">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small">WW Soll Sommer (°C)</label>
                                    <input type="number" step="0.1" class="form-control form-control-sm" name="WWS" value="<?= $conf['WWS'] ?>">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small">WW Soll Winter (°C)</label>
                                    <input type="number" step="0.1" class="form-control form-control-sm" name="WWW" value="<?= $conf['WWW'] ?>">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small">Heizung Soll (°C)</label>
                                    <input type="number" step="0.1" class="form-control form-control-sm" name="HZ" value="<?= $conf['HZ'] ?>">
                                </div>
                            </div>
                            
                            <button type="submit" name="save_config" class="btn btn-primary btn-sm w-100 mt-2">
                                <i class="fas fa-save me-1"></i> Speichern & Dienst neustarten
                            </button>
                        </form>
                    </div>

                    <div class="row g-0 border-top pt-2 mt-2">
                        <div class="col-6 small text-muted">
                            <i class="fas fa-file-code me-1"></i> energy_manager.py: <b><?= $pyMtime ?></b>
                        </div>
                        <div class="col-6 small text-muted">
                            <i class="fas fa-cog me-1"></i> config.lux.json: <b><?= $configMtime ?></b>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
var isLuxtronikEditing = false;

function toggleLuxConfig() {
    var form = document.getElementById('lux-config-form');
    if (form.style.display === 'none') {
        form.style.display = 'block';
        isLuxtronikEditing = true; // Stop auto-refresh
    } else {
        form.style.display = 'none';
        isLuxtronikEditing = false; // Resume auto-refresh
    }
}

// Funktion zum automatischen Neuladen der Daten
function refreshLuxtronik() {
    // Nicht aktualisieren, wenn User gerade editiert
    if (typeof isLuxtronikEditing !== 'undefined' && isLuxtronikEditing) return;

    // Wir suchen das Element mit der ID 'luxtronik-card'
    // Hinweis: Du musst deiner ersten <div class="card..."> die ID 'luxtronik-card' geben!
    const container = document.getElementById('luxtronik-card');
    if (!container) return;

    // Wir laden einfach den Inhalt der aktuellen Seite neu und extrahieren die Karte
    fetch(window.location.href)
        .then(response => response.text())
        .then(html => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const newContent = doc.getElementById('luxtronik-card').innerHTML;
            container.innerHTML = newContent;
            console.log("Luxtronik Daten aktualisiert: " + new Date().toLocaleTimeString());
        })
        .catch(err => console.warn('Update fehlgeschlagen:', err));
}

// Alle 30 Sekunden aktualisieren
setInterval(refreshLuxtronik, 30000);
</script>