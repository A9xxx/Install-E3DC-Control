<?php
// luxtronik.php - Optimierte Anzeige mit Wärmequelle und Soll-Werten

if (!isset($base_path) || !isset($paths)) {
    $paths = getInstallPaths();
    $base_path = rtrim($paths['install_path'], '/') . '/';
}

// Versuche zuerst, die Ramdisk-Datei zu lesen (viel schneller!)
// ... Pfade laden wie gehabt ...

$ramdiskFile = '/var/www/html/ramdisk/luxtronik.json';
$json = null;

// Konfigurations-Pfad (im Installationsverzeichnis)
$luxInstallDir = rtrim($paths['home_dir'], '/') . '/Install/Installer/luxtronik/';
$configFile = $luxInstallDir . 'config.lux.json';
$serviceName = 'energy_manager'; // Name des Systemd-Services

// Speichern der Konfiguration
if (isset($_POST['save_config'])) {
    // Bestehende Konfiguration laden, um Werte zu erhalten, die nicht im Formular sind
    $currentConf = [];
    if (file_exists($configFile)) {
        $decoded = json_decode(file_get_contents($configFile), true);
        if (is_array($decoded)) {
            $currentConf = $decoded;
        }
    }

    // Prüfen, ob wir im "Nur-Laden-Modus" waren (für bedingte Felder)
    $wasChargingOnly = ($currentConf['luxtronik'] ?? 0) == 0;

    $newConf = [
        'luxtronik' => isset($_POST['luxtronik_active']) ? 1 : 0,
        'auto_mode' => isset($_POST['auto_mode']) ? 1 : 0,
        'luxtronik_ip' => $_POST['luxtronik_ip'] ?? ($currentConf['luxtronik_ip'] ?? ''),
        'GRID_START_LIMIT' => (int)($_POST['GRID_START_LIMIT'] ?? ($currentConf['GRID_START_LIMIT'] ?? -3500)),
        'MIN_SOC' => (int)($_POST['MIN_SOC'] ?? ($currentConf['MIN_SOC'] ?? 80)),
        'AT_LIMIT' => (float)($_POST['AT_LIMIT'] ?? ($currentConf['AT_LIMIT'] ?? 10.0)),
        'WWS' => (float)($_POST['WWS'] ?? ($currentConf['WWS'] ?? 50.0)),
        'WWW' => (float)($_POST['WWW'] ?? ($currentConf['WWW'] ?? 48.0)),
        'HZ' => (float)($_POST['HZ'] ?? ($currentConf['HZ'] ?? 32.0)),
        'price_boost_enable' => (!$wasChargingOnly) ? (isset($_POST['price_boost_enable']) ? 1 : 0) : ($currentConf['price_boost_enable'] ?? 0),
        'price_limit' => (float)($_POST['price_limit'] ?? ($currentConf['price_limit'] ?? 20.0)),
        'price_hard_limit' => (float)($_POST['price_hard_limit'] ?? ($currentConf['price_hard_limit'] ?? -99.0)),
        'price_min_duration' => (int)($_POST['price_min_duration'] ?? ($currentConf['price_min_duration'] ?? 60)),
        'price_max_daily' => (int)($_POST['price_max_daily'] ?? ($currentConf['price_max_daily'] ?? 180)),
        'stop_delay_minutes' => (int)($_POST['stop_delay_minutes'] ?? ($currentConf['stop_delay_minutes'] ?? 10)),
        'manual_boost_max_duration' => (int)($_POST['manual_boost_max_duration'] ?? ($currentConf['manual_boost_max_duration'] ?? 180)),
        'rl_source' => $_POST['rl_source'] ?? ($currentConf['rl_source'] ?? 'internal'),
        'wq_min_temp' => (float)($_POST['wq_min_temp'] ?? ($currentConf['wq_min_temp'] ?? 1.0)),
        'manual_boost_min_soc' => (int)($_POST['manual_boost_min_soc'] ?? ($currentConf['manual_boost_min_soc'] ?? 25)),
        'pv_pause_enable' => isset($_POST['pv_pause_enable']) ? 1 : 0,
        'pv_pause_soc' => (int)($_POST['pv_pause_soc'] ?? ($currentConf['pv_pause_soc'] ?? 80)),
        'pv_pause_watt' => (float)($_POST['pv_pause_watt'] ?? ($currentConf['pv_pause_watt'] ?? 3000.0)),
        'pv_pause_timeout_minutes' => (int)($_POST['pv_pause_timeout_minutes'] ?? ($currentConf['pv_pause_timeout_minutes'] ?? 120)),
        // Morning Boost Config
        'morning_boost_enable' => isset($_POST['morning_boost_enable']) ? 1 : 0,
        'morning_boost_prio' => $_POST['morning_boost_prio'] ?? 'wallbox',
        'morning_boost_wb_power' => (float)($_POST['morning_boost_wb_power'] ?? 7.0),
        'morning_boost_min_hours' => (int)($_POST['morning_boost_min_hours'] ?? 3),
        'morning_boost_min_pv_pct' => (float)($_POST['morning_boost_min_pv_pct'] ?? 50.0),
        'morning_boost_target_soc' => (int)($_POST['morning_boost_target_soc'] ?? 20),
        'morning_boost_deadline' => (int)($_POST['morning_boost_deadline'] ?? 8),
        // Super Intelligence Config
        'super_intelligence_enable' => isset($_POST['super_intelligence_enable']) ? 1 : 0,
        'super_intelligence_deadline' => (int)($_POST['super_intelligence_deadline'] ?? 8),
        // Telegram Notification
        'telegram_token' => $_POST['telegram_token'] ?? ($currentConf['telegram_token'] ?? ''),
        'telegram_chat_id' => $_POST['telegram_chat_id'] ?? ($currentConf['telegram_chat_id'] ?? ''),
    ];

    // JSON speichern
    file_put_contents($configFile, json_encode($newConf, JSON_PRETTY_PRINT));
    
    // Wenn manueller Boost aktiv ist, müssen die neuen Werte sofort an die WP gesendet werden
    if (file_exists('/var/www/html/ramdisk/manual_boost.flag')) {
        $python = getPythonInterpreter();
        $boostScript = rtrim($paths['home_dir'], '/') . '/Install/Installer/luxtronik/set_manual_boost.py';
        shell_exec(escapeshellarg($python) . " " . escapeshellarg($boostScript) . " on > /dev/null 2>&1");
    }
    
    // Dienst neu starten
    shell_exec("sudo systemctl restart $serviceName > /dev/null 2>&1 &");
    
    // Seite neu laden (JS Redirect um POST-Daten loszuwerden)
    echo "<script>window.location.href = window.location.href;</script>";
    exit;
}

// Dienst-Status prüfen
$serviceStatus = trim(shell_exec("sudo systemctl is-active $serviceName"));
$isServiceRunning = ($serviceStatus === 'active');

if (file_exists($ramdiskFile)) {
    $json = json_decode(file_get_contents($ramdiskFile), true);
} 

// FALLBACK NUR NUTZEN, WENN DER DIENST AUSGESCHALTET IST
if (!$json && !$isServiceRunning) {
    $python = getPythonInterpreter();
    $script = rtrim($paths['home_dir'], '/') . '/Install/Installer/luxtronik/get_luxtronik.py';
    // Der $configFile (e3dc.config.txt) wird nicht mehr übergeben. Das Python-Skript
    // liest seine Konfiguration nun direkt aus der 'config.lux.json' im selben Verzeichnis.
    $cmd = escapeshellarg($python) . " " . escapeshellarg($script);
    $output = shell_exec($cmd);
    $json = json_decode($output, true);
}

// Falls immer noch kein JSON da ist, ein leeres Objekt erstellen
if (!$json) {
    $json = ['success' => false, 'error' => 'Warte auf Daten vom Hintergrunddienst...', 'data' => [], 'status' => []];
}

$data = $json['data'] ?? [];
$status = $json['status'] ?? [];
$success = $json['success'] ?? false;
$error = $json['error'] ?? ($json['error'] ?? '');

// Neustart auslösen (Absturzsicher)
if (isset($_POST['restart_manager'])) {
    // Dienst im Hintergrund neu starten
    shell_exec("sudo systemctl restart $serviceName > /dev/null 2>&1 &");
    
    // JS-Redirect nutzen, da PHP header() hier crasht (Headers already sent)
    echo "<script>window.location.href = window.location.href;</script>";
    exit;
}

// Zeitstempel der Dateien für die Anzeige
$configMtime = file_exists($configFile) ? date("H:i:s d.m.", filemtime($configFile)) : '--';
$pyMtime = file_exists($luxInstallDir . 'energy_manager.py') ? date("H:i:s d.m.", filemtime($luxInstallDir . 'energy_manager.py')) : '--';

// NEU: WP-Verbrauch Logik (Präzise vs. Live-Fallback)
$wp_power_w = 0;
$wp_source = 'live';

if (isset($data['Leistung_Verdichter_W'])) {
    $wp_power_w = $data['Leistung_Verdichter_W'] ?? 0;

    // Fix: Wenn Verdichter aus ist, Verbrauch auf 0 setzen (verhindert "eingefrorene" Werte)
    if (empty($data['Verdichter_Ein'])) {
        $wp_power_w = 0;
    }
    $wp_source = 'luxtronik';
} else {
    $liveFile = '/var/www/html/ramdisk/live.txt';
    if (file_exists($liveFile)) {
        $content = file_get_contents($liveFile);
        if (preg_match('/WP.*?([\d\.]+)\s*W/', $content, $m)) {
            $wp_power_w = (float)$m[1] * 1000;
        }
    }
}

$cop = 0;
if ($wp_power_w > 0 && !empty($data['Leistung_Heiz_kW'])) {
    $cop = ($data['Leistung_Heiz_kW'] * 1000) / $wp_power_w;
}

// Frequenz Berechnung (Näherung)
// Frequenz Berechnung (Neu - 2D-Interpolation nach Vorlauf- und Quellentemperatur)
$calc_freq = 0;
if ($wp_power_w > 0) {
    // Basis-Grenzwerte der Frequenz (laut SWCV 122 Datenblatt)
    $f_min = 20.0;
    $f_max = 94.0;
    $delta_f = $f_max - $f_min; // 74.0 Hz

    // Aktuelle Sensordaten abgreifen (mit Fallbacks für Stabilität)
    $T_quelle = $data['Sole_Ein'] ?? 0.0; 
    $T_vl = $data['Vorlauf_Ist'] ?? 35.0; 
    $P_e = $wp_power_w / 1000.0; // W in kW
    $Q_h = $data['Leistung_Heiz_kW'] ?? 0.0;

    // --- 1. Elektrische Leistungsgrenzen (f1) ---
    // Aus Pe-Diagramm (SWCV 122): 
    // Pe_max steigt um ca. 0.045 kW pro °C Vorlauf über 35°C und ca. 0.02 kW pro °C Quelle.
    // Pe_min steigt um ca. 0.025 kW pro °C Vorlauf über 35°C.
    $P_e_min = 0.5 + 0.025 * ($T_vl - 35.0);
    $P_e_max = 3.2 + 0.045 * ($T_vl - 35.0) + 0.02 * $T_quelle;
    
    // Clamping & Berechnung f1
    $P_e_clamped = max($P_e_min, min($P_e_max, $P_e));
    $f1 = $f_min;
    $p_diff = $P_e_max - $P_e_min;
    if ($p_diff > 0) {
        $f1 = $f_min + (($P_e_clamped - $P_e_min) / $p_diff) * $delta_f;
    }

    // --- 2. Thermische Leistungsgrenzen (f2) ---
    // Aus Qh-Diagramm:
    // Qh_max sinkt bei höherem Vorlauf (-0.05 kW/°C), steigt stark mit Quelle (+0.35 kW/°C).
    // Qh_min steigt leicht mit Vorlauf (+0.04 kW/°C) und Quelle (+0.08 kW/°C).
    $Q_h_min = 2.2 + 0.04 * ($T_vl - 35.0) + 0.08 * $T_quelle;
    $Q_h_max = 13.0 - 0.05 * ($T_vl - 35.0) + 0.35 * $T_quelle;
    
    // Clamping & Berechnung f2
    $Q_h_clamped = max($Q_h_min, min($Q_h_max, $Q_h));
    $f2 = $f_min;
    $q_diff = $Q_h_max - $Q_h_min;
    if ($q_diff > 0) {
        $f2 = $f_min + (($Q_h_clamped - $Q_h_min) / $q_diff) * $delta_f;
    }

    // --- 3. Kombinierte Formel ---
    // Gewichtung bleibt bei 60% Elektrisch, 40% Thermisch
    $calc_freq_raw = (0.6 * $f1) + (0.4 * $f2);
    
    // Finaler Sanity Check: Frequenz hart auf 20-94 Hz begrenzen
    $calc_freq = max($f_min, min($f_max, $calc_freq_raw));
}

// Neue, feinere COP-Farblogik
$copColor = 'text-secondary'; // Grau, wenn aus
if ($cop > 0) {
    if ($cop >= 4.8) {
        $copColor = 'text-success fw-bolder';   // Grün & extra fett: Überragend!
    } elseif ($cop >= 3.8) {
        $copColor = 'text-info';                // Blau: Sehr guter Normalbetrieb
    } elseif ($cop >= 2.8) {
        $copColor = 'text-warning';             // Gelb: Akzeptabel (z.B. bei extremer Kälte oder hoher WW-Temp)
    } else {
        $copColor = 'text-danger';              // Rot: Unterdurchschnittlich (evtl. Abtau-Phase)
    }
}

// Stats Logic (Min/Max Tracking für den Tag)
$statsFile = '/var/www/html/ramdisk/luxtronik_stats.json';
$historyFile = '/var/www/html/ramdisk/luxtronik_history.json';
$today = date('Y-m-d');
$stats = ['date' => $today, 'p_min' => null, 'p_max' => 0, 'cop_min' => null, 'cop_max' => 0];

// Versuch: Stats aus History berechnen (genauer)
$historyUsed = false;
if (file_exists($historyFile)) {
    $lines = @file($historyFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines !== false) {
        $historyUsed = true;
        foreach ($lines as $line) {
            $row = json_decode($line, true);
            if (!$row || !isset($row['ts']) || strpos($row['ts'], $today) !== 0) continue;

            $d = $row['data'] ?? [];
            $p = floatval($d['Leistung_Heiz_kW'] ?? 0);
            $cons = floatval($d['Leistung_Verdichter_W'] ?? 0);
            
            $c = ($cons > 0 && $p > 0) ? ($p * 1000) / $cons : 0;

            if ($p > 0) {
                if ($stats['p_min'] === null || $p < $stats['p_min']) $stats['p_min'] = $p;
                if ($p > $stats['p_max']) $stats['p_max'] = $p;
            }
            if ($c > 0) {
                if ($stats['cop_min'] === null || $c < $stats['cop_min']) $stats['cop_min'] = $c;
                if ($c > $stats['cop_max']) $stats['cop_max'] = $c;
            }
        }
    }
}

// Fallback auf einfache Stats-Datei
if (!$historyUsed && file_exists($statsFile)) {
    $tmp = json_decode(file_get_contents($statsFile), true);
    if ($tmp && isset($tmp['date']) && $tmp['date'] === $today) $stats = $tmp;
}

// Boost
if (isset($_POST['manual_boost'])) {
    $action = $_POST['manual_boost'] == 'on' ? 'on' : 'off';
    $python = getPythonInterpreter();
    $boostScript = rtrim($paths['home_dir'], '/') . '/Install/Installer/luxtronik/set_manual_boost.py';
    shell_exec(escapeshellarg($python) . " " . escapeshellarg($boostScript) . " " . $action);
}

// Prüfen, ob Flag existiert
$manualBoostActive = file_exists('/var/www/html/ramdisk/manual_boost.flag');
if ($success) {
    $currP = $data['Leistung_Heiz_kW'] ?? 0;
    if ($currP > 0) {
        if ($stats['p_min'] === null || $currP < $stats['p_min']) $stats['p_min'] = $currP;
        if ($currP > $stats['p_max']) $stats['p_max'] = $currP;
    }
    
    if ($cop > 0) {
        if ($stats['cop_min'] === null || $cop < $stats['cop_min']) $stats['cop_min'] = $cop;
        if ($cop > $stats['cop_max']) $stats['cop_max'] = $cop;
    }
    if (!$historyUsed) file_put_contents($statsFile, json_encode($stats));
}

$p_min_disp = ($stats['p_min'] !== null) ? number_format($stats['p_min'], 1, ',', '.') : '--';
$p_max_disp = number_format($stats['p_max'], 1, ',', '.');
$cop_min_disp = ($stats['cop_min'] !== null) ? number_format($stats['cop_min'], 2, ',', '.') : '--';
$cop_max_disp = number_format($stats['cop_max'], 2, ',', '.');

function fmtVal($val, $unit='') {
    if (!isset($val) || $val === '--') return '--';
    return number_format((float)$val, 1, ',', '.') . $unit;
}

$jaz = 0;
if (!empty($data['Energie_Elek_kWh']) && $data['Energie_Elek_kWh'] > 0) {
    $jaz = $data['Energie_Waerme_kWh'] / $data['Energie_Elek_kWh'];
}

function getModeText($val) {
    if (!isset($val)) return '--';
    $modes = [0 => 'Aus', 1 => 'Setpoint', 2 => 'Offset', 3 => 'Level'];
    return $modes[$val] ?? '--';
}

// Config laden für Editor
$conf = [];
if (file_exists($configFile)) {
    $decoded = json_decode(file_get_contents($configFile), true);
    if (is_array($decoded)) {
        $conf = $decoded;
    }
}
// Defaults falls Werte fehlen
$conf['luxtronik'] = $conf['luxtronik'] ?? 1;
$conf['auto_mode'] = $conf['auto_mode'] ?? 1;
$conf['luxtronik_ip'] = $conf['luxtronik_ip'] ?? '192.168.178.88';
$conf['GRID_START_LIMIT'] = $conf['GRID_START_LIMIT'] ?? -3500;
$conf['MIN_SOC'] = $conf['MIN_SOC'] ?? 80;
$conf['AT_LIMIT'] = $conf['AT_LIMIT'] ?? 10.0;
$conf['WWS'] = $conf['WWS'] ?? 50.0;
$conf['WWW'] = $conf['WWW'] ?? 48.0;
    $conf['HZ'] = $conf['HZ'] ?? 32.0;
$conf['price_boost_enable'] = $conf['price_boost_enable'] ?? 0;
$conf['price_limit'] = $conf['price_limit'] ?? 20.0;
$conf['price_hard_limit'] = $conf['price_hard_limit'] ?? -99.0;
$conf['price_min_duration'] = $conf['price_min_duration'] ?? 60;
$conf['price_max_daily'] = $conf['price_max_daily'] ?? 180;
$conf['stop_delay_minutes'] = $conf['stop_delay_minutes'] ?? 10;
$conf['manual_boost_max_duration'] = $conf['manual_boost_max_duration'] ?? 180;
$conf['rl_source'] = $conf['rl_source'] ?? 'internal';
$conf['wq_min_temp'] = $conf['wq_min_temp'] ?? 1.0;
$conf['manual_boost_min_soc'] = $conf['manual_boost_min_soc'] ?? 25;
$conf['pv_pause_enable'] = $conf['pv_pause_enable'] ?? 0;
$conf['pv_pause_soc'] = $conf['pv_pause_soc'] ?? 80;
$conf['pv_pause_watt'] = $conf['pv_pause_watt'] ?? 3000.0;
$conf['pv_pause_timeout_minutes'] = $conf['pv_pause_timeout_minutes'] ?? 120;
$conf['morning_boost_enable'] = $conf['morning_boost_enable'] ?? 0;
$conf['morning_boost_prio'] = $conf['morning_boost_prio'] ?? 'wallbox';
$conf['morning_boost_wb_power'] = $conf['morning_boost_wb_power'] ?? 7.0;
$conf['morning_boost_min_hours'] = $conf['morning_boost_min_hours'] ?? 3;
$conf['morning_boost_min_pv_pct'] = $conf['morning_boost_min_pv_pct'] ?? 50.0;
$conf['morning_boost_target_soc'] = $conf['morning_boost_target_soc'] ?? 20;
$conf['morning_boost_deadline'] = $conf['morning_boost_deadline'] ?? 8;
$conf['super_intelligence_enable'] = $conf['super_intelligence_enable'] ?? 0;
$conf['super_intelligence_deadline'] = $conf['super_intelligence_deadline'] ?? 8;

$autoMode = $json['auto_mode'] ?? $conf['auto_mode'];
$isChargingOnly = ($conf['luxtronik'] == 0);
$cardTitle = $isChargingOnly ? 'Intelligentes Lademanagement' : 'Luxtronik Status';
?>

<div id="luxtronik-card" class="card shadow-sm mb-4" style="border-radius: 16px;">
    <div class="card-body p-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="card-title text-info fw-bold m-0"><i class="fas <?= $isChargingOnly ? 'fa-charging-station' : 'fa-water' ?> me-2"></i><?= $cardTitle ?></h5>
            <div>
                <?php if($success): ?>
                    <span class="badge bg-success">Verbunden</span>
                    <?php if($autoMode == 0): ?>
                        <span class="badge bg-secondary ms-1">Automatik Aus</span>
                    <?php endif; ?>
                <?php else: ?>
                    <span class="badge bg-danger">Fehler</span>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!$success && !$isChargingOnly): ?>
            <?php if (strpos($error, 'Dienst startet gerade') !== false): ?>
                <div class="alert alert-info d-flex align-items-center shadow-sm">
                    <i class="fas fa-spinner fa-spin me-3 fs-3 text-info"></i>
                    <div>
                        <strong>Wärmepumpe wird abgefragt...</strong><br>
                        <small>Der Hintergrunddienst sammelt die ersten Daten. Bitte kurzen Moment Geduld.</small>
                    </div>
                </div>
                <script>
                    setTimeout(function() {
                        window.location.href = window.location.href;
                    }, 3000);
                </script>
            <?php else: ?>
                <div class="alert alert-danger shadow-sm">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Verbindung fehlgeschlagen: <small><?= htmlspecialchars($error) ?></small>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <?php if ($success && !$isChargingOnly && isset($data['Fehler_Nr']) && $data['Fehler_Nr'] > 0): ?>
            <div class="alert alert-danger d-flex align-items-center mb-3">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <div>
                    <strong>Störung!</strong> Fehlercode: <strong><?= $data['Fehler_Nr'] ?></strong>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($success && !$isChargingOnly): ?>
        <div class="mb-3">
            <form method="post" class="d-inline">
                <?php if ($manualBoostActive): ?>
                    <button type="submit" name="manual_boost" value="off" class="btn btn-danger w-100 fw-bold shadow-sm">
                        <i class="fas fa-bolt-lightning me-2"></i> MORGEN-BOOST STOPPEN
                    </button>
                <?php else: ?>
                    <button type="submit" name="manual_boost" value="on" class="btn btn-outline-warning w-100 fw-bold shadow-sm">
                        <i class="fas fa-battery-empty me-2"></i> BATTERIE LEEREN (FULL POWER)
                    </button>
                <?php endif; ?>
            </form>
        </div>

        <h6 class="text-muted text-uppercase small fw-bold mb-2">Effizienz & Leistung</h6>
        <div class="row g-2 mb-3">
            <div class="col-6 col-md-3">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle text-center h-100 d-flex flex-column justify-content-center">
                    <div class="small text-muted">Akt. Heizleistung</div>
                    <div class="fs-5 fw-bold"><?= fmtVal($data['Leistung_Heiz_kW'] ?? 0, ' kW') ?></div>
                    <div class="d-flex justify-content-center gap-2 text-muted" style="font-size:0.7rem;">
                        <span class="text-nowrap">Min: <?= $p_min_disp ?></span>
                        <span class="text-nowrap">Max: <?= $p_max_disp ?></span>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle text-center h-100 d-flex flex-column justify-content-center">
                    <div class="small text-muted" title="Datenquelle: <?= $wp_source ?>">Akt. Verbrauch<?= $wp_source !== 'luxtronik' ? ' <i class="fas fa-info-circle small text-muted"></i>' : '' ?></div>
                    <div class="fs-5 fw-bold text-warning"><?= number_format($wp_power_w / 1000, 2, ',', '.') ?> kW</div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle text-center h-100 d-flex flex-column justify-content-center">
                    <div class="small text-muted">COP</div>
                    <div class="fs-5 fw-bold <?= $copColor ?>"><?= ($cop > 0) ? number_format($cop, 2, ',', '.') : '--' ?></div>
                    <div class="d-flex justify-content-center gap-2 text-muted" style="font-size:0.7rem;">
                        <span class="text-nowrap">Min: <?= $cop_min_disp ?></span>
                        <span class="text-nowrap">Max: <?= $cop_max_disp ?></span>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle text-center h-100 d-flex flex-column justify-content-center">
                    <div class="small text-muted">JAZ (Gesamt)</div>
                    <div class="fs-5 fw-bold text-success"><?= number_format($jaz, 2, ',', '.') ?></div>
                </div>
            </div>
            <div class="col-12 mt-2">
                <div class="d-flex justify-content-around align-items-center p-2 bg-body-tertiary rounded border border-secondary-subtle">
                    <span class="small">∑ Wärme: <b><?= fmtVal($data['Energie_Waerme_kWh'], ' kWh') ?></b></span>
                    <span class="small">∑ Strom: <b><?= fmtVal($data['Energie_Elek_kWh'], ' kWh') ?></b></span>
                </div>
            </div>
        </div>

        <h6 class="text-muted text-uppercase small fw-bold mb-2">Status & Wärmequelle (Sole)</h6>
        <div class="row g-2 mb-3">
            <div class="col-12">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle d-flex justify-content-between align-items-center">
                    <div>
                        <span class="small text-muted me-2">Status:</span>
                        <?php if(!empty($data['Verdichter_Ein'])): ?>
                            <span class="badge bg-warning text-dark"><i class="fas fa-sync fa-spin me-1"></i> Verdichter läuft</span>
                            <?php if($calc_freq > 0): ?>
                                <span class="badge bg-info text-dark ms-1" title="Berechnet aus P_el"><?= number_format($calc_freq, 1, ',', '.') ?> Hz</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="badge bg-secondary">Bereit / Aus</span>
                        <?php endif; ?>
                    </div>
                    <div class="text-center">
                        <?php 
                            $ba = $data['Betriebsart'] ?? -1;
                            $baClass = 'bg-secondary';
                            $baText = '--';
                            if ($ba == 0) { $baClass = 'bg-warning text-dark'; $baText = 'Heizen'; }
                            elseif ($ba == 1) { $baClass = 'bg-danger'; $baText = 'Warmwasser'; }
                            elseif ($ba == 3) { $baClass = 'bg-primary'; $baText = 'EVU-Sperre'; }
                            elseif ($ba == 5) { $baClass = 'bg-secondary'; $baText = 'Aus'; }
                        ?>
                        <span class="badge <?= $baClass ?>"><?= $baText ?></span>
                    </div>
                    <div class="text-end">
                        <span class="small text-info">Ein: <?= fmtVal($data['Sole_Ein'] ?? '--', '°C') ?></span>
                        <span class="small text-primary ms-3">Aus: <?= fmtVal($data['Sole_Aus'] ?? '--', '°C') ?></span>
                    </div>
                </div>
            </div>
        </div>

        <h6 class="text-muted text-uppercase small fw-bold mb-2">Temperaturen</h6>
        <div class="row g-2 mb-3">
            <div class="col-6 col-md-3 text-center">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle">
                    <div class="small text-muted">Außen</div>
                    <div class="fs-5 fw-bold"><?= fmtVal($data['Aussentemp'], '°C') ?></div>
                    <div class="text-muted" style="font-size:0.75rem">Mittel: <?= fmtVal($data['Aussentemp_Mittel'] ?? '--', '°C') ?></div>
                </div>
            </div>
            <div class="col-6 col-md-3 text-center">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle">
                    <div class="small text-muted">Warmwasser</div>
                    <div class="fs-5 fw-bold text-warning"><?= fmtVal($data['Warmwasser_Ist'], '°C') ?></div>
                    <div class="text-muted" style="font-size:0.75rem">Soll: <?= fmtVal($data['Warmwasser_Soll'] ?? '--', '°C') ?></div>
                </div>
            </div>
            <div class="col-6 col-md-3 text-center">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle">
                    <div class="small text-muted">Vorlauf</div>
                    <div class="fs-5 fw-bold text-danger"><?= fmtVal($data['Vorlauf_Ist'], '°C') ?></div>
                    <div class="text-muted" style="font-size:0.75rem">Istwert</div>
                </div>
            </div>
            <div class="col-6 col-md-3 text-center">
                <div class="p-2 bg-body-tertiary rounded border border-secondary-subtle">
                    <?php if ($conf['rl_source'] === 'external'): ?>
                        <div class="small text-muted">Rücklauf (Extern)</div>
                        <div class="fs-5 fw-bold text-info"><?= fmtVal($data['Ruecklauf_Extern'] ?? '--', '°C') ?></div>
                        <div class="d-flex justify-content-center gap-2 text-muted" style="font-size:0.7rem;">
                            <span class="text-nowrap">Soll: <?= fmtVal($data['Ruecklauf_Soll']) ?></span>
                            <span class="text-nowrap">Int: <?= fmtVal($data['Ruecklauf_Ist'] ?? '--') ?></span>
                        </div>
                    <?php else: ?>
                        <div class="small text-muted">Rücklauf</div>
                        <div class="fs-5 fw-bold text-info"><?= fmtVal($data['Ruecklauf_Ist'], '°C') ?></div>
                        <div class="d-flex justify-content-center gap-2 text-muted" style="font-size:0.7rem;">
                            <span class="text-nowrap">Soll: <?= fmtVal($data['Ruecklauf_Soll']) ?></span>
                            <span class="text-nowrap">Ext: <?= fmtVal($data['Ruecklauf_Extern'] ?? '--') ?></span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <h6 class="text-muted text-uppercase small fw-bold mb-2">Smart Home Interface Status</h6>
        <div class="row g-2">
            <div class="col-6">
                <div class="p-2 bg-dark-subtle rounded border border-secondary-subtle">
                    <div class="small text-muted">Modus Heizung</div>
                    <span class="badge bg-primary"><?= getModeText($status['HZ_Mode'] ?? null) ?></span>
                    <span class="small ms-2">SHI-Soll: <?= fmtVal($status['HZ_Setpoint'] ?? '--', '°C') ?></span>
                </div>
            </div>
            <div class="col-6">
                <div class="p-2 bg-dark-subtle rounded border border-secondary-subtle">
                    <div class="small text-muted">Modus WW</div>
                    <span class="badge bg-warning text-dark"><?= getModeText($status['WW_Mode'] ?? null) ?></span>
                    <span class="small ms-2">SHI-Soll: <?= fmtVal($status['WW_Setpoint'] ?? '--', '°C') ?></span>
                </div>
            </div>
        </div>
        <?php endif; // End of success & !isChargingOnly block ?>

        <h6 class="text-muted text-uppercase small fw-bold mb-2">Service-Steuerung & Updates</h6>
        <div class="row g-2 mb-3">
            <div class="col-12">
                <div class="p-3 bg-body-tertiary rounded border border-secondary-subtle">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div>
                            <span class="small text-muted me-2">Energy-Manager:</span>
                            <span class="badge <?= $isServiceRunning ? 'bg-success' : 'bg-danger' ?>" style="cursor:pointer;" onclick="showEnergyManagerLog()" title="Log anzeigen">
                                <?= strtoupper($serviceStatus) ?>
                            </span>
                        </div>
                        <div class="d-flex gap-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="toggleLuxConfig()">
                                <i class="fas fa-cog"></i> Konfiguration
                            </button>
                            <form method="post" class="d-inline">
                            <button type="submit" name="restart_manager" class="btn btn-sm btn-outline-info">
                                <i class="fas fa-sync-alt"></i> Neustart
                            </button>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Config Editor (Hidden by default) -->
                    <div id="lux-config-form" style="<?= $isChargingOnly ? 'display:block;' : 'display:none;' ?>" class="mt-3 border-top pt-3">
                        <form method="post">
                            <h6 class="text-muted small fw-bold mt-1 mb-2">Allgemeine Einstellungen</h6>
                            <div class="form-check form-switch mb-3">
                                <input class="form-check-input" type="checkbox" name="luxtronik_active" id="luxActive" <?= $conf['luxtronik'] ? 'checked' : '' ?>>
                                <label class="form-check-label" for="luxActive" title="Schaltet die gesamte Luxtronik-Integration (Anzeige & Hintergrunddienst) ein oder aus.">Luxtronik Integration (UI & Dienst)</label>
                            </div>
                            <div class="form-check form-switch mb-3">
                                <input class="form-check-input" type="checkbox" name="auto_mode" id="luxAuto" <?= $conf['auto_mode'] ? 'checked' : '' ?>>
                                <label class="form-check-label" for="luxAuto" title="Aktiviert die automatische Regelung durch den Energy Manager (PV-Überschuss, Preise). Wenn aus, nur Monitoring.">Automatik-Regelung (Energy Manager)</label>
                            </div>
                            <?php if (!$isChargingOnly): ?>
                            <div class="row g-2 mb-3">
                                <div class="col-md-12">
                                    <label class="form-label small" title="IP-Adresse der Luxtronik-Steuerung im lokalen Netzwerk (z.B. 192.168.178.88).">IP-Adresse der Wärmepumpe</label>
                                    <input type="text" class="form-control form-control-sm" name="luxtronik_ip" value="<?= htmlspecialchars($conf['luxtronik_ip']) ?>">
                                </div>
                            </div>

                            <h6 class="text-muted small fw-bold mt-4 mb-2">PV-Überschuss-Boost</h6>
                            <div class="row g-2 mb-2">
                                <div class="col-md-6">
                                    <label class="form-label small" title="Leistung in Watt, ab der der Boost startet. Negativ = Einspeisung (z.B. -3500 = ab 3500W Einspeisung).">Start-Grenze (Watt, negativ=Einspeisung)</label>
                                    <input type="number" class="form-control form-control-sm" name="GRID_START_LIMIT" value="<?= $conf['GRID_START_LIMIT'] ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small" title="Zeit in Minuten, die der Boost nach Wegfall der Bedingungen weiterläuft (Taktungsschutz).">Stop-Verzögerung (Minuten)</label>
                                    <input type="number" class="form-control form-control-sm" name="stop_delay_minutes" value="<?= $conf['stop_delay_minutes'] ?>">
                                    <div class="form-text" style="font-size:0.7rem">Toleranz bei Netzbezug/Wolken</div>
                                </div>
                            </div>
                             <div class="row g-2 mb-2">
                                <div class="col-6 col-md-3">
                                    <label class="form-label small" title="Mindest-Ladestand der Hausbatterie in %, damit der Boost freigegeben wird.">Min SoC (%)</label>
                                    <input type="number" class="form-control form-control-sm" name="MIN_SOC" value="<?= $conf['MIN_SOC'] ?>">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small" title="Grenzwert in °C für Sommer/Winter-Umschaltung. Über diesem Wert wird nur Warmwasser erhöht.">Außentemp. Limit (°C)</label>
                                    <input type="number" step="0.1" class="form-control form-control-sm" name="AT_LIMIT" value="<?= $conf['AT_LIMIT'] ?>">
                                </div>
                                <div class="col-6 col-md-2">
                                    <label class="form-label small" title="Zieltemperatur für Warmwasser im Boost-Modus (wenn Außentemp > Limit).">WW Soll Sommer</label>
                                    <input type="number" step="0.1" class="form-control form-control-sm" name="WWS" value="<?= $conf['WWS'] ?>">
                                </div>
                                <div class="col-6 col-md-2">
                                    <label class="form-label small" title="Zieltemperatur für Warmwasser im Winterbetrieb (wenn Außentemp < Limit).">WW Soll Winter</label>
                                    <input type="number" step="0.1" class="form-control form-control-sm" name="WWW" value="<?= $conf['WWW'] ?>">
                                </div>
                                <div class="col-6 col-md-2">
                                    <label class="form-label small" title="Zieltemperatur für den Heizungs-Rücklauf im Boost-Modus (nur Winter).">Heizung Soll</label>
                                    <input type="number" step="0.1" class="form-control form-control-sm" name="HZ" value="<?= $conf['HZ'] ?>">
                                </div>
                            </div>

                            <h6 class="text-muted small fw-bold mt-3 mb-2">Prognose-Pause (Experimentell)</h6>
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" name="pv_pause_enable" id="pvPause" <?= $conf['pv_pause_enable'] ? 'checked' : '' ?>>
                                <label class="form-check-label small" for="pvPause" title="Pausiert die Wärmepumpe vor erwarteten PV-Ertragsspitzen, um Platz im Speicher/Estrich zu schaffen.">Pause vor PV-Ertrag aktivieren</label>
                            </div>
                            <div class="row g-2 mb-2 align-items-end">
                                <div class="col-4">
                                    <label class="form-label small" title="Batterie-SoC, ab dem die 'Aushungern'-Pause vor einer erwarteten PV-Spitze aktiviert wird.">Min SoC für Pause</label>
                                    <input type="number" class="form-control form-control-sm" name="pv_pause_soc" value="<?= $conf['pv_pause_soc'] ?>">
                                </div>
                                <div class="col-4">
                                    <label class="form-label small" title="Maximale Dauer der Pause in Minuten, falls die Sonne doch nicht kommt.">Pause Timeout (Min)</label>
                                    <input type="number" class="form-control form-control-sm" name="pv_pause_timeout_minutes" value="<?= $conf['pv_pause_timeout_minutes'] ?>">
                                </div>
                                <div class="col-4">
                                    <label class="form-label small" title="PV-Leistung in Watt, die laut Prognose erwartet wird, um die Pause auszulösen.">Erwartete PV-Erzeugung</label>
                                    <input type="number" class="form-control form-control-sm" name="pv_pause_watt" value="<?= $conf['pv_pause_watt'] ?>">
                                </div>
                            </div>
                            <?php endif; ?>

                            <h6 class="text-muted small fw-bold mt-3 mb-2">Intelligente Speicher-Entladung (Morgen)</h6>
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" name="morning_boost_enable" id="morningBoost" <?= $conf['morning_boost_enable'] ? 'checked' : '' ?>>
                                <label class="form-check-label small" for="morningBoost" title="Aktiviert die prognosebasierte Entladung des Speichers am frühen Morgen, um Platz für PV-Ertrag zu schaffen.">Aktivieren (bei hoher PV-Prognose)</label>
                            </div>
                            <div class="row g-2 mb-2">
                                <div class="col-6 col-md-4">
                                    <label class="form-label small" title="Legt fest, welches Gerät den Speicher leeren soll (Auto oder Wärmepumpe).">Priorität</label>
                                    <select class="form-select form-select-sm" name="morning_boost_prio">
                                        <option value="wallbox" <?= ($conf['morning_boost_prio'] ?? 'wallbox') === 'wallbox' ? 'selected' : '' ?>>Wallbox (Auto laden)</option>
                                        <option value="wallbox_only" <?= ($conf['morning_boost_prio'] ?? 'wallbox') === 'wallbox_only' ? 'selected' : '' ?>>Nur Wallbox (kein Fallback)</option>
                                        <option value="heatpump" <?= ($conf['morning_boost_prio'] ?? 'wallbox') === 'heatpump' ? 'selected' : '' ?>>Wärmepumpe (Boost)</option>
                                    </select>
                                </div>
                                <div class="col-6 col-md-4">
                                    <label class="form-label small" title="Angenommene Ladeleistung der Wallbox in kW für die Zeitplanung (z.B. 7.0 oder 11.0).">WB Leistung (kW)</label>
                                    <input type="number" step="0.1" class="form-control form-control-sm" name="morning_boost_wb_power" value="<?= $conf['morning_boost_wb_power'] ?>">
                                    <div class="form-text" style="font-size:0.7rem">Annahme für Planung</div>
                                </div>
                                <div class="col-6 col-md-4">
                                    <label class="form-label small" title="Uhrzeit (Stunde), bis zu der der Speicher auf den Ziel-SoC entladen sein soll.">Ziel-Zeit (Stunde)</label>
                                    <input type="number" class="form-control form-control-sm" name="morning_boost_deadline" value="<?= $conf['morning_boost_deadline'] ?>">
                                    <div class="form-text" style="font-size:0.7rem">z.B. 8 für 08:00 Uhr</div>
                                </div>
                                <div class="col-6 col-md-4">
                                    <label class="form-label small" title="Gewünschter Rest-Ladestand nach der morgendlichen Entleerung.">Ziel-SoC (%)</label>
                                    <input type="number" class="form-control form-control-sm" name="morning_boost_target_soc" value="<?= $conf['morning_boost_target_soc'] ?>">
                                    <div class="form-text" style="font-size:0.7rem">Entladen bis SoC</div>
                                </div>
                                <div class="col-6 col-md-4">
                                    <label class="form-label small" title="Mindestanzahl an Stunden mit 99% SoC laut Prognose, um die Entladung zu aktivieren.">Bedingung: Dauer 99% (h)</label>
                                    <input type="number" class="form-control form-control-sm" name="morning_boost_min_hours" value="<?= $conf['morning_boost_min_hours'] ?>">
                                </div>
                                <div class="col-6 col-md-4">
                                    <label class="form-label small" title="Erwarteter PV-Ertrag (in % der Speicherkapazität) während der Voll-Phasen.">Bedingung: PV-Ertrag (%)</label>
                                    <input type="number" step="0.1" class="form-control form-control-sm" name="morning_boost_min_pv_pct" value="<?= $conf['morning_boost_min_pv_pct'] ?>">
                                </div>
                            </div>

                            <h6 class="text-muted small fw-bold mt-4 mb-2">Superintelligenz <span class="badge bg-warning text-dark">Experimentell</span></h6>
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" name="super_intelligence_enable" id="superIntel" <?= $conf['super_intelligence_enable'] ? 'checked' : '' ?>>
                                <label class="form-check-label small" for="superIntel" title="Aktiviert eine aggressive, dynamische Entladung über die Wallbox bei extrem guten PV-Prognosen.">Aktivieren (Dynamische Wallbox-Entladung bei Extrem-Prognose)</label>
                            </div>
                            <div class="row g-2 mb-2">
                                <div class="col-6">
                                    <label class="form-label small" title="Uhrzeit, bis zu der die aggressive Entladung abgeschlossen sein soll.">Ziel-Zeit (Stunde)</label>
                                    <input type="number" class="form-control form-control-sm" name="super_intelligence_deadline" value="<?= $conf['super_intelligence_deadline'] ?>">
                                </div>
                                <div class="col-6 d-flex align-items-end pb-1">
                                    <div class="form-text small text-info">
                                        <i class="fas fa-info-circle me-1"></i>Entlädt auf den "Manuell Boost Min-SoC" (aktuell: <b><?= $conf['manual_boost_min_soc'] ?>%</b>).
                                    </div>
                                </div>
                            </div>
                            
                            <?php if (!$isChargingOnly): ?>
                            <h6 class="text-muted small fw-bold mt-3 mb-2">Strompreis-Boost (aWATTar/Tibber)</h6>
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" name="price_boost_enable" id="priceBoost" <?= $conf['price_boost_enable'] ? 'checked' : '' ?>>
                                <label class="form-check-label small" for="priceBoost" title="Aktiviert den Boost bei günstigen Strompreisen (aWATTar/Tibber) und pausiert bei teuren Preisen.">Strompreis-Boost aktivieren</label>
                            </div>
                            <div class="row g-2 mb-2">
                                <div class="col-6 col-md-3">
                                    <label class="form-label small" title="Maximaler Strompreis in ct/kWh, bei dem der Preis-Boost aktiviert wird.">Preis-Limit (ct/kWh)</label>
                                    <input type="number" step="0.1" class="form-control form-control-sm" name="price_limit" value="<?= $conf['price_limit'] ?>">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small text-success" title="Preisgrenze, unter der IMMER geboostet wird (ignoriert Tageslimits und Sperren).">Zwangs-Limit (ct)</label>
                                    <input type="number" step="0.1" class="form-control form-control-sm" name="price_hard_limit" value="<?= $conf['price_hard_limit'] ?>">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small" title="Mindestdauer eines Preis-Boost-Intervalls in Minuten.">Min. Dauer (Min)</label>
                                    <input type="number" class="form-control form-control-sm" name="price_min_duration" value="<?= $conf['price_min_duration'] ?>">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label small" title="Maximale Gesamtdauer für Preis-Boosts pro Tag in Minuten.">Max. pro Tag (Min)</label>
                                    <input type="number" class="form-control form-control-sm" name="price_max_daily" value="<?= $conf['price_max_daily'] ?>">
                                </div>
                            </div>

                            <h6 class="text-muted small fw-bold mt-3 mb-2">Manuelle Steuerung & Schutz</h6>
                             <div class="row g-2 mb-2">
                                <div class="col-6">
                                    <label class="form-label small text-warning" title="Sicherheits-Grenze: Manuelle Entladung stoppt, wenn dieser SoC unterschritten wird.">Manuell Boost Min-SoC (%)</label>
                                    <input type="number" class="form-control form-control-sm" name="manual_boost_min_soc" value="<?= $conf['manual_boost_min_soc'] ?>">
                                    <div class="form-text" style="font-size:0.7rem">Stoppt "Batterie leeren" bei SoC</div>
                                </div>
                                <div class="col-6">
                                    <label class="form-label small" title="Automatische Abschaltung des manuellen Boosts nach dieser Zeit.">Man. Boost Dauer (Min)</label>
                                    <input type="number" class="form-control form-control-sm" name="manual_boost_max_duration" value="<?= $conf['manual_boost_max_duration'] ?>">
                                    <div class="form-text" style="font-size:0.7rem">Max. Dauer für "Batterie leeren"</div>
                                </div>
                                <div class="col-6">
                                    <label class="form-label small text-danger" title="Sicherheits-Abschaltung des Boosts, wenn die Wärmequelle (Sole) zu kalt wird.">WQ Min-Temp (°C)</label>
                                    <input type="number" step="0.1" class="form-control form-control-sm" name="wq_min_temp" value="<?= $conf['wq_min_temp'] ?>">
                                    <div class="form-text" style="font-size:0.7rem">Not-Aus bei Unterschreitung</div>
                                </div>
                                <div class="col-6">
                                    <label class="form-label small" title="Auswahl des Temperaturfühlers für die Regelung (Intern oder Extern).">Sensor Rücklauf</label>
                                    <select class="form-select form-select-sm" name="rl_source">
                                        <option value="internal" <?= ($conf['rl_source'] ?? 'internal') === 'internal' ? 'selected' : '' ?>>Intern (Ruecklauf_Ist)</option>
                                        <option value="external" <?= ($conf['rl_source'] ?? 'internal') === 'external' ? 'selected' : '' ?>>Extern (Ruecklauf_Extern)</option>
                                    </select>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <h6 class="text-muted small fw-bold mt-3 mb-2">Benachrichtigungen (Telegram)</h6>
                            <?php if (file_exists('/usr/local/bin/boot_notify.sh')): ?>
                                <div class="alert alert-light border small py-2 mb-2 text-muted">
                                    <i class="fas fa-shield-alt text-success me-2"></i>Verwende zentrale Watchdog-Konfiguration.
                                </div>
                            <?php else: ?>
                            <div class="row g-2 mb-2">
                                <div class="col-12">
                                    <label class="form-label small" title="Telegram Bot Token für Benachrichtigungen (vom BotFather).">Bot Token</label>
                                    <input type="text" class="form-control form-control-sm" name="telegram_token" value="<?= htmlspecialchars($conf['telegram_token'] ?? '') ?>" placeholder="z.B. 123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11">
                                </div>
                                <div class="col-12">
                                    <label class="form-label small" title="Telegram Chat ID, an die Nachrichten gesendet werden.">Chat ID</label>
                                    <input type="text" class="form-control form-control-sm" name="telegram_chat_id" value="<?= htmlspecialchars($conf['telegram_chat_id'] ?? '') ?>" placeholder="z.B. 123456789">
                                </div>
                            </div>
                            <?php endif; ?>

                            <button type="submit" name="save_config" class="btn btn-primary btn-sm w-100 mt-2">
                                <i class="fas fa-save me-1"></i> Speichern & Dienst neustarten
                            </button>
                        </form>
                    </div>

                    <div class="row g-0 border-top pt-2 mt-2">
                        <div class="col-6 small text-muted">
                            <i class="fas fa-file-code me-1"></i> energy_manager.py: <b><?= $pyMtime ?></b>
                        </div>
                        <div class="col-6 small text-muted">
                            <i class="fas fa-cog me-1"></i> config.lux.json: <b><?= $configMtime ?></b>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Energy Manager Log Modal -->
<div class="modal fade" id="energyManagerLogModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content bg-dark text-light border-secondary">
            <div class="modal-header border-secondary">
                <h5 class="modal-title"><i class="fas fa-robot me-2"></i>Energy Manager Log</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body bg-black p-2">
                <pre id="energy-manager-log-content" style="font-family: monospace; font-size: 0.8rem; color: #ccc; white-space: pre-wrap;">Lade Protokoll...</pre>
            </div>
            <div class="modal-footer border-secondary">
                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal">Schließen</button>
            </div>
        </div>
    </div>
</div>

<script>
var isLuxtronikEditing = false;

function toggleLuxConfig() {
    var form = document.getElementById('lux-config-form');
    if (form.style.display === 'none') {
        form.style.display = 'block';
        isLuxtronikEditing = true; // Stop auto-refresh
    } else {
        form.style.display = 'none';
        isLuxtronikEditing = false; // Resume auto-refresh
    }
}

// Funktion zum automatischen Neuladen der Daten
function refreshLuxtronik() {
    // Nicht aktualisieren, wenn User gerade editiert
    if (typeof isLuxtronikEditing !== 'undefined' && isLuxtronikEditing) return;

    // Wir suchen das Element mit der ID 'luxtronik-card'
    // Hinweis: Du musst deiner ersten <div class="card..."> die ID 'luxtronik-card' geben!
    const container = document.getElementById('luxtronik-card');
    if (!container) return;

    // Wir laden einfach den Inhalt der aktuellen Seite neu und extrahieren die Karte
    fetch(window.location.href)
        .then(response => response.text())
        .then(html => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const newContent = doc.getElementById('luxtronik-card').innerHTML;
            container.innerHTML = newContent;
            console.log("Luxtronik Daten aktualisiert: " + new Date().toLocaleTimeString());
        })
        .catch(err => console.warn('Update fehlgeschlagen:', err));
}

function showEnergyManagerLog() {
    const modal = new bootstrap.Modal(document.getElementById('energyManagerLogModal'));
    modal.show();
    document.getElementById('energy-manager-log-content').innerText = 'Lade Protokoll...';
    
    // Die Action wird von index.php/mobile.php verarbeitet, je nachdem, wo luxtronik.php inkludiert ist.
    // Wir nutzen einen relativen Pfad, der im aktuellen Kontext funktioniert.
    fetch('?action=get_energy_manager_log')
        .then(r => r.text())
        .then(text => {
            document.getElementById('energy-manager-log-content').innerText = text;
        })
        .catch(e => {
            document.getElementById('energy-manager-log-content').innerText = 'Fehler beim Laden des Protokolls.';
        });
}

// Alle 15 Sekunden aktualisieren
setInterval(refreshLuxtronik, 15000);
</script>