<?php
if (!defined('VIEW_MODE')) {
    define('VIEW_MODE', 'mobile');
}
require_once 'helpers.php';
handleVersionCheck(__FILE__);
handleUpdatePreparation();
handleUpdateCheck();
handleServiceRestart();
handleWatchdogStatus();
handleWatchdogLog();
handleEnergyManagerLog();
handleSaveSetting();
handleStatus();
handleRunNow();
handleRunLiveHistory();
handleRunUpdate();
handleArchivDiagram();
handleDailyStats();

$stampFile = '/var/www/html/tmp/plot_soc_done_mobile';
$lastUpdateTs = file_exists($stampFile) ? filemtime($stampFile) : 0;

// Logik einbinden (Config, Forecast, Preise)
require_once 'logic.php';

// Luxtronik Global Toggle Handler
if (isset($_POST['save_lux_global'])) {
    $paths = getInstallPaths();
    $configFile = rtrim($paths['install_path'], '/') . '/e3dc.config.txt';
    $key = 'luxtronik';
    $val = isset($_POST['lux_active']) ? '1' : '0';

    if (file_exists($configFile)) {
        $lines = file($configFile, FILE_IGNORE_NEW_LINES);
        $newLines = [];
        $found = false;

        foreach ($lines as $line) {
            if (preg_match('/^\s*' . preg_quote($key, '/') . '\s*=/i', $line)) {
                $newLines[] = "$key = $val";
                $found = true;
            } else {
                $newLines[] = $line;
            }
        }
        if (!$found) {
            $newLines[] = "\n# Luxtronik-Integration\n$key = $val";
        }
        file_put_contents($configFile, implode("\n", $newLines) . "\n", LOCK_EX);
    }
    
    shell_exec("sudo systemctl restart energy_manager > /dev/null 2>&1 &");
    header("Location: mobile.php?seite=config");
    exit;
}

$historyFiles = getHistoryBackupFiles();

// Luxtronik History Files scannen
$luxtronikFiles = [];
$luxPath = '/var/www/html/tmp/luxtronik_archive/';
if (is_dir($luxPath)) {
    $files = glob($luxPath . 'luxtronik_*.json');
    if($files) {
        rsort($files);
        foreach ($files as $f) {
            if (preg_match('/luxtronik_(\d{4}-\d{2}-\d{2})\.json/', basename($f), $m)) {
                $date = $m[1];
                // Dummy-Dateiname für plot_live_history.py
                $luxtronikFiles[] = ['file' => 'history_' . $date . '.txt', 'label' => date('d.m.Y', strtotime($date))];
            }
        }
    }
}

// Wir versuchen, die statische awattardebug.23.txt zu laden, damit der Graph nicht immer bei "jetzt" beginnt.
// Wir übernehmen die MwSt ($awmwst oder $mwst) aus der logic.php, falls vorhanden.
$vatToUse = isset($awmwst) ? $awmwst : (isset($mwst) ? $mwst : 0);
$staticData = loadStaticPriceData($vatToUse);
$useStaticData = false;
if ($staticData) {
    $priceHistory = $staticData['prices'];
    $priceStartHour = $staticData['start_hour'];
    $priceInterval = $staticData['interval'];
    $useStaticData = true;
    echo "<!-- Static Data Loaded from: " . htmlspecialchars($staticData['source']) . " -->";
}

$seite = $_GET['seite'] ?? 'live';
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E3DC Mobile Pro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="manifest" href="manifest_mobile.json">
    <link rel="preconnect" href="https://cdn.jsdelivr.net">
    <link rel="preconnect" href="https://cdnjs.cloudflare.com">

    <style>
        :root {
            --bg-body: #0b0e14; --text-body: #f8fafc;
            --bg-card: #1a1f29; --border-card: #2d3748;
            --bg-nav: #1a1f29; --text-muted: #94a3b8;
            --chart-line: rgba(255,255,255,0.5);
            --chart-overlay: rgba(0,0,0,0.2);
        }
        [data-theme="light"] {
            --bg-body: #f1f5f9; --text-body: #0f172a;
            --bg-card: #ffffff; --border-card: #e2e8f0;
            --bg-nav: #ffffff; --text-muted: #64748b;
            --chart-line: rgba(0,0,0,0.3);
            --chart-overlay: rgba(0,0,0,0.05);
        }
        body { background-color: var(--bg-body); color: var(--text-body); font-family: -apple-system, sans-serif; transition: background-color 0.3s, color 0.3s; }
        /* Globaler Hover-Effekt für Desktop-Nutzer (Finger-Cursor) */
        button, .nav-item, .btn, [onclick], .fill-bar { cursor: pointer; }
        .dashboard-card { background: var(--bg-card); border: 1px solid var(--border-card); border-radius: 20px; padding: 18px; position: relative; overflow: hidden; height: 100%; transition: background 0.3s, border-color 0.3s; }
        .fill-bar { position: absolute; top: 0; left: 0; height: 100%; transition: width 1.5s ease-in-out, background 0.5s; z-index: 1; opacity: 0.18; }
        .card-content { position: relative; z-index: 2; text-align: center; }
        .label { font-size: 0.7rem; color: var(--text-muted); font-weight: 600; letter-spacing: 0.05em; margin-bottom: 4px; }
        .value { font-size: 1.8rem; font-weight: 900; line-height: 1.2; }
        .unit { font-size: 0.8rem; color: var(--text-muted); font-weight: bold; }
        .mobile-nav { display: flex; justify-content: space-around; background: var(--bg-nav); border: 1px solid var(--border-card); border-radius: 20px; padding: 10px; margin-bottom: 20px; transition: background 0.3s; }
        .nav-item { color: var(--text-muted); text-decoration: none; font-size: 0.75rem; text-align: center; flex: 1; }
        .nav-item i { display: block; font-size: 1.1rem; margin-bottom: 2px; }
        .nav-item.active { color: #3b82f6; font-weight: bold; }
        .pv-val { color: #fbbf24; } .home-val { color: #3b82f6; } .wb-val { color: #a855f7; } .wp-val { color: #22d3ee; }
        @keyframes pulse-dynamic { 0% { opacity: 0.18; } 50% { opacity: var(--pulse-intensity, 0.4); } 100% { opacity: 0.18; } }
        .pulse-active { animation: pulse-dynamic var(--pulse-speed, 2s) infinite ease-in-out; }
        .price-ultra-cheap { text-shadow: 0 0 10px rgba(16, 185, 129, 0.8); }
        #price-chart { position: absolute; bottom: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 1; color: var(--text-muted); }
        #price-line { position: absolute; top: 0; bottom: 0; width: 1px; border-left: 1px dashed var(--chart-line); z-index: 2; pointer-events: none; display: none; }
        #price-line-day { position: absolute; top: 0; bottom: 0; width: 1px; border-left: 1px dotted rgba(255,255,255,0.3); z-index: 1; pointer-events: none; display: none; }
        #price-line-yesterday { position: absolute; top: 0; bottom: 0; width: 1px; border-left: 1px dotted rgba(255,255,255,0.3); z-index: 1; pointer-events: none; display: none; }
        #price-overlay-tomorrow { position: absolute; top: 0; bottom: 0; right: 0; background: var(--chart-overlay); z-index: 0; pointer-events: none; display: none; }
        #price-label-tomorrow { position: absolute; top: 5px; right: 5px; color: rgba(255,255,255,0.3); font-size: 0.7rem; font-weight: bold; display: none; pointer-events: none; }
        #price-label-yesterday { position: absolute; top: 5px; left: 5px; color: rgba(255,255,255,0.3); font-size: 0.7rem; font-weight: bold; display: none; pointer-events: none; }
        #price-time-label { position: absolute; bottom: 4px; transform: translateX(-50%); color: white; font-size: 10px; font-weight: bold; z-index: 3; pointer-events: none; opacity: 0.9; white-space: nowrap; display: none; text-shadow: 1px 1px 2px black; }
        #price-val-min { position: absolute; top: 12px; left: 15px; z-index: 5; font-size: 1.1rem; font-weight: bold; text-align: left; line-height: 1.1; pointer-events: none; }
        #price-val-max { position: absolute; top: 12px; right: 15px; z-index: 5; font-size: 1.1rem; font-weight: bold; text-align: right; line-height: 1.1; pointer-events: none; }
        @keyframes blinker { 50% { opacity: 0.2; } }
        .blink-extreme { animation: blinker 0.8s linear infinite; }
        #val-pv-forecast .unit { color: inherit; }

        /* Desktop-spezifische Layout-Korrekturen */
        .mode-desktop .mobile-nav { display: none; }
        .mode-desktop .dashboard-card { margin-bottom: 20px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3); }
        .mode-desktop #diagramContainer { display: block !important; }
        .mode-desktop #toggleDiagramBtn { display: none; }
        /* Korrektur für den Status-Kreis im Stop-Feld auf Desktop */
        .mode-desktop .status-kreis { float: left; margin-right: 15px; position: static; }

        /* Energiefluss Styles (Mobile angepasst) */
        .flow-container { background-color: var(--bg-card); border: 1px solid var(--border-card); border-radius: 20px; position: relative; width: 100%; height: 400px; overflow: hidden; font-family: sans-serif; margin-bottom: 10px; }
        .flow-svg { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 1; pointer-events: none; }
        .flow-line { fill: none; stroke-width: 3; opacity: 0.2; }
        .flow-dots { fill: none; stroke-width: 5; stroke-dasharray: 0 20; animation: flowAnim 1s linear infinite; stroke-linecap: round; }
        @keyframes flowAnim { to { stroke-dashoffset: -60; } }
        .flow-dots.reverse { animation-direction: reverse; }
        .flow-dots.stopped { animation-play-state: paused; opacity: 0; }
        .flow-node { position: absolute; transform: translate(-50%, -50%); border-radius: 50%; display: flex; flex-direction: column; align-items: center; justify-content: center; z-index: 10; background: var(--bg-card); border: 3px solid; width: 80px; height: 80px; text-align: center; transition: background 0.3s, border-color 0.3s; }
        .flow-node .fa-icon { font-size: 1.4rem; margin-bottom: 2px; }
        .flow-node .val { font-size: 0.9rem; font-weight: bold; }
        .flow-node .label { font-size: 0.6rem; color: var(--text-muted); text-transform: uppercase; }
        .flow-node .price-tag { position: absolute; bottom: -20px; background: var(--bg-nav); padding: 2px 6px; border-radius: 8px; font-size: 0.7rem; font-weight: bold; border: 1px solid var(--border-card); white-space: nowrap; }
        .flow-node-back {
            position: absolute; transform: translate(-50%, -50%); border-radius: 50%;
            z-index: 5; background-color: var(--bg-card);
            width: 80px; height: 80px;
            top: 15%; left: 50%;
        }
        .node-pv { border-color: #ffc107; color: #ffc107; box-shadow: 0 0 15px rgba(255,193,7,0.3); top: 25%; left: 20%; }
        .node-grid { border-color: #6c757d; color: #ced4da; box-shadow: 0 0 15px rgba(108,117,125,0.3); top: 75%; left: 20%; }
        .node-bat { border-color: #dc3545; color: #dc3545; box-shadow: 0 0 15px rgba(220,53,69,0.3); top: 15%; left: 50%; }
        .node-bat.charging { border-color: #2ecc71; color: #2ecc71; box-shadow: 0 0 15px rgba(46,204,113,0.3); }
        .node-home { border-color: #0dcaf0; color: #0dcaf0; box-shadow: 0 0 15px rgba(13,202,240,0.3); top: 25%; left: 80%; }
        .node-wb { border-color: #2ecc71; color: #2ecc71; box-shadow: 0 0 15px rgba(46,204,113,0.3); top: 75%; left: 80%; }
        .node-wp { border-color: #22d3ee; color: #22d3ee; box-shadow: 0 0 15px rgba(34,211,238,0.3); top: 50%; left: 80%; }
        .node-wp.boost { border-color: #dc3545; color: #dc3545; box-shadow: 0 0 20px rgba(220,53,69,0.6); }
        .node-center { background: transparent; border: none; box-shadow: none; width: 70px; height: 70px; top: 50%; left: 50%; padding: 0; }
        .node-center img { width: 100%; height: 100%; border-radius: 50%; box-shadow: 0 0 20px #0d6efd; }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body class="mode-<?php echo VIEW_MODE; ?>" data-theme="<?= $darkMode ? 'dark' : 'light' ?>" data-bs-theme="<?= $darkMode ? 'dark' : 'light' ?>">
<div class="container py-3">
    <div class="mobile-nav">
        <a href="mobile.php" class="nav-item <?= $seite=='live'?'active':'' ?>"><i class="fas fa-bolt"></i>Live</a>
        <a href="mobile.php?seite=forecast" class="nav-item <?= $seite=='forecast'?'active':'' ?>"><i class="fas fa-chart-area"></i>Prognose</a>
        <a href="mobile.php?seite=wallbox" class="nav-item <?= $seite=='wallbox'?'active':'' ?>"><i class="fas fa-charging-station"></i>Wallbox</a>
        <?php if ($luxtronikEnabled): ?>
        <a href="mobile.php?seite=luxtronik" class="nav-item <?= $seite=='luxtronik'?'active':'' ?>"><i class="fas fa-water"></i>WP</a>
        <?php endif; ?>
        <?php if (!$luxtronikEnabled): ?>
        <a href="mobile.php?seite=charging" class="nav-item <?= $seite=='charging'?'active':'' ?>"><i class="fas fa-magic"></i>Smart</a>
        <?php endif; ?>
        <a href="mobile.php?seite=config" class="nav-item <?= $seite=='config'?'active':'' ?>">
            <div class="d-inline-block position-relative">
                <i class="fas fa-cog"></i>
                <span id="update-badge-nav" class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle" style="display:<?= getUpdateStatusFromCache() > 0 ? 'inline-block' : 'none' ?>;"></span>
            </div>
            <div>Config</div>
        </a>
        <a href="mobile.php?seite=history" class="nav-item <?= $seite=='history'?'active':'' ?>"><i class="fas fa-chart-line"></i>Historie</a>
        <a href="mobile.php?seite=archiv" class="nav-item <?= $seite=='archiv'?'active':'' ?>"><i class="fas fa-history"></i>Archiv</a>
    </div>

    <?php if ($seite == 'live'): ?>
        <div class="d-flex justify-content-between align-items-center mb-3 px-2">
            <h5 class="m-0 fw-bold">E3DC Status</h5>
            <div class="d-flex align-items-center gap-3">
                <i id="watchdog-icon" class="fas fa-shield-alt text-secondary" style="display:none; font-size: 1.1rem; cursor:pointer;" title="Watchdog" onclick="showWatchdogLog()"></i>
                <?= renderConnectionBadge() ?>
                <i class="fas fa-<?= $darkMode ? 'moon' : 'sun' ?> text-secondary" style="cursor:pointer;" onclick="toggleDarkMode(this)"></i>
                <span class="badge border border-secondary text-info" id="live-time" style="background: var(--bg-card);">--:--:--</span>
            </div>
        </div>

        <!-- Live Energiefluss (Ersetzt die alten Kacheln) -->
        
        <!-- Statistik Bar -->
        <div class="dashboard-card mb-2 d-flex justify-content-around align-items-center py-2" onclick="toggleStatsView('mobile')" style="cursor:pointer; background: var(--bg-nav); border-color: var(--border-card);">
            <div class="text-center" title="Autarkie (Momentan)">
                <div class="label m-0">Autarkie (Live)</div>
                <div class="fw-bold text-success" id="m-val-autarky-live" style="font-size: 1.2rem;">--%</div>
            </div>
            <div class="text-center" title="Autarkie (Heute)">
                <div class="label m-0">Autarkie (Tag)</div>
                <div class="fw-bold text-success" id="m-val-autarky-day" style="font-size: 1.2rem;">--%</div>
            </div>
            <div class="text-center" title="Eigenverbrauch (Heute)">
                <div class="label m-0">Eigenverbrauch</div>
                <div class="fw-bold text-warning" id="m-val-selfcon-day" style="font-size: 1.2rem;">--%</div>
            </div>
            <i class="fas fa-chevron-down text-muted" id="m-stats-chevron"></i>
        </div>

        <div id="m-flow-wrapper" class="position-relative mb-2">
            <?= renderEnergyFlow('mobile') ?>
            
            <!-- Mobile Statistics View Overlay -->
            <div id="m-stats-view" class="position-absolute top-0 start-0 w-100 h-100 p-3" style="display: none; background: var(--bg-card); border-radius: 20px; z-index: 20; overflow-y: auto; border: 1px solid var(--border-card);">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h6 class="fw-bold m-0"><i class="fas fa-chart-pie text-secondary me-2"></i>Tagesstatistik</h6>
                    <button class="btn btn-sm btn-outline-secondary" onclick="toggleStatsView('mobile')"><i class="fas fa-times"></i></button>
                </div>
                
                <select class="form-select form-select-sm mb-3 bg-dark text-white border-secondary" id="m-stats-history-select" onchange="loadStatsForDate(this.value, 'mobile')">
                    <option value="today">Heute (Live)</option>
                    <?php foreach ($historyFiles as $hf): ?>
                        <option value="<?= htmlspecialchars($hf['file']) ?>"><?= htmlspecialchars($hf['label']) ?></option>
                    <?php endforeach; ?>
                </select>

                <div class="d-flex justify-content-around mb-3 pb-2 border-bottom border-secondary">
                    <div class="text-center">
                        <div class="label m-0">Autarkie</div>
                        <div class="fw-bold text-success fs-5" id="m-stat-overlay-autarky">--%</div>
                    </div>
                    <div class="text-center">
                        <div class="label m-0">Eigenverbrauch</div>
                        <div class="fw-bold text-warning fs-5" id="m-stat-overlay-selfcon">--%</div>
                    </div>
                </div>

                <div class="mb-3">
                    <div class="d-flex justify-content-between align-items-center border-bottom border-secondary pb-1 mb-2">
                        <div class="label text-warning m-0"><i class="fas fa-sun me-1"></i> Sonne (PV)</div>
                        <span id="m-stat-pv-total" class="badge bg-warning text-dark">-- kWh</span>
                    </div>
                    <div class="d-flex justify-content-between small text-muted"><span>Haus:</span> <span id="m-stat-pv-home" class="fw-bold text-body">-- kWh (--%)</span></div>
                    <div class="d-flex justify-content-between small text-muted"><span>Batterie:</span> <span id="m-stat-pv-bat" class="fw-bold text-body">-- kWh (--%)</span></div>
                    <div class="d-flex justify-content-between small text-muted"><span>Wallbox:</span> <span id="m-stat-pv-wb" class="fw-bold text-body">-- kWh (--%)</span></div>
                    <div class="d-flex justify-content-between small text-muted"><span>WP:</span> <span id="m-stat-pv-wp" class="fw-bold text-body">-- kWh (--%)</span></div>
                    <div class="d-flex justify-content-between small text-muted"><span>Netz:</span> <span id="m-stat-pv-grid" class="fw-bold text-body">-- kWh (--%)</span></div>
                </div>
                <div>
                    <div class="d-flex justify-content-between align-items-center border-bottom border-secondary pb-1 mb-2">
                        <div class="label text-danger m-0"><i class="fas fa-network-wired me-1"></i> Netzbezug</div>
                        <span id="m-stat-grid-total" class="badge bg-danger">-- kWh</span>
                    </div>
                    <div class="d-flex justify-content-between small text-muted"><span>Haus:</span> <span id="m-stat-grid-home" class="fw-bold text-body">-- kWh (--%)</span></div>
                    <div class="d-flex justify-content-between small text-muted"><span>Batterie:</span> <span id="m-stat-grid-bat" class="fw-bold text-body">-- kWh (--%)</span></div>
                    <div class="d-flex justify-content-between small text-muted"><span>Wallbox:</span> <span id="m-stat-grid-wb" class="fw-bold text-body">-- kWh (--%)</span></div>
                    <div class="d-flex justify-content-between small text-muted"><span>WP:</span> <span id="m-stat-grid-wp" class="fw-bold text-body">-- kWh (--%)</span></div>
                </div>
            </div>
        </div>

        <div class="dashboard-card mb-2" id="card-price">
            <svg id="price-chart" preserveAspectRatio="none" viewBox="0 0 240 100"></svg>
            <div id="price-line"></div>
            <div id="price-line-day"></div>
            <div id="price-line-yesterday"></div>
            <div id="price-overlay-tomorrow"></div>
            <div id="price-label-tomorrow">Morgen</div>
            <div id="price-label-yesterday">Gestern</div>
            <div id="price-time-label"></div>
            <div id="price-val-min"></div>
            <div id="price-val-max"></div>
            <div class="card-content">
                <div class="label">aktueller Strompreis</div>
                <div class="value" id="val-price">--<span class="unit"> ct/kWh</span></div>
            </div>
        </div>

        <div id="diagramContainer" style="display:none;" class="mb-3">
            <div id="diagramControls" class="d-flex justify-content-between align-items-center p-2 flex-wrap gap-2">
                <select class="form-select form-select-sm border-secondary" style="width: auto; max-width: 140px;" id="mobileHistorySelect" onchange="updateDiagramHistory(this.value)">
                    <option value="" selected>Live</option>
                    <?php foreach ($historyFiles as $hf): ?>
                        <option value="<?= htmlspecialchars($hf['file']) ?>"><?= htmlspecialchars($hf['label']) ?></option>
                    <?php endforeach; ?>
                </select>
                <select class="form-select form-select-sm border-secondary" style="width: auto; max-width: 140px; display:none;" id="mobileHistorySelectWP" onchange="updateDiagramHistory(this.value)">
                    <option value="" selected>Live</option>
                    <?php foreach ($luxtronikFiles as $lf): ?>
                        <option value="<?= htmlspecialchars($lf['file']) ?>"><?= htmlspecialchars($lf['label']) ?></option>
                    <?php endforeach; ?>
                </select>
                <div class="btn-group btn-group-sm" role="group" id="liveTimeFilter">
                    <button type="button" class="btn btn-outline-info active" onclick="setLiveHours(6, this)">6h</button>
                    <button type="button" class="btn btn-outline-info" onclick="setLiveHours(12, this)">12h</button>
                    <button type="button" class="btn btn-outline-info" onclick="setLiveHours(24, this)">24h</button>
                    <button type="button" class="btn btn-outline-info" onclick="setLiveHours(48, this)">48h</button>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <span id="diagramStatus" class="small text-info"><?= $lastUpdateTs ? date('H:i', $lastUpdateTs) : '' ?></span>
                    <button id="diagramUpdateBtn" class="btn btn-sm btn-outline-light" onclick="updateDiagram()">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
            </div>
            <div id="diagramDetails" class="text-center mb-2 small text-info fw-bold" style="display:none;"></div>
            <div style="height: 50vh; min-height: 400px; border-radius: 20px; overflow: hidden; border: 1px solid var(--border-card);">
                <iframe id="diagramFrame" src="" style="width: 100%; height: 100%; border: none;" scrolling="no"></iframe>
            </div>
        </div>

    <?php elseif ($seite == 'forecast'): ?>
        <div class="d-flex justify-content-between align-items-center mb-3 px-2">
            <h5 class="m-0 fw-bold">SoC Prognose</h5>
            <button id="forecastUpdateBtn" class="btn btn-sm btn-outline-secondary" onclick="updateForecast()">
                <i class="fas fa-sync-alt"></i> Update
            </button>
        </div>
        <div class="dashboard-card" style="height: calc(100vh - 180px); display: flex; flex-direction: column;">
            <div style="flex: 1; border-radius: 20px; overflow: hidden;">
                <iframe id="forecastFrame" src="diagramm_mobile.html?t=<?= time() ?>" style="width: 100%; height: 100%; border: none;" scrolling="no"></iframe>
            </div>
            <div class="text-center mt-2 small text-muted" id="forecastStatus"></div>
        </div>

    <?php elseif ($seite == 'wallbox'): include 'Wallbox.php';
          elseif ($seite == 'config'): ?>
        <div class="mb-3">
            <button id="btn-system-update" class="btn btn-outline-warning w-100 py-3 rounded-4 border-secondary fw-bold shadow-sm position-relative" onclick="startSystemUpdate()">
                <i class="fas fa-cloud-download-alt me-2"></i>E3DC-Control Update
                <span id="update-badge-btn" class="badge bg-danger position-absolute top-0 start-100 translate-middle rounded-pill" style="display:<?= getUpdateStatusFromCache() > 0 ? 'inline-block' : 'none' ?>;">!</span>
            </button>
            <button class="btn btn-outline-danger w-100 py-3 rounded-4 border-secondary fw-bold shadow-sm mt-3" onclick="restartService()">

                <i class="fas fa-power-off me-2"></i>E3DC-Control Neustart
            </button>
        </div>
        
        <?php $energyManagerServiceExists = file_exists('/etc/systemd/system/energy_manager.service'); ?>
        <?php if ($energyManagerServiceExists): ?>
            <div class="dashboard-card mb-3 p-3 d-flex align-items-center justify-content-between">
                <div>
                    <div class="fw-bold text-info"><i class="fas fa-robot me-2"></i>Energy Manager</div>
                    <div class="small text-muted">WP & intelligentes Laden</div>
                </div>
                <form method="post">
                    <input type="hidden" name="save_lux_global" value="1">
                    <div class="form-check form-switch m-0">
                        <input class="form-check-input" type="checkbox" name="lux_active" value="1" <?= $luxtronikEnabled ? 'checked' : '' ?> onchange="this.form.submit()" style="transform: scale(1.3);">
                    </div>
                </form>
            </div>
        <?php endif; ?>

        <?php include 'config_editor.php'; ?>
    <?php elseif ($seite == 'luxtronik' && $luxtronikEnabled): ?>
        <?php include 'luxtronik.php'; ?>
    <?php elseif ($seite == 'charging'): ?>
        <?php include 'luxtronik.php'; ?>
    <?php elseif ($seite == 'history'): ?>
        <?php include 'history.php'; ?>
    <?php elseif ($seite == 'archiv'): ?>
        <?php include 'archiv.php'; ?>
    <?php endif; ?>
</div>

<?= renderUpdateModal('modal-dialog-scrollable modal-fullscreen-sm-down') ?>
<?= renderWatchdogModal('modal-dialog-scrollable modal-fullscreen-sm-down') ?>
<?= renderChangelogModal('modal-dialog-scrollable modal-fullscreen-sm-down') ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="solar.js?v=<?= file_exists('solar.js') ? filemtime('solar.js') : time() ?>"></script>
<script>
const PV_MAX = <?= $pvMax ?>; const WP_MAX = <?= $wpMax ?>; const BAT_MAX = <?= $maxBatPower ?>; const BAT_CAPACITY = <?= $batteryCapacity ?>; const AVGS = <?= json_encode($avgs) ?>;
const PRICE_HISTORY = <?= json_encode($priceHistory) ?>;
let FORECAST_DATA = <?= json_encode($forecastData) ?>;
const LON = <?= json_encode($lon) ?>;
const PV_STRINGS = <?= json_encode($pvStrings) ?>;
const PV_ATMOSPHERE = <?= json_encode($pvAtmosphere) ?>;
let DARK_MODE = <?= $darkMode ? 'true' : 'false' ?>;
let SHOW_FORECAST = <?= $showForecast ? 'true' : 'false' ?>;
const PRICE_START_HOUR = <?= $priceStartHour ?>;
const PRICE_INTERVAL = <?= $priceInterval ?>;
const USE_STATIC_CHART = <?= $useStaticData ? 'true' : 'false' ?>;
let lastUpdateTs = <?= $lastUpdateTs ?>;
let priceTendencyHtml = '';
let CURRENT_VIEW = 'normal';
let statusCheckInterval = null;
let currentLiveHours = 6;
let flowAnimationCache = {};

function formatWatts(w) {
    if (Math.abs(w) >= 4000) return (w/1000).toLocaleString('de-DE',{minimumFractionDigits:2, maximumFractionDigits:2})+'<span class="unit"> kW</span>';
    return Math.round(w).toLocaleString('de-DE')+'<span class="unit"> W</span>';
}

function toggleForecast(el) {
    SHOW_FORECAST = !SHOW_FORECAST;
    // Icon umschalten
    if (SHOW_FORECAST) el.classList.replace('fa-eye-slash', 'fa-eye');
    else el.classList.replace('fa-eye', 'fa-eye-slash');
    
    // Speichern
    fetch('mobile.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=save_setting&key=show_forecast&value=' + (SHOW_FORECAST ? '1' : '0')
    });
    updateDashboard();
}

function toggleDarkMode(el) {
    DARK_MODE = !DARK_MODE;
    document.body.setAttribute('data-theme', DARK_MODE ? 'dark' : 'light');
    document.body.setAttribute('data-bs-theme', DARK_MODE ? 'dark' : 'light');
    el.className = DARK_MODE ? 'fas fa-moon text-secondary' : 'fas fa-sun text-secondary';
    
    // Speichern
    fetch('mobile.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=save_setting&key=darkmode&value=' + (DARK_MODE ? '1' : '0')
    });

    // Refresh currently visible diagram to apply the new theme
    const currentPage = '<?= $seite ?>';
    // WICHTIG: Auch wenn der Container gerade ausgeblendet ist, wollen wir beim nächsten Öffnen
    // das richtige Theme. Aber um Serverlast zu sparen, aktualisieren wir nur, wenn sichtbar
    // ODER wir setzen ein Flag, dass ein Update nötig ist.
    if (currentPage === 'live') {
        updateDiagram();
    } else if (currentPage === 'forecast') {
        updateForecast();
    } else if (currentPage === 'history' && typeof window.triggerHistoryUpdate === 'function') {
        // history.php is included, its function should be available
        window.triggerHistoryUpdate();
    } else if (currentPage === 'archiv') {
        const frame = document.getElementById('archivFrame');
        if (frame && frame.src) {
            // Rebuild URL to include new theme and bust cache
            let url = new URL(frame.src, window.location.origin);
            url.searchParams.set('dark', DARK_MODE ? '1' : '0');
            url.searchParams.set('ts', Date.now());
            frame.src = url.href;
        }
    }
}

function updateDashboard() {
    // Prüfen ob wir auf der Live-Seite sind (Flow-View existiert)
    if (document.getElementById('flow-view') == null) return;
    
    fetch('get_live_json.php').then(r => r.json()).then(data => {
        const timeElem = document.getElementById('live-time');
        timeElem.innerText = data.time;
        
        const now = Math.floor(Date.now() / 1000);
        const dataTs = data.ts || 0;
        const age = now - dataTs;

        // PV Logik & Farben
        
        // Connection Badge Update
        const statusBadge = document.getElementById('connection-status');
        if (statusBadge) {
            if (age > 300) {
                statusBadge.className = 'badge rounded-pill bg-warning text-dark';
                statusBadge.innerText = 'Veraltet';
            } else {
                statusBadge.className = 'badge rounded-pill bg-success text-white';
                statusBadge.innerText = 'Online';
            }
        }

        // --- Flow Logic ---
        const updateFlow = (id, val, reverse) => {
            const el = document.getElementById(id);
            if (!el) return;

            if (!flowAnimationCache[id]) {
                flowAnimationCache[id] = { speed: null, gap: null, reverse: null, stopped: false };
            }
            const cache = flowAnimationCache[id];

            if (Math.abs(val) < 15) {
                if (!cache.stopped) {
                    el.classList.add('stopped');
                    cache.stopped = true;
                }
                return;
            }

            const absVal = Math.abs(val);
            let newGap = 30; // 30 ist Teiler von 60 (CSS Offset) -> flüssiger Loop
            if (absVal > 6000) newGap = 10;
            else if (absVal > 3000) newGap = 15;
            else if (absVal > 1000) newGap = 20;

            // Geschwindigkeit in Stufen, um "Hüpfen" zu vermeiden
            let newSpeed;
            if (absVal < 500) newSpeed = 6.0;
            else if (absVal < 2000) newSpeed = 5.0;
            else if (absVal < 4500) newSpeed = 4.0;
            else if (absVal < 9000) newSpeed = 3.0;
            else newSpeed = 2.0; // >= 9000W

            if (cache.stopped) {
                el.classList.remove('stopped');
                cache.stopped = false;
            }

            if (cache.reverse !== reverse) {
                if (reverse) el.classList.add('reverse');
                else el.classList.remove('reverse');
                cache.reverse = reverse;
            }

            if (cache.gap !== newGap) { el.style.strokeDasharray = `0 ${newGap}`; cache.gap = newGap; }
            if (cache.speed !== newSpeed) { el.style.animationDuration = newSpeed + 's'; cache.speed = newSpeed; }
        };

        let pv = data.pv || 0;
        let bat = data.bat || 0;
        let grid = data.grid || 0;
        let h = (data.wp > 10) ? Math.max(0, (data.home_raw || 0)-data.wp) : (data.home_raw || 0);
        let wb = data.wb || 0;
        let wp = data.wp || 0;

        // Werte setzen
        $('#f-val-pv').html(formatWatts(pv));
        $('#f-val-home').html(formatWatts(h));
        
        // Tagesertrag PV (als extra Tag)
        const yieldTag = $('#f-val-pv-yield');
        if (data.pv_today_kwh != null && data.pv_today_kwh > 0) {
            yieldTag.text(data.pv_today_kwh.toLocaleString('de-DE', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + ' kWh').show();
        } else {
            yieldTag.hide();
        }
        
        // Wallbox Session (als extra Tag)
        const wbSessionTag = $('#f-val-wb-session');
        if (data.wb_session_kwh != null && (data.wb_session_kwh > 0 || data.wb_locked === true)) {
            wbSessionTag.text(data.wb_session_kwh.toLocaleString('de-DE', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + ' kWh').show();
        } else {
            wbSessionTag.hide();
        }

        $('#f-val-wb').html(formatWatts(wb));
        $('#f-val-wp').html(formatWatts(wp));
        $('#f-val-grid').html(formatWatts(grid));
        $('#f-val-bat').html(formatWatts(Math.abs(bat))); // Batterie bleibt positiv (Laden/Entladen durch Farbe/Richtung)
        $('#f-lbl-soc').text(Math.round(data.soc) + '% SoC');
        
        // Autarkie (Momentan)
        let autarkieLive = calculateLiveAutarky(h, wb, wp, grid);
        if (document.getElementById('m-val-autarky-live')) $('#m-val-autarky-live').text(autarkieLive.toFixed(0) + '%');
        
        // Tageswerte
        if (data.autarky_day !== undefined) $('#m-val-autarky-day').text(Math.round(data.autarky_day) + '%');
        if (data.selfcon_day !== undefined) $('#m-val-selfcon-day').text(Math.round(data.selfcon_day) + '%');
        
        if (currentStatsDate === 'today' && data.stats) {
            updateStatsUI(data, 'mobile');
        }

        // Batterie Visualisierung
        if (bat > 0) {
            $('#f-node-bat').addClass('charging');
            $('#flow-line-bat, #flow-dot-bat').attr('stroke', '#2ecc71');
        } else {
            $('#f-node-bat').removeClass('charging');
            $('#flow-line-bat, #flow-dot-bat').attr('stroke', '#dc3545');
        }
        
        // SoC Fill
        let socPct = Math.round(data.soc);
        let fillCol = (bat > 0) ? 'rgba(46, 204, 113, 0.3)' : 'rgba(220, 53, 69, 0.2)';
        let bgCol = DARK_MODE ? '#1a1f29' : '#f8f9fa';
        $('#f-node-bat').css('background', `linear-gradient(to top, ${fillCol} ${socPct}%, ${bgCol} ${Math.min(100, socPct + 10)}%)`);

        // WP Boost
        if (data.wp_boost_active === true) {
            $('.node-wp').addClass('boost');
            $('#flow-line-wp, #flow-dot-wp').attr('stroke', '#dc3545');
        } else {
            $('.node-wp').removeClass('boost');
            $('#flow-line-wp, #flow-dot-wp').attr('stroke', '#22d3ee');
        }
        
        // Netz Farbe (Einspeisung = Grün, Bezug = Grau)
        if (grid < 0) {
            $('#flow-dot-grid').attr('stroke', '#2ecc71');
        } else {
            $('#flow-dot-grid').attr('stroke', '#6c757d');
        }
        
        // Wallbox Lock Icon
        if (data.wb_locked === true) {
            $('#f-wb-lock').show();
        } else {
            $('#f-wb-lock').hide();
        }

        // Animationen
        updateFlow('flow-dot-pv', pv, false);
        updateFlow('flow-dot-home', h, false);
        updateFlow('flow-dot-wb', wb, false);
        updateFlow('flow-dot-wp', wp, false);
        updateFlow('flow-dot-grid', grid, grid < 0);
        updateFlow('flow-dot-bat', bat, bat > 0);

        // Click Handler für Details (Diagramme öffnen)
        $('.node-pv').off('click').on('click', () => toggleDiagram('pv'));
        $('.node-bat').off('click').on('click', () => toggleDiagram('bat'));
        $('.node-grid').off('click').on('click', () => toggleDiagram('grid'));
        $('.node-wb').off('click').on('click', () => toggleDiagram('wb'));
        $('.node-wp').off('click').on('click', () => toggleDiagram('wp'));
        
        // Strompreis
        const priceVal = document.getElementById('val-price');
        const priceCard = document.getElementById('card-price');
        const priceNum = Number(data.price_ct);
            if (priceVal) {
                function gmtToLocal(slot) {
                    const val = parseFloat(slot);
                    if (isNaN(val)) return '--:--';
                    
                    const gmtHour = Math.floor(val);
                    const gmtMin = Math.round((val - gmtHour) * 60);
                    
                    const now = new Date();
                    const date = new Date();
                    date.setUTCHours(gmtHour, gmtMin, 0, 0);
                    
                    let dayLabel = (date.getDate() !== now.getDate()) ? 'morgen' : 'heute';
                    let localHour = date.getHours();
                    let localMin = date.getMinutes();
                    return dayLabel + ' ' + String(localHour).padStart(2, '0') + ':' + String(localMin).padStart(2, '0');
                }
                let minPrice = '--';
                let minTime = '--:--';
                let maxPrice = '--';
                let maxTime = '--:--';
                if (typeof data.price_min_ct === 'number') {
                    minPrice = data.price_min_ct.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                }
                if (typeof data.price_max_ct === 'number') {
                    maxPrice = data.price_max_ct.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                }
                
                // Flat-Tariff Check
                let pMinVal = (typeof data.price_min_ct === 'number') ? data.price_min_ct : 0;
                let pMaxVal = (typeof data.price_max_ct === 'number') ? data.price_max_ct : 0;
                if (priceCard) priceCard.style.display = (Math.abs(pMaxVal - pMinVal) < 0.1) ? 'none' : 'block';

                minTime = gmtToLocal(data.price_min_slot);
                maxTime = gmtToLocal(data.price_max_slot);

                // Tendenz vorab berechnen für die Hauptanzeige
                let prices = (data.prices && data.prices.length > 0) ? data.prices : PRICE_HISTORY;
                let startHour = PRICE_START_HOUR;
                let interval = PRICE_INTERVAL;

                // Wenn statische Daten geladen wurden (z.B. awattardebug.23.txt), nutzen wir diese für den Chart,
                // da die Live-Daten (data.prices) oft abgeschnitten sind (Strich ganz links).
                if (USE_STATIC_CHART) {
                    prices = PRICE_HISTORY;
                } else if (data.prices && data.prices.length > 0) {
                     if (data.price_start_hour !== undefined && data.price_start_hour !== null) startHour = data.price_start_hour;
                     if (data.price_interval !== undefined && data.price_interval !== null) interval = data.price_interval;
                }

                priceTendencyHtml = '';
                let hourDiff = 0;
                if (prices && prices.length > 0) {
                    const now = new Date();
                    const curGmtDec = now.getUTCHours() + (now.getUTCMinutes() / 60);
                    

                    hourDiff = curGmtDec - startHour;
                    if (hourDiff < 0) hourDiff += 24;
                    let idx = Math.floor(hourDiff / interval);
                    if (prices[idx] !== undefined && prices[idx+1] !== undefined) {
                        const diff = prices[idx+1] - prices[idx];
                        const isExtreme = Math.abs(diff) > 5;
                        const blinkClass = isExtreme ? ' blink-extreme' : '';
                        
                        if (diff > 0.1) priceTendencyHtml = '<i class="fas fa-arrow-trend-up text-danger ms-2' + blinkClass + '" style="font-size: 0.7em; vertical-align: middle;" title="Preis steigend"></i>';
                        else if (diff < -0.1) priceTendencyHtml = '<i class="fas fa-arrow-trend-down text-success ms-2' + blinkClass + '" style="font-size: 0.7em; vertical-align: middle;" title="Preis fallend"></i>';
                        else priceTendencyHtml = '<i class="fas fa-arrow-right text-info ms-2" style="font-size: 0.7em; vertical-align: middle;" title="Preis stabil"></i>';
                    }
                }

                // Intelligent Price Integration in Flow
                const fPrice = document.getElementById('f-val-price');
                if (fPrice) {
                    fPrice.style.display = 'block';
                    fPrice.innerText = (Number.isFinite(priceNum) ? priceNum.toLocaleString('de-DE', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) : '--') + ' ct';
                    
                    // Farbe basierend auf Level
                    fPrice.style.color = 'var(--text-body)';
                    if (data.price_level === 'cheap') fPrice.style.color = '#10b981';
                    else if (data.price_level === 'expensive') fPrice.style.color = '#f43f5e';
                    else fPrice.style.color = '#fbbf24';
                }

                let priceText = (Number.isFinite(priceNum) ? priceNum.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '--') + '<span class="unit"> ct/kWh</span>' + priceTendencyHtml;
                priceVal.innerHTML = priceText;

                const minEl = document.getElementById('price-val-min');
                const maxEl = document.getElementById('price-val-max');
                if (minEl) minEl.innerHTML = '<span style="color:#10b981">' + minPrice + '<span class="unit" style="font-size:0.65em;margin-left:2px"> ct</span></span><br><span style="font-size:0.65em;color:#aaa;font-weight:normal">' + minTime + '</span>';
                if (maxEl) maxEl.innerHTML = '<span style="color:#f43f5e">' + maxPrice + '<span class="unit" style="font-size:0.65em;margin-left:2px"> ct</span></span><br><span style="font-size:0.65em;color:#aaa;font-weight:normal">' + maxTime + '</span>';

                // Hintergrund-Chart zeichnen (Stufenlinie als Area-Chart)
                const chart = document.getElementById('price-chart');
                if (chart && prices && prices.length > 0) {
                    const min = Math.min(...prices);
                    const max = Math.max(...prices);
                    const range = max - min || 1;
                    let pathData = "M 0 100"; // Start unten links
                    
                    let minIndices = [];
                    let maxIndices = [];

                    for (let i = 0; i < prices.length; i++) {
                        if (Math.abs(prices[i] - min) < 0.001) minIndices.push(i);
                        if (Math.abs(prices[i] - max) < 0.001) maxIndices.push(i);

                        const xStart = (i / prices.length) * 240;
                        const xEnd = ((i + 1) / prices.length) * 240;
                        const y = 100 - ((prices[i] - min) / range * 60 + 5); // Skaliert auf max 60% Höhe
                        pathData += ` L ${xStart} ${y} H ${xEnd}`;
                        if (i < prices.length - 1) {
                            const nextY = 100 - ((prices[i+1] - min) / range * 60 + 5);
                            pathData += ` V ${nextY}`;
                        }
                    }
                    pathData += " L 240 100 Z"; // Schließen nach unten rechts
                    
                    // Farbige Balken für Min/Max generieren
                    let bars = "";
                    const slotW = 240 / prices.length;
                    const getY = (p) => 100 - ((p - min) / range * 60 + 5);
                    
                    maxIndices.forEach(i => {
                        bars += `<rect x="${i*slotW}" y="${getY(prices[i])}" width="${slotW}" height="${100-getY(prices[i])}" fill="#f43f5e" fill-opacity="0.4" />`;
                    });
                    minIndices.forEach(i => {
                        bars += `<rect x="${i*slotW}" y="${getY(prices[i])}" width="${slotW}" height="${100-getY(prices[i])}" fill="#10b981" fill-opacity="0.7" />`;
                    });

                    // Aktuelle Zeit Markierung berechnen (GMT Abgleich)
                    const now = new Date();
                    const xPosPercent = (hourDiff / (prices.length * PRICE_INTERVAL)) * 100;
                    
                    chart.innerHTML = `<path d="${pathData}" fill="currentColor" fill-opacity="0.25" stroke="none" />` + bars;
                    
                    // Marker-Elemente (HTML statt SVG um Verzerrung zu vermeiden)
                    const line = document.getElementById('price-line');
                    const label = document.getElementById('price-time-label');
                    if (xPosPercent >= 0 && xPosPercent <= 100) {
                        line.style.left = xPosPercent + '%'; line.style.display = 'block';
                        label.style.left = xPosPercent + '%'; label.style.display = 'block';
                        label.innerText = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
                        // Label-Anker korrigieren
                        if (xPosPercent > 85) label.style.transform = 'translateX(-100%)';
                        else if (xPosPercent < 15) label.style.transform = 'translateX(0%)';
                        else label.style.transform = 'translateX(-50%)';
                    }

                    // Tagestrenner (Morgen 00:00 Uhr Local)
                    const dayLine = document.getElementById('price-line-day');
                    const yesterdayLine = document.getElementById('price-line-yesterday');
                    const dayOverlay = document.getElementById('price-overlay-tomorrow');
                    const dayLabel = document.getElementById('price-label-tomorrow');
                    const yesterdayLabel = document.getElementById('price-label-yesterday');

                    if (dayLine) {
                        const totalHours = prices.length * PRICE_INTERVAL;
                        const nowLocal = new Date();
                        const localHours = nowLocal.getHours() + (nowLocal.getMinutes() / 60);
                        
                        // hourDiff ist die Zeit von Chart-Start bis JETZT (berechnet oben)
                        // Wir berechnen die Positionen relativ zu JETZT
                        
                        // Start von Heute (00:00 Uhr) = Jetzt - localHours
                        let posToday = hourDiff - localHours;
                        
                        // Start von Morgen (24:00 Uhr) = Jetzt + (24 - localHours)
                        let posTomorrow = hourDiff + (24 - localHours);
                        
                        const pctToday = (posToday / totalHours) * 100;
                        const pctTomorrow = (posTomorrow / totalHours) * 100;
                        
                        // Linie für Morgen
                        if (pctTomorrow > 0 && pctTomorrow < 100) { 
                            dayLine.style.left = pctTomorrow + '%'; dayLine.style.display = 'block'; 
                            if (dayOverlay) { dayOverlay.style.left = pctTomorrow + '%'; dayOverlay.style.display = 'block'; }
                        } else { 
                            dayLine.style.display = 'none'; 
                            if (dayOverlay) {
                                if (pctTomorrow <= 0) { // Alles ist Morgen
                                    dayOverlay.style.left = '0%'; dayOverlay.style.display = 'block';
                                } else {
                                    dayOverlay.style.display = 'none';
                                }
                            }
                        }
                        if (dayLabel) {
                            dayLabel.style.display = (pctTomorrow < 100) ? 'block' : 'none';
                        }

                        // Linie für Heute (Start of Today)
                        if (pctToday > 0 && pctToday < 100) { 
                            yesterdayLine.style.left = pctToday + '%'; yesterdayLine.style.display = 'block'; 
                        } else { 
                            yesterdayLine.style.display = 'none'; 
                        }
                        
                        if (yesterdayLabel) {
                            yesterdayLabel.style.display = (pctToday > 0) ? 'block' : 'none';
                        }
                    }
                }
                updateLastUpdateDisplay();

                if (priceNum < 10) {
                    priceVal.className = 'value text-success price-ultra-cheap';
                    if (priceCard) {
                        priceCard.style.background = 'rgba(16, 185, 129, 0.25)';
                        priceCard.style.borderColor = '#10b981';
                    }
                } else if (data.price_level === 'cheap') {
                    priceVal.className = 'value text-success';
                    if (priceCard) {
                        priceCard.style.background = 'rgba(16, 185, 129, 0.13)';
                        priceCard.style.borderColor = '#2d3748';
                    }
                } else if (data.price_level === 'expensive') {
                    priceVal.className = 'value text-danger';
                    if (priceCard) {
                        priceCard.style.background = 'rgba(244, 63, 94, 0.13)';
                        priceCard.style.borderColor = '#2d3748';
                    }
                } else {
                    priceVal.className = 'value';
                    priceVal.style.color = '#fbbf24';
                    if (priceCard) {
                        priceCard.style.background = 'rgba(251, 191, 36, 0.13)';
                        priceCard.style.borderColor = '#2d3748';
                    }
                }
            }

        // Details über dem Diagramm aktualisieren
        const detailsEl = document.getElementById('diagramDetails');
        const diagContainer = document.getElementById('diagramContainer');
        if (detailsEl && diagContainer.style.display !== 'none') {
            let content = '';
            if (CURRENT_VIEW === 'pv') {
                if (data.dc0_w !== undefined) content = `Gesamt: ${data.pv}W | String 1: ${data.dc0_w}W (${data.dc0_v}V) | String 2: ${data.dc1_w}W (${data.dc1_v}V)`;
            } else if (CURRENT_VIEW === 'grid') {
                if (data.grid_p1 !== undefined) content = `Netz: ${data.grid}W (L1: ${data.grid_p1} | L2: ${data.grid_p2} | L3: ${data.grid_p3})`;
                if (data.ac0_w !== undefined) {
                    const wrTotal = (data.ac0_w || 0) + (data.ac1_w || 0) + (data.ac2_w || 0);
                    content += `<br>WR: ${wrTotal}W (L1: ${data.ac0_w} | L2: ${data.ac1_w} | L3: ${data.ac2_w})`;
                }
            } else if (CURRENT_VIEW === 'wb') {
                if (data.wb_p1 !== undefined) content = `Wallbox L1: ${data.wb_p1}W | L2: ${data.wb_p2}W | L3: ${data.wb_p3}W`;
            } else if (CURRENT_VIEW === 'bat') {
                if (data.bat_v !== undefined) content = `Spannung: ${data.bat_v}V | Strom: ${data.bat_a}A`;
            }
            
            if (content) {
                detailsEl.innerHTML = content;
                detailsEl.style.display = 'block';
            } else {
                detailsEl.style.display = 'none';
            }
        }
    }).catch(() => {
        const statusBadge = document.getElementById('connection-status');
        if (statusBadge) {
            statusBadge.className = 'badge rounded-pill bg-danger text-white';
            statusBadge.innerText = 'Offline';
        }
    });
}

function updateLastUpdateDisplay() {
    if (!lastUpdateTs) return;
    const d = new Date(lastUpdateTs * 1000);
    const timeStr = d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0');
    document.getElementById('diagramStatus').innerHTML = timeStr;
}

function toggleDiagram(view = 'normal') {
    let c = document.getElementById('diagramContainer');

    // --- NEU: Statistik-Overlay schließen, falls es geöffnet ist ---
    if (typeof statsViewActive !== 'undefined' && statsViewActive) {
        toggleStatsView('mobile');
    }

    // If diagram is hidden, or we are switching to a different view
    if (c.style.display === 'none' || CURRENT_VIEW !== view) {
        c.style.display = 'block';
        CURRENT_VIEW = view;
        updateDashboard(); // Sofort Details aktualisieren
        
        // Reset History Select to Live when opening new tile
        const histSelect = document.getElementById('mobileHistorySelect');
        const histSelectWP = document.getElementById('mobileHistorySelectWP');
        if(histSelect) histSelect.value = '';
        if(histSelectWP) histSelectWP.value = '';
        
        // Toggle correct dropdown
        if (view === 'wp') {
            if(histSelect) histSelect.style.display = 'none';
            if(histSelectWP) histSelectWP.style.display = 'block';
        } else {
            if(histSelect) histSelect.style.display = 'block';
            if(histSelectWP) histSelectWP.style.display = 'none';
        }
        
        updateDiagramHistory(''); // Reset UI and trigger update
    } 
    // If diagram is visible and we click the same tile again, hide it
    else { 
        c.style.display = 'none'; 
    }
}

function setLiveHours(hours, btn) {
    currentLiveHours = hours;
    const group = document.getElementById('liveTimeFilter');
    if (group) {
        group.querySelectorAll('.btn').forEach(b => b.classList.remove('active'));
    }
    if (btn) btn.classList.add('active');
    updateDiagram();
}

function updateDiagramHistory(file) {
    const btnGroup = document.getElementById('liveTimeFilter');
    if (file) {
        if(btnGroup) btnGroup.style.display = 'none';
    } else {
        if(btnGroup) btnGroup.style.display = 'inline-flex';
    }
    updateDiagram();
}

function updateDiagram() {
    const btn = document.getElementById('diagramUpdateBtn');
    const status = document.getElementById('diagramStatus');
    const frame = document.getElementById('diagramFrame');
    const historySelect = document.getElementById('mobileHistorySelect');
    const historySelectWP = document.getElementById('mobileHistorySelectWP');
    
    let file = '';
    if (CURRENT_VIEW === 'wp' && historySelectWP) file = historySelectWP.value;
    else if (historySelect) file = historySelect.value;
    
    btn.disabled = true;
    status.textContent = 'Lade Daten...';
    
    let url = 'mobile.php?action=run_live_history&view=' + CURRENT_VIEW + '&dark=' + (DARK_MODE ? '1' : '0');
    if (file) url += '&file=' + encodeURIComponent(file);
    else url += '&hours=' + currentLiveHours;

    fetch(url)
    .then(r => r.json())
    .then(data => {
        if (data.ok) {
            const checkInterval = setInterval(() => { fetch('mobile.php?action=run_live_history&mode=status')
                .then(r => r.json())
                .then(stat => {
                    if (!stat.running) {
                        clearInterval(checkInterval);
                        // Nur neu laden, wenn kein Fehler vorliegt
                        if (!stat.error) {
                            frame.onload = function() {
                                frame.style.opacity = '1';
                                frame.onload = null;
                            };
                            frame.style.opacity = '0.5';
                            const newUrl = 'live_diagramm.html?t=' + Date.now();
                            frame.src = newUrl;
                            lastUpdateTs = Math.floor(Date.now() / 1000);
                            status.textContent = 'Aktualisiert';
                            setTimeout(updateLastUpdateDisplay, 2000);
                        } else {
                            status.textContent = 'Fehler!';
                        }
                        btn.disabled = false;
                    }
                });
            }, 400);
        } else {
            status.textContent = 'Fehler: ' + (data.error || 'Unbekannt');
            btn.disabled = false;
        }
    }).catch(() => {
        status.textContent = 'Fehler';
        btn.disabled = false;
    });
}

function updateForecast() {
    const btn = document.getElementById('forecastUpdateBtn');
    const status = document.getElementById('forecastStatus');
    const frame = document.getElementById('forecastFrame');
    
    if(btn) btn.disabled = true;
    if(status) status.textContent = 'Berechne Prognose...';
    
    fetch('mobile.php?action=run_now&mode=mobile&dark=' + (DARK_MODE ? '1' : '0'))
    .then(r => r.text())
    .then(txt => {
        if (txt === 'started' || txt === 'running') {
            const checkInterval = setInterval(() => {
                fetch('mobile.php?action=status&mode=mobile')
                .then(r => r.json())
                .then(stat => {
                    if (!stat.running) {
                        clearInterval(checkInterval);
                        if (!stat.error) {
                            frame.onload = function() {
                                frame.style.opacity = '1';
                                frame.onload = null;
                            };
                            frame.style.opacity = '0.5';
                            frame.src = 'diagramm_mobile.html?t=' + Date.now();
                            if(status) status.textContent = 'Aktualisiert: ' + new Date().toLocaleTimeString();
                        } else {
                            if(status) status.textContent = 'Fehler bei der Berechnung';
                        }
                        if(btn) btn.disabled = false;
                    }
                });
            }, 400);
        } else if (txt === 'skipped') {
             if(status) status.textContent = 'Daten sind aktuell.';
             if(btn) btn.disabled = false;
        } else {
             if(status) status.textContent = 'Fehler: ' + txt;
             if(btn) btn.disabled = false;
        }
    })
    .catch(() => {
        if(status) status.textContent = 'Netzwerkfehler';
        if(btn) btn.disabled = false;
    });
}

// startSystemUpdate, pollUpdate, finalize entfernt -> jetzt in solar.js

updateDashboard(); setInterval(updateDashboard, 2000);

// Initialisierung für Desktop-Modus
window.addEventListener('DOMContentLoaded', () => {
    if (document.body.classList.contains('mode-desktop')) {
        document.getElementById('diagramFrame').src = 'diagramm_mobile.html?t=' + Date.now();
    }

    // Update Check (Initial)
    setTimeout(() => {
        fetch('mobile.php?action=check_update').then(r=>r.json()).then(d => {
            const btnUpdate = document.getElementById('btn-system-update');
            if(d.success && d.missing > 0) {
                const bNav = document.getElementById('update-badge-nav');
                const bBtn = document.getElementById('update-badge-btn');
                if(bNav) bNav.style.display = 'inline-block';
                if(bBtn) { bBtn.style.display = 'inline-block'; bBtn.innerText = d.missing + ' NEU'; }
                
                if(btnUpdate) {
                    btnUpdate.classList.remove('btn-outline-warning');
                    btnUpdate.classList.add('btn-warning');
                }
            }
        });
    }, 2000);
    
    // Periodische Prüfung alle 15 Minuten
    setInterval(() => {
        fetch('mobile.php?action=check_update').then(r=>r.json()).then(d => {
            const bNav = document.getElementById('update-badge-nav');
            const bBtn = document.getElementById('update-badge-btn');
            if(d.success && d.missing > 0) {
                if(bNav) bNav.style.display = 'inline-block';
                if(bBtn) { bBtn.style.display = 'inline-block'; bBtn.innerText = d.missing + ' NEU'; }
            } else {
                if(bNav) bNav.style.display = 'none';
                if(bBtn) bBtn.style.display = 'none';
            }
        });
    }, 900000); // 15 Minuten

    // restartService entfernt -> jetzt in solar.js

    // Watchdog Status
    function checkWatchdog() {
        fetch('mobile.php?action=watchdog_status').then(r=>r.json()).then(data => {
            const icon = document.getElementById('watchdog-icon');
            if (data.installed) {
                icon.style.display = 'inline-block';
                icon.title = data.message;
                if (data.warning) {
                    icon.className = 'fas fa-shield-alt text-warning';
                } else if (data.active) {
                    icon.className = 'fas fa-shield-alt text-success';
                } else {
                    icon.className = 'fas fa-shield-alt text-danger';
                }
            } else {
                icon.style.display = 'none';
            }
        }).catch(e=>{});
    }
    setInterval(checkWatchdog, 10000);
    checkWatchdog();

    // showWatchdogLog, handleConnectionClick entfernt -> jetzt in solar.js
});
</script>
<script>
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
      navigator.serviceWorker.register('./sw.js')
        .then(reg => console.log('Service Worker erfolgreich registriert!', reg))
        .catch(err => console.error('Service Worker Registrierung fehlgeschlagen:', err));
    });
  } else {
    console.log('Service Worker wird von diesem Browser nicht unterstützt.');
  }
</script>
</body>
</html>
