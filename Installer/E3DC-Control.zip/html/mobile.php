<?php
require_once 'helpers.php';
$paths = getInstallPaths();
$configFile = rtrim($paths['install_path'], '/') . '/e3dc.config.txt';

// Einmaliges Auslesen der Config beim Laden
$wpMax = 5000;
if (file_exists($configFile)) {
    $conf = file_get_contents($configFile);
    if (preg_match('/wpmax\s*=\s*([\d\.]+)/i', $conf, $m)) {
        $wpMax = $m[1] * 1000; 
    }
}

$mobileLiveUrl = 'mobile.php';
$mobileWallboxUrl = getContextPageUrl('wallbox');
$mobileConfigUrl = getContextPageUrl('config');
$mobileArchivUrl = getContextPageUrl('archiv');
$mobileStartTriggerUrl = getContextPageUrl('start', ['mode' => 'mobile']);
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E3DC Mobile Pro</title>
    <!-- PWA Setup -->
    <link rel="manifest" href="manifest.json" crossorigin="use-credentials">
    <meta name="theme-color" content="#0b0e14">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <link rel="apple-touch-icon" href="icons/icon-192.png">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #0b0e14; color: #f8fafc; font-family: -apple-system, sans-serif; }
        .dashboard-card {
            background: #1a1f29; border: 1px solid #2d3748; border-radius: 20px;
            padding: 18px; margin-bottom: 12px; position: relative; overflow: hidden;
        }
        .fill-bar { position: absolute; top: 0; left: 0; height: 100%; transition: width 1.5s ease-in-out; z-index: 1; }
        .card-content { position: relative; z-index: 2; text-align: center; }
        .label { font-size: 0.75rem; text-transform: uppercase; color: #94a3b8; letter-spacing: 0.05em; margin-bottom: 5px; }
        .value { font-size: 2rem; font-weight: 800; line-height: 1.2; }
        .unit { font-size: 0.9rem; color: #64748b; font-weight: normal; margin-left: 2px; }
        
        /* Farben */
        .pv-val { color: #fbbf24; }
        .home-val { color: #3b82f6; }
        .wb-val { color: #a855f7; }
        .wp-val { color: #22d3ee; }
        .text-success { color: #10b981 !important; }
        .text-danger { color: #f43f5e !important; }
        
        #diagramContainer { border-radius: 20px; overflow: hidden; border: 1px solid #2d3748; margin-top: 15px; }

        /* Navigation */
        .mobile-nav {
            display: flex; justify-content: space-around; background: #1a1f29; 
            border: 1px solid #2d3748; border-radius: 20px; padding: 10px; margin-bottom: 20px;
        }
        .nav-item { color: #94a3b8; text-decoration: none; font-size: 0.8rem; text-align: center; flex: 1; }
        .nav-item i { display: block; font-size: 1.2rem; margin-bottom: 3px; }
        .nav-item.active { color: #3b82f6; font-weight: bold; }
        
        /* Überschreibung für eingebettete Formulare */
        .dashboard-card h1, .dashboard-card h2 { font-size: 1.2rem; color: #3b82f6; margin-bottom: 15px; text-align: left; }
        .dashboard-card .config-box { background: transparent; border: none; padding: 0; margin: 0; }
        .dashboard-card .config-item { margin-bottom: 15px; }
        .dashboard-card label { color: #94a3b8; font-size: 0.8rem; }
        .dashboard-card input[type="text"], .dashboard-card input[type="number"], .dashboard-card select {
            background: #0b0e14; border: 1px solid #2d3748; border-radius: 10px; color: #fff; padding: 10px;
        }
    </style>
    <!-- FontAwesome für Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
<div class="container py-3">
    <!-- Mobile Navigation -->
    <div class="mobile-nav">
        <a href="<?= htmlspecialchars($mobileLiveUrl) ?>" class="nav-item <?= !isset($_GET['seite']) ? 'active' : '' ?>">
            <i class="fas fa-bolt"></i>Live
        </a>
        <a href="<?= htmlspecialchars($mobileWallboxUrl) ?>" class="nav-item <?= ($_GET['seite']??'')=='wallbox' ? 'active' : '' ?>">
            <i class="fas fa-charging-station"></i>Wallbox
        </a>
        <a href="<?= htmlspecialchars($mobileConfigUrl) ?>" class="nav-item <?= ($_GET['seite']??'')=='config' ? 'active' : '' ?>">
            <i class="fas fa-cog"></i>Config
        </a>
        <a href="<?= htmlspecialchars($mobileArchivUrl) ?>" class="nav-item <?= ($_GET['seite']??'')=='archiv' ? 'active' : '' ?>">
            <i class="fas fa-history"></i>Archiv
        </a>
    </div>

    <?php
    $seite = $_GET['seite'] ?? 'live';
    if ($seite === 'auto') {
        $seite = 'wallbox';
    }
    if ($seite == 'live'):
    ?>

    <div class="d-flex justify-content-between align-items-center mb-4 px-2">
        <h5 class="m-0 fw-bold">E3DC Status</h5>
        <span class="badge border border-secondary text-info" id="live-time" style="background: #1a1f29; font-size: 0.9rem;">--:--:--</span>
    </div>

    <div class="dashboard-card">
        <div class="card-content">
            <div class="label">Photovoltaik</div>
            <div class="value pv-val" id="val-pv">0<span class="unit"> W</span></div>
        </div>
    </div>

    <div class="dashboard-card">
        <div id="fill-bat" class="fill-bar" style="width: 0%; background: rgba(16, 185, 129, 0.15);"></div>
        <div class="card-content">
            <div class="label" id="label-soc">Batterie (0%)</div>
            <div class="value" id="val-bat">0<span class="unit"> W</span></div>
        </div>
    </div>

    <div id="card-wp" class="dashboard-card" style="display:none;">
        <div id="fill-wp" class="fill-bar" style="width: 0%; background: rgba(34, 211, 238, 0.15);"></div>
        <div class="card-content">
            <div class="label">Wärmepumpe</div>
            <div class="value wp-val" id="val-wp">0<span class="unit"> W</span></div>
        </div>
    </div>

    <div id="card-wb" class="dashboard-card" style="display:none;">
        <div class="card-content">
            <div class="label">Wallbox</div>
            <div class="value wb-val" id="val-wb">0<span class="unit"> W</span></div>
        </div>
    </div>

    <div class="row g-2">
        <div class="col-6">
            <div class="dashboard-card">
                <div class="card-content">
                    <div class="label">Haus (Rest)</div>
                    <div class="value home-val" id="val-home">0</div>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="dashboard-card">
                <div class="card-content">
                    <div class="label">Netz</div>
                    <div class="value" id="val-grid">0</div>
                </div>
            </div>
        </div>
    </div>

    <div class="d-grid gap-2 mt-4">
        <button id="toggleDiagramBtn" class="btn btn-dark py-3 rounded-4 border-secondary" onclick="toggleDiagram()">
            📊 Diagramm einblenden
        </button>
        
        <div id="diagramContainer" style="display:none; margin-top: 10px;">
            <div id="diagramControls" class="d-flex justify-content-between align-items-center mb-2 px-2">
                <span id="diagramStatus" class="text-info small" style="font-size: 0.8rem;"></span>
                <button onclick="forceRefresh()" class="btn btn-outline-info btn-sm rounded-pill px-3" style="font-size: 0.75rem;">
                    ⟳ Aktualisieren
                </button>
            </div>
            <div style="height: 420px; border-radius: 20px; overflow: hidden; border: 1px solid #2d3748;">
                <iframe id="diagramFrame" src="" style="width: 100%; height: 100%; border: none;"></iframe>
            </div>
        </div>
    </div>

    <?php else: ?>
    <!-- Content Bereich für Unterseiten -->
    <div class="dashboard-card shadow-lg">
        <div class="card-content" style="text-align: left !important;">
            <?php
            switch ($seite) {
                case 'wallbox': include 'Wallbox.php'; break;
                case 'config': include 'config_editor.php'; break;
                case 'archiv': include 'mobile_archiv.php'; break;
                default: echo "Seite nicht gefunden.";
            }
            ?>
        </div>
    </div>
    <?php endif; ?>

</div>

<script>
const WP_MAX = <?= $wpMax ?>;
let statusCheckInterval = null;
const startTriggerUrl = "<?= htmlspecialchars($mobileStartTriggerUrl, ENT_QUOTES, 'UTF-8') ?>";

function formatWatts(watts) {
    let absW = Math.abs(watts);
    if (absW >= 1000) {
        return (watts / 1000).toLocaleString('de-DE', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + '<span class="unit"> kW</span>';
    }
    return watts.toLocaleString('de-DE') + '<span class="unit"> W</span>';
}

function updateDashboard() {
    const timeEl = document.getElementById('live-time');
    if (!timeEl) return;
    
    fetch('get_live_json.php')
        .then(response => response.json())
        .then(data => {
            if (data.time) timeEl.innerText = data.time;
            
            // Solar
            const pvEl = document.getElementById('val-pv');
            if (pvEl) pvEl.innerHTML = formatWatts(data.pv || 0);
            
            // Batterie
            const batVal = document.getElementById('val-bat');
            const batLabel = document.getElementById('label-soc');
            const batFill = document.getElementById('fill-bat');
            
            if (batVal) {
                batVal.innerHTML = formatWatts(data.bat || 0) + (data.bat >= 0 ? ' <small class="arrow">↑</small>' : ' <small class="arrow">↓</small>');
                batVal.className = 'value ' + (data.bat >= 0 ? 'text-success' : 'text-danger');
            }
            if (batLabel) batLabel.innerText = `Batterie (${data.soc || 0}%)`;
            if (batFill) batFill.style.width = (data.soc || 0) + '%';

            // Wärmepumpe
            const wpCard = document.getElementById('card-wp');
            const wpVal = document.getElementById('val-wp');
            const wpFill = document.getElementById('fill-wp');
            
            if (data.wp > 10) {
                if (wpCard) wpCard.style.display = 'block';
                if (wpVal) wpVal.innerHTML = formatWatts(data.wp);
                let wpPerc = Math.min(100, (data.wp / (WP_MAX * 1.1)) * 100);
                if (wpFill) wpFill.style.width = wpPerc + '%';
            } else {
                if (wpCard) wpCard.style.display = 'none';
            }

            // Wallbox
            const wbCard = document.getElementById('card-wb');
            const wbVal = document.getElementById('val-wb');
            if (data.wb > 0) {
                if (wbCard) wbCard.style.display = 'block';
                if (wbVal) wbVal.innerHTML = formatWatts(data.wb);
            } else {
                if (wbCard) wbCard.style.display = 'none';
            }

            // Haus (WP herausrechnen)
            const homeVal = document.getElementById('val-home');
            let homeReal = (data.wp > 10) ? Math.max(0, (data.home_raw || 0) - data.wp) : (data.home_raw || 0);
            if (homeVal) homeVal.innerHTML = formatWatts(homeReal);

            // Netz
            const gridVal = document.getElementById('val-grid');
            if (gridVal) {
                gridVal.innerHTML = formatWatts(data.grid || 0) + (data.grid <= 0 ? ' <small class="arrow">↑</small>' : ' <small class="arrow">↓</small>');
                gridVal.className = 'value ' + (data.grid <= 0 ? 'text-success' : 'text-danger');
            }
        });
}

function toggleDiagram() {
    let container = document.getElementById('diagramContainer');
    let frame = document.getElementById('diagramFrame');
    let btn = document.getElementById('toggleDiagramBtn');
    let status = document.getElementById('diagramStatus');
    
    if (container.style.display === 'none') {
        container.style.display = 'block';
        btn.innerText = "📊 Diagramm ausblenden";
        
        status.innerText = "Prüfe auf Updates...";
        
        // Triggert start_content.php - die Logik in PHP prüft, ob 15 Min + Offset um sind.
        fetch(startTriggerUrl).then(() => {
            // Hole Status um zu wissen ob Python gestartet wurde
            checkDiagramStatus(true);
        });
        
    } else {
        container.style.display = 'none';
        btn.innerText = "📊 Diagramm einblenden";
        if (statusCheckInterval) clearInterval(statusCheckInterval);
    }
}

/**
 * Erzwingt ein Update des Diagramms über run_now.php
 */
function forceRefresh() {
    let status = document.getElementById('diagramStatus');
    status.innerText = "Update erzwungen...";
    
    fetch('run_now.php?mode=mobile')
        .then(() => {
            checkDiagramStatus(true);
        });
}

/**
 * Fragt den Status ab und aktualisiert den iframe bei Erfolg
 */
function checkDiagramStatus(initial = false) {
    let statusEl = document.getElementById('diagramStatus');
    let frame = document.getElementById('diagramFrame');
    
    fetch('status.php?mode=mobile')
        .then(res => res.json())
        .then(data => {
            if (data.running) {
                statusEl.innerText = "⏳ Wird aktualisiert...";
                if (!statusCheckInterval) {
                    statusCheckInterval = setInterval(() => checkDiagramStatus(false), 3000);
                }
            } else {
                const wasRunning = statusCheckInterval !== null;
                if (statusCheckInterval) {
                    clearInterval(statusCheckInterval);
                    statusCheckInterval = null;
                }
                
                if (data.error) {
                    statusEl.innerText = "❌ Fehler";
                } else {
                    statusEl.innerText = "✓ Letztes: " + (data.last_update || "unbekannt");
                    
                    // Reload Iframe if needed (initial load OR just finished running)
                    let newSrc = 'diagramm_mobile.html?ts=' + new Date().getTime();
                    if (initial || wasRunning || frame.src.indexOf('diagramm_mobile.html') === -1) {
                        frame.src = newSrc;
                    }
                }
            }
        })
        .catch(() => {
            statusEl.innerText = "Keine Verbindung";
        });
}

// Initialer Aufruf und Interval
updateDashboard();
setInterval(updateDashboard, 4000);

// PWA Service Worker Registration
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('sw.js')
            .then(reg => console.log('SW registered', reg))
            .catch(err => console.log('SW Registration failed', err));
    });
}
</script>
</body>
</html>