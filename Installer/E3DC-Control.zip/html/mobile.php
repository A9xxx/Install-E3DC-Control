<?php
if (!defined('VIEW_MODE')) {
    define('VIEW_MODE', 'mobile');
}
require_once 'helpers.php';
$paths = getInstallPaths();
$configFile = rtrim($paths['install_path'], '/') . '/e3dc.config.txt';
$historyFile = rtrim($paths['install_path'], '/') . '/live_history.txt';

$stampFile = '/var/www/html/tmp/plot_soc_done_mobile';
$lastUpdateTs = file_exists($stampFile) ? filemtime($stampFile) : 0;

// AJAX Handler für Diagramm-Update (startet das Python-Script zur Diagramm-Erstellung)
if (isset($_GET['ajax']) && $_GET['ajax'] === 'update_plot') {
    header('Content-Type: application/json');
    $installPath = rtrim($paths['install_path'], '/');
    $scriptPath = $installPath . '/plot_soc_changes.py';
    if (!file_exists($scriptPath)) {
        echo json_encode(['success' => false, 'error' => 'Script nicht gefunden']);
        exit;
    }
    // In das Verzeichnis wechseln und Script ausführen
    $cmd = "cd " . escapeshellarg($installPath) . " && python3 " . escapeshellarg($scriptPath) . " awattardebug.txt mobile 2>&1";
    @exec($cmd, $output, $return_var);
    echo json_encode(['success' => ($return_var === 0)]);
    exit;
}

// 1. Auslesen der Config (WP_MAX und PV_MAX aus forecast1)
$wpMax = 5000; 
$pvMax = 10000; // Fallback
$maxBatPower = 3000; // Fallback
$batteryCapacity = 0; // Fallback
$lat = 51.16; $lon = 10.45; // Default (Mitte DE)
$pvStrings = [];

if (file_exists($configFile)) {
    $conf = file_get_contents($configFile);
    if (preg_match('/wpmax\s*=\s*([\d\.]+)/i', $conf, $m)) { $wpMax = $m[1] * 1000; }
    if (preg_match('/maximumLadeleistung\s*=\s*([\d\.]+)/i', $conf, $m)) { $maxBatPower = $m[1]; }
    if (preg_match('/speichergroesse\s*=\s*([\d\.]+)/i', $conf, $m)) { $batteryCapacity = (float)$m[1]; }
    if (preg_match('/hoehe\s*=\s*([\d\.]+)/i', $conf, $m)) { $lat = (float)$m[1]; }
    if (preg_match('/laenge\s*=\s*([\d\.]+)/i', $conf, $m)) { $lon = (float)$m[1]; }

    // Alle Forecast-Strings einlesen (z.B. forecast1 = 40/-50/15.4)
    if (preg_match_all('/forecast(\d+)\s*=\s*([\d\.\-]+)\/([\d\.\-]+)\/([\d\.]+)/i', $conf, $matches, PREG_SET_ORDER)) {
        $totalPv = 0;
        foreach ($matches as $m) {
            $p = (float)$m[4] * 1000;
            $pvStrings[] = ['tilt' => (float)$m[2], 'azimuth' => (float)$m[3], 'power' => $p];
            $totalPv += $p;
        }
        if ($totalPv > 0) $pvMax = $totalPv;
    } elseif (preg_match('/forecast1\s*=\s*[^=]+\/([\d\.]+)/i', $conf, $m)) { 
        $pvMax = $m[1] * 1000; // Fallback alte Logik
    }
}

// 2. 24h Mittelwerte berechnen (Cache 1 Std)
function get24hAverages($filePath) {
    $cacheFile = '/tmp/e3dc_avgs.json';
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 3600) return json_decode(file_get_contents($cacheFile), true);

    $avgs = ['home' => 800, 'grid' => 1000, 'wb' => 4000];
    if (file_exists($filePath)) {
        $lines = array_slice(file($filePath), -1000); // Letzte Einträge
        $sums = ['h' => 0, 'g' => 0, 'w' => 0]; $c = 0;
        foreach ($lines as $l) {
            $d = json_decode($l, true);
            if ($d) { $sums['h'] += abs($d['home_raw']??0); $sums['g'] += abs($d['grid']??0); $sums['w'] += ($d['wb']??0); $c++; }
        }
        if ($c > 0) $avgs = ['home' => $sums['h']/$c, 'grid' => $sums['g']/$c, 'wb' => $sums['w']/$c];
    }
    file_put_contents($cacheFile, json_encode($avgs));
    return $avgs;
}
$avgs = get24hAverages($historyFile);

// Strompreise aus awattardebug.txt für den Hintergrund-Chart laden
$priceHistory = [];
$forecastData = [];
$priceStartHour = 0;
$priceInterval = 1.0;
$currentHour = (int)date('H');

// Intelligente Dateiauswahl & Merge (0.txt/12.txt + live debug.txt)
$baseFile = 'awattardebug.0.txt';
if ($currentHour >= 22 || $currentHour < 10) {
    $baseFile = 'awattardebug.12.txt';
}

$filesToRead = [];
// 1. Basis-Datei
$fBase = rtrim($paths['install_path'], '/') . '/' . $baseFile;
if (file_exists($fBase)) $filesToRead[] = $fBase;
elseif ($baseFile === 'awattardebug.12.txt') {
    // Fallback auf 0.txt wenn 12.txt fehlt
    $f0 = rtrim($paths['install_path'], '/') . '/awattardebug.0.txt';
    if (file_exists($f0)) $filesToRead[] = $f0;
}
// 2. Live-Datei (für Updates ab 13/14 Uhr)
$fLive = rtrim($paths['install_path'], '/') . '/awattardebug.txt';
if (file_exists($fLive)) $filesToRead[] = $fLive;

$chartDataMap = [];
$forecastDataMap = [];

foreach ($filesToRead as $file) {
    $readingData = false;
    $lastTime = -1;
    $dayOffset = 0;

    foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $trimmed = trim($line);
        if ($trimmed === 'Data') { 
            $readingData = true; 
            // Reset für Data-Sektion, da diese oft eigenständig beginnt
            $lastTime = -1;
            $dayOffset = 0;
            continue; 
        }
        
        $cols = preg_split('/\s+/', $trimmed);
        if (count($cols) < 1 || !is_numeric($cols[0])) continue;

        // Tagestrennung erkennen (0.00 nach 23.75)
        $rawTime = (float)$cols[0];
        if ($lastTime !== -1 && $rawTime < $lastTime) {
            $dayOffset += 24;
        }
        $lastTime = $rawTime;
        $h = sprintf('%.2f', $rawTime + $dayOffset);

        if (!$readingData) {
            if (count($cols) >= 2 && is_numeric($cols[1])) {
                $chartDataMap[$h] = (float)$cols[1];
            }
        } else {
            // Prognose nach Data: Spalte 0 = Zeit, Spalte 4 = % Ladung in 15min
            // Berechnung Watt: % * Kapazität(kWh) * 40 (da 4 * 15min = 1h und %/100 -> Faktor 40)
            if (count($cols) >= 5 && is_numeric($cols[4])) {
                $forecastDataMap[$h] = (float)$cols[4] * $batteryCapacity * 40;
            }
        }
    }
}

// Sortieren und Arrays befüllen
uksort($chartDataMap, function($a, $b) { return (float)$a <=> (float)$b; });
uksort($forecastDataMap, function($a, $b) { return (float)$a <=> (float)$b; });

foreach ($chartDataMap as $h => $val) {
    if (empty($priceHistory)) $priceStartHour = (float)$h;
    elseif (count($priceHistory) === 1) $priceInterval = max(0.25, (float)$h - $priceStartHour);
    $priceHistory[] = $val;
}
foreach ($forecastDataMap as $h => $val) {
    $forecastData[] = ['h' => (float)$h, 'w' => $val];
}

$seite = $_GET['seite'] ?? 'live';
$mobileStartTriggerUrl = getContextPageUrl('start', ['mode' => 'mobile']);
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E3DC Mobile Pro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #0b0e14; color: #f8fafc; font-family: -apple-system, sans-serif; }
        /* Globaler Hover-Effekt für Desktop-Nutzer (Finger-Cursor) */
        button, .nav-item, .btn, [onclick], .fill-bar { cursor: pointer; }
        .dashboard-card { background: #1a1f29; border: 1px solid #2d3748; border-radius: 20px; padding: 18px; position: relative; overflow: hidden; height: 100%; }
        .fill-bar { position: absolute; top: 0; left: 0; height: 100%; transition: width 1.5s ease-in-out, background 0.5s; z-index: 1; opacity: 0.18; }
        .card-content { position: relative; z-index: 2; text-align: center; }
        .label { font-size: 0.7rem; color: #cbd5e1; font-weight: 600; letter-spacing: 0.05em; margin-bottom: 4px; }
        .value { font-size: 1.8rem; font-weight: 900; line-height: 1.2; }
        .unit { font-size: 0.8rem; color: #94a3b8; font-weight: bold; }
        .mobile-nav { display: flex; justify-content: space-around; background: #1a1f29; border: 1px solid #2d3748; border-radius: 20px; padding: 10px; margin-bottom: 20px; }
        .nav-item { color: #94a3b8; text-decoration: none; font-size: 0.75rem; text-align: center; flex: 1; }
        .nav-item i { display: block; font-size: 1.1rem; margin-bottom: 2px; }
        .nav-item.active { color: #3b82f6; font-weight: bold; }
        .pv-val { color: #fbbf24; } .home-val { color: #3b82f6; } .wb-val { color: #a855f7; } .wp-val { color: #22d3ee; }
        @keyframes pulse-dynamic { 0% { opacity: 0.18; } 50% { opacity: var(--pulse-intensity, 0.4); } 100% { opacity: 0.18; } }
        .pulse-active { animation: pulse-dynamic var(--pulse-speed, 2s) infinite ease-in-out; }
        .price-ultra-cheap { text-shadow: 0 0 10px rgba(16, 185, 129, 0.8); }
        #price-chart { position: absolute; bottom: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 1; opacity: 0.25; color: #94a3b8; }
        #price-line { position: absolute; top: 0; bottom: 0; width: 1px; border-left: 1px dashed rgba(255,255,255,0.5); z-index: 2; pointer-events: none; display: none; }
        #price-line-day { position: absolute; top: 0; bottom: 0; width: 1px; border-left: 1px dotted rgba(255,255,255,0.3); z-index: 1; pointer-events: none; display: none; }
        #price-line-yesterday { position: absolute; top: 0; bottom: 0; width: 1px; border-left: 1px dotted rgba(255,255,255,0.3); z-index: 1; pointer-events: none; display: none; }
        #price-overlay-tomorrow { position: absolute; top: 0; bottom: 0; right: 0; background: rgba(0,0,0,0.2); z-index: 0; pointer-events: none; display: none; }
        #price-label-tomorrow { position: absolute; top: 5px; right: 5px; color: rgba(255,255,255,0.3); font-size: 0.7rem; font-weight: bold; display: none; pointer-events: none; }
        #price-time-label { position: absolute; bottom: 4px; transform: translateX(-50%); color: white; font-size: 10px; font-weight: bold; z-index: 3; pointer-events: none; opacity: 0.9; white-space: nowrap; display: none; text-shadow: 1px 1px 2px black; }
        @keyframes blinker { 50% { opacity: 0.2; } }
        .blink-extreme { animation: blinker 0.8s linear infinite; }
        #val-pv-forecast .unit { color: inherit; }

        /* Desktop-spezifische Layout-Korrekturen */
        .mode-desktop .mobile-nav { display: none; }
        .mode-desktop .dashboard-card { margin-bottom: 20px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3); }
        .mode-desktop #diagramContainer { display: block !important; }
        .mode-desktop #toggleDiagramBtn { display: none; }
        /* Korrektur für den Status-Kreis im Stop-Feld auf Desktop */
        .mode-desktop .status-kreis { float: left; margin-right: 15px; position: static; }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body class="mode-<?php echo VIEW_MODE; ?>">
<div class="container py-3">
    <div class="mobile-nav">
        <a href="mobile.php" class="nav-item <?= $seite=='live'?'active':'' ?>"><i class="fas fa-bolt"></i>Live</a>
        <a href="mobile.php?seite=wallbox" class="nav-item <?= $seite=='wallbox'?'active':'' ?>"><i class="fas fa-charging-station"></i>Wallbox</a>
        <a href="mobile.php?seite=config" class="nav-item <?= $seite=='config'?'active':'' ?>"><i class="fas fa-cog"></i>Config</a>
        <a href="mobile.php?seite=history" class="nav-item <?= $seite=='history'?'active':'' ?>"><i class="fas fa-chart-line"></i>Historie</a>
        <a href="mobile.php?seite=archiv" class="nav-item <?= $seite=='archiv'?'active':'' ?>"><i class="fas fa-history"></i>Archiv</a>
    </div>

    <?php if ($seite == 'live'): ?>
        <div class="d-flex justify-content-between align-items-center mb-3 px-2">
            <h5 class="m-0 fw-bold">E3DC Status</h5>
            <span class="badge border border-secondary text-info" id="live-time" style="background: #1a1f29;">--:--:--</span>
        </div>

        <div class="dashboard-card mb-2">
            <div id="fill-pv" class="fill-bar" style="width: 0%; background: #fbbf24;"></div>
            <div class="card-content">
                <div class="label">Photovoltaik (Max: <?= round($pvMax/1000,1) ?> kWp)</div>
                <div class="value pv-val" id="val-pv">0</div>
                <div id="val-pv-forecast" style="font-size: 0.9rem; font-weight: bold; margin-top: -2px; display:none; color: #fbbf24;"></div>
            </div>
        </div>

        <div class="dashboard-card mb-2">
            <div id="fill-bat" class="fill-bar" style="width: 0%; background: #10b981;"></div>
            <div class="card-content">
                <div class="label" id="label-soc">Batterie</div>
                <div class="value" id="val-bat">0</div>
            </div>
        </div>

        <div class="row g-2 mb-2">
            <div class="col-6">
                <div class="dashboard-card">
                    <div id="fill-home" class="fill-bar" style="width: 0%; background: #3b82f6;"></div>
                    <div class="card-content">
                        <div class="label">Haus</div>
                        <div class="value home-val" id="val-home">0</div>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="dashboard-card">
                    <div id="fill-grid" class="fill-bar" style="width: 0%; background: #f43f5e;"></div>
                    <div class="card-content">
                        <div class="label">Netz</div>
                        <div class="value" id="val-grid">0</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-2 mb-2" id="wb-wp-row">
            <div id="card-wb" class="col-12" style="display:none;">
                <div class="dashboard-card">
                    <div id="fill-wb" class="fill-bar" style="width: 0%; background: #a855f7;"></div>
                    <div class="card-content"><div class="label">Wallbox</div><div class="value wb-val" id="val-wb">0</div></div>
                </div>
            </div>
            <div id="card-wp" class="col-12" style="display:none;">
                <div class="dashboard-card">
                    <div id="fill-wp" class="fill-bar" style="width: 0%; background: #22d3ee;"></div>
                    <div class="card-content"><div class="label">Wärmepumpe</div><div class="value wp-val" id="val-wp">0</div></div>
                </div>
            </div>
        </div>

        <div class="dashboard-card mb-2" id="card-price">
            <svg id="price-chart" preserveAspectRatio="none" viewBox="0 0 240 100"></svg>
            <div id="price-line"></div>
            <div id="price-line-day"></div>
            <div id="price-line-yesterday"></div>
            <div id="price-overlay-tomorrow"></div>
            <div id="price-label-tomorrow">Morgen</div>
            <div id="price-time-label"></div>
            <div class="card-content">
                <div class="label">aktueller Strompreis</div>
                <div class="value" id="val-price">--<span class="unit"> ct/kWh</span></div>
            </div>
        </div>

        <button id="toggleDiagramBtn" class="btn btn-dark w-100 py-3 rounded-4 border-secondary mb-2" onclick="toggleDiagram()">📊 Diagramm einblenden</button>
        <div id="diagramContainer" style="display:none;" class="mb-3">
            <div id="diagramControls" class="d-flex justify-content-between align-items-center p-2">
                <span id="diagramStatus" class="small text-info"><?= $lastUpdateTs ? 'Update: '.date('H:i', $lastUpdateTs) : '' ?></span>
                <button id="diagramUpdateBtn" class="btn btn-sm btn-outline-light" onclick="updateDiagram()">
                    <i class="fas fa-sync-alt"></i> Update
                </button>
            </div>
            <div style="height: 400px; border-radius: 20px; overflow: hidden; border: 1px solid #2d3748;">
                <iframe id="diagramFrame" src="" style="width: 100%; height: 100%; border: none;"></iframe>
            </div>
        </div>

    <?php elseif ($seite == 'wallbox'): include 'Wallbox.php';
          elseif ($seite == 'config'): 
    ?>
        <div class="mb-3">
            <button class="btn btn-warning w-100 py-3 rounded-4 border-secondary fw-bold shadow-sm" onclick="startSystemUpdate()">
                <i class="fas fa-cloud-download-alt me-2"></i>E3DC-Control Update
            </button>
        </div>
    <?php
            include 'config_editor.php';
          elseif ($seite == 'history'): include 'history.php';
          elseif ($seite == 'archiv'): include 'archiv.php';
    endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const PV_MAX = <?= $pvMax ?>; const WP_MAX = <?= $wpMax ?>; const BAT_MAX = <?= $maxBatPower ?>; const BAT_CAPACITY = <?= $batteryCapacity ?>; const AVGS = <?= json_encode($avgs) ?>;
const PRICE_HISTORY = <?= json_encode($priceHistory) ?>;
const FORECAST_DATA = <?= json_encode($forecastData) ?>;
const LAT = <?= $lat ?>;
const LON = <?= $lon ?>;
const PV_STRINGS = <?= json_encode($pvStrings) ?>;
const PRICE_START_HOUR = <?= $priceStartHour ?>;
const PRICE_INTERVAL = <?= $priceInterval ?>;
const startTriggerUrl = "<?= $mobileStartTriggerUrl ?>";
let lastUpdateTs = <?= $lastUpdateTs ?>;
let priceTendencyHtml = '';
let statusCheckInterval = null;

// Update Modal HTML dynamisch einfügen (damit es überall verfügbar ist)
document.body.insertAdjacentHTML('beforeend', `
<div class="modal fade" id="updateModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-scrollable modal-fullscreen-sm-down">
        <div class="modal-content bg-dark text-light border-secondary">
            <div class="modal-header border-secondary">
                <h5 class="modal-title"><i class="fas fa-sync fa-spin me-2" id="update-spinner"></i>Update</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close" id="update-close-btn" style="display:none;"></button>
            </div>
            <div class="modal-body bg-black p-2">
                <pre id="update-log" style="font-family: monospace; font-size: 0.75rem; color: #0f0; white-space: pre-wrap;">Starte...</pre>
            </div>
            <div class="modal-footer border-secondary">
                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal" id="update-finish-btn" disabled>Schließen</button>
            </div>
        </div>
    </div>
</div>
`);

function formatWatts(w) {
    if (Math.abs(w) >= 4000) return (w/1000).toLocaleString('de-DE',{minimumFractionDigits:2, maximumFractionDigits:2})+'<span class="unit"> kW</span>';
    return Math.round(w).toLocaleString('de-DE')+'<span class="unit"> W</span>';
}

// Sonnenstand Berechnung (Vereinfacht)
function getTheoreticalPower() {
    if (!PV_STRINGS || PV_STRINGS.length === 0) return 0;
    const now = new Date();
    const rad = Math.PI / 180;
    // Tag des Jahres
    const start = new Date(now.getFullYear(), 0, 0);
    const diff = now - start;
    const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    // Deklination & Zeitgleichung
    const B = (360 / 365) * (dayOfYear - 81) * rad;
    const declination = 23.45 * Math.sin(B) * rad;
    const eot = 9.87 * Math.sin(2 * B) - 7.53 * Math.cos(B) - 1.5 * Math.sin(B);
    
    // Sonnenzeit & Stundenwinkel
    const lst = now.getUTCHours() + now.getUTCMinutes() / 60 + LON / 15 + eot / 60;
    const omega = (lst - 12) * 15 * rad;
    const latRad = LAT * rad;
    
    // Sonnenhöhe (Elevation)
    const sinEl = Math.sin(latRad) * Math.sin(declination) + Math.cos(latRad) * Math.cos(declination) * Math.cos(omega);
    const el = Math.asin(sinEl);
    if (el < 0) return 0; // Nacht
    
    // Sonnenazimut (Süd = 0, West = +, Ost = -)
    // cos(AzS) = (sin(Lat) * sin(El) - sin(Dec)) / (cos(Lat) * cos(El))
    const cosAzS = (Math.sin(latRad) * sinEl - Math.sin(declination)) / (Math.cos(latRad) * Math.cos(el));
    let sunAz = Math.acos(Math.min(1, Math.max(-1, cosAzS)));
    if (omega < 0) sunAz = -sunAz; // Morgens negativ (Ost)
    
    let totalW = 0;
    const CLEAR_SKY_FACTOR = 0.9; // Schönwetter-Faktor (STC wird selten erreicht)
    for (let s of PV_STRINGS) {
        const tiltRad = s.tilt * rad;
        const panelAz = s.azimuth * rad;
        
        const cosTheta = sinEl * Math.cos(tiltRad) + Math.cos(el) * Math.sin(tiltRad) * Math.cos(sunAz - panelAz);
        if (cosTheta > 0) {
            // Einfaches Modell: Geometrischer Faktor * Leistung
            // Optional: Atmosphären-Dämpfung bei flacher Sonne (Air Mass)
            // intensity ~ 1000 * sin(el)^0.1 (sehr grob) oder einfach geometrisch STC (1000W/m2)
            totalW += s.power * cosTheta;
        }
    }
    return totalW * CLEAR_SKY_FACTOR;
}

function updateDashboard() {
    if (document.getElementById('val-pv') == null) return;
    fetch('get_live_json.php').then(r => r.json()).then(data => {
        document.getElementById('live-time').innerText = data.time;
        
        // PV Logik & Farben
        let pv = data.pv || 0;
        let pvFill = document.getElementById('fill-pv');
        document.getElementById('val-pv').innerHTML = formatWatts(pv);
        pvFill.style.width = Math.min(100, (pv / PV_MAX) * 100) + '%';
        if (pv > 14000) pvFill.style.background = '#991b1b'; // Dunkelrot
        else if (pv > 12000) pvFill.style.background = '#ef4444'; // Rot
        else if (pv > 10000) pvFill.style.background = '#f97316'; // Orange
        else pvFill.style.background = '#fbbf24'; // Gelb

        // Prognose Anzeige
        if (typeof FORECAST_DATA !== 'undefined' && FORECAST_DATA.length > 0) {
            const now = new Date();
            const curGmt = now.getUTCHours() + (now.getUTCMinutes() / 60);
            let best = null; let minDiff = 100;
            for (let d of FORECAST_DATA) {
                let diff = Math.abs(d.h - curGmt);
                if (diff < minDiff) { minDiff = diff; best = d; }
            }
            const fElem = document.getElementById('val-pv-forecast');
            if (best && minDiff < 0.5 && fElem) {
                let fVal = best.w;
                let sollVal = getTheoreticalPower();

                if (fVal < 10 && sollVal < 10) {
                    fElem.style.display = 'none';
                } else {
                    let ratio = (fVal > 0) ? (pv / fVal) : 0;
                    let pctStr = (fVal > 0) ? Math.round(ratio * 100) + '%' : '-';
                    let sollStr = (sollVal > 0) ? ` | <span style="color:#fff">Soll: ${formatWatts(sollVal)}</span>` : '';
                    fElem.innerHTML = `Prognose: ${formatWatts(fVal)} (${pctStr})${sollStr}`;
                    
                    if (fVal > 0 && ratio < 0.75) fElem.style.color = '#ef4444'; // Rot (< 75%)
                    else if (fVal > 0 && ratio > 1.25) fElem.style.color = '#10b981'; // Grün (> 125%)
                    else fElem.style.color = '#fbbf24'; // Gelb (Standard)
                    
                    fElem.style.display = 'block';
                }
            } else if (fElem) { fElem.style.display = 'none'; }
        }

        // Batterie
        let bat = data.bat || 0;
        let batFill = document.getElementById('fill-bat');
        let batIcon = bat >= 0 ? '<i class="fas fa-arrow-up small me-1"></i>' : '<i class="fas fa-arrow-down small me-1"></i>';
        document.getElementById('val-bat').innerHTML = batIcon + formatWatts(bat);
        document.getElementById('val-bat').className = 'value ' + (bat >= 0 ? 'text-white' : 'text-danger');
        batFill.style.width = (data.soc || 0) + '%';
        batFill.style.background = (bat >= 0) ? '#10b981' : '#ef4444'; // + Grün (Laden), - Rot (Entladen)
        
        let absBat = Math.abs(bat);
        if (absBat > 20) {
            let ratio = Math.min(1, absBat / BAT_MAX);
            let speed = 2.5 - (ratio * 2.1); // Von 2.5s (langsam) bis 0.4s (schnell)
            let intensity = 0.25 + (ratio * 0.55); // Von 0.25 bis 0.8 Opacity
            batFill.style.setProperty('--pulse-speed', speed + 's');
            batFill.style.setProperty('--pulse-intensity', intensity);
        }
        batFill.classList.toggle('pulse-active', absBat > 20);
        let capInfo = (BAT_CAPACITY > 0) ? ` von ${BAT_CAPACITY} kWh` : '';
        let timeInfo = '';
        if (BAT_CAPACITY > 0 && absBat > 50) {
            let hours = 0;
            let soc = parseFloat(data.soc) || 0;
            let timePrefix = '';
            if (bat > 0 && soc < 100) {
                hours = ((100 - soc) / 100 * BAT_CAPACITY * 1000) / bat;
                timePrefix = 'voll in';
            } else if (bat < 0 && soc > 0) {
                hours = (soc / 100 * BAT_CAPACITY * 1000) / absBat;
                timePrefix = 'leer in';
            }
            
            if (hours > 0 && hours < 48) {
                let h = Math.floor(hours);
                let m = Math.round((hours - h) * 60);
                timeInfo = ` | ${timePrefix} ${h}:${m.toString().padStart(2, '0')}h`;
            }
        }
        document.getElementById('label-soc').innerHTML = `Batterie (${data.soc}%)${capInfo}<span>${timeInfo}</span>`;

        // Haus & Netz
        let h = (data.wp > 10) ? Math.max(0, (data.home_raw || 0)-data.wp) : (data.home_raw || 0);
        document.getElementById('val-home').innerHTML = formatWatts(h);
        document.getElementById('fill-home').style.width = Math.min(100, (h / AVGS.home) * 100) + '%';
        
        let grid = data.grid || 0;
        let gridFill = document.getElementById('fill-grid');
        let gridIcon = grid <= 0 ? '<i class="fas fa-arrow-up small me-1"></i>' : '<i class="fas fa-arrow-down small me-1"></i>';
        document.getElementById('val-grid').innerHTML = gridIcon + formatWatts(grid);
        document.getElementById('val-grid').className = 'value ' + (grid <= 0 ? 'text-success' : 'text-danger');
        gridFill.style.width = Math.min(100, (Math.abs(grid) / AVGS.grid) * 100) + '%';
        gridFill.style.background = (grid <= 0) ? '#10b981' : '#f43f5e'; // - Grün (Einspeisung), + Rot (Bezug)

        // WP & WB Layout
        const wpC = document.getElementById('card-wp'); const wbC = document.getElementById('card-wb');
        wpC.style.display = data.wp > 10 ? 'block' : 'none';
        wbC.style.display = data.wb > 0 ? 'block' : 'none';
        if (data.wp > 10 && data.wb > 0) { wpC.className = 'col-6'; wbC.className = 'col-6'; }
        else { wpC.className = 'col-12'; wbC.className = 'col-12'; }
        if (data.wp > 10) { document.getElementById('val-wp').innerHTML = formatWatts(data.wp); document.getElementById('fill-wp').style.width = Math.min(100, (data.wp / WP_MAX) * 100) + '%'; }
        if (data.wb > 0) { document.getElementById('val-wb').innerHTML = formatWatts(data.wb); document.getElementById('fill-wb').style.width = Math.min(100, (data.wb / AVGS.wb) * 100) + '%'; }
        
        // Strompreis
        const priceVal = document.getElementById('val-price');
        const priceCard = document.getElementById('card-price');
        const priceNum = Number(data.price_ct);
            if (priceVal) {
                function gmtToLocal(slot) {
                    if (!slot || !/^[0-9]+\.[0-9]{2}$/.test(slot)) return '--:--';
                    const [h, m] = slot.split('.');
                    let gmtHour = parseInt(h);
                    let gmtMin = Math.round((parseInt(m) / 100) * 60);
                    let now = new Date();
                    let date = new Date();
                    date.setUTCHours(gmtHour, gmtMin, 0, 0);
                    
                    let dayLabel = (date.getDate() !== now.getDate()) ? 'morgen' : 'heute';
                    let localHour = date.getHours();
                    let localMin = date.getMinutes();
                    return dayLabel + ' um ' + String(localHour).padStart(2, '0') + ':' + String(localMin).padStart(2, '0');
                }
                let minPrice = '--';
                let minTime = '--:--';
                let maxPrice = '--';
                let maxTime = '--:--';
                if (typeof data.price_min_ct === 'number') {
                    minPrice = data.price_min_ct.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                }
                if (typeof data.price_max_ct === 'number') {
                    maxPrice = data.price_max_ct.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                }
                minTime = gmtToLocal(data.price_min_slot);
                maxTime = gmtToLocal(data.price_max_slot);

                // Tendenz vorab berechnen für die Hauptanzeige
                const prices = (data.prices && data.prices.length > 0) ? data.prices : PRICE_HISTORY;
                priceTendencyHtml = '';
                let hourDiff = 0;
                if (prices && prices.length > 0) {
                    const now = new Date();
                    const curGmtDec = now.getUTCHours() + (now.getUTCMinutes() / 60);
                    hourDiff = curGmtDec - PRICE_START_HOUR;
                    if (hourDiff < 0) hourDiff += 24;
                    let idx = Math.floor(hourDiff / PRICE_INTERVAL);
                    if (prices[idx] !== undefined && prices[idx+1] !== undefined) {
                        const diff = prices[idx+1] - prices[idx];
                        const isExtreme = Math.abs(diff) > 5;
                        const blinkClass = isExtreme ? ' blink-extreme' : '';
                        
                        if (diff > 0.1) priceTendencyHtml = '<i class="fas fa-arrow-trend-up text-danger ms-2' + blinkClass + '" style="font-size: 0.7em; vertical-align: middle;" title="Preis steigend"></i>';
                        else if (diff < -0.1) priceTendencyHtml = '<i class="fas fa-arrow-trend-down text-success ms-2' + blinkClass + '" style="font-size: 0.7em; vertical-align: middle;" title="Preis fallend"></i>';
                        else priceTendencyHtml = '<i class="fas fa-arrow-right text-info ms-2" style="font-size: 0.7em; vertical-align: middle;" title="Preis stabil"></i>';
                    }
                }

                let priceText = (Number.isFinite(priceNum) ? priceNum.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '--') + '<span class="unit"> ct/kWh</span>' + priceTendencyHtml;
                priceText += '<div style="display:flex;justify-content:space-between;margin-top:8px;">';
                priceText += '<span style="font-size:0.9em;font-weight:600;text-align:left;color:#10b981!important">' + minPrice + '<span class="unit" style="font-size:0.6em;margin-left:4px"> ct/kWh</span><br><span style="font-size:0.7em;color:#aaa">' + minTime + '</span></span>';
                priceText += '<span style="font-size:0.9em;font-weight:600;text-align:right;color:#f43f5e!important">' + maxPrice + '<span class="unit" style="font-size:0.6em;margin-left:4px"> ct/kWh</span><br><span style="font-size:0.7em;color:#aaa">' + maxTime + '</span></span>';
                priceText += '</div>';
                priceVal.innerHTML = priceText;

                // Hintergrund-Chart zeichnen (Stufenlinie als Area-Chart)
                const chart = document.getElementById('price-chart');
                if (chart && prices && prices.length > 0) {
                    const min = Math.min(...prices);
                    const max = Math.max(...prices);
                    const range = max - min || 1;
                    let pathData = "M 0 100"; // Start unten links
                    for (let i = 0; i < prices.length; i++) {
                        const xStart = (i / prices.length) * 240;
                        const xEnd = ((i + 1) / prices.length) * 240;
                        const y = 100 - ((prices[i] - min) / range * 60 + 5); // Skaliert auf max 60% Höhe
                        pathData += ` L ${xStart} ${y} H ${xEnd}`;
                        if (i < prices.length - 1) {
                            const nextY = 100 - ((prices[i+1] - min) / range * 60 + 5);
                            pathData += ` V ${nextY}`;
                        }
                    }
                    pathData += " L 240 100 Z"; // Schließen nach unten rechts
                    
                    // Aktuelle Zeit Markierung berechnen (GMT Abgleich)
                    const now = new Date();
                    const xPosPercent = (hourDiff / (prices.length * PRICE_INTERVAL)) * 100;
                    
                    chart.innerHTML = `<path d="${pathData}" fill="currentColor" stroke="none" />`;
                    
                    // Marker-Elemente (HTML statt SVG um Verzerrung zu vermeiden)
                    const line = document.getElementById('price-line');
                    const label = document.getElementById('price-time-label');
                    if (xPosPercent >= 0 && xPosPercent <= 100) {
                        line.style.left = xPosPercent + '%'; line.style.display = 'block';
                        label.style.left = xPosPercent + '%'; label.style.display = 'block';
                        label.innerText = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
                        // Label-Anker korrigieren
                        if (xPosPercent > 85) label.style.transform = 'translateX(-100%)';
                        else if (xPosPercent < 15) label.style.transform = 'translateX(0%)';
                        else label.style.transform = 'translateX(-50%)';
                    }

                    // Tagestrenner (Morgen 00:00 Uhr Local)
                    const dayLine = document.getElementById('price-line-day');
                    const yesterdayLine = document.getElementById('price-line-yesterday');
                    const dayOverlay = document.getElementById('price-overlay-tomorrow');
                    const dayLabel = document.getElementById('price-label-tomorrow');
                    if (dayLine) {
                        const offset = -new Date().getTimezoneOffset() / 60;
                        // Mitternacht Local = 24:00 Local. In GMT: 24 - offset.
                        let midnightGmt = 24 - offset;
                        let midnightGmtYesterday = midnightGmt - 24; // Heute 00:00
                        let pos = midnightGmt - PRICE_START_HOUR;
                        const totalHours = prices.length * PRICE_INTERVAL;
                        const pct = (pos / totalHours) * 100;
                        
                        if (pct > 0 && pct < 100) { 
                            dayLine.style.left = pct + '%'; dayLine.style.display = 'block'; 
                            if (dayOverlay) { dayOverlay.style.left = pct + '%'; dayOverlay.style.display = 'block'; }
                            if (dayLabel) { dayLabel.style.display = 'block'; }
                        }
                        else { 
                            dayLine.style.display = 'none'; 
                            if (dayOverlay) dayOverlay.style.display = 'none';
                            if (dayLabel) dayLabel.style.display = 'none';
                        }

                        // Gestern Strich (Heute 00:00)
                        let posYest = midnightGmtYesterday - PRICE_START_HOUR;
                        const pctYest = (posYest / totalHours) * 100;
                        if (pctYest > 0 && pctYest < 100 && yesterdayLine) { yesterdayLine.style.left = pctYest + '%'; yesterdayLine.style.display = 'block'; }
                        else if (yesterdayLine) { yesterdayLine.style.display = 'none'; }
                    }
                }
                updateLastUpdateDisplay();

                if (priceNum < 10) {
                    priceVal.className = 'value text-success price-ultra-cheap';
                    if (priceCard) {
                        priceCard.style.background = 'rgba(16, 185, 129, 0.25)';
                        priceCard.style.borderColor = '#10b981';
                    }
                } else if (data.price_level === 'cheap') {
                    priceVal.className = 'value text-success';
                    if (priceCard) {
                        priceCard.style.background = 'rgba(16, 185, 129, 0.13)';
                        priceCard.style.borderColor = '#2d3748';
                    }
                } else if (data.price_level === 'expensive') {
                    priceVal.className = 'value text-danger';
                    if (priceCard) {
                        priceCard.style.background = 'rgba(244, 63, 94, 0.13)';
                        priceCard.style.borderColor = '#2d3748';
                    }
                } else {
                    priceVal.className = 'value';
                    priceVal.style.color = '#fbbf24';
                    if (priceCard) {
                        priceCard.style.background = 'rgba(251, 191, 36, 0.13)';
                        priceCard.style.borderColor = '#2d3748';
                    }
                }
            }
    });
}

function updateLastUpdateDisplay() {
    if (!lastUpdateTs) return;
    const d = new Date(lastUpdateTs * 1000);
    const timeStr = d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0');
    document.getElementById('diagramStatus').innerHTML = 'Update: ' + timeStr;
}

function toggleDiagram() {
    let c = document.getElementById('diagramContainer'); let f = document.getElementById('diagramFrame');
    if (c.style.display === 'none') {
        c.style.display = 'block';
        const now = Math.floor(Date.now() / 1000);
        // Automatisches Update nur wenn älter als 15 Min (900 Sek)
        if (now - lastUpdateTs > 900) {
            updateDiagram();
        } else if (!f.src || f.src === window.location.href) {
            f.src = 'diagramm_mobile.html?t=' + Date.now();
        }
    } else { c.style.display = 'none'; }
}

function updateDiagram() {
    const btn = document.getElementById('diagramUpdateBtn');
    const status = document.getElementById('diagramStatus');
    const frame = document.getElementById('diagramFrame');
    
    btn.disabled = true;
    status.textContent = 'Lade Daten...';
    
    const timestamp = Date.now();
    fetch('mobile.php?ajax=update_plot')
    .then(r => r.json())
    .then(data => {
        // Erzwinge Neuladen des iFrames durch Austausch der Location
        const newUrl = 'diagramm_mobile.html?t=' + timestamp;
        frame.contentWindow.location.replace(newUrl);
        if (data.success) {
            lastUpdateTs = Math.floor(Date.now() / 1000);
            status.textContent = 'Aktualisiert';
        } else {
            status.textContent = 'Fehler';
        }
        btn.disabled = false;
        setTimeout(updateLastUpdateDisplay, 2000);
    }).catch(() => {
        status.textContent = 'Fehler';
        btn.disabled = false;
    });
}

function startSystemUpdate() {
    if (!confirm('Update starten? System wird neu gestartet.')) return;
    
    const modal = new bootstrap.Modal(document.getElementById('updateModal'));
    modal.show();
    
    const log = document.getElementById('update-log');
    const spinner = document.getElementById('update-spinner');
    const closeBtn = document.getElementById('update-close-btn');
    const finishBtn = document.getElementById('update-finish-btn');
    
    // Reset UI
    log.innerText = "Starte Anfrage...\n";
    spinner.className = "fas fa-sync fa-spin me-2";
    closeBtn.style.display = 'none';
    finishBtn.disabled = true;
    finishBtn.innerText = "Schließen";
    
    // Start Request
    fetch('run_update.php?action=start')
        .then(r => r.json())
        .then(data => {
            if (data.status === 'started' || data.status === 'running') {
                log.innerText = "Update gestartet. Warte auf Ausgabe...\n";
                pollUpdate();
            } else {
                log.innerText = "Fehler: " + (data.message || "Unbekannter Fehler");
                finishBtn.disabled = false;
            }
        })
        .catch(err => {
            log.innerText = "Netzwerkfehler beim Starten: " + err;
            finishBtn.disabled = false;
        });

    function pollUpdate() {
        const interval = setInterval(() => {
            fetch('run_update.php?action=poll')
                .then(r => r.json())
                .then(data => {
                    log.innerText = data.log;
                    const modalBody = log.parentElement;
                    modalBody.scrollTop = modalBody.scrollHeight;

                    if (!data.running) {
                        clearInterval(interval);
                        finalize(data.log);
                    }
                })
                .catch(err => console.error("Poll error:", err));
        }, 1000);
    }

    function finalize(logText) {
        spinner.classList.remove('fa-spin', 'fa-sync');
        
        if (logText.includes("Update erfolgreich abgeschlossen") || logText.includes("Du bist auf dem neuesten Stand")) {
            spinner.classList.add('fa-check-circle', 'text-success');
            log.innerText += "\n\n✓ Vorgang erfolgreich beendet.";
        } else {
            spinner.classList.add('fa-times-circle', 'text-danger');
            log.innerText += "\n\n✗ Update fehlgeschlagen oder unvollständig.";
        }

        closeBtn.style.display = 'block';
        finishBtn.disabled = false;
    }
}

updateDashboard(); setInterval(updateDashboard, 4000);

// Initialisierung für Desktop-Modus
window.addEventListener('DOMContentLoaded', () => {
    if (document.body.classList.contains('mode-desktop')) {
        document.getElementById('diagramFrame').src = 'diagramm_mobile.html?t=' + Date.now();
    }
});
</script>
</body>
</html>
