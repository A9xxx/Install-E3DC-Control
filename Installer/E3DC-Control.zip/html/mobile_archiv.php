<?php
/* =====================================================================
   mobile_archiv.php - Mobile Archivansicht für PWA
   ===================================================================== */

$paths = getInstallPaths();
$base_path = rtrim($paths['install_path'], '/') . '/';

$entries = [];
if (is_dir($base_path) && is_readable($base_path)) {
    $files = glob($base_path . 'awattardebug.*.txt');

    foreach ($files as $file) {
        if (preg_match('/awattardebug\.(\d+)\.txt$/', $file, $m)) {
            $entries[] = [
                'num' => (int)$m[1],
                'name' => basename($file),
                'time' => date('d.m.Y H:i', filemtime($file))
            ];
        }
    }
}

usort($entries, fn($a, $b) => $b['num'] <=> $a['num']);

$selectedFile = null;
$changed = null;

if (isset($_GET['file'])) {
    $requestedFile = basename($_GET['file']);

    if (validateFilename($requestedFile)) {
        $fullpath = $base_path . $requestedFile;
        if (is_file($fullpath) && is_readable($fullpath)) {
            $selectedFile = $requestedFile;
            $changed = date('d.m.Y H:i', filemtime($fullpath));
        }
    }
}
?>

<div id="archivHeader" class="d-flex justify-content-between align-items-center mb-3 px-1">
    <h5 class="m-0 fw-bold text-info">Archiv</h5>
    <?php if ($changed): ?>
        <span class="badge border border-secondary text-info" style="background: #1a1f29; font-size: 0.8rem;">
            <?= htmlspecialchars($changed) ?>
        </span>
    <?php endif; ?>
</div>

<?php if (empty($entries)): ?>
    <?= errorMessage('Keine Archive gefunden', 'Es wurden keine Archiv-Dateien gefunden.') ?>
<?php else: ?>
    <form id="archivForm" method="GET" action="<?= htmlspecialchars(getContextPageUrl('archiv')) ?>" class="mb-3">
        <input type="hidden" name="seite" value="archiv">

        <div class="d-grid gap-2">
            <select name="file" class="form-select" style="background:#0b0e14; border:1px solid #2d3748; color:#f8fafc; border-radius:12px;">
                <option value="">Bitte wählen…</option>
                <?php foreach ($entries as $e): ?>
                    <option value="<?= htmlspecialchars($e['name']) ?>" <?= ($selectedFile === $e['name']) ? 'selected' : '' ?>>
                        Datei <?= (int)$e['num'] ?> (<?= htmlspecialchars($e['time']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-outline-info rounded-pill py-2">Anzeigen</button>
        </div>
    </form>
<?php endif; ?>

<div id="archivContainer" style="margin-top: 10px;">
    <?php if ($selectedFile): ?>
        <div id="archivFrameWrap" style="height: 420px; border-radius: 20px; overflow: hidden; border: 1px solid #2d3748; background:#0b0e14;">
            <iframe
                id="archivFrame"
                src="archiv_diagramm.php?file=<?= urlencode($selectedFile) ?>&ts=<?= time() ?>"
                style="width: 100%; height: 100%; border: none;">
            </iframe>
        </div>
    <?php else: ?>
        <div class="text-center text-secondary" style="padding: 20px 10px;">Archivdatei wählen, dann wird das Diagramm hier angezeigt.</div>
    <?php endif; ?>
</div>

<script>
(function () {
    const frameWrap = document.getElementById('archivFrameWrap');
    if (!frameWrap) return;

    function adjustArchivFrameHeight() {
        const header = document.getElementById('archivHeader');
        const form = document.getElementById('archivForm');
        const topOffset = frameWrap.getBoundingClientRect().top;
        const maxHeight = 760;

        let reserved = 24;
        if (header) reserved += header.offsetHeight;
        if (form) reserved += form.offsetHeight;

        const available = Math.max(280, Math.min(maxHeight, window.innerHeight - topOffset - reserved));
        frameWrap.style.height = available + 'px';
    }

    adjustArchivFrameHeight();
    window.addEventListener('resize', adjustArchivFrameHeight);
    window.addEventListener('orientationchange', function () {
        setTimeout(adjustArchivFrameHeight, 120);
    });
})();
</script>
