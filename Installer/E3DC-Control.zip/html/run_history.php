<?php
// Alias für run_live_history.php (falls irgendwo noch run_history.php aufgerufen wird)
require_once __DIR__ . '/run_live_history.php';
