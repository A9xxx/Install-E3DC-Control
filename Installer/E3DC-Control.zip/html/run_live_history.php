<?php
/* =====================================================================
   run_live_history.php - Manuelle Aktualisierung des Live-48h-Diagramms
   ROBUSTE VERSION
   ===================================================================== */
header('Content-Type: application/json; charset=utf-8');

require_once 'helpers.php';

$lock = '/var/www/html/tmp/plot_live_history_running';
$paths = getInstallPaths();
$script = rtrim($paths['install_path'], '/') . '/plot_live_history.py';
$lock_timeout = 300; // 5 Minuten in Sekunden

// NEU: Selbstheilungs-Mechanismus für alte Lock-Dateien
if (file_exists($lock) && (time() - @filemtime($lock)) > $lock_timeout) {
    @unlink($lock); // Lösche verwaiste Lock-Datei, die älter als 5 Minuten ist
}

if (isset($_GET['mode']) && $_GET['mode'] === 'status') {
    $running = file_exists($lock);
    $html = '/var/www/html/live_diagramm.html';
    $last = file_exists($html) ? date('d.m.Y H:i', filemtime($html)) : null;
    echo json_encode(['running' => $running, 'last_update' => $last]);
    exit(0);
}

if (file_exists($lock)) {
    echo json_encode(['ok' => true, 'status' => 'running']);
    exit(0);
}

if (!is_file($script) || !is_executable($script)) {
    echo json_encode(['ok' => false, 'error' => 'Skript nicht gefunden oder nicht ausführbar']);
    exit(0);
}

// ENTFERNT: Das PHP-Skript erstellt die Lock-Datei nicht mehr. Das macht das Python-Skript jetzt selbst.
// @mkdir(dirname($lock), 0755, true);
// @touch($lock);

// Stunden-Parameter abfangen (Standard 6)
$hours = isset($_GET['hours']) ? (int)$_GET['hours'] : 6;

// NEU: Datei-Parameter für Archiv-Diagramme
$file_param = '';
if (isset($_GET['file']) && !empty($_GET['file'])) {
    $requested_file = basename($_GET['file']);
    $full_path = '/var/www/html/tmp/history_backups/' . $requested_file;
    if (file_exists($full_path)) {
        $file_param = ' --file ' . escapeshellarg($full_path);
        $hours = 24; // Archiv-Dateien sind immer 24h
    }
}

// Befehl mit dem --hours Parameter zusammenbauen
$cmd = 'python3 ' . escapeshellarg($script) . ' --hours ' . escapeshellarg($hours) . $file_param . ' 2>/dev/null &';
@shell_exec($cmd);

echo json_encode(['ok' => true, 'status' => 'started']);
?>