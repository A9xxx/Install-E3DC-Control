<?php
/* =====================================================================
   run_now.php - Manuelle Aktualisierung starten
   ===================================================================== */

header('Content-Type: text/plain; charset=utf-8');

require_once 'helpers.php';

// Modus auslesen
$mode = (isset($_GET['mode'])) ? $_GET['mode'] : 'normal';

if ($mode == 'mobile') {
    $lock  = "/var/www/html/tmp/plot_soc_running_mobile";
    $error = "/var/www/html/tmp/plot_soc_error_mobile";
    $mode_param = "mobile";
} elseif ($mode == 'archiv') {
    $lock  = "/var/www/html/tmp/plot_soc_running_archiv";
    $error = "/var/www/html/tmp/plot_soc_error_archiv";
    $mode_param = "archiv";
} else {
    $lock  = "/var/www/html/tmp/plot_soc_running";
    $error = "/var/www/html/tmp/plot_soc_error";
    $mode_param = "normal";
}

$paths = getInstallPaths();
$install_path = rtrim($paths['install_path'], '/') . '/';  // Sicherstellen dass trailing slash vorhanden ist
$python_script = $install_path . "plot_soc_changes.py";

// Lösche alte Fehlerdatei
@unlink($error);

// Prüfe, ob bereits läuft
if (file_exists($lock)) {
    // Prüfen ob die Datei älter als 5 Minuten (300 Sekunden) ist
    if (time() - filemtime($lock) > 300) {
        @unlink($lock); // Alte Lock-Datei löschen (Selbstheilung)
    } else {
        echo "running";
        exit(0);
    }
}

// Erstelle Verzeichnis
@mkdir(dirname($lock), 0755, true);
@mkdir(dirname($error), 0755, true);

// Erstelle Lock-Datei
touch($lock);

// Detaillierte Berechtigungsprüfung
$permission_error = null;

if (!is_file($python_script)) {
    $permission_error = "Python-Skript nicht gefunden:\n$python_script";
} elseif (!is_readable($python_script)) {
    $permission_error = "Keine Leseberechtigung:\n$python_script";
} elseif (!is_executable($python_script)) {
    $permission_error = "Keine Ausführungsberechtigung:\n$python_script\n\nBitte führen Sie aus:\nchmod +x $python_script";
}

if ($permission_error) {
    // Speichere sofort Fehlermeldung
    file_put_contents($error, "Fehler:\n\n$permission_error");
    @unlink($lock);
    echo "started";
    exit(0);
}

if (!function_exists('shell_exec') || (ini_get('disable_functions') && strpos(ini_get('disable_functions'), 'shell_exec') !== false)) {
    // shell_exec ist deaktiviert
    file_put_contents($error, "Fehler:\n\nshell_exec() ist in PHP deaktiviert.\nBitte in php.ini aktivieren.");
    @unlink($lock);
    echo "started";
    exit(0);
}

// Versuche Script zu starten
$process_started = false;
if (function_exists('shell_exec') && !(ini_get('disable_functions') && strpos(ini_get('disable_functions'), 'shell_exec') !== false)) {
    $cmd = "nohup /usr/bin/python3 $python_script " . $install_path . "awattardebug.txt $mode_param > /dev/null 2>&1 &";
    $output = @shell_exec($cmd);
    
    // Kleine Verzögerung für Prozessstart
    usleep(100000);
    
    // Prüfe mit ps ob Prozess läuft (mode-spezifisch)
    $ps_output = @shell_exec("ps aux | grep python3 | grep plot_soc_changes | grep $mode_param | grep -v grep");
    if (!empty($ps_output)) {
        $process_started = true;
    }
}

if (!$process_started) {
    // Prozess konnte nicht gestartet werden
    $last_python_error = "Fehler:\n\nPython-Skript konnte nicht gestartet werden.\n\nMögliche Gründe:\n";
    $last_python_error .= "- Shell-Zugriff blockiert\n";
    $last_python_error .= "- Prozessmanager (AppArmor/SELinux) blockiert\n";
    $last_python_error .= "- Systemlast zu hoch\n";
    $last_python_error .= "- Fehlende Dateiberechtigungen\n\n";
    $last_python_error .= "Command: /usr/bin/python3 $python_script";
    
    file_put_contents($error, $last_python_error);
    @unlink($lock);
    echo "started";
    exit(0);
}

echo "started";
exit(0);
?>
