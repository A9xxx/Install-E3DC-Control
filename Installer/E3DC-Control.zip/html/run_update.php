<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'helpers.php';

$paths = getInstallPaths();

// Versuche den Installer an verschiedenen Orten zu finden
$candidates = [
    rtrim($paths['install_path'], '/') . '/../Install/installer_main.py',
    $paths['home_dir'] . '/Install/installer_main.py'
];

$installer_main = false;
foreach ($candidates as $candidate) {
    if (file_exists($candidate)) {
        $installer_main = realpath($candidate);
        break;
    }
}

// Sicherheitscheck: Existiert der Installer?
if (!$installer_main) {
    echo json_encode(['status' => 'error', 'message' => "Installer nicht gefunden. Gesucht in:\n" . implode("\n", $candidates)]);
    exit;
}

$logFile = '/var/www/html/tmp/update.log';
$pidFile = '/var/www/html/tmp/update.pid';
$action = $_GET['action'] ?? 'start';

if ($action === 'start') {
    // Prüfen ob bereits läuft
    if (file_exists($pidFile)) {
        $pid = (int)trim(file_get_contents($pidFile));
        if (file_exists("/proc/$pid")) {
             echo json_encode(['status' => 'running', 'message' => 'Update läuft bereits.']);
             exit;
        }
        @unlink($pidFile);
    }

    // Log-Datei vorbereiten
    file_put_contents($logFile, "Initialisiere Update-Prozess...\n");
    chmod($logFile, 0666);

    // Befehl zusammenbauen (im Hintergrund mit nohup)
    $cmd = "sudo /usr/bin/python3 " . escapeshellarg($installer_main) . " --update-e3dc";
    $fullCmd = sprintf("nohup %s > %s 2>&1 & echo $!", $cmd, escapeshellarg($logFile));
    
    $pid = exec($fullCmd);
    
    if ($pid) {
        file_put_contents($pidFile, $pid);
        echo json_encode(['status' => 'started', 'pid' => $pid]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Konnte Prozess nicht starten.']);
    }

} elseif ($action === 'poll') {
    $log = file_exists($logFile) ? file_get_contents($logFile) : '';
    
    $running = false;
    if (file_exists($pidFile)) {
        $pid = (int)trim(file_get_contents($pidFile));
        if (file_exists("/proc/$pid")) {
            $running = true;
        } else {
            @unlink($pidFile);
        }
    }
    
    echo json_encode([
        'running' => $running,
        'log' => $log
    ]);
}
?>