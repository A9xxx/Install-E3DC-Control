<?php
/**
 * save_setting.php - Speichert einzelne Config-Werte per AJAX
 */
require_once 'helpers.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['key'], $_POST['value'])) {
    $paths = getInstallPaths();
    $configFile = rtrim($paths['install_path'], '/') . '/e3dc.config.txt';
    
    $key = trim($_POST['key']);
    $val = trim($_POST['value']);
    
    // Einfache Sicherheitsprüfung für Key
    if (!preg_match('/^[a-z0-9_]+$/i', $key)) {
        http_response_code(400);
        die('Invalid key');
    }

    $lines = file_exists($configFile) ? file($configFile, FILE_IGNORE_NEW_LINES) : [];
    $newLines = [];
    $found = false;

    foreach ($lines as $line) {
        // Suche nach "key = ..." (case insensitive)
        if (preg_match('/^\s*' . preg_quote($key, '/') . '\s*=/i', $line)) {
            $newLines[] = "$key = $val";
            $found = true;
        } else {
            $newLines[] = $line;
        }
    }

    if (!$found) {
        $newLines[] = "$key = $val";
    }

    // Datei schreiben (mit Lock)
    if (file_put_contents($configFile, implode("\n", $newLines) . "\n", LOCK_EX) !== false) {
        echo "ok";
    } else {
        http_response_code(500);
        echo "error";
    }
}
?>
