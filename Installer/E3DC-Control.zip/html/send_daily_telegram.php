<?php
require_once __DIR__ . '/helpers.php';

$paths = getInstallPaths();
$confRes = loadE3dcConfig();
$config = $confRes['config'] ?? [];

$stats_enabled = isset($config['telegram_stats_enable']) ? (int)$config['telegram_stats_enable'] : 0;
if ($stats_enabled !== 1) {
    exit(0); // Tagesstatistik ist in der Konfiguration deaktiviert
}

$token = $config['telegram_token'] ?? '';
$chat_id = $config['telegram_chat_id'] ?? '';

if (empty($token) || empty($chat_id)) {
    exit(0); // Telegram nicht konfiguriert
}

$backupDir = '/var/www/html/tmp/history_backups/';
$yesterday = date('Y-m-d', strtotime('yesterday'));
$targetFile = $backupDir . 'history_' . $yesterday . '.txt';

if (!file_exists($targetFile)) {
    error_log("Telegram-Stats: Keine Backup-Datei gefunden ($targetFile).");
    exit(0);
}

$lines = file($targetFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$statsData = calculateDailyEnergyStats($lines);

if (empty($statsData) || !isset($statsData['stats'])) {
    error_log("Telegram-Stats: Fehler bei der Statistik-Berechnung.");
    exit(0);
}

$s = $statsData['stats'];
$hasWp = isset($config['wp']) && (strtolower($config['wp']) === 'true' || $config['wp'] == '1');
$hasLux = isset($config['luxtronik']) && $config['luxtronik'] == '1';
$showWp = $hasWp || $hasLux;

$msg = "📊 *Tagesstatistik (" . date('d.m.Y', strtotime('yesterday')) . ")*\n\n";

$msg .= "☀️ *Sonne (PV):* " . number_format($s['total_pv_kwh'], 2, ',', '.') . " kWh\n";
$msg .= "  ├ Haus: " . number_format($s['pv_home_kwh'], 2, ',', '.') . " kWh (" . $s['pv_home_pct'] . "%)\n";
$msg .= "  ├ Batterie: " . number_format($s['pv_bat_kwh'], 2, ',', '.') . " kWh (" . $s['pv_bat_pct'] . "%)\n";
$msg .= "  ├ Wallbox: " . number_format($s['pv_wb_kwh'], 2, ',', '.') . " kWh (" . $s['pv_wb_pct'] . "%)\n";
if ($showWp) $msg .= "  ├ WP: " . number_format($s['pv_wp_kwh'], 2, ',', '.') . " kWh (" . $s['pv_wp_pct'] . "%)\n";
$msg .= "  └ Netz: " . number_format($s['pv_grid_kwh'], 2, ',', '.') . " kWh (" . $s['pv_grid_pct'] . "%)\n\n";

$msg .= "🔋 *Batterie (Out):* " . number_format($s['total_bat_out_kwh'], 2, ',', '.') . " kWh\n";
$msg .= "  ├ Haus: " . number_format($s['bat_home_kwh'], 2, ',', '.') . " kWh (" . $s['bat_home_pct'] . "%)\n";
if ($showWp) {
    $msg .= "  ├ Wallbox: " . number_format($s['bat_wb_kwh'], 2, ',', '.') . " kWh (" . $s['bat_wb_pct'] . "%)\n";
    $msg .= "  └ WP: " . number_format($s['bat_wp_kwh'], 2, ',', '.') . " kWh (" . $s['bat_wp_pct'] . "%)\n\n";
} else {
    $msg .= "  └ Wallbox: " . number_format($s['bat_wb_kwh'], 2, ',', '.') . " kWh (" . $s['bat_wb_pct'] . "%)\n\n";
}

$msg .= "🔌 *Netzbezug:* " . number_format($s['total_grid_in_kwh'], 2, ',', '.') . " kWh\n";
$msg .= "  ├ Haus: " . number_format($s['grid_home_kwh'], 2, ',', '.') . " kWh (" . $s['grid_home_pct'] . "%)\n";
$msg .= "  ├ Batterie: " . number_format($s['grid_bat_kwh'], 2, ',', '.') . " kWh (" . $s['grid_bat_pct'] . "%)\n";
if ($showWp) {
    $msg .= "  ├ Wallbox: " . number_format($s['grid_wb_kwh'], 2, ',', '.') . " kWh (" . $s['grid_wb_pct'] . "%)\n";
    $msg .= "  └ WP: " . number_format($s['grid_wp_kwh'], 2, ',', '.') . " kWh (" . $s['grid_wp_pct'] . "%)\n\n";
} else {
    $msg .= "  └ Wallbox: " . number_format($s['grid_wb_kwh'], 2, ',', '.') . " kWh (" . $s['grid_wb_pct'] . "%)\n\n";
}

$msg .= "📈 *Autarkie:* " . $statsData['autarky_day'] . "%\n";
$msg .= "♻️ *Eigenverbrauch:* " . $statsData['selfcon_day'] . "%\n";

$url = "https://api.telegram.org/bot" . $token . "/sendMessage";
$postData = ['chat_id' => $chat_id, 'text' => $msg, 'parse_mode' => 'Markdown'];

$ch = curl_init(); curl_setopt($ch, CURLOPT_URL, $url); curl_setopt($ch, CURLOPT_POST, 1); curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData)); curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); curl_setopt($ch, CURLOPT_TIMEOUT, 10); curl_exec($ch); curl_close($ch);
?>