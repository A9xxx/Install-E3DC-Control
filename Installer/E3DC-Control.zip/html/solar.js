/**
 * Berechnet Sonnenstand und theoretische PV-Leistung.
 * Benötigt die globalen Konstanten: PV_STRINGS, LAT, LON
 */

function getSunPosition() {
    if (typeof LAT === 'undefined' || typeof LON === 'undefined') return null;
    const now = new Date();
    const rad = Math.PI / 180;
    const start = new Date(now.getFullYear(), 0, 0);
    const diff = now - start;
    const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    const B = (360 / 365) * (dayOfYear - 81) * rad;
    const declination = 23.45 * Math.sin(B) * rad;
    const eot = 9.87 * Math.sin(2 * B) - 7.53 * Math.cos(B) - 1.5 * Math.sin(B);
    
    const lst = now.getUTCHours() + now.getUTCMinutes() / 60 + LON / 15 + eot / 60;
    const omega = (lst - 12) * 15 * rad;
    const latRad = LAT * rad;
    
    const sinEl = Math.sin(latRad) * Math.sin(declination) + Math.cos(latRad) * Math.cos(declination) * Math.cos(omega);
    const el = Math.asin(sinEl);
    
    return { el, sinEl, declination, omega, latRad };
}

function isDaytime() {
    const pos = getSunPosition();
    if (!pos) return true;
    // Tag = Elevation > -3 Grad (bürgerliche Dämmerung beginnt bei -6, aber für PV/Optik ist -3 gut)
    return (pos.el * 180 / Math.PI) > -3;
}

function getTheoreticalPower() {
    if (typeof PV_STRINGS === 'undefined' || !PV_STRINGS || PV_STRINGS.length === 0) return 0;
    
    const pos = getSunPosition();
    if (!pos || pos.el < 0) return 0; // Nacht (geometrisch)
    
    const cosAzS = (Math.sin(pos.latRad) * pos.sinEl - Math.sin(pos.declination)) / (Math.cos(pos.latRad) * Math.cos(pos.el));
    let sunAz = Math.acos(Math.min(1, Math.max(-1, cosAzS)));
    if (pos.omega < 0) sunAz = -sunAz;
    
    let totalW = 0;
    const airMass = 1 / Math.max(0.05, pos.sinEl);
    const transmission = (typeof PV_ATMOSPHERE !== 'undefined') ? PV_ATMOSPHERE : 0.7;
    const intensityFactor = 1.35 * Math.pow(transmission, Math.pow(airMass, 0.678));

    for (let s of PV_STRINGS) {
        const tiltRad = s.tilt * (Math.PI / 180);
        const panelAz = s.azimuth * (Math.PI / 180);
        const cosTheta = pos.sinEl * Math.cos(tiltRad) + Math.cos(pos.el) * Math.sin(tiltRad) * Math.cos(sunAz - panelAz);
        if (cosTheta > 0) totalW += s.power * cosTheta * intensityFactor;
    }
    return totalW;
}

/**
 * SYSTEM FUNCTIONS (Shared between Desktop & Mobile)
 */

function restartService() {
    if (!confirm('Möchtest du den E3DC-Control Service wirklich neu starten?')) return;
    
    fetch('index.php?action=restart_service')
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert("✓ Service wird neu gestartet.\nDas Web-Interface ist kurzzeitig eventuell nicht erreichbar.");
            } else {
                alert("✗ Fehler: " + data.message);
            }
        })
        .catch(err => alert("Netzwerkfehler: " + err));
}

function showWatchdogLog() {
    const modalEl = document.getElementById('watchdogModal');
    if (!modalEl) return;
    const modal = new bootstrap.Modal(modalEl);
    modal.show();
    
    const contentEl = document.getElementById('watchdog-log-content');
    if(contentEl) contentEl.innerText = 'Lade Protokoll...';
    
    // Action ist in helpers.php definiert und überall verfügbar
    fetch('index.php?action=watchdog_log')
        .then(r => r.text())
        .then(text => {
            if(contentEl) contentEl.innerText = text;
        })
        .catch(e => {
            if(contentEl) contentEl.innerText = 'Fehler beim Laden.';
        });
}

function handleConnectionClick() {
    const badge = document.getElementById('connection-status');
    if (!badge) return;
    
    // Check auf Klassen (Bootstrap Farben) oder Text
    const isOffline = badge.classList.contains('bg-danger') || badge.classList.contains('bg-warning') || badge.innerText === 'Offline' || badge.innerText.includes('Veraltet');
    
    if (isOffline) {
        if (confirm("Verbindungsprobleme erkannt.\nMöchtest du den E3DC-Service neu starten?")) {
            restartService();
        } else {
            badge.innerText = "Lade...";
            if (typeof fetchData === 'function') fetchData(); // Desktop
            else if (typeof updateDashboard === 'function') updateDashboard(); // Mobile
            else location.reload();
        }
    } else {
        badge.innerText = "Aktualisiere...";
        if (typeof fetchData === 'function') fetchData();
        else if (typeof updateDashboard === 'function') updateDashboard();
        else location.reload();
    }
}

// Gemeinsame Update-Logik
function startSystemUpdate(btnId = null) {
    // Optional: Button disablen während des Checks
    const btn = btnId ? document.getElementById(btnId) : null;
    let originalContent = '';
    if (btn) {
        originalContent = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i>';
        btn.disabled = true;
    }
    
    fetch('index.php?action=check_update&force_check=1')
    .then(r => r.json())
    .then(data => {
        if (btn) {
            btn.innerHTML = originalContent;
            btn.disabled = false;
        }

        let missing = data.missing || 0;
        let force = false;
        let proceed = false;

        if (data.success) {
            if (missing > 0) {
                if (confirm(`Es sind ${missing} neue Updates verfügbar.\nUpdate jetzt durchführen?`)) {
                    proceed = true;
                }
            } else {
                if (confirm("Das System ist bereits auf dem neuesten Stand.\nMöchtest du E3DC-Control trotzdem neu installieren (Update erzwingen)?")) {
                    proceed = true;
                    force = true;
                }
            }
        } else {
            alert("Fehler beim Update-Check: " + (data.error || "Unbekannt"));
        }

        if (!proceed) return;
        return fetch('index.php?action=prepare_update&force=' + force + '&discard=false');
    })
    .then(response => {
        if (!response) return; // Abgebrochen

        const modal = new bootstrap.Modal(document.getElementById('updateModal'));
        modal.show();
        
        const log = document.getElementById('update-log');
        const spinner = document.getElementById('update-spinner');
        const closeBtn = document.getElementById('update-close-btn');
        const finishBtn = document.getElementById('update-finish-btn');
        
        // Reset UI
        log.innerText = "Starte Anfrage...\n";
        spinner.className = "fas fa-sync fa-spin me-2";
        closeBtn.style.display = 'none';
        finishBtn.disabled = true;
        finishBtn.innerText = "Schließen";
        
        // Start Request
        fetch('index.php?action=run_update&mode=start&t=' + Date.now())
            .then(r => r.json())
            .then(data => {
                if (data.status === 'started' || data.status === 'running') {
                    log.innerText = "Update gestartet. Warte auf Ausgabe...\n";
                    pollUpdate(log, spinner, closeBtn, finishBtn);
                } else {
                    log.innerText = "Fehler: " + (data.message || "Unbekannter Fehler");
                    finishBtn.disabled = false;
                }
            })
            .catch(err => {
                log.innerText = "Netzwerkfehler beim Starten: " + err;
                finishBtn.disabled = false;
            });
    })
    .catch(err => {
        if (btn) { btn.innerHTML = originalContent; btn.disabled = false; }
        alert("Fehler: " + err);
    });
}

function pollUpdate(log, spinner, closeBtn, finishBtn) {
    let tick = 0;
    const interval = setInterval(() => {
        tick++;
        fetch('index.php?action=run_update&mode=poll&t=' + Date.now())
            .then(r => r.json())
            .then(data => {
                if (typeof data.log === 'string') log.innerText = data.log;
                const modalBody = log.parentElement;
                modalBody.scrollTop = modalBody.scrollHeight;

                const logText = data.log || "";
                const successFound = logText.includes("Update erfolgreich abgeschlossen") || 
                                     logText.includes("Du bist auf dem neuesten Stand") ||
                                     logText.includes("Vorgang abgebrochen");

                if (!data.running || successFound) {
                    clearInterval(interval);
                    setTimeout(() => {
                        spinner.classList.remove('fa-spin', 'fa-sync');
                        if (successFound) {
                            spinner.classList.add('fa-check-circle', 'text-success');
                            log.innerText += "\n\n✓ Vorgang beendet.";
                            // Optional: Reload triggern oder Badges resetten
                            if(typeof checkInstallerUpdate === 'function') checkInstallerUpdate(); 
                        } else {
                            spinner.classList.add('fa-times-circle', 'text-danger');
                            log.innerText += "\n\n✗ Vorgang beendet (Fehler/Abbruch).";
                        }
                        closeBtn.style.display = 'block';
                        finishBtn.disabled = false;
                    }, 500);
                }
            })
            .catch(err => {
                console.error("Poll error:", err);
            });
    }, 1000);
}

/**
 * Berechnet die Live-Autarkie in %
 */
function calculateLiveAutarky(home, wb, wp, grid) {
    let totalVerbrauch = home + wb + wp;
    let netzBezug = grid > 0 ? grid : 0;
    
    // Kleine Netzbezüge (Regelabweichungen des WR) ignorieren
    if (netzBezug < 30) netzBezug = 0;
    
    if (totalVerbrauch <= 0) return 100;
    
    let autarky = ((totalVerbrauch - netzBezug) / totalVerbrauch) * 100;
    // Schwankungen im obersten Bereich unterdrücken (>= 97% -> 100%)
    if (autarky >= 97) autarky = 100;
    
    return Math.max(0, Math.min(100, autarky));
}

let statsViewActive = false;
let currentStatsDate = 'today';

function loadStatsForDate(val, mode) {
    currentStatsDate = val;
    const prefix = mode === 'mobile' ? 'm-' : '';
    
    if (val === 'today') {
        if (typeof fetchData === 'function') fetchData();
        if (typeof updateDashboard === 'function') updateDashboard();
    } else {
        fetch((mode === 'mobile' ? 'mobile.php' : 'index.php') + '?action=get_daily_stats&file=' + encodeURIComponent(val))
        .then(r => r.json())
        .then(data => { updateStatsUI(data, mode); });
    }
}

function updateStatsUI(data, mode) {
    const prefix = mode === 'mobile' ? 'm-' : '';
    
    if (data.autarky_day !== undefined) { const elA = document.getElementById(prefix + 'stat-overlay-autarky'); if (elA) elA.innerText = Math.round(data.autarky_day) + '%'; }
    if (data.selfcon_day !== undefined) { const elS = document.getElementById(prefix + 'stat-overlay-selfcon'); if (elS) elS.innerText = Math.round(data.selfcon_day) + '%'; }
    
    if (data.stats) {
        const setStat = (id, val, pct) => { const el = document.getElementById(prefix + id); if (el) el.innerText = `${(val||0).toFixed(2)} kWh (${(pct||0).toFixed(0)}%)`; };
        
        const elPvTotal = document.getElementById(prefix + 'stat-pv-total');
        if (elPvTotal) elPvTotal.innerText = `${(data.stats.total_pv_kwh||0).toFixed(2)} kWh`;
        
        const elBatTotal = document.getElementById(prefix + 'stat-bat-total');
        if (elBatTotal) elBatTotal.innerText = `${(data.stats.total_bat_out_kwh||0).toFixed(2)} kWh`;

        const elGridTotal = document.getElementById(prefix + 'stat-grid-total');
        if (elGridTotal) elGridTotal.innerText = `${(data.stats.total_grid_in_kwh||0).toFixed(2)} kWh`;

        setStat('stat-pv-home', data.stats.pv_home_kwh, data.stats.pv_home_pct);
        setStat('stat-pv-bat', data.stats.pv_bat_kwh, data.stats.pv_bat_pct);
        setStat('stat-pv-wb', data.stats.pv_wb_kwh, data.stats.pv_wb_pct);
        setStat('stat-pv-wp', data.stats.pv_wp_kwh, data.stats.pv_wp_pct);
        setStat('stat-pv-grid', data.stats.pv_grid_kwh, data.stats.pv_grid_pct);
        
        setStat('stat-bat-home', data.stats.bat_home_kwh, data.stats.bat_home_pct);
        setStat('stat-bat-wb', data.stats.bat_wb_kwh, data.stats.bat_wb_pct);
        setStat('stat-bat-wp', data.stats.bat_wp_kwh, data.stats.bat_wp_pct);
        
        setStat('stat-grid-home', data.stats.grid_home_kwh, data.stats.grid_home_pct);
        setStat('stat-grid-bat', data.stats.grid_bat_kwh, data.stats.grid_bat_pct);
        setStat('stat-grid-wb', data.stats.grid_wb_kwh, data.stats.grid_wb_pct);
        setStat('stat-grid-wp', data.stats.grid_wp_kwh, data.stats.grid_wp_pct);
    }
}

function toggleStatsView(mode = 'desktop') {
    statsViewActive = !statsViewActive;
    const elId = mode === 'mobile' ? 'm-stats-view' : 'stats-view';
    const chevronId = mode === 'mobile' ? 'm-stats-chevron' : null;
    const el = document.getElementById(elId);
    if (el) el.style.display = statsViewActive ? 'block' : 'none';
    if (chevronId) {
        const ch = document.getElementById(chevronId);
        if (ch) ch.className = statsViewActive ? 'fas fa-chevron-up text-muted' : 'fas fa-chevron-down text-muted';
    }
}

/**
 * DASHBOARD & CHART LOGIC (Moved from index.php)
 */

function toggleDarkMode() {
    if (typeof DARK_MODE === 'undefined') return;
    DARK_MODE = !DARK_MODE;
    const html = document.documentElement;
    const icon = document.getElementById('darkmode-icon');
    
    html.setAttribute('data-bs-theme', DARK_MODE ? 'dark' : 'light');
    if (icon) icon.className = DARK_MODE ? 'fas fa-moon' : 'fas fa-sun';
    
    // Save setting via fetch
    const formData = new FormData();
    formData.append('action', 'save_setting');
    formData.append('key', 'darkmode');
    formData.append('value', DARK_MODE ? '1' : '0');
    
    fetch('index.php', { method: 'POST', body: formData });
    
    // Refresh charts if function exists (Desktop)
    if (typeof refreshData === 'function') {
        setTimeout(() => refreshData(false), 100);
    }
}

function toggleForecast(el) {
    if (typeof SHOW_FORECAST === 'undefined') return;
    SHOW_FORECAST = !SHOW_FORECAST;
    
    if (el) {
        if (SHOW_FORECAST) el.classList.replace('fa-eye-slash', 'fa-eye');
        else el.classList.replace('fa-eye', 'fa-eye-slash');
    }
    
    const formData = new FormData();
    formData.append('action', 'save_setting');
    formData.append('key', 'show_forecast');
    formData.append('value', SHOW_FORECAST ? '1' : '0');
    
    fetch('index.php', { method: 'POST', body: formData });
    
    if (typeof fetchData === 'function') fetchData();
}

function switchChartMode(mode, view = 'normal') {
    const select = document.getElementById('chart-mode-select');
    if (select) select.value = mode;
    
    if (typeof CURRENT_VIEW !== 'undefined') CURRENT_VIEW = view;
    
    // --- NEU: Statistik-Overlay schließen, wenn ein anderes Diagramm aufgerufen wird ---
    if (typeof statsViewActive !== 'undefined' && statsViewActive) {
        statsViewActive = false;
        const statsElDesktop = document.getElementById('stats-view');
        if (statsElDesktop) statsElDesktop.style.display = 'none';
        
        const statsElMobile = document.getElementById('m-stats-view');
        if (statsElMobile) statsElMobile.style.display = 'none';
        const chevron = document.getElementById('m-stats-chevron');
        if (chevron) chevron.className = 'fas fa-chevron-down text-muted';
    }

    // Reset History Dropdown
    if (mode === 'live') {
        $('#history-select-normal').val('');
        $('#history-select-wp').val('');
    }
    
    const iframe = document.getElementById('chart-frame');
    const flowView = document.getElementById('flow-view');
    const title = document.getElementById('chart-title');
    const liveControls = document.getElementById('live-controls');
    const archiveSelect = document.getElementById('archive-select');

    if(iframe) iframe.style.display = 'block';
    if(flowView) flowView.style.display = 'none';

    if (mode === 'flow') {
        if(title) title.innerHTML = '<i class="fas fa-project-diagram me-2 text-info"></i>Live Energiefluss';
        if(liveControls) liveControls.style.display = 'none';
        if(archiveSelect) archiveSelect.style.display = 'none';
        if(iframe) iframe.style.display = 'none';
        if(flowView) flowView.style.display = 'block';
        if(typeof fetchData === 'function') fetchData(); 
    } else if (mode === 'forecast') {
        if(title) title.innerHTML = '<i class="fas fa-chart-line me-2 text-secondary"></i>SoC Prognose';
        if(liveControls) liveControls.style.display = 'none';
        if(archiveSelect) archiveSelect.style.display = 'none';
        if(iframe) iframe.src = 'diagramm.html?t=' + new Date().getTime();
        // Trigger update check
        $.get('index.php?action=run_now&dark=' + (DARK_MODE ? '1' : '0'));
    } else if (mode === 'live') {
        let titleText = 'Leistungsverlauf';
        if (view === 'pv') titleText = 'PV Strings';
        if (view === 'grid') titleText = 'Netz & WR Phasen';
        if (view === 'bat') titleText = 'Batterie Details';
        if (view === 'wb') titleText = 'Wallbox Phasen';
        if (view === 'wp') titleText = 'Wärmepumpe Details';
        
        if(title) title.innerHTML = '<i class="fas fa-chart-area me-2 text-secondary"></i>' + titleText;
        if(liveControls) liveControls.style.display = 'flex';
        
        // Toggle correct dropdown
        if (view === 'wp') {
            document.getElementById('history-select-normal').style.display = 'none';
            document.getElementById('history-select-wp').style.display = 'inline-block';
        } else {
            document.getElementById('history-select-normal').style.display = 'inline-block';
            document.getElementById('history-select-wp').style.display = 'none';
        }
        
        if(archiveSelect) archiveSelect.style.display = 'none';
        if(iframe) iframe.src = 'live_diagramm.html?t=' + new Date().getTime();
        
        let hours = 6;
        const activeBtn = document.querySelector('#live-controls .btn.active');
        if (activeBtn) hours = parseInt(activeBtn.innerText);
        updateChart(hours, null);
        if(typeof fetchData === 'function') fetchData();

    } else if (mode === 'archive') {
        if(title) title.innerHTML = '<i class="fas fa-history me-2 text-secondary"></i>Archiv';
        if(liveControls) liveControls.style.display = 'none';
        if(archiveSelect) {
            archiveSelect.style.display = 'inline-block';
            if (archiveSelect.options.length > 1 && archiveSelect.selectedIndex <= 0) {
               archiveSelect.selectedIndex = 1;
               loadArchive(archiveSelect.value);
            } else if (archiveSelect.value) {
               loadArchive(archiveSelect.value);
            }
        }
    }
}

function updateChart(hours, btn) {
    if(btn) {
        $('.btn-group-custom .btn').removeClass('active');
        $(btn).addClass('active');
        $('#live-controls select').val('');
    }
    
    const iframe = document.getElementById('chart-frame');
    if(iframe) iframe.style.opacity = '0.5';

    $.get('index.php?action=run_live_history&hours=' + hours + '&view=' + CURRENT_VIEW + '&dark=' + (DARK_MODE ? '1' : '0'), function() {
        const checkInterval = setInterval(function() {
            $.getJSON('index.php?action=run_live_history&mode=status', function(status) {
                if (!status.running) {
                    clearInterval(checkInterval);
                    if(iframe) {
                        iframe.onload = function() {
                            iframe.style.opacity = '1';
                            iframe.onload = null;
                        };
                        iframe.src = 'live_diagramm.html?t=' + new Date().getTime();
                    }
                }
            });
        }, 400);
    });
}

function updateChartHistory(file) {
    if (!file) {
        updateChart(6, document.querySelector('.btn-group-custom .btn:first-child'));
        return;
    }
    
    $('.btn-group-custom .btn').removeClass('active');
    
    const iframe = document.getElementById('chart-frame');
    if(iframe) iframe.style.opacity = '0.5';

    $.get('index.php?action=run_live_history&file=' + encodeURIComponent(file) + '&view=' + CURRENT_VIEW + '&dark=' + (DARK_MODE ? '1' : '0'), function() {
        const checkInterval = setInterval(function() {
            $.getJSON('index.php?action=run_live_history&mode=status', function(status) {
                if (!status.running) {
                    clearInterval(checkInterval);
                    if(iframe) {
                        iframe.onload = function() {
                            iframe.style.opacity = '1';
                            iframe.onload = null;
                        };
                        iframe.src = 'live_diagramm.html?t=' + new Date().getTime();
                    }
                }
            });
        }, 400);
    });
}

function loadArchive(file) {
    const iframe = document.getElementById('chart-frame');
    if(iframe) iframe.src = 'index.php?action=archiv_diagram&file=' + encodeURIComponent(file) + '&ts=' + new Date().getTime() + '&dark=' + (DARK_MODE ? '1' : '0');
}

function refreshData(isAuto = false) {
    if(typeof fetchData === 'function') fetchData();
    const iframe = document.getElementById('chart-frame');
    if (!iframe) return;

    const btn = document.getElementById('main-refresh-btn');
    if (btn && !btn.dataset.originalHtml) {
        btn.dataset.originalHtml = btn.innerHTML;
    }
    const originalHtml = btn ? btn.dataset.originalHtml : '';

    if(btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    }

    const startTime = Date.now();
    const timeoutMs = 30000;

    const handleTimeout = (interval) => {
        if (Date.now() - startTime > timeoutMs) {
            clearInterval(interval);
            if(btn) {
                btn.innerHTML = '<i class="fas fa-exclamation-triangle text-danger"></i>';
                setTimeout(() => {
                    btn.disabled = false;
                    btn.innerHTML = originalHtml;
                }, 3000);
            }
            if (iframe) iframe.style.opacity = '1';
            return true;
        }
        return false;
    };

    const modeSelect = document.getElementById('chart-mode-select');
    const modeValue = modeSelect ? modeSelect.value : '';
    const isLive = iframe.src.includes('live_diagramm.html') || modeValue === 'live';
    const isForecast = !isLive && (iframe.src.includes('diagramm.html') || modeValue === 'forecast');

    if (isLive) {
        iframe.style.opacity = '0.5';
        let hours = 6;
        const activeBtn = document.querySelector('#live-controls .btn.active');
        if (activeBtn) hours = parseInt(activeBtn.innerText);

        $.get('index.php?action=run_live_history&hours=' + hours + '&view=' + CURRENT_VIEW + '&dark=' + (DARK_MODE ? '1' : '0'), function() {
            const checkInterval = setInterval(function() {
                if (handleTimeout(checkInterval)) return; 

                $.getJSON('index.php?action=run_live_history&mode=status', function(status) {
                    if (!status.running) {
                        clearInterval(checkInterval);
                        iframe.onload = function() {
                            iframe.style.opacity = '1';
                            iframe.onload = null;
                        };
                        iframe.src = 'live_diagramm.html?t=' + new Date().getTime();
                        if(btn) {
                            btn.disabled = false;
                            btn.innerHTML = originalHtml;
                        }
                    }
                });
            }, 400);
        });

    } else if (isForecast) {
        let url = 'index.php?action=run_now&dark=' + (DARK_MODE ? '1' : '0');
        if (isAuto) url += '&auto=1';

        $.get(url, function(response) {
            if (response.trim() === 'skipped') {
                if(btn) {
                    btn.disabled = false;
                    btn.innerHTML = originalHtml;
                }
                return;
            }

            const checkInterval = setInterval(function() {
                if (handleTimeout(checkInterval)) return;

                $.getJSON('index.php?action=status', function(status) {
                    if (!status.running) {
                        clearInterval(checkInterval);
                        if (!status.error) {
                            iframe.onload = function() {
                                iframe.style.opacity = '1';
                                iframe.onload = null;
                            };
                            iframe.src = iframe.src.split('?')[0] + '?t=' + new Date().getTime();
                        }
                        if(btn) {
                            btn.disabled = false;
                            btn.innerHTML = originalHtml;
                        }
                    }
                });
            }, 400);
        });
    } else {
        iframe.src = iframe.src;
        if(btn) {
            btn.disabled = false;
            btn.innerHTML = originalHtml;
        }
    }
}