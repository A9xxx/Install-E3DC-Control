<?php
/* =====================================================================
   E3DC-Control - start_content.php (Überarbeitete Version)
   
   - Besseres Interval Management
   - Fehlerbehandlung für Dateizugriff
   - Race-Condition Vermeidung
   - Berechtigungsprüfung
   ===================================================================== */

$stamp = "/var/www/html/tmp/plot_soc_last_run";
$lock  = "/var/www/html/tmp/plot_soc_running";
$done  = "/var/www/html/tmp/plot_soc_done";
$error = "/var/www/html/tmp/plot_soc_error";
$diagramm = "/var/www/html/diagramm.html";

// Prüfe Tmp-Verzeichnis
$tmp_dir = "/var/www/html/tmp";
if (!is_dir($tmp_dir)) {
    @mkdir($tmp_dir, 0755, true);
}

$needsUpdate = false;
$paths = getInstallPaths();
$install_path = rtrim($paths['install_path'], '/') . '/';  // Sicherstellen dass trailing slash vorhanden ist
$python_script = $install_path . "plot_soc_changes.py";

// Prüfe Python-Berechtigungen
$has_exec_permission = false;
if (is_file($python_script)) {
    $perms = fileperms($python_script);
    $has_exec_permission = (($perms & 0x0040) != 0); // Prüfe execute-Bit
}

// Prüfe, ob Update nötig ist (alle 10 Minuten)
if (!file_exists($stamp) || (time() - filemtime($stamp)) > 600) {
    $needsUpdate = true;
}

if (!file_exists($diagramm) || (time() - filemtime($diagramm)) > 600) {
    $needsUpdate = true;
}

// Starte Python-Skript wenn nötig
if ($needsUpdate && !file_exists($lock)) {
    @mkdir(dirname($error), 0755, true);
    
    // Detaillierte Berechtigungsprüfung
    $permission_error = null;
    $solution = null;
    
    if (!is_file($python_script)) {
        $permission_error = "Python-Skript nicht gefunden";
        $solution = "Datei: $python_script\n\nLösung:\nÜberprüfen Sie, ob die Datei existiert.";
    } elseif (!is_readable($python_script)) {
        $permission_error = "Keine Leseberechtigung für Python-Skript";
        $solution = "Datei: $python_script\n\nLösung:\nFühren Sie aus:\nchmod 755 $python_script";
    } elseif (!is_executable($python_script)) {
        $permission_error = "Keine Ausführungsberechtigung für Python-Skript";
        $solution = "Datei: $python_script\n\nLösung:\nFühren Sie aus:\nchmod +x $python_script";
    }
    
    if ($permission_error) {
        // Speichere sofort Fehlermeldung mit Lösung (HTML-formatiert)
        $error_output = "<div style='background: #1e1e1e; border: 1px solid #555; border-radius: 6px; padding: 20px; color: #fff;'>";
        $error_output .= "<div style='padding: 15px; background: #3d1f1f; border-left: 4px solid #f44336; border-radius: 4px; margin-bottom: 20px;'>";
        $error_output .= "<strong style='color: #f44336; font-size: 18px;'>⚠ " . htmlspecialchars($permission_error) . "</strong><br>";
        $error_output .= "Datei: <strong>" . htmlspecialchars($python_script) . "</strong>";
        $error_output .= "</div>";
        
        $error_output .= "<strong style='display: block; margin-bottom: 15px; font-size: 16px;'>📋 Lösungsmöglichkeiten:</strong>";
        
        $error_output .= "<div style='margin-bottom: 15px;'>";
        $error_output .= "<strong>1. Ausführungsberechtigungen setzen (als Benutzer " . htmlspecialchars($paths['install_user']) . "):</strong><br>";
        $error_output .= "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        $error_output .= "chmod +x " . htmlspecialchars($python_script) . "<br>";
        $error_output .= "# oder<br>";
        $error_output .= "chmod 755 " . htmlspecialchars($python_script);
        $error_output .= "</code>";
        $error_output .= "</div>";
        
        $error_output .= "<div>";
        $error_output .= "<strong>2. Aktuelle Berechtigungen prüfen:</strong><br>";
        $error_output .= "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        $error_output .= "ls -la " . htmlspecialchars(dirname($python_script));
        $error_output .= "</code>";
        $error_output .= "</div>";
        
        $error_output .= "</div>";
        file_put_contents($error, $error_output);
    } elseif (!function_exists('shell_exec') || (ini_get('disable_functions') && strpos(ini_get('disable_functions'), 'shell_exec') !== false)) {
        // shell_exec ist deaktiviert (HTML-formatiert)
        $error_output = "<div style='background: #1e1e1e; border: 1px solid #555; border-radius: 6px; padding: 20px; color: #fff;'>";
        $error_output .= "<div style='padding: 15px; background: #3d1f1f; border-left: 4px solid #f44336; border-radius: 4px; margin-bottom: 20px;'>";
        $error_output .= "<strong style='color: #f44336; font-size: 18px;'>⚠ PHP-Funktion 'shell_exec' ist deaktiviert</strong><br>";
        $error_output .= "Das Python-Skript kann nicht gestartet werden.";
        $error_output .= "</div>";
        
        $error_output .= "<strong style='display: block; margin-bottom: 15px; font-size: 16px;'>📋 Lösungsmöglichkeiten:</strong>";
        
        $error_output .= "<div style='margin-bottom: 15px;'>";
        $error_output .= "<strong>1. PHP-Konfiguration anpassen:</strong><br>";
        $error_output .= "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        $error_output .= "Öffnen Sie die php.ini und entfernen Sie 'shell_exec' aus der disabled_functions Liste.<br><br>";
        $error_output .= "Vorher: disable_functions = ...,shell_exec,...<br>";
        $error_output .= "Nachher: disable_functions = ...,...";
        $error_output .= "</code>";
        $error_output .= "</div>";
        
        $error_output .= "<div>";
        $error_output .= "<strong>2. PHP-Dienst neu starten:</strong><br>";
        $error_output .= "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
        $error_output .= "sudo systemctl restart php-fpm";
        $error_output .= "</code>";
        $error_output .= "</div>";
        
        $error_output .= "</div>";
        file_put_contents($error, $error_output);
    } else {
        // Versuche Script zu starten
        $cmd = "nohup /usr/bin/python3 $python_script " . $install_path . "awattardebug.txt normal > /dev/null 2>&1 &";
        $output = @shell_exec($cmd);
        
        // Kleine Verzögerung für Prozessstart
        usleep(200000);
        
        // Prüfe mit ps ob Prozess wirklich läuft
        $ps_output = @shell_exec("ps aux 2>/dev/null | grep python3 | grep plot_soc_changes | grep -v grep");
        
        if (!empty($ps_output)) {
            // Prozess läuft - erstelle Lock-Datei
            @mkdir(dirname($lock), 0755, true);
            touch($lock);
        } else {
            // Prozess konnte nicht gestartet werden (HTML-formatiert)
            $error_txt = "<div style='background: #1e1e1e; border: 1px solid #555; border-radius: 6px; padding: 20px; color: #fff;'>";
            $error_txt .= "<div style='padding: 15px; background: #3d1f1f; border-left: 4px solid #f44336; border-radius: 4px; margin-bottom: 20px;'>";
            $error_txt .= "<strong style='color: #f44336; font-size: 18px;'>⚠ Python-Skript konnte nicht gestartet werden</strong><br>";
            $error_txt .= "Der Prozess wurde nicht erfolgreich gestartet.";
            $error_txt .= "</div>";
            
            $error_txt .= "<strong style='display: block; margin-bottom: 15px; font-size: 16px;'>⚡ Mögliche Gründe:</strong>";
            $error_txt .= "<ul style='margin-left: 20px; line-height: 1.8;'>";
            $error_txt .= "<li>Shell-Zugriff blockiert</li>";
            $error_txt .= "<li>Prozessmanager blockiert (AppArmor/SELinux)</li>";
            $error_txt .= "<li>Systemlast zu hoch</li>";
            $error_txt .= "<li>Fehlende Dateiberechtigungen</li>";
            $error_txt .= "</ul>";
            
            $error_txt .= "<strong style='display: block; margin-bottom: 15px; margin-top: 20px; font-size: 16px;'>📋 Lösungsmöglichkeiten:</strong>";
            
            $error_txt .= "<div style='margin-bottom: 15px;'>";
            $error_txt .= "<strong>1. Systemlast prüfen:</strong><br>";
            $error_txt .= "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
            $error_txt .= "cat /proc/loadavg";
            $error_txt .= "</code>";
            $error_txt .= "</div>";
            
            $error_txt .= "<div style='margin-bottom: 15px;'>";
            $error_txt .= "<strong>2. SELinux Status prüfen:</strong><br>";
            $error_txt .= "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace;'>";
            $error_txt .= "getenforce";
            $error_txt .= "</code>";
            $error_txt .= "</div>";
            
            $error_txt .= "<div>";
            $error_txt .= "<strong>3. Manueller Test:</strong><br>";
            $error_txt .= "<code style='display: block; background: #0a0a0a; padding: 15px; margin: 10px 0; border-radius: 4px; border-left: 3px solid #0073e6; overflow-x: auto; font-size: 13px; line-height: 1.6; font-family: monospace; word-break: break-all;'>";
            $error_txt .= htmlspecialchars($cmd);
            $error_txt .= "</code>";
            $error_txt .= "</div>";
            
            $error_txt .= "</div>";
            file_put_contents($error, $error_txt);
        }
    }
}

$initialStatus = "";
if (file_exists($lock)) {
    $initialStatus = "Diagramm wird aktualisiert…";
}
?>

<div style="text-align:center; margin:15px 10px;">
    <button id="forceUpdateBtn" class="form-button" style="margin: 0 auto;">⟳ Diagramm aktualisieren</button>
</div>

<iframe id="diagrammFrame" style="width:100%; height: 500px; min-height: 300px; border:none; margin-top:20px; border-radius:4px; display:block;"></iframe>

<div id="errorBox" style="display:none; margin:15px 10px;"></div>

<div id="lastUpdate" style="text-align:center; margin-top:10px; font-size:15px; color:#aaa; word-break: break-word;"></div>
<div id="updateStatus" style="text-align:center; margin-top:10px; font-size:15px; color:#0073e6; font-weight:bold; word-break: break-word;"></div>

<script>
const updateStatus = document.getElementById("updateStatus");
const diagrammFrame = document.getElementById("diagrammFrame");
const errorBox = document.getElementById("errorBox");
const lastUpdate = document.getElementById("lastUpdate");

let statusInterval = null;
let missingCount = 0;
let lastFrameSrc = "";
let errorCheckInterval = null;  // Neuer Interval für Error-Checks
let updateCheckInterval = null;  // Interval für Diagramm-Updates
let hasActiveError = false;  // Flag um zu sehen, ob ein Error angezeigt wird
let shouldCheckError = true;  // Flag um Error-Checks zu deaktivieren wenn nicht nötig

// ==================== Error-Check ====================
// Hinweis: Error-Checks laufen jetzt über status.php - keine separaten Requests mehr
function checkError() {
    // Diese Funktion wird nur noch für manuelle Refreshs genutzt
    // Der reguläre Betrieb läuft über status.php
    return new Promise(resolve => {
        resolve(false);
    });
}

// ==================== Error anzeigen ====================
function showError(message) {
    if (hasActiveError) return;  // Verhindere mehrfaches Aufrufen
    
    hasActiveError = true;
    shouldCheckError = true;  // Weiter Error-Checks machen
    errorBox.innerHTML = message;  // HTML-Inhalt verwenden statt textContent
    errorBox.style.display = "block";
    diagrammFrame.style.display = "none";
    updateStatus.innerHTML = "";
    lastUpdate.innerHTML = "";
    
    // Stoppe ALLE Intervals wenn Error angezeigt wird
    if (errorCheckInterval) {
        clearInterval(errorCheckInterval);
        errorCheckInterval = null;
    }
    if (updateCheckInterval) {
        clearInterval(updateCheckInterval);
        updateCheckInterval = null;
    }
    if (statusInterval) {
        clearInterval(statusInterval);
        statusInterval = null;
    }
}

// ==================== Error verstecken ====================
function hideError() {
    hasActiveError = false;
    shouldCheckError = false;  // Keine weiteren Error-Checks nötig
    errorBox.style.display = "none";
    diagrammFrame.style.display = "block";
    
    console.log("ERROR versteckt - Starte Intervals wieder");
    
    // Intelligenteres Polling-Interval basierend auf Device-Typ
    const isMobile = window.innerWidth <= 768;
    const pollInterval = isMobile ? 1000 : 500;  // Weniger frequent auf Mobile
    
    // Starte Error-Check Interval wieder
    if (!errorCheckInterval) {
        errorCheckInterval = setInterval(() => {
            checkError();
        }, pollInterval);
    }
    
    // Starte Update-Check Interval wieder (4 Sekunden auf allen Geräten)
    if (!updateCheckInterval) {
        updateCheckInterval = setInterval(checkUpdate, 4000);
    }
}

// ==================== Responsive Iframe-Höhe ====================
function adjustIframeHeight() {
    const windowHeight = window.innerHeight;
    const button = document.getElementById("forceUpdateBtn");
    const lastUpdate = document.getElementById("lastUpdate");
    const updateStatus = document.getElementById("updateStatus");
    
    // Berechne verfügbare Höhe
    // Mit Button (ca. 60px) + Margin (ca. 35px) + Status-Text (ca. 60px) + Padding (ca. 30px)
    let reservedHeight = 185;
    
    // Auf Mobile: weniger Reserved Height
    if (window.innerWidth <= 768) {
        reservedHeight = 150;
    }
    
    const availableHeight = Math.max(300, windowHeight - reservedHeight);
    diagrammFrame.style.height = availableHeight + "px";
}

// ==================== Status-Check ====================
function checkStatus() {
    fetch("status.php", { cache: "no-store" })
        .then(res => res.json())
        .then(status => {
            if (status.error && status.error_message) {
                // Error gefunden
                shouldCheckError = true;
                showError(status.error_message);
                if (statusInterval) {
                    clearInterval(statusInterval);
                    statusInterval = null;
                }
            } else if (status.running) {
                // Script läuft noch
                shouldCheckError = true;
                updateStatus.innerHTML = "⏳ Diagramm wird aktualisiert…";
                missingCount = 0;
            } else {
                // Script ist nicht mehr aktiv
                missingCount++;
                if (missingCount >= 3) {
                    shouldCheckError = true;  // Kurz noch Error-Check
                    updateStatus.innerHTML = "";
                    if (statusInterval) {
                        clearInterval(statusInterval);
                        statusInterval = null;
                    }
                    // Zeige letzte Aktualisierung wenn vorhanden
                    if (status.last_update) {
                        lastUpdate.innerHTML = "✓ Letzte Aktualisierung: " + status.last_update;
                    }
                }
            }
        })
        .catch(() => {
            // Netzwerkfehler - ignorieren
        });
}

// ==================== Timeout für "stuck" Status ====================
function setupTimeout(timeoutMs = 120000) {
    // Nach 2 Minuten: Wenn noch immer "läuft", ist wahrscheinlich was falsch
    setTimeout(() => {
        if (statusInterval) {
            // Script läuft noch immer - das ist verdächtig
            missingCount = 999;  // Force Error-Check
            checkStatus();
        }
    }, timeoutMs);
}

// ==================== Button Handler ====================
document.getElementById("forceUpdateBtn").addEventListener("click", () => {
    hideError();
    updateStatus.innerHTML = "🚀 Manuelle Aktualisierung gestartet…";
    missingCount = 0;

    fetch("run_now.php", { cache: "no-store" })
        .then(res => res.text())
        .then(txt => {
            txt = txt.trim();
            if (txt === "running") {
                updateStatus.innerHTML = "⚠️ Läuft bereits im Hintergrund…";
            } else if (txt === "started") {
                updateStatus.innerHTML = "✓ Aktualisierung gestartet…";
                missingCount = 0;

                // Intelligente Polling-Interval basierend auf Device
                const isMobile = window.innerWidth <= 768;
                const statusPollInterval = isMobile ? 3000 : 2000;

                if (!statusInterval) {
                    statusInterval = setInterval(checkStatus, statusPollInterval);
                    setupTimeout(120000);  // 2 Minuten Timeout
                }
                
                // Prüfe SOFORT auf Fehler (nicht erst nach 1 Sekunde)
                setTimeout(() => {
                    checkError();
                }, 100);
            } else {
                updateStatus.innerHTML = "❌ Fehler beim Starten";
                console.error("Unerwartete Antwort:", txt);
            }
        })
        .catch(err => {
            updateStatus.innerHTML = "❌ Fehler beim Starten";
            console.error("Fetch-Fehler:", err);
        });
});

// ==================== DOMContentLoaded ====================
document.addEventListener("DOMContentLoaded", () => {

    let lastSize = 0;
    let stableSize = 0;
    let stableSince = 0;

    // Initiale Iframe-Height anpassen
    adjustIframeHeight();

    // Responsive Iframe-Height bei Window-Größenänderung
    window.addEventListener("resize", adjustIframeHeight);
    window.addEventListener("orientationchange", () => {
        setTimeout(adjustIframeHeight, 100);  // Kurze Verzögerung für orientationchange
    });

    // Intelligenteres Polling-Interval basierend auf Device-Typ und Connection
    const isMobile = window.innerWidth <= 768;
    const isSlowConnection = navigator.connection && 
                           (navigator.connection.effectiveType === '3g' || 
                            navigator.connection.effectiveType === '4g' && navigator.connection.downlink < 5);
    
    const statusPollInterval = isMobile || isSlowConnection ? 3000 : 2000;  // Weniger frequent auf Mobile/langsamer Connection
    const errorPollInterval = isMobile ? 1000 : 500;  // Error-Checks weniger frequent auf Mobile

    // Prüfe auf Datei-Updates (Größenvergleich)
    function checkUpdate() {
        // Überspringe wenn bereits ein Error angezeigt wird
        if (hasActiveError) {
            return;
        }

        fetch("diagramm.html", { method: "HEAD", cache: "no-store" })
            .then(res => {
                const contentLength = res.headers.get("Content-Length");
                if (!contentLength) return;

                const newSize = parseInt(contentLength, 10);
                const now = Date.now();

                // Größe stabil nach 1 Sekunde?
                if (newSize !== stableSize) {
                    stableSize = newSize;
                    stableSince = now;
                    return;
                }

                if (now - stableSince < 1000) {
                    return;
                }

                // Neue Datei erkannt
                if (newSize !== lastSize) {
                    lastSize = newSize;

                    // Hole die aktuelle Zeit von status.php
                    fetch("status.php", { cache: "no-store" })
                        .then(res => res.json())
                        .then(status => {
                            if (status.last_update) {
                                lastUpdate.innerHTML = "✓ Letzte Aktualisierung: " + status.last_update;
                            }
                        })
                        .catch(() => {});

                    const newSrc = "diagramm.html?ts=" + now;
                    if (lastFrameSrc !== newSrc) {
                        lastFrameSrc = newSrc;
                        hideError();
                        shouldCheckError = false;  // Stoppe Error-Checks nach erfolgreicher Aktualisierung
                        diagrammFrame.src = newSrc;
                    }
                }
            })
            .catch(err => {
                console.warn("Fehler beim Prüfen der Diagramm-Datei:", err);
            });
    }

    // SOFORT beim Load: Status-Check
    fetch("status.php", { cache: "no-store" })
        .then(res => res.json())
        .then(status => {
            // Zeige letzte Aktualisierung
            if (status.last_update) {
                lastUpdate.innerHTML = "✓ Letzte Aktualisierung: " + status.last_update;
            }
            
            if (status.error && status.error_message) {
                shouldCheckError = true;
                showError(status.error_message);
            } else if (status.running) {
                shouldCheckError = true;  // Prüfe auf Fehler wenn Script läuft
                missingCount = 0;
                statusInterval = setInterval(checkStatus, statusPollInterval);
                setupTimeout(120000);  // 2 Minuten Timeout
                updateStatus.innerHTML = "⏳ Diagramm wird aktualisiert…";
            } else {
                shouldCheckError = false;  // Kein Error-Check nötig wenn nichts läuft
            }
        })
        .catch(() => {});

    // Starte kontinuierliche Status-Prüfung (intelligenter basierend auf Device)
    errorCheckInterval = setInterval(() => {
        if (!shouldCheckError || hasActiveError) return;
        
        fetch("status.php", { cache: "no-store" })
            .then(res => res.json())
            .then(status => {
                if (status.error && status.error_message && !hasActiveError) {
                    showError(status.error_message);
                }
            })
            .catch(() => {});
    }, errorPollInterval);

    // Starte periodische Dateiprüfung
    updateCheckInterval = setInterval(checkUpdate, 4000);

    // Lade Initial-Frame
    diagrammFrame.src = "diagramm.html?ts=" + Date.now();
});
</script>
