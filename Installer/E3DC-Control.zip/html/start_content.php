<?php
/* =====================================================================
   E3DC-Control - start_content.php (Überarbeitete Version)
   
   - Besseres Interval Management
   - Fehlerbehandlung für Dateizugriff
   - Race-Condition Vermeidung
   - Berechtigungsprüfung
   ===================================================================== */

$stamp = "/var/www/html/tmp/plot_soc_last_run";
$lock  = "/var/www/html/tmp/plot_soc_running";
$done  = "/var/www/html/tmp/plot_soc_done";
$error = "/var/www/html/tmp/plot_soc_error";
$diagramm = "/var/www/html/diagramm.html";

// Prüfe Tmp-Verzeichnis
$tmp_dir = "/var/www/html/tmp";
if (!is_dir($tmp_dir)) {
    @mkdir($tmp_dir, 0755, true);
}

$needsUpdate = false;
$python_script = "/home/pi/E3DC-Control/plot_soc_changes.py";

// Prüfe Python-Berechtigungen
$has_exec_permission = false;
if (is_file($python_script)) {
    $perms = fileperms($python_script);
    $has_exec_permission = (($perms & 0x0040) != 0); // Prüfe execute-Bit
}

// Prüfe, ob Update nötig ist (alle 10 Minuten)
if (!file_exists($stamp) || (time() - filemtime($stamp)) > 600) {
    $needsUpdate = true;
}

if (!file_exists($diagramm) || (time() - filemtime($diagramm)) > 600) {
    $needsUpdate = true;
}

// Starte Python-Skript wenn nötig
if ($needsUpdate && !file_exists($lock)) {
    @mkdir(dirname($error), 0755, true);
    
    // Detaillierte Berechtigungsprüfung
    $permission_error = null;
    $solution = null;
    
    if (!is_file($python_script)) {
        $permission_error = "Python-Skript nicht gefunden";
        $solution = "Datei: $python_script\n\nLösung:\nÜberprüfen Sie, ob die Datei existiert.";
    } elseif (!is_readable($python_script)) {
        $permission_error = "Keine Leseberechtigung für Python-Skript";
        $solution = "Datei: $python_script\n\nLösung:\nFühren Sie aus:\nchmod 755 $python_script";
    } elseif (!is_executable($python_script)) {
        $permission_error = "Keine Ausführungsberechtigung für Python-Skript";
        $solution = "Datei: $python_script\n\nLösung:\nFühren Sie aus:\nchmod +x $python_script";
    }
    
    if ($permission_error) {
        // Speichere sofort Fehlermeldung mit Lösung
        $error_output = "❌ " . $permission_error . "\n\n" . $solution;
        file_put_contents($error, $error_output);
    } elseif (!function_exists('shell_exec') || (ini_get('disable_functions') && strpos(ini_get('disable_functions'), 'shell_exec') !== false)) {
        // shell_exec ist deaktiviert
        $error_output = "❌ PHP-Funktion 'shell_exec' ist deaktiviert\n\n";
        $error_output .= "Lösung:\n";
        $error_output .= "Öffnen Sie php.ini und entfernen Sie 'shell_exec' aus der disabled_functions Liste.\n\n";
        $error_output .= "disable_functions = ...,shell_exec,...  (entfernen)";
        file_put_contents($error, $error_output);
    } else {
        // Versuche Script zu starten
        $cmd = "nohup /usr/bin/python3 $python_script /home/pi/E3DC-Control/awattardebug.txt normal > /dev/null 2>&1 &";
        $output = @shell_exec($cmd);
        
        // Kleine Verzögerung für Prozessstart
        usleep(200000);
        
        // Prüfe mit ps ob Prozess wirklich läuft
        $ps_output = @shell_exec("ps aux 2>/dev/null | grep python3 | grep plot_soc_changes | grep -v grep");
        
        if (!empty($ps_output)) {
            // Prozess läuft - erstelle Lock-Datei
            @mkdir(dirname($lock), 0755, true);
            touch($lock);
        } else {
            // Prozess konnte nicht gestartet werden
            $error_txt = "❌ Python-Skript konnte nicht gestartet werden.

Mögliche Gründe:
- Shell-Zugriff blockiert
- Prozessmanager blockiert (AppArmor/SELinux)
- Systemlast zu hoch
- Fehlende Dateiberechtigungen

Lösung:
1. Prüfen Sie die Systemlasts: 'cat /proc/loadavg'
2. Prüfen Sie SELinux Status: 'getenforce'
3. Testen Sie manuell: '$cmd'";
            file_put_contents($error, $error_txt);
        }
    }
}

$initialStatus = "";
if (file_exists($lock)) {
    $initialStatus = "Diagramm wird aktualisiert…";
}
?>

<div style="text-align:center; margin:15px;">
    <button id="forceUpdateBtn" class="form-button">⟳ Diagramm aktualisieren</button>
</div>

<iframe id="diagrammFrame" style="width:100%; height: calc(100vh - 280px); border:none; margin-top:20px; border-radius:4px; display:block;"></iframe>

<div id="errorBox" style="display:none; padding:20px; margin:20px; background:#ffebee; border:2px solid #c62828; border-radius:4px; color:#c62828; font-family:monospace; white-space:pre-wrap; word-break:break-all; text-align:left; line-height:1.6; font-size:13px;"></div>

<div id="lastUpdate" style="text-align:center; margin-top:10px; font-size:14px; color:#aaa;"></div>
<div id="updateStatus" style="text-align:center; margin-top:10px; font-size:14px; color:#0073e6; font-weight:bold;"></div>

<script>
const updateStatus = document.getElementById("updateStatus");
const diagrammFrame = document.getElementById("diagrammFrame");
const errorBox = document.getElementById("errorBox");
const lastUpdate = document.getElementById("lastUpdate");

let statusInterval = null;
let missingCount = 0;
let lastFrameSrc = "";
let errorCheckInterval = null;  // Neuer Interval für Error-Checks
let updateCheckInterval = null;  // Interval für Diagramm-Updates
let hasActiveError = false;  // Flag um zu sehen, ob ein Error angezeigt wird
let shouldCheckError = true;  // Flag um Error-Checks zu deaktivieren wenn nicht nötig

// ==================== Error-Check ====================
// Hinweis: Error-Checks laufen jetzt über status.php - keine separaten Requests mehr
function checkError() {
    // Diese Funktion wird nur noch für manuelle Refreshs genutzt
    // Der reguläre Betrieb läuft über status.php
    return new Promise(resolve => {
        resolve(false);
    });
}

// ==================== Error anzeigen ====================
function showError(message) {
    if (hasActiveError) return;  // Verhindere mehrfaches Aufrufen
    
    hasActiveError = true;
    shouldCheckError = true;  // Weiter Error-Checks machen
    errorBox.textContent = message;
    errorBox.style.display = "block";
    diagrammFrame.style.display = "none";
    updateStatus.innerHTML = "";
    lastUpdate.innerHTML = "";
    
    // Stoppe ALLE Intervals wenn Error angezeigt wird
    if (errorCheckInterval) {
        clearInterval(errorCheckInterval);
        errorCheckInterval = null;
    }
    if (updateCheckInterval) {
        clearInterval(updateCheckInterval);
        updateCheckInterval = null;
    }
    if (statusInterval) {
        clearInterval(statusInterval);
        statusInterval = null;
    }
}

// ==================== Error verstecken ====================
function hideError() {
    hasActiveError = false;
    shouldCheckError = false;  // Keine weiteren Error-Checks nötig
    errorBox.style.display = "none";
    diagrammFrame.style.display = "block";
    
    console.log("ERROR versteckt - Starte Intervals wieder");
    
    // Starte Error-Check Interval wieder
    if (!errorCheckInterval) {
        errorCheckInterval = setInterval(() => {
            checkError();
        }, 500);
    }
    
    // Starte Update-Check Interval wieder
    if (!updateCheckInterval) {
        updateCheckInterval = setInterval(checkUpdate, 4000);
    }
}

// ==================== Status-Check ====================
function checkStatus() {
    fetch("status.php", { cache: "no-store" })
        .then(res => res.json())
        .then(status => {
            if (status.error && status.error_message) {
                // Error gefunden
                shouldCheckError = true;
                showError(status.error_message);
                if (statusInterval) {
                    clearInterval(statusInterval);
                    statusInterval = null;
                }
            } else if (status.running) {
                // Script läuft noch
                shouldCheckError = true;
                updateStatus.innerHTML = "⏳ Diagramm wird aktualisiert…";
                missingCount = 0;
            } else {
                // Script ist nicht mehr aktiv
                missingCount++;
                if (missingCount >= 3) {
                    shouldCheckError = true;  // Kurz noch Error-Check
                    updateStatus.innerHTML = "";
                    if (statusInterval) {
                        clearInterval(statusInterval);
                        statusInterval = null;
                    }
                    // Zeige letzte Aktualisierung wenn vorhanden
                    if (status.last_update) {
                        lastUpdate.innerHTML = "✓ Letzte Aktualisierung: " + status.last_update;
                    }
                }
            }
        })
        .catch(() => {
            // Netzwerkfehler - ignorieren
        });
}

// ==================== Timeout für "stuck" Status ====================
function setupTimeout(timeoutMs = 120000) {
    // Nach 2 Minuten: Wenn noch immer "läuft", ist wahrscheinlich was falsch
    setTimeout(() => {
        if (statusInterval) {
            // Script läuft noch immer - das ist verdächtig
            missingCount = 999;  // Force Error-Check
            checkStatus();
        }
    }, timeoutMs);
}

// ==================== Button Handler ====================
document.getElementById("forceUpdateBtn").addEventListener("click", () => {
    hideError();
    updateStatus.innerHTML = "🚀 Manuelle Aktualisierung gestartet…";
    missingCount = 0;

    fetch("run_now.php", { cache: "no-store" })
        .then(res => res.text())
        .then(txt => {
            txt = txt.trim();
            if (txt === "running") {
                updateStatus.innerHTML = "⚠️ Läuft bereits im Hintergrund…";
            } else if (txt === "started") {
                updateStatus.innerHTML = "✓ Aktualisierung gestartet…";
                missingCount = 0;

                if (!statusInterval) {
                    statusInterval = setInterval(checkStatus, 2000);
                    setupTimeout(120000);  // 2 Minuten Timeout
                }
                
                // Prüfe SOFORT auf Fehler (nicht erst nach 1 Sekunde)
                setTimeout(() => {
                    checkError();
                }, 100);
            } else {
                updateStatus.innerHTML = "❌ Fehler beim Starten";
                console.error("Unerwartete Antwort:", txt);
            }
        })
        .catch(err => {
            updateStatus.innerHTML = "❌ Fehler beim Starten";
            console.error("Fetch-Fehler:", err);
        });
});

// ==================== DOMContentLoaded ====================
document.addEventListener("DOMContentLoaded", () => {

    let lastSize = 0;
    let stableSize = 0;
    let stableSince = 0;

    // Prüfe auf Datei-Updates (Größenvergleich)
    function checkUpdate() {
        // Überspringe wenn bereits ein Error angezeigt wird
        if (hasActiveError) {
            return;
        }

        fetch("diagramm.html", { method: "HEAD", cache: "no-store" })
            .then(res => {
                const contentLength = res.headers.get("Content-Length");
                if (!contentLength) return;

                const newSize = parseInt(contentLength, 10);
                const now = Date.now();

                // Größe stabil nach 1 Sekunde?
                if (newSize !== stableSize) {
                    stableSize = newSize;
                    stableSince = now;
                    return;
                }

                if (now - stableSince < 1000) {
                    return;
                }

                // Neue Datei erkannt
                if (newSize !== lastSize) {
                    lastSize = newSize;

                    // Hole die aktuelle Zeit von status.php
                    fetch("status.php", { cache: "no-store" })
                        .then(res => res.json())
                        .then(status => {
                            if (status.last_update) {
                                lastUpdate.innerHTML = "✓ Letzte Aktualisierung: " + status.last_update;
                            }
                        })
                        .catch(() => {});

                    const newSrc = "diagramm.html?ts=" + now;
                    if (lastFrameSrc !== newSrc) {
                        lastFrameSrc = newSrc;
                        hideError();
                        shouldCheckError = false;  // Stoppe Error-Checks nach erfolgreicher Aktualisierung
                        diagrammFrame.src = newSrc;
                    }
                }
            })
            .catch(err => {
                console.warn("Fehler beim Prüfen der Diagramm-Datei:", err);
            });
    }

    // SOFORT beim Load: Status-Check
    fetch("status.php", { cache: "no-store" })
        .then(res => res.json())
        .then(status => {
            // Zeige letzte Aktualisierung
            if (status.last_update) {
                lastUpdate.innerHTML = "✓ Letzte Aktualisierung: " + status.last_update;
            }
            
            if (status.error && status.error_message) {
                shouldCheckError = true;
                showError(status.error_message);
            } else if (status.running) {
                shouldCheckError = true;  // Prüfe auf Fehler wenn Script läuft
                missingCount = 0;
                statusInterval = setInterval(checkStatus, 2000);
                setupTimeout(120000);  // 2 Minuten Timeout
                updateStatus.innerHTML = "⏳ Diagramm wird aktualisiert…";
            } else {
                shouldCheckError = false;  // Kein Error-Check nötig wenn nichts läuft
            }
        })
        .catch(() => {});

    // Starte kontinuierliche Status-Prüfung (alle 500ms)
    errorCheckInterval = setInterval(() => {
        if (!shouldCheckError || hasActiveError) return;
        
        fetch("status.php", { cache: "no-store" })
            .then(res => res.json())
            .then(status => {
                if (status.error && status.error_message && !hasActiveError) {
                    showError(status.error_message);
                }
            })
            .catch(() => {});
    }, 500);

    // Starte periodische Dateiprüfung
    updateCheckInterval = setInterval(checkUpdate, 4000);

    // Lade Initial-Frame
    diagrammFrame.src = "diagramm.html?ts=" + Date.now();
});
</script>
