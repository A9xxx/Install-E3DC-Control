<?php
/* =====================================================================
   status.php - Status-Abfrage (verhindert 404-Fehler in DevTools)
   ===================================================================== */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');

// Setze Timezone auf Deutschland (CET/CEST)
date_default_timezone_set('Europe/Berlin');

// Modus auslesen
$mode = (isset($_GET['mode']) && $_GET['mode'] == 'mobile') ? 'mobile' : 'normal';

if ($mode == 'mobile') {
    $lock  = "/var/www/html/tmp/plot_soc_running_mobile";
    $error = "/var/www/html/tmp/plot_soc_error_mobile";
    $diagramm = "/var/www/html/diagramm_mobile.html";
} else {
    $lock  = "/var/www/html/tmp/plot_soc_running";
    $error = "/var/www/html/tmp/plot_soc_error";
    $diagramm = "/var/www/html/diagramm.html";
}

$status = [
    'running' => file_exists($lock),
    'error' => false,
    'error_message' => null,
    'last_update' => null
];

if (file_exists($error)) {
    $status['error'] = true;
    $status['error_message'] = file_get_contents($error);
}

// Hole Modifikationszeit der diagramm.html
if (file_exists($diagramm)) {
    $mtime = filemtime($diagramm);
    $status['last_update'] = date('H:i:s', $mtime);
}

echo json_encode($status);
exit(0);
?>
