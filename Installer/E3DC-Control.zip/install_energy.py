import os
import sys
import subprocess
from pathlib import Path

# --- KONFIGURATION ---
SERVICE_NAME = "wp-manager.service"
BASE_DIR = Path("/home/pi/Install/Installer/luxtronik")
SCRIPT_PATH = BASE_DIR / "energy_manager.py"
SERVICE_PATH = Path(f"/etc/systemd/system/{SERVICE_NAME}")
RAMDISK_DIR = Path("/var/www/html/ramdisk")

def run(cmd):
    try:
        subprocess.run(cmd, shell=True, check=True)
        return True
    except Exception as e:
        print(f"Fehler: {e}")
        return False

def setup():
    print("--- Installation Luxtronik PV-Manager ---")

    # 1. Verzeichnisse prüfen/erstellen
    if not RAMDISK_DIR.exists():
        run(f"sudo mkdir -p {RAMDISK_DIR}")
    run(f"sudo chown -R pi:www-data {RAMDISK_DIR}")
    run(f"sudo chmod -R 775 {RAMDISK_DIR}")

    # 2. Service Datei schreiben
    service_content = f"""[Unit]
Description=Luxtronik PV-Manager Hintergrunddienst
After=network.target

[Service]
ExecStart={sys.executable} -u {SCRIPT_PATH}
WorkingDirectory={BASE_DIR}
StandardOutput=inherit
StandardError=inherit
Restart=always
User=pi

[Install]
WantedBy=multi-user.target
"""
    
    with open("/tmp/wp-manager.service", "w") as f:
        f.write(service_content)
    
    run(f"sudo mv /tmp/wp-manager.service {SERVICE_PATH}")
    run(f"sudo chmod 644 {SERVICE_PATH}")

    # 3. Systemd aktivieren
    run("sudo systemctl daemon-reload")
    run(f"sudo systemctl enable {SERVICE_NAME}")
    run(f"sudo systemctl restart {SERVICE_NAME}")

    print("\n[OK] Dienst installiert und gestartet!")
    print(f"Prüfen mit: sudo journalctl -u {SERVICE_NAME} -f")

if __name__ == "__main__":
    setup()