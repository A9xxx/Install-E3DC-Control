from luxtronik import LuxtronikModbus
wp = LuxtronikModbus()
if wp.connect():
    print(wp.read_all_sensors())
    wp.close()