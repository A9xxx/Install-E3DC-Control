import socket
import struct

def read_luxtronik_modbus(register_addr, func_code=4):
    host = '192.168.178.88'
    port = 502
    unit_id = 1
    
    # MBAP Header + PDU
    # Transaction ID: 0001, Protocol: 0000, Length: 0006, Unit: 01
    # Function: 03 (Holding) oder 04 (Input)
    # Address: register_addr, Quantity: 0001
    packet = struct.pack('>HHHBBHH', 1, 0, 6, unit_id, func_code, register_addr, 1)

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(5)
        s.connect((host, port))
        s.sendall(packet)
        
        # Antwort: Header(7) + Func(1) + Bytes(1) + Data(2) = 11 Bytes
        response = s.recv(11)
        s.close()

        if len(response) == 11:
            # Die Daten liegen in den letzten 2 Bytes (signed short für Temperaturen)
            val = struct.unpack('>h', response[9:11])[0]
            return val
        elif len(response) == 9:
            return f"Modbus Fehler Code: {response[8]}"
        else:
            return f"Unerwartete Antwortlänge: {len(response)}"

    except Exception as e:
        return f"Fehler: {e}"

# Test: Außentemperatur (Register 10108)
out_temp_raw = read_luxtronik_modbus(10300, func_code=4)

if isinstance(out_temp_raw, int):
    print(f"Erfolg! Außentemperatur: {out_temp_raw / 10} °C")
else:
    print(out_temp_raw)