import socket
import struct

def activate_shi_warmwasser(temp_celsius):
    host = '192.168.178.88'
    port = 502
    
    # 1. Modus auf '1' (Setpoint) setzen
    # Register 10005, Wert 1
    packet_mode = struct.pack('>HHHBBHH', 10, 0, 6, 1, 6, 10005, 1)
    
    # 2. Temperatur auf Zielwert setzen
    # Register 10006, Wert (Temp * 10)
    val_temp = int(temp_celsius * 10)
    packet_temp = struct.pack('>HHHBBHH', 11, 0, 6, 1, 6, 10006, val_temp)
    packet_reset = struct.pack('>HHHBBHH', 12, 0, 6, 1, 6, 10005, 0)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(5)
        s.connect((host, port))
        
        # Erst Modus aktivieren
        #print("Aktiviere SHI Modus (Register 10005 -> 1)...")
        #s.sendall(packet_mode)
        #s.recv(12) # Antwort abwarten
        
        # Dann Temperatur schreiben
        #print(f"Setze Soll-Temperatur (Register 10006 -> {val_temp})...")
        #s.sendall(packet_temp)
        #s.recv(12)

        s.sendall(packet_reset)
        s.recv(12) # Antwort abwarten

        s.close()
        print("\nERFOLG: Modus ist aktiv und Temperatur gesetzt.")
        print("Jetzt sollte die Wärmepumpe den neuen Wert anfahren.")

        packet_reset = struct.pack('>HHHBBHH', 12, 0, 6, 1, 6, 10005, 0)
    except Exception as e:
        print(f"Fehler: {e}")

# Testlauf
activate_shi_warmwasser(45.0)