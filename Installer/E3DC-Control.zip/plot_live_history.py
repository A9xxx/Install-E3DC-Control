#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E3DC-Control - Live-History-Diagramm (Dark Mode)
Liest JSON-Lines aus der Ramdisk und erstellt ein optimiertes Diagramm im Dark-Mode.
Inklusive dynamischer Preis-Integration.
"""

import os
import sys
import json
import re
import logging
import argparse
from datetime import timedelta
from datetime import datetime
from pathlib import Path

# Standard-Ausgabe auf UTF-8 erzwingen (verhindert UnicodeEncodeError z.B. bei cron)
try:
    if not sys.stdout.isatty():
        sys.stdout.reconfigure(encoding='utf-8', line_buffering=True)
    else:
        sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

# ============================================================
# KONFIGURATION
# ============================================================

LIVE_HISTORY_FILE = "/var/www/html/ramdisk/live_history.txt"
LUXTRONIK_HISTORY_FILE = "/var/www/html/ramdisk/luxtronik_history.json"
LUXTRONIK_ARCHIVE_DIR = "/var/www/html/tmp/luxtronik_archive"
OUTPUT_HTML = "/var/www/html/live_diagramm.html"
LOCKFILE = "/var/www/html/tmp/plot_live_history_running"
STAMP_FILE = "/var/www/html/tmp/plot_live_history_last_run"
LOG_DIR = "/var/www/html/logs"

go = None # Lazy Loading für Plotly

from diagram_helpers import (
    set_web_file_permissions,
    set_web_directory_permissions,
    get_or_create_logger,
    load_config as load_e3dc_config,
)

# ============================================================
# HELPER: LOCKING & LOGGING
# ============================================================

def setup_logging():
    os.makedirs(LOG_DIR, exist_ok=True)
    set_web_directory_permissions(LOG_DIR)
    log_file = os.path.join(LOG_DIR, "diagram.log")
    set_web_file_permissions(log_file)
    return get_or_create_logger("diagram", log_file)

def acquire_lock():
    os.makedirs(os.path.dirname(LOCKFILE), mode=0o775, exist_ok=True)
    set_web_directory_permissions(os.path.dirname(LOCKFILE))
    
    # Versuche alte Lock-Datei zu entfernen (wie in plot_soc_changes.py)
    try:
        if os.path.exists(LOCKFILE):
            os.remove(LOCKFILE)
    except Exception:
        pass

    try:
        # Neue Datei erstellen (touch)
        Path(LOCKFILE).touch(mode=0o666)
        set_web_file_permissions(LOCKFILE)
        return True
    except Exception:
        return False

def release_lock():
    try:
        if os.path.exists(LOCKFILE):
            os.remove(LOCKFILE)
    except Exception:
        pass

def load_darkmode_config():
    """Liest die darkmode-Einstellung aus der e3dc.config.txt"""
    config = load_e3dc_config()
    return config.get('darkmode', True)

def parse_live_history(filepath, hours_to_show=6):
    data = {
        "times": [], "pv": [], "bat": [], "home": [], 
        "grid": [], "soc": [], "wp": [], "wb": [], "price": [],
        "dc0_w": [], "dc1_w": [], "dc0_v": [], "dc1_v": [],
        "wb_p1": [], "wb_p2": [], "wb_p3": [],
        "ac0_w": [], "ac1_w": [], "ac2_w": [],
        "grid_p1": [], "grid_p2": [], "grid_p3": [],
        "bat_v": [], "bat_a": [],
        "wr_total": []
    }

    if not os.path.exists(filepath):
        return None

    # Gruppierung nach Minuten für Mittelwertbildung
    minute_data = {} 

    try:
        with open(filepath, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line: continue
                try:
                    entry_raw = json.loads(line)
                    entry = {k.lower(): v for k, v in entry_raw.items()}
                    dt = datetime.fromisoformat(entry["ts"])
                    # Schlüssel für die Minute (Sekunden auf 0 setzen)
                    m_key = dt.replace(second=0, microsecond=0)

                    if m_key not in minute_data:
                        minute_data[m_key] = []
                    minute_data[m_key].append(entry)
                except (json.JSONDecodeError, ValueError, KeyError):
                    continue
                    
        if not minute_data:
            return None

        # Sortieren und Mittelwerte berechnen
        sorted_minutes = sorted(minute_data.keys())
        latest_time = sorted_minutes[-1]
        cutoff_time = latest_time - timedelta(hours=hours_to_show)

        for m_dt in sorted_minutes:
            if m_dt < cutoff_time:
                continue
            
            entries = minute_data[m_dt]
            n = len(entries)
            
            data["times"].append(m_dt)
            data["pv"].append(sum(float(e.get("pv", 0)) for e in entries) / n)
            data["bat"].append(sum(float(e.get("bat", 0)) for e in entries) / n)
            # 'home' ist der korrigierte Hausverbrauch (ohne WP), mit Fallback auf 'home_raw'
            data["home"].append(sum(float(e.get("home", e.get("home_raw", 0))) for e in entries) / n)
            data["grid"].append(sum(float(e.get("grid", 0)) for e in entries) / n)
            data["soc"].append(sum(float(e.get("soc", 0)) for e in entries) / n)
            data["wp"].append(sum(float(e.get("wp", 0)) for e in entries) / n)
            data["wb"].append(sum(float(e.get("wb", 0)) for e in entries) / n)
            
            # Details
            data["dc0_w"].append(sum(float(e.get("dc0_w", 0)) for e in entries) / n)
            data["dc0_v"].append(sum(float(e.get("dc0_v", 0)) for e in entries) / n)
            data["dc1_w"].append(sum(float(e.get("dc1_w", 0)) for e in entries) / n)
            data["dc1_v"].append(sum(float(e.get("dc1_v", 0)) for e in entries) / n)
            data["wb_p1"].append(sum(float(e.get("wb_p1", 0)) for e in entries) / n)
            data["wb_p2"].append(sum(float(e.get("wb_p2", 0)) for e in entries) / n)
            data["wb_p3"].append(sum(float(e.get("wb_p3", 0)) for e in entries) / n)
            data["ac0_w"].append(sum(float(e.get("ac0_w", 0)) for e in entries) / n)
            data["ac1_w"].append(sum(float(e.get("ac1_w", 0)) for e in entries) / n)
            data["ac2_w"].append(sum(float(e.get("ac2_w", 0)) for e in entries) / n)
            data["wr_total"].append(sum(float(e.get("ac0_w", 0)) + float(e.get("ac1_w", 0)) + float(e.get("ac2_w", 0)) for e in entries) / n)
            data["grid_p1"].append(sum(float(e.get("grid_p1", 0)) for e in entries) / n)
            data["grid_p2"].append(sum(float(e.get("grid_p2", 0)) for e in entries) / n)
            data["grid_p3"].append(sum(float(e.get("grid_p3", 0)) for e in entries) / n)
            data["bat_v"].append(sum(float(e.get("bat_v", 0)) for e in entries) / n)
            data["bat_a"].append(sum(float(e.get("bat_a", 0)) for e in entries) / n)
            
            # Preis ist meist pro Stunde gleich, Mittelwert schadet aber nicht
            prices = [float(e["price_ct"]) for e in entries if e.get("price_ct") is not None]
            data["price"].append(sum(prices) / len(prices) if prices else None)

        return data
    except Exception as e:
        print(f"Fehler beim Parsen: {e}", file=sys.stderr)
        return None

def parse_luxtronik_history(filepaths, hours_to_show=6):
    """Parst die Luxtronik-History JSON-Dateien (Liste oder Einzeldatei)."""
    data = {
        "times": [],
        "power": [],
        "vl": [], "rl": [], "rl_soll": [],
        "ww": [], "ww_soll": [],
        "aussen": [],
        "sole_ein": [], "sole_aus": []
        ,"consumption": [], "cop": []
    }
    
    if isinstance(filepaths, str):
        filepaths = [filepaths]

    minute_data = {}

    try:
        for filepath in filepaths:
            if not os.path.exists(filepath):
                continue
            with open(filepath, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line: continue
                    try:
                        entry_raw = json.loads(line)
                        # Struktur: {"ts": "...", "data": {...}}
                        ts_str = entry_raw.get("ts")
                        d = entry_raw.get("data", {})
                        
                        if not ts_str: continue
                        
                        dt = datetime.fromisoformat(ts_str)
                        m_key = dt.replace(second=0, microsecond=0)

                        if m_key not in minute_data:
                            minute_data[m_key] = []
                        minute_data[m_key].append(d)
                    except:
                        continue
        
        if not minute_data:
            return None

        sorted_minutes = sorted(minute_data.keys())
        latest_time = sorted_minutes[-1]
        cutoff_time = latest_time - timedelta(hours=hours_to_show)

        for m_dt in sorted_minutes:
            if m_dt < cutoff_time: continue
            
            entries = minute_data[m_dt]
            data["times"].append(m_dt)
            
            # Helper für Mittelwert, ignoriert None
            def avg(key, scale=1.0):
                vals = [float(e.get(key, 0)) for e in entries if e.get(key) is not None]
                return (sum(vals) / len(vals)) * scale if vals else 0

            data["power"].append(avg("Leistung_Heiz_kW", 1000)) # kW -> W
            data["vl"].append(avg("Vorlauf_Ist"))
            data["rl"].append(avg("Ruecklauf_Ist"))
            data["rl_soll"].append(avg("Ruecklauf_Soll"))
            data["ww"].append(avg("Warmwasser_Ist"))
            data["ww_soll"].append(avg("Warmwasser_Soll"))
            data["aussen"].append(avg("Aussentemp"))
            data["sole_ein"].append(avg("Sole_Ein"))
            data["sole_aus"].append(avg("Sole_Aus"))
            
            # Verbrauch & COP
            verdichter = avg("Leistung_Verdichter_W")
            cons = verdichter
            heiz_w = avg("Leistung_Heiz_kW", 1000)
            cop = 0
            if cons > 0:
                cop = heiz_w / cons
            data["consumption"].append(cons)
            data["cop"].append(cop)

        return data
    except Exception as e:
        print(f"Fehler beim Parsen Luxtronik: {e}", file=sys.stderr)
        return None

# ============================================================
# DIAGRAMM ERSTELLEN (DARK MODE)
# ============================================================

def create_live_diagram(data, view_mode='normal', force_dark=False, force_light=False):
    last_time = data["times"][-1]
    stand_str = last_time.strftime("%d.%m. %H:%M Uhr")

    # Preise separat auswerten für eigene Skalierung auf y3
    prices = data.get("price", [])
    valid_prices = [p for p in prices if p is not None]
    p_min = min(valid_prices) if valid_prices else 0
    p_max = max(valid_prices) if valid_prices else 50
    show_price = (p_max - p_min) > 0.1

    dark_mode = load_darkmode_config()
    if force_dark:
        dark_mode = True
    if force_light:
        dark_mode = False
    
    if dark_mode:
        template = "plotly_dark"
        c_bg_paper = "#1e1e1e"
        c_bg_plot = "#1e1e1e"
        c_text = "#e0e0e0"
        c_grid = "#333333"
        c_soc_fill = 'rgba(144, 238, 144, 0.15)'
        c_price = '#BA55D3'
        c_pv = '#FFD700'
        c_bat_load = '#98FB98'
        c_bat_unload = '#2E7D32'
        c_home = '#FF4500'
    else:
        template = "plotly_white"
        c_bg_paper = "#ffffff"
        c_bg_plot = "#ffffff"
        c_text = "#333333"
        c_grid = "#e0e0e0"
        c_soc_fill = 'rgba(85, 139, 47, 0.2)'
        c_price = '#8E24AA'
        c_pv = '#F57F17'
        c_bat_load = '#558B2F'
        c_bat_unload = '#33691E'
        c_home = '#D84315'

    fig = go.Figure()

    if view_mode == 'pv':
        # PV Detailansicht (Strings)
        title_text = f"PV Strings (Stand: {stand_str})"
        # Leistung (Links)
        fig.add_trace(go.Scatter(x=data["times"], y=data["dc0_w"], name="String 1 (W)", line=dict(color='#FFD700', width=2), hovertemplate='S1: %{y:.0f} W<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["dc1_w"], name="String 2 (W)", line=dict(color='#FFA500', width=2), hovertemplate='S2: %{y:.0f} W<extra></extra>'))
        # Spannung (Rechts - y3)
        fig.add_trace(go.Scatter(x=data["times"], y=data["dc0_v"], name="String 1 (V)", line=dict(color='#FFFFE0', width=1, dash='dot'), yaxis="y3", hovertemplate='S1: %{y:.0f} V<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["dc1_v"], name="String 2 (V)", line=dict(color='#FFDAB9', width=1, dash='dot'), yaxis="y3", hovertemplate='S2: %{y:.0f} V<extra></extra>'))

    elif view_mode == 'grid':
        # Netz & Wechselrichter Detailansicht (Phasen)
        title_text = f"Netz & WR Phasen (Stand: {stand_str})"
        
        # Netz Gesamt (Hervorgehoben)
        fig.add_trace(go.Scatter(x=data["times"], y=data["grid"], name="Netz Gesamt", line=dict(color=c_text, width=3), hovertemplate='Netz: %{y:.0f} W<extra></extra>'))

        # Netz (Rot-Töne)
        fig.add_trace(go.Scatter(x=data["times"], y=data["grid_p1"], name="Netz L1", line=dict(color='#f43f5e', width=1.5), hovertemplate='Netz L1: %{y:.0f} W<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["grid_p2"], name="Netz L2", line=dict(color='#e11d48', width=1.5), hovertemplate='Netz L2: %{y:.0f} W<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["grid_p3"], name="Netz L3", line=dict(color='#be123c', width=1.5), hovertemplate='Netz L3: %{y:.0f} W<extra></extra>'))

        # WR Gesamt (Hervorgehoben)
        c_wr_total = '#00FFFF' if dark_mode else '#008B8B'
        fig.add_trace(go.Scatter(x=data["times"], y=data["wr_total"], name="WR Gesamt", line=dict(color=c_wr_total, width=3, dash='dot'), hovertemplate='WR: %{y:.0f} W<extra></extra>'))

        # Wechselrichter (Blau-Töne)
        fig.add_trace(go.Scatter(x=data["times"], y=data["ac0_w"], name="WR L1", line=dict(color='#3b82f6', width=1.5, dash='dot'), hovertemplate='WR L1: %{y:.0f} W<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["ac1_w"], name="WR L2", line=dict(color='#2563eb', width=1.5, dash='dot'), hovertemplate='WR L2: %{y:.0f} W<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["ac2_w"], name="WR L3", line=dict(color='#1d4ed8', width=1.5, dash='dot'), hovertemplate='WR L3: %{y:.0f} W<extra></extra>'))

    elif view_mode == 'bat':
        # Batterie Detailansicht
        title_text = f"Batterie Details (Stand: {stand_str})"
        fig.add_trace(go.Scatter(x=data["times"], y=data["bat"], name="Leistung (W)", line=dict(color=c_bat_load, width=2), hovertemplate='Leistung: %{y:.0f} W<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["soc"], name="SOC (%)", line=dict(color=c_soc_fill, width=2), yaxis="y2", hovertemplate='SOC: %{y:.1f} %<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["bat_v"], name="Spannung (V)", line=dict(color='#FFFF00', width=1.5, dash='dot'), yaxis="y3", hovertemplate='Spannung: %{y:.1f} V<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["bat_a"], name="Strom (A)", line=dict(color='#00FFFF', width=1.5, dash='dot'), yaxis="y3", hovertemplate='Strom: %{y:.1f} A<extra></extra>'))
    
    elif view_mode == 'wb':
        # Wallbox Detailansicht (Phasen)
        title_text = f"Wallbox Phasen (Stand: {stand_str})"
        fig.add_trace(go.Scatter(x=data["times"], y=data["wb"], name="WB Gesamt", line=dict(color='#00CED1', width=3), hovertemplate='Gesamt: %{y:.0f} W<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["wb_p1"], name="Phase 1", line=dict(color='#00BFFF', width=1.5), hovertemplate='L1: %{y:.0f} W<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["wb_p2"], name="Phase 2", line=dict(color='#1E90FF', width=1.5), hovertemplate='L2: %{y:.0f} W<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["wb_p3"], name="Phase 3", line=dict(color='#4169E1', width=1.5), hovertemplate='L3: %{y:.0f} W<extra></extra>'))
        
    elif view_mode == 'wp':
        # Wärmepumpe Detailansicht
        title_text = f"Wärmepumpe Details (Stand: {stand_str})"
        
        # Leistung (Links)
        fig.add_trace(go.Scatter(x=data["times"], y=data["power"], name="Heizleistung (W)", line=dict(color='#1E90FF', width=2, shape='hv'), hovertemplate='Heizung: %{y:.0f} W<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["consumption"], name="Verbrauch (W)", line=dict(color='#FF4500', width=2, shape='hv'), hovertemplate='Verbrauch: %{y:.0f} W<extra></extra>'))
        
        # COP (Rechts - y3)
        fig.add_trace(go.Scatter(x=data["times"], y=data["cop"], name="COP", line=dict(color='#32CD32', width=2, dash='dot'), yaxis="y3", hovertemplate='COP: %{y:.1f}<extra></extra>'))
        
        # Temperaturen (Rechts - y3)
        # Vorlauf/Rücklauf
        fig.add_trace(go.Scatter(x=data["times"], y=data["vl"], name="Vorlauf", line=dict(color='#FF4500', width=1.5), yaxis="y3", hovertemplate='VL: %{y:.1f} °C<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["rl"], name="Rücklauf", line=dict(color='#FFA500', width=1.5), yaxis="y3", hovertemplate='RL: %{y:.1f} °C<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["rl_soll"], name="RL Soll", line=dict(color='#FFA500', width=1, dash='dot'), yaxis="y3", hovertemplate='RL Soll: %{y:.1f} °C<extra></extra>'))
        
        # Warmwasser
        fig.add_trace(go.Scatter(x=data["times"], y=data["ww"], name="Warmwasser", line=dict(color='#FF1493', width=1.5), yaxis="y3", hovertemplate='WW: %{y:.1f} °C<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["ww_soll"], name="WW Soll", line=dict(color='#FF1493', width=1, dash='dot'), yaxis="y3", hovertemplate='WW Soll: %{y:.1f} °C<extra></extra>'))
        
        # Außen
        fig.add_trace(go.Scatter(x=data["times"], y=data["aussen"], name="Außen", line=dict(color='#00CED1', width=1.5), yaxis="y3", hovertemplate='Außen: %{y:.1f} °C<extra></extra>'))

    else:
        # Standardansicht (Normal)
        title_text = f"Live Verlauf (Stand: {stand_str})"
        
        # 1. SOC als Fläche ohne Linie auf eigener Achse (y2)
        fig.add_trace(go.Scatter(
            x=data["times"], y=data["soc"], name="SOC %",
            fill='tozeroy',
            mode='lines',
            line=dict(width=0), # Keine sichtbare Linie
            fillcolor=c_soc_fill,
            yaxis="y2",
            hovertemplate='SOC: %{y:.1f}%<extra></extra>'
        ))
        
        # 2. Preis als Stufendiagramm auf dritter Achse (y3)
        if show_price:
            fig.add_trace(go.Scatter(
                x=data["times"], y=data["price"], name="Preis (ct)", mode='lines',
                line=dict(color=c_price, width=2, shape='hv'),
                yaxis="y3",
                hovertemplate='Preis: %{y:.2f} ct<extra></extra>'
            ))

        # Die restlichen Leistungswerte
        fig.add_trace(go.Scatter(x=data["times"], y=data["pv"], name="PV", line=dict(color=c_pv, width=2), hovertemplate='PV: %{y:.0f} W<extra></extra>'))
        
        # Batterie & Netz: Negative Werte werden nach oben geklappt (abs) mit sauberem Hover
        fig.add_trace(go.Scatter(x=data["times"], y=[v if v >= 0 else 0 for v in data["bat"]], name="Bat. Laden", line=dict(color=c_bat_load, width=2), hovertemplate='Batterie Laden: %{y:.0f} W<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=[abs(v) if v < 0 else 0 for v in data["bat"]], name="Bat. Entladen", line=dict(color=c_bat_unload, width=2), hovertemplate='Batterie Entladen: %{y:.0f} W<extra></extra>'))
        
        fig.add_trace(go.Scatter(x=data["times"], y=data["home"], name="Haus", line=dict(color=c_home, width=2), hovertemplate='Hausverbrauch: %{y:.0f} W<extra></extra>'))
        
        fig.add_trace(go.Scatter(x=data["times"], y=[v if v > 1 else 0 for v in data["grid"]], name="Netzbezug", line=dict(color='#A9A9A9', width=2, dash='dot'), hovertemplate='Netzbezug: %{y:.0f} W<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=[abs(v) if v < -1 else 0 for v in data["grid"]], name="Einspeisung", line=dict(color='#FF8C00', width=2, dash='dot'), hovertemplate='Netzeinspeisung: %{y:.0f} W<extra></extra>'))
        
        fig.add_trace(go.Scatter(x=data["times"], y=data["wp"], name="WP", line=dict(color='#1E90FF', width=2), hovertemplate='Wärmepumpe: %{y:.0f} W<extra></extra>'))
        fig.add_trace(go.Scatter(x=data["times"], y=data["wb"], name="WB", line=dict(color='#00CED1', width=2), hovertemplate='Wallbox: %{y:.0f} W<extra></extra>'))

    # Dark Mode Layout
    fig.update_layout(
        template=template,
        autosize=True,
        title=dict(text=title_text, x=0.5, xanchor='center', font=dict(color=c_text)),
        font=dict(color=c_text), 
        margin=dict(l=50, r=50, t=60, b=80), 
        legend=dict(
            orientation="h", 
            y=-0.15, # Legende unter die X-Achse schieben
            x=0.5, 
            xanchor='center', 
            font=dict(color=c_text, size=10)
        ),
        hovermode="x unified",
        hoverdistance=1, # Verhindert das "Einfangen" von Nachbarminuten
        
        paper_bgcolor=c_bg_paper, 
        plot_bgcolor=c_bg_plot,  
        
        xaxis=dict(
            type='date', tickformat="%H:%M", tickmode="auto",
            gridcolor=c_grid, zerolinecolor=c_grid,
            domain=[0.05, 0.85] # Platz für die Y-Achsen rechts schaffen
        ),
        yaxis=dict(
            title="Leistung (W)",
            gridcolor=c_grid, 
            zeroline=True, zerolinecolor="#666666", zerolinewidth=2,
            side="left",
        ),
        yaxis2=dict(
            title=dict(text="SOC (%)", font=dict(color="#00FF7F")),
            tickfont=dict(color="#00FF7F"),
            overlaying="y", side="right", 
            range=[0, 105],
            showgrid=False
        ),
        # Y3 wird dynamisch genutzt: Entweder Preis (Normalansicht) oder Spannung (Detailansichten)
        yaxis3=dict(
            title=dict(text="Temperatur (°C)" if view_mode == 'wp' else ("Spannung (V) / Strom (A)" if view_mode == 'bat' else ("Spannung (V)" if view_mode == 'pv' else ("Preis (ct)" if show_price else ""))), font=dict(color=c_price)),
            tickfont=dict(color=c_text if view_mode in ['pv', 'bat'] else c_price),
            overlaying="y", side="right",
            anchor="free",
            position=0.95,
            range=[0, 1000] if view_mode == 'pv' else ([p_min - 2, p_max + 2] if (view_mode not in ['bat', 'wp'] and show_price) else None),
            showgrid=False,
            showline=show_price if view_mode == 'normal' else True,
            showticklabels=show_price if view_mode == 'normal' else True
        )
    )
    return fig

# ============================================================
# MAIN
# ============================================================

def main():
    # Argument-Parser für die Stunden
    parser = argparse.ArgumentParser()
    parser.add_argument("--hours", type=int, default=6, help="Anzahl der anzuzeigenden Stunden (wird für Archivdateien ignoriert und auf 24 gesetzt).")
    parser.add_argument("--file", type=str, default=None, help="Pfad zu einer Archiv-Datei, die statt der Live-Daten genutzt werden soll.")
    parser.add_argument("--view", type=str, default="normal", help="Ansichtsmodus: normal, pv, wb")
    parser.add_argument("--dark", action="store_true", help="Dark Mode erzwingen")
    parser.add_argument("--light", action="store_true", help="Light Mode erzwingen")
    args = parser.parse_args()

    # Fallback: Manuelle Prüfung von sys.argv, falls argparse zickt
    if "--dark" in sys.argv: args.dark = True
    if "--light" in sys.argv: args.light = True

    # Lock-Check (wird durch helpers.php unlink meist umgangen, aber als Sicherheit)
    if not acquire_lock(): return 0
    try:
        logger = setup_logging()
        
        # Entscheiden, welche Datei verwendet wird: Archiv oder Live-Standard
        source_file = args.file if args.file else LIVE_HISTORY_FILE
        is_archive = bool(args.file)
        
        # Daten parsen je nach Modus
        if args.view == 'wp':
            files_to_read = []
            if args.file:
                # Archiv-Modus: Datum aus Dateinamen extrahieren (history_YYYY-MM-DD.txt)
                basename = os.path.basename(args.file)
                match = re.search(r'(\d{4}-\d{2}-\d{2})', basename)
                if match:
                    date_str = match.group(1)
                    f = os.path.join(LUXTRONIK_ARCHIVE_DIR, f"luxtronik_{date_str}.json")
                    if os.path.exists(f):
                        files_to_read.append(f)
            else:
                # Live-Modus: Immer RAM-Disk verwenden (wie vom User gewünscht)
                files_to_read = [LUXTRONIK_HISTORY_FILE]
                
            data = parse_luxtronik_history(files_to_read, hours_to_show=args.hours)
        else:
            data = parse_live_history(source_file, hours_to_show=args.hours)

        if not data or not data["times"]:
            logger.warning(f"Keine gültigen Daten im Zeitraum in Datei '{source_file}' gefunden.")
            return 0

        global go
        import plotly.graph_objects as go

        fig = create_live_diagram(data, view_mode=args.view, force_dark=args.dark, force_light=args.light)
        
        os.makedirs(os.path.dirname(OUTPUT_HTML), mode=0o755, exist_ok=True)
        fig.write_html(
            OUTPUT_HTML,
            include_plotlyjs="cdn",
            full_html=True,
            config={"displaylogo": False, "displayModeBar": False, "responsive": True}
        )

        try: Path(STAMP_FILE).touch(mode=0o666)
        except Exception: pass

        log_msg = (
            f"Archiv-Diagramm '{os.path.basename(source_file)}' erstellt." if is_archive
            else f"Live-Diagramm aktualisiert ({args.hours}h). Stand: {data['times'][-1]}"
        )
        logger.info(log_msg)
        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        if 'logger' in locals(): logger.exception("Kritischer Fehler im Plotter")
        return 1
    finally:
        release_lock()

if __name__ == "__main__":
    sys.exit(main())