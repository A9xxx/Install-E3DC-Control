#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E3DC-Control - Diagramm-Generator (Monolithisch)
Erstellt Speichernutzungspläne aus awattardebug.txt (ohne externe Module)
"""

import os
import sys
import json
import re
import logging
import pwd
import grp
from datetime import datetime, timedelta, timezone
from pathlib import Path

try:
    import plotly.graph_objects as go
except ImportError:
    print("ERROR: plotly not installed. Run: pip3 install plotly")
    sys.exit(1)

# ============================================================
# PERMISSION HELPER
# ============================================================

def get_web_file_owner():
    """Ermittelt die UIDs für pi und www-data."""
    try:
        pi_uid = pwd.getpwnam("pi").pw_uid
        www_data_gid = grp.getgrnam("www-data").gr_gid
        return pi_uid, www_data_gid
    except (KeyError, OSError):
        # Fallback zu Standard-IDs
        return 1000, 33

def set_web_file_permissions(path, mode=0o664):
    """
    Setzt Permissions für Web-Dateien (pi:www-data).
    
    Args:
        path: Dateipath
        mode: Oktalzahl für Permissions (Standard: 664 für Dateien, 775 für Dirs)
    """
    try:
        if os.path.exists(path):
            pi_uid, www_data_gid = get_web_file_owner()
            os.chown(path, pi_uid, www_data_gid)
            os.chmod(path, mode)
    except Exception:
        # Fallback: nur chmod versuchen
        try:
            os.chmod(path, mode)
        except:
            pass

def set_web_directory_permissions(dirpath, mode=0o775):
    """
    Setzt Permissions für Web-Verzeichnisse (pi:www-data 775).
    
    Args:
        dirpath: Verzeichnispath
        mode: Oktalzahl für Permissions (Standard: 775)
    """
    try:
        if os.path.exists(dirpath):
            pi_uid, www_data_gid = get_web_file_owner()
            os.chown(dirpath, pi_uid, www_data_gid)
            os.chmod(dirpath, mode)
    except Exception:
        try:
            os.chmod(dirpath, mode)
        except:
            pass

# ============================================================
# LOGGING SETUP
# ============================================================

def setup_diagram_logging(mode):
    """Initialisiert Logging für Diagramm-Generator."""
    log_dir = "/var/www/html/logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, "diagram.log")
    
    logger = logging.getLogger("diagram")
    if not logger.handlers:
        handler = logging.FileHandler(log_file, encoding='utf-8')
        formatter = logging.Formatter('%(asctime)s - [%(levelname)s] - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        logger.propagate = False
    
    # Setze Ownership und Permissions
    set_web_file_permissions(log_file, 0o664)
    set_web_directory_permissions(log_dir, 0o775)
    
    return logger

# ============================================================
# KONFIGURATION
# ============================================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_PATH = SCRIPT_DIR + "/"

# Eingabeparameter auslesen
input_file = sys.argv[1] if len(sys.argv) > 1 else "awattardebug.txt"
mode = sys.argv[2].lower() if len(sys.argv) > 2 else "normal"

# Logging initialisieren
diagram_logger = setup_diagram_logging(mode)

if mode == "mobile":
    output_file = "/var/www/html/diagramm_mobile.html"
    done_file = "/var/www/html/tmp/plot_soc_done_mobile"
elif mode == "archiv":
    output_file = "/var/www/html/archiv_diagramm.html"
    done_file = "/var/www/html/tmp/plot_soc_done_archiv"
else:
    output_file = "/var/www/html/diagramm.html"
    done_file = "/var/www/html/tmp/plot_soc_done"

# -------------------------------------------------------------

# Lockfile-Logik harmonisieren
if mode == "archiv":
    lockfile = "/var/www/html/tmp/plot_soc_running_archiv"
elif mode == "mobile":
    lockfile = "/var/www/html/tmp/plot_soc_running_mobile"
else:
    lockfile = "/var/www/html/tmp/plot_soc_running"

# Version
version = "2026.02.18"

# ============================================================
# CONFIG LADEN
# ============================================================

def load_config():
    """Lädt Config aus config.json und e3dc.config.txt"""
    config = {
        'awmwst': 19.0,
        'awnebenkosten': 0.0,
        'speichergroesse': 13.5,
        'cver': 'E3DC v?.?.?',
        'enable_heatpump': True,
        'enable_wallbox': True
    }
    
    # config.json
    json_path = os.path.join(BASE_PATH, "config.json")
    if os.path.isfile(json_path):
        try:
            with open(json_path, "r", encoding='utf-8') as f:
                config.update(json.load(f))
        except:
            pass
    
    # e3dc.config.txt
    config_path = os.path.join(BASE_PATH, "e3dc.config.txt")
    if os.path.isfile(config_path):
        try:
            with open(config_path, "r", encoding='utf-8') as f:
                for line in f:
                    if '=' in line:
                        parts = line.split('=')
                        if len(parts) == 2:
                            key = parts[0].strip()
                            value_str = parts[1].strip()
                            try:
                                if '.' in value_str:
                                    config[key] = float(value_str)
                                else:
                                    config[key] = int(value_str)
                            except:
                                config[key] = value_str
        except:
            pass
    
    # E3DC_CONF.h (Versionsnummer)
    header_path = os.path.join(BASE_PATH, "E3DC_CONF.h")
    if os.path.isfile(header_path):
        try:
            with open(header_path, "r", encoding='utf-8') as f:
                for line in f:
                    if "VERSION" in line or "version" in line:
                        parts = line.split()
                        if len(parts) >= 3:
                            config['cver'] = parts[2].strip().replace('"', '')
                        break
        except:
            pass
    
    return config

# ============================================================
# ZEITKONVERSION (GMT → CET/CEST)
# ============================================================

def is_dst(dt):
    """Prüft, ob ein Datum in der Sommerzeit liegt (CEST, UTC+2)"""
    # Sommerzeit in Deutschland: Letzter Sonntag im März bis letzter Sonntag im Oktober
    # Vereinfachte Regel: DST ungefähr ab März bis Oktober
    year = dt.year
    
    # Letzter Sonntag im März (Sommerzeit-Anfang)
    march = datetime(year, 3, 31)
    last_sunday_march = march - timedelta(days=march.weekday() + 1)
    
    # Letzter Sonntag im Oktober (Sommerzeit-Ende)
    october = datetime(year, 10, 31)
    last_sunday_october = october - timedelta(days=october.weekday() + 1)
    
    return last_sunday_march <= dt < last_sunday_october

def gmt_to_cet(dt_gmt):
    """Konvertiert GMT zu CET/CEST basierend auf DST"""
    if is_dst(dt_gmt):
        return dt_gmt + timedelta(hours=2), "CEST"  # UTC+2 (Sommerzeit)
    else:
        return dt_gmt + timedelta(hours=1), "CET"   # UTC+1 (Winterzeit)

# ============================================================
# WALLBOX PARSING
# ============================================================

_TIME_PRICE_RE = re.compile(
    r"um\s+(\d+):\s*(\d+)\s+zu\s+([\d\.]+)ct/kWh"
)


def _parse_wallbox_date(line):
    """Erwartet z.B. 'am 28.1.' und liefert ein datetime.date (aktuelles Jahr)."""
    match = re.search(r"(\d+)\.(\d+)\.", line + ".")
    if not match:
        raise ValueError(f"Kein Datum gefunden: {line}")

    day, month = map(int, match.groups())
    year = datetime.now().year
    return datetime(year, month, day).date()


def _parse_wallbox_time_price(line, base_date):
    """Erwartet z.B. 'um 0:15 zu 28.900ct/kWh' und liefert (datetime, preis_ct)."""
    match = _TIME_PRICE_RE.search(line)
    if not match:
        return None

    hour = int(match.group(1))
    minute = int(match.group(2))
    price = float(match.group(3).replace(",", "."))

    dt = datetime(
        base_date.year,
        base_date.month,
        base_date.day,
        hour,
        minute
    )
    return dt, price


def parse_wallbox_file(path):
    """Parst e3dc.wallbox.txt und liefert Eintraege mit Datum, Preis und Quelle."""
    with open(path, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f.readlines() if line.strip()]

    if len(lines) < 2:
        return []

    try:
        manual_hours = int(lines[0])
    except Exception:
        manual_hours = 0

    entries = []
    base_date = None
    source = "manual"
    manual_count = 0

    for line in lines[1:]:
        if line.startswith("am "):
            try:
                base_date = _parse_wallbox_date(line)
            except Exception:
                pass
            continue

        if line.startswith("Von der Ladezeitenautomatik"):
            source = "auto"
            continue

        if line == "CET":
            break

        if base_date is not None:
            parsed = _parse_wallbox_time_price(line, base_date)
            if parsed:
                dt, price = parsed

                if source == "manual":
                    if manual_count >= manual_hours:
                        source = "auto"
                    else:
                        manual_count += 0.25  # 15 Minuten = 0.25h

                entries.append({
                    "dt": dt,
                    "price_ct": price,
                    "source": source
                })

    entries.sort(key=lambda e: e["dt"])
    return entries

# ============================================================
# PARSING
# ============================================================

def parse_simulation_file(filepath, config):
    """
    Parst awattardebug.txt mit zwei Blöcken:
    1. "Simulation" - Simulations-Werte (SoC nach Simulation)
    2. "Data" - Echte/geplante Daten (AT, WP, Preis, PV)
    """
    
    if not os.path.isfile(filepath):
        raise FileNotFoundError(f"Datei nicht gefunden: {filepath}")
    
    # Datei-Zeitstempel
    dt_file = datetime.fromtimestamp(os.path.getmtime(filepath))
    
    awmwst = config.get('awmwst', 19.0)
    awnebenkosten = config.get('awnebenkosten', 0.0)
    speichergroesse = config.get('speichergroesse', 13.5)
    
    times = []
    times_dt = []
    soc_values = []
    price_values = []
    temperatur_values = []
    wp_values = []
    pv_values = []
    pv_display = []  # PV mit intelligenter Einheit (W/kW)
    
    # Deutsche Wochentage
    weekdays_de = {0: 'Mo', 1: 'Di', 2: 'Mi', 3: 'Do', 4: 'Fr', 5: 'Sa', 6: 'So'}
    
    wpmin = float('inf')
    wpmax = float('-inf')
    tmin = float('inf')
    tmax = float('-inf')
    
    tz_name = "CET"  # Standard-Zeitzone
    
    after_simulation = False
    last_time_value = None  # Rohe Zeit aus der Datei (z.B. 8.5 für 8:30)
    day_count = 0  # Zählt, wie viele Mitternachtsübergänge wir gesehen haben
    
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            
            # Umschalten zwischen Blöcken
            if 'Simulation' in line:
                after_simulation = True
                last_time_value = None  # Zurücksetzen für neuen Block
                continue
            
            if line == 'Data' or line.startswith('Data'):
                after_simulation = False
                last_time_value = None  # Zurücksetzen für neuen Block
                continue
            
            if not line or line.startswith('notstrom'):
                continue
            
            parts = line.split()
            if len(parts) < 3:
                continue
            
            try:
                # Zeit aus Datei (GMT) - als Float (z.B. 8.5 = 8:30)
                time_value = float(parts[0])
                h_str,f_str = parts[0].split('.')
                hour = int(h_str)
                minute = round(float('0.' + f_str) * 60)
                
                # Erkenne Mitternachtsübergang: Wenn Zeit kleiner ist als letzte Zeit
                # (und nicht am Anfang), ist ein neuer Tag begonnen
                if last_time_value is not None and time_value < last_time_value:
                    day_count += 1
                
                last_time_value = time_value
                
                dt_gmt = datetime(
                    year=dt_file.year,
                    month=dt_file.month,
                    day=dt_file.day,
                    hour=hour,
                    minute=minute
                )
                
                # Addiere die erkannten Tage einmal
                dt_gmt += timedelta(days=day_count)
                
                # Konvertiere GMT zu CET/CEST
                dt_local, tz_name = gmt_to_cet(dt_gmt)
                
                # Nach Simulation oder Data
                if after_simulation:
                    # SIMULATION BLOCK: parts[2]=SoC
                    soc = float(parts[2])
                    soc_values.append(soc)
                    # German weekday + time (in CET/CEST)
                    time_str = f"{weekdays_de[dt_local.weekday()]} {dt_local.strftime('%H:%M')}"
                    times.append(time_str)
                    times_dt.append(dt_local)
                
                else:
                    # DATA BLOCK: parts[0]=Zeit, parts[1]=Preis, parts[3]=WP, parts[4]=PV, parts[5]=AT
                    if len(parts) >= 6:
                        preis_raw = float(parts[1])  # Preis in ct/kWh
                        wp = float(parts[3]) * speichergroesse * 4 / 100  # Wärmepumpe
                        pv = float(parts[4]) * 40 * speichergroesse  # PV Ertrag
                        at = float(parts[5])      # Außentemperatur
                        
                        # Preislogik
                        if dt_file > datetime(2024, 12, 19):
                            preis = preis_raw * (awmwst / 100 + 1) + awnebenkosten
                        else:
                            preis = preis_raw / 10 * (awmwst / 100 + 1) + awnebenkosten
                        
                        # German weekday + time (in CET/CEST)
                        time_str = f"{weekdays_de[dt_local.weekday()]} {dt_local.strftime('%H:%M')}"
                        times.append(time_str)
                        times_dt.append(dt_local)
                        temperatur_values.append(round(at, 2))
                        wp_values.append(round(wp, 2))
                        price_values.append(round(preis, 2))
                        # PV in kW speichern
                        pv_kw = pv / 1000
                        pv_values.append(round(pv_kw, 2))
                        
                        # PV Display für Hover (intelligent formatiert)
                        if pv >= 2000:
                            pv_display.append(f"{pv_kw:.2f} kW")
                        else:
                            pv_display.append(f"{pv:.0f} W")
                        
                        tmin = min(tmin, at)
                        tmax = max(tmax, at)
                        wpmin = min(wpmin, wp)
                        wpmax = max(wpmax, wp)
            
            except (ValueError, IndexError):
                continue
    
    return {
        'times': times,
        'times_dt': times_dt,
        'tz_name': tz_name,
        'soc_values': soc_values,
        'temperatur_values': temperatur_values,
        'wp_values': wp_values,
        'price_values': price_values,
        'pv_values': pv_values,
        'pv_display': pv_display,
        'wpmin': wpmin if wpmin != float('inf') else 0,
        'wpmax': wpmax if wpmax != float('-inf') else 10,
        'tmin': tmin if tmin != float('inf') else 0,
        'tmax': tmax if tmax != float('-inf') else 30,
        'dt_file': dt_file
    }

# ============================================================
# DIAGRAMM ERSTELLEN (SINGLE FIGURE MIT OVERLAYTEN Y-ACHSEN)
# ============================================================

def create_diagram(data, config, mode):
    """Erstellt das Plotly-Diagramm mit einem Figure und 5 overlayten Y-Achsen"""
    
    # SINGLE FIGURE (NICHT make_subplots)
    fig = go.Figure()

    is_mobile = (mode == "mobile")

    # Schriftgrößen und Abstände definieren
    font_size = 10 if is_mobile else 12
    margin_config = dict(l=5, r=5, t=30, b=5) if is_mobile else dict(l=50, r=50, t=50, b=80)
    
    times = data['times']
    times_dt = data['times_dt']
    
    # ========== ALLE 5 TRACES ZUM GLEICHEN FIGURE HINZUFÜGEN ==========
    
    # 1. SoC (grüne Fläche) - Y-Achse 1
    fig.add_trace(
        go.Scatter(
            x=times,
            y=data['soc_values'],
            name='SoC (%)',
            line=dict(color='#9AC353', width=3),
            fill='tozeroy',
            fillcolor='rgba(154, 195, 83, 0.4)',
            yaxis='y',
            hovertemplate='SoC: %{y:.1f}%<extra></extra>'
        )
    )
    
    # 2. Strompreis (violett) - Y-Achse 3 - STUFENDIAGRAMM
    fig.add_trace(
        go.Scatter(
            x=times,
            y=data['price_values'],
            name='Preis (ct/kWh)',
            line=dict(color='#BA55D3', width=2, shape='hv'),
            yaxis='y3',
            hovertemplate='Preis: %{y:.2f} ct<extra></extra>'
        )
    )
    
    # 3. PV Ertrag (gelb) - Y-Achse 2
    fig.add_trace(
        go.Scatter(
            x=times,
            y=data['pv_values'],
            customdata=data['pv_display'],
            name='PV (kW)',
            line=dict(color='rgba(255,194,56,1)', width=3),
            yaxis='y2',
            hovertemplate='PV: %{customdata}<extra></extra>'
        )
    )
    
    # 4. Wärmepumpe (blau) - Y-Achse 4 (optional)
    if config.get('enable_heatpump', True):
        fig.add_trace(
            go.Scatter(
                x=times,
                y=data['wp_values'],
                name='WP (kW)',
                line=dict(color='#1E90FF', width=3),
                yaxis='y4',
                hovertemplate='WP: %{y:.2f} kW<extra></extra>'
            )
        )
    
    # 5. Außentemperatur (grün/cyan) - Y-Achse 5
    fig.add_trace(
        go.Scatter(
            x=times,
            y=data['temperatur_values'],
            name='AT (°C)',
            line=dict(color='#00FF7F', width=3),
            yaxis='y5',
            hovertemplate='AT: %{y:.1f}°C<extra></extra>'
        )
    )

    # 6. Wallbox-Preise (optional)
    if config.get('enable_wallbox', False) and data.get('wallbox'):
        wallbox = data['wallbox']
        if wallbox.get('manual_x'):
            fig.add_trace(
                go.Scatter(
                    x=wallbox['manual_x'],
                    y=wallbox['manual_y'],
                    name='Wallbox (M)',
                    mode='markers',
                    marker=dict(color='#FF6B35', size=7, symbol='circle'),
                    yaxis='y3',
                    hovertemplate='Wallbox: %{y:.3f} ct<extra></extra>'
                )
            )
        if wallbox.get('auto_x'):
            fig.add_trace(
                go.Scatter(
                    x=wallbox['auto_x'],
                    y=wallbox['auto_y'],
                    name='Wallbox (A)',
                    mode='markers',
                    marker=dict(color='#00CED1', size=7, symbol='diamond'),
                    yaxis='y3',
                    hovertemplate='Wallbox: %{y:.3f} ct<extra></extra>'
                )
            )
    
    # ========== X-ACHSE KONFIGURIEREN ==========
    
    ld = round(len(data['pv_values']) / 5) if data['pv_values'] else 8
    
    # ========== PRIMARY Y-ACHSE (y) für SoC ==========
    
    yaxis_config = dict(
        title=None,
        range=[0, 101],
        showgrid=False,
        zeroline=False,
        showline=True,
        showticklabels=True,
        tickfont=dict(color='#9AC353', size=11),
        linecolor='#9AC353',
        linewidth=2,
        nticks=8,
        side='left'
    )
    
    # ========== SEKUNDÄRE Y-ACHSEN (OVERLAYING) ==========
    
    # y3: Preis (violett) - LINKS DANEBEN mit anchor free
    yaxis3_config = dict(
        title=None,
        overlaying='y',
        side='left',
        anchor='free',
        position=0.00 if is_mobile else 0.00,
        showgrid=False,
        zeroline=False,
        showline=True,
        showticklabels=True,
        tickfont=dict(color='#BA55D3', size=font_size-2 if is_mobile else 10),
        linecolor='#BA55D3',
        linewidth=1.5,
        nticks=5 if is_mobile else 8,
        tickformat='.1f'
    )
    
    # y2: PV (gelb) - HAUPTACHSE RECHTS
    yaxis2_config = dict(
        title=None,
        overlaying='y',
        side='right',
        anchor='free',
        position=0.92 if is_mobile else 0.92,
        range=[0, max(data['pv_values']) * 1.1] if data['pv_values'] else [0, 1],
        showgrid=False,
        zeroline=False,
        showline=True,
        showticklabels=True,
        tickfont=dict(color='rgba(255,194,56,1)', size=font_size-2 if is_mobile else 11),
        linecolor='rgba(255,194,56,1)',
        linewidth=2,
        nticks=5 if is_mobile else 8,
        tickformat='.1f'
    )
    
    # y4: WP (blau) - ZWEITE ACHSE RECHTS mit anchor free
    yaxis4_config = dict(
        title=None,
        overlaying='y',
        side='right',
        anchor='free',
        position=1.00 if is_mobile else 1.00,  # Dicht neben Chart rechts
        showgrid=False,
        zeroline=False,
        showline=True,
        showticklabels=True,
        tickfont=dict(color='#1E90FF', size=font_size-1 if is_mobile else 10),
        linecolor='#1E90FF',
        linewidth=1.5,
        nticks=5 if is_mobile else 7,
        tickformat='.1f'
    )

    if not config.get('enable_heatpump', True):
        yaxis4_config.update({
            'showline': False,
            'showticklabels': False,
            'ticks': ''
        })
    
    # y5: AT (Außentemperatur, cyan) - DRITTE ACHSE RECHTS mit anchor free
    yaxis5_config = dict(
        title=None,
        overlaying='y',
        side='right',
        anchor='free',
        position=0.96 if is_mobile else 0.96,  # Mit ausreichend Abstand zu y4
        range=[data['tmin']-2, data['tmax']+2],
        showgrid=False,
        zeroline=False,
        showline=True,
        showticklabels=True,
        tickfont=dict(color='#00FF7F', size=font_size-1 if is_mobile else 10),
        linecolor='#00FF7F',
        linewidth=1.5,
        nticks=5 if is_mobile else 7,
        tickformat='.1f'
    )
    
    # y-Achse 1 (SoC) anpassen
    yaxis_config['position'] = 0.04 if is_mobile else 0.04
    yaxis_config['anchor'] = 'free'
    yaxis_config['overlaying'] = None
    yaxis_config['tickfont']['size'] = font_size-2 if is_mobile else 11
    yaxis_config['nticks'] = 5 if is_mobile else 8

    # ========== LAYOUT KONFIGURIEREN ==========
    
    fig.update_layout(
        template="plotly_dark",
        height=400 if is_mobile else 600,
        dragmode="pan" if is_mobile else "zoom",
        modebar_remove=['zoom', 'pan', 'zoomIn', 'zoomOut', 'autoscale', 'select'],
        
        paper_bgcolor='rgba(0,0,0,0)' if is_mobile else '#242424',
        plot_bgcolor='rgba(0,0,0,0)' if is_mobile else '#242424',
        font=dict(color='rgb(230,230,230)', size=font_size),
        
        # X-Achse Konfiguration
        xaxis=dict(
            title=None,
            type='category',
            tickmode='linear',
            dtick=ld,
            showgrid=False,
            gridcolor='#444',
            linecolor='white',
            tickfont=dict(size=font_size),
            domain=[0.08, 0.88] if is_mobile else [0.04, 0.92],  # Genug Platz für Y-Achsen links/rechts
            autorange=False,
            range=[0, len(data['soc_values'])-1],
            nticks=6 if is_mobile else 12
        ),
        
        # Y-Achsen definieren
        yaxis=yaxis_config,
        yaxis2=yaxis2_config,
        yaxis3=yaxis3_config,
        yaxis4=yaxis4_config,
        yaxis5=yaxis5_config,
        
        hovermode='x unified',
        hoverlabel=dict(bgcolor='#333333', font_size=font_size, font_color='white'),
        
        legend=dict(
            orientation='h',
            yanchor='bottom',
            y=-0.45 if is_mobile else -0.15,
            xanchor='center',
            x=0.5,
            font=dict(size=font_size-2 if is_mobile else 10)
        ),
        
        autosize=True,
        margin=dict(l=5, r=5, t=50, b=100) if is_mobile else margin_config
    )

    # ========== ANNOTATIONEN ==========
    
    cver = config.get('cver', 'E3DC')
    dt_str = data['dt_file'].strftime("%d.%m.%y  %H:%M:%S")
    tz_offset = "+02" if data['tz_name'] == "CEST" else "+01"
    
    # ========== Y-ACHSEN TITEL (ANNOTATIONS) ==========
    
    anno_y = 1.12 if is_mobile else 1.08  # Etwas höher für Mobile
    
    annotations = [
        # y3: Preis (violett) - Links außen
        dict(
            x=0.00 if is_mobile else 0.00, y=anno_y,
            xref="paper", yref="paper",
            text="Preis",
            showarrow=False,
            textangle=270,
            font=dict(color="#BA55D3", size=font_size-2 if is_mobile else font_size),
            xanchor="center"
        ),
        # yaxis: SoC (grün) - Links Standard
        dict(
            x=0.04 if is_mobile else 0.04, y=anno_y,
            xref="paper", yref="paper",
            text="SoC",
            showarrow=False,
            textangle=270,
            font=dict(color="#9AC353", size=font_size-2 if is_mobile else font_size),
            xanchor="center"
        ),
        # yaxis2: PV (gelb) - Rechts Standard
        dict(
            x=0.92 if is_mobile else 0.92, y=anno_y,
            xref="paper", yref="paper",
            text="PV",
            showarrow=False,
            textangle=270,
            font=dict(color="rgba(255,194,56,1)", size=font_size-2 if is_mobile else font_size),
            xanchor="center"
        ),
        # yaxis5: AT (cyan) - Rechts tertiär
        dict(
            x=0.96 if is_mobile else 0.96, y=anno_y,
            xref="paper", yref="paper",
            text="AT",
            showarrow=False,
            textangle=270,
            font=dict(color="#00FF7F", size=font_size-2 if is_mobile else font_size),
            xanchor="center"
        ),
        # Zeitstempel
        dict(
            x=1, y=-0.25 if is_mobile else -0.12,
            xref='paper',
            yref='paper',
            text=f'{dt_str}' if is_mobile else f'{dt_str} {tz_offset} {data["tz_name"]}',
            showarrow=False,
            xanchor='right',
            yanchor='bottom',
            font=dict(size=font_size-2 if is_mobile else 12)
        )
    ]

    if config.get('enable_heatpump', True):
        annotations.append(dict(
            x=1.00 if is_mobile else 1.00, y=anno_y,
            xref="paper", yref="paper",
            text="WP",
            showarrow=False,
            textangle=270,
            font=dict(color="#1E90FF", size=font_size-2 if is_mobile else font_size),
            xanchor="center"
        ))
    
    fig.update_layout(annotations=annotations)
    
    return fig

# ============================================================
# HAUPTPROGRAMM
# ============================================================

error_file = lockfile.replace('plot_soc_running', 'plot_soc_error')

def cleanup_lock():
    """Löscht Lock-Datei"""
    if os.path.exists(lockfile):
        try:
            os.remove(lockfile)
        except:
            pass

try:
    # Lösche alte Fehlerdatei
    if os.path.exists(error_file):
        try:
            os.remove(error_file)
        except:
            pass
    
    # Prüfe Berechtigungen auf kritischen Dateien
    script_path = os.path.abspath(__file__)
    # ... (rest of checks)
    
    # Erstelle Lock-Datei
    os.makedirs(os.path.dirname(lockfile), mode=0o755, exist_ok=True)
    try:
        if os.path.exists(lockfile):
            os.remove(lockfile)
    except:
        pass
    
    try:
        Path(lockfile).touch(mode=0o666)
        set_web_file_permissions(lockfile, 0o664)
    except Exception as e:
        print(f"WARN: Could not touch lockfile {lockfile}: {e}", file=sys.stderr)
        diagram_logger.warning(f"Konnte Lock-Datei nicht erstellen: {lockfile}")
    
    print(f"Processing: {os.path.basename(input_file)} (mode: {mode})", file=sys.stderr)
    diagram_logger.info(f"Start: Verarbeite {os.path.basename(input_file)} (mode={mode})")
    
    # Config laden
    config = load_config()
    
    # Datei parsen
    data = parse_simulation_file(input_file, config)

    # Wallbox-Datei parsen (optional)
    if config.get('enable_wallbox', False):
        wallbox_path = os.path.join(BASE_PATH, "e3dc.wallbox.txt")
        if os.path.isfile(wallbox_path):
            wallbox_entries = parse_wallbox_file(wallbox_path)
            weekdays_de = {0: 'Mo', 1: 'Di', 2: 'Mi', 3: 'Do', 4: 'Fr', 5: 'Sa', 6: 'So'}
            wallbox_manual_x = []
            wallbox_manual_y = []
            wallbox_auto_x = []
            wallbox_auto_y = []

            for entry in wallbox_entries:
                label = f"{weekdays_de[entry['dt'].weekday()]} {entry['dt'].strftime('%H:%M')}"
                if entry['source'] == 'manual':
                    wallbox_manual_x.append(label)
                    wallbox_manual_y.append(entry['price_ct'])
                else:
                    wallbox_auto_x.append(label)
                    wallbox_auto_y.append(entry['price_ct'])

            data['wallbox'] = {
                'manual_x': wallbox_manual_x,
                'manual_y': wallbox_manual_y,
                'auto_x': wallbox_auto_x,
                'auto_y': wallbox_auto_y
            }
        else:
            print(f"WARN: Wallbox-Datei nicht gefunden: {wallbox_path}", file=sys.stderr)
    
    if not data['soc_values']:
        print("ERROR: No SOC data found in file", file=sys.stderr)
        diagram_logger.error(f"Keine SoC-Daten in {input_file} gefunden (mode={mode})")
        sys.exit(1)
    
    print(f"✓ Parsed {len(data['soc_values'])} data points", file=sys.stderr)
    diagram_logger.info(f"Datei geparst: {len(data['soc_values'])} Datenpunkte (mode={mode})")
    
    # Diagramm erstellen
    fig = create_diagram(data, config, mode)
    
    # Output-Verzeichnis erstellen
    os.makedirs(os.path.dirname(output_file), mode=0o755, exist_ok=True)
    
    # HTML speichern
    fig.write_html(
        output_file,
        include_plotlyjs='cdn',
        full_html=False,
        config={'displaylogo': False, 'displayModeBar': True}
    )
    
    # Berechtigungen sicherstellen (damit der Webserver sie überschreiben kann)
    set_web_file_permissions(output_file, 0o664)
    
    print(f"✓ Diagramm erstellt: {output_file}", file=sys.stderr)
    diagram_logger.info(f"✓ Diagramm erfolgreich erstellt: {os.path.basename(output_file)}")
    
    # Done-Datei
    try:
        Path(done_file).touch(mode=0o666)
        set_web_file_permissions(done_file, 0o664)
    except:
        pass
    
    try:
        last_run_file = '/var/www/html/tmp/plot_soc_last_run'
        Path(last_run_file).touch(mode=0o666)
        set_web_file_permissions(last_run_file, 0o664)
    except:
        pass
    
    print(f"✓ Erfolgreich abgeschlossen", file=sys.stderr)
    sys.exit(0)

except Exception as e:
    print(f"ERROR: {e}", file=sys.stderr)
    import traceback
    error_msg = f"Fehler beim Erstellen des Diagramms:\n\n{str(e)}\n\n{traceback.format_exc()}"
    
    # Logge zu diagram.log
    diagram_logger.error(f"✗ Fehler beim Diagramm-Generator: {str(e)}")
    
    # Speichere Fehlermeldung auch in error_file
    try:
        os.makedirs(os.path.dirname(error_file), mode=0o755, exist_ok=True)
        with open(error_file, 'w', encoding='utf-8') as f:
            f.write(error_msg)
        set_web_file_permissions(error_file, 0o664)
    except Exception as eo:
        print(f"Fehler beim Schreiben der Fehlerdatei: {eo}", file=sys.stderr)
        diagram_logger.error(f"Konnte Fehlerdatei nicht schreiben: {eo}")
    
    print(f"ERROR: {e}", file=sys.stderr)
    traceback.print_exc(file=sys.stderr)
    cleanup_lock()
    sys.exit(1)

finally:
    # Lock-Datei löschen (as a safety net)
    cleanup_lock()
