#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E3DC-Control - Diagramm-Generator (Monolithisch)
Erstellt Speichernutzungspläne aus awattardebug.txt (ohne externe Module)
"""

import os
import sys
import json
import logging
import pwd
import grp
from datetime import datetime, timedelta, timezone
from pathlib import Path

try:
    import plotly.graph_objects as go
except ImportError:
    print("ERROR: plotly not installed. Run: pip3 install plotly")
    sys.exit(1)

# ============================================================
# KONSTANTEN
# ============================================================

WEB_ROOT = "/var/www/html"
WEEKDAYS_DE = {0: 'Mo', 1: 'Di', 2: 'Mi', 3: 'Do', 4: 'Fr', 5: 'Sa', 6: 'So'}

# ============================================================
# PERMISSION HELPER
# ============================================================

def get_web_file_owner():
    """Ermittelt UID des install_user und GID von www-data dynamisch."""
    try:
        install_user = None

        # Bevorzugt: installer Web-Config
        config_path = os.path.join(WEB_ROOT, "e3dc_paths.json")
        if os.path.isfile(config_path):
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    web_cfg = json.load(f)
                install_user = web_cfg.get("install_user")
            except Exception:
                pass

        # Fallback 1: Aus Pfad /home/<user>/E3DC-Control ableiten
        if not install_user:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            parts = script_dir.split(os.sep)
            if len(parts) >= 3 and parts[1] == "home":
                install_user = parts[2]

        # Fallback 2: Umgebungsvariablen
        if not install_user:
            env_user = os.environ.get("SUDO_USER") or os.environ.get("USER")
            if env_user and env_user != "root":
                install_user = env_user

        if not install_user:
            install_user = pwd.getpwuid(os.getuid()).pw_name

        install_uid = pwd.getpwnam(install_user).pw_uid
        www_data_gid = grp.getgrnam("www-data").gr_gid
        return install_uid, www_data_gid
    except (KeyError, OSError):
        # Fallback zu Standard-IDs
        return 1000, 33

def set_web_file_permissions(path, mode=0o664):
    """
    Setzt Permissions für Web-Dateien (install_user:www-data).
    
    Args:
        path: Dateipath
        mode: Oktalzahl für Permissions (Standard: 664 für Dateien, 775 für Dirs)
    """
    try:
        if os.path.exists(path):
            install_uid, www_data_gid = get_web_file_owner()
            os.chown(path, install_uid, www_data_gid)
            os.chmod(path, mode)
    except Exception:
        # Fallback: nur chmod versuchen
        try:
            os.chmod(path, mode)
        except:
            pass

def set_web_directory_permissions(dirpath, mode=0o775):
    """
    Setzt Permissions für Web-Verzeichnisse (install_user:www-data 775).
    
    Args:
        dirpath: Verzeichnispath
        mode: Oktalzahl für Permissions (Standard: 775)
    """
    try:
        if os.path.exists(dirpath):
            install_uid, www_data_gid = get_web_file_owner()
            os.chown(dirpath, install_uid, www_data_gid)
            os.chmod(dirpath, mode)
    except Exception:
        try:
            os.chmod(dirpath, mode)
        except:
            pass

# ============================================================
# LOGGING SETUP
# ============================================================

def setup_diagram_logging(mode):
    """Initialisiert Logging für Diagramm-Generator."""
    log_dir = os.path.join(WEB_ROOT, "logs")
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, "diagram.log")
    
    logger = logging.getLogger("diagram")
    if not logger.handlers:
        handler = logging.FileHandler(log_file, encoding='utf-8')
        formatter = logging.Formatter('%(asctime)s - [%(levelname)s] - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        logger.propagate = False
    
    # Setze Ownership und Permissions
    set_web_file_permissions(log_file, 0o664)
    set_web_directory_permissions(log_dir, 0o775)
    
    return logger

# ============================================================
# KONFIGURATION
# ============================================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_PATH = SCRIPT_DIR + "/"

# Eingabeparameter auslesen
input_file = sys.argv[1] if len(sys.argv) > 1 else "awattardebug.txt"
mode = sys.argv[2].lower() if len(sys.argv) > 2 else "normal"
force_dark = "dark" in sys.argv
force_light = "light" in sys.argv

# Logging initialisieren
diagram_logger = setup_diagram_logging(mode)

# Debug-Info
print(f"Theme force: dark={force_dark}, light={force_light}", file=sys.stderr)

if mode == "mobile":
    output_file = os.path.join(WEB_ROOT, "diagramm_mobile.html")
    done_file = os.path.join(WEB_ROOT, "tmp/plot_soc_done_mobile")
elif mode == "archiv":
    output_file = os.path.join(WEB_ROOT, "archiv_diagramm.html")
    done_file = os.path.join(WEB_ROOT, "tmp/plot_soc_done_archiv")
else:
    output_file = os.path.join(WEB_ROOT, "diagramm.html")
    done_file = os.path.join(WEB_ROOT, "tmp/plot_soc_done")

# -------------------------------------------------------------

# Lockfile-Logik harmonisieren
if mode == "archiv":
    lockfile = os.path.join(WEB_ROOT, "tmp/plot_soc_running_archiv")
elif mode == "mobile":
    lockfile = os.path.join(WEB_ROOT, "tmp/plot_soc_running_mobile")
else:
    lockfile = os.path.join(WEB_ROOT, "tmp/plot_soc_running")

# Version
version = "2026.02.18"

# ============================================================
# CONFIG LADEN
# ============================================================

def load_config():
    """Lädt Config aus config.json und e3dc.config.txt"""
    def _parse_numeric(value):
        """Konvertiert Konfig-Werte robust nach float/int (inkl. deutschem Komma)."""
        if isinstance(value, (int, float)):
            return value
        if not isinstance(value, str):
            return value

        cleaned = value.strip().strip('"').strip("'")
        if not cleaned:
            return value

        normalized = cleaned.replace(',', '.')

        try:
            if any(ch in normalized for ch in ['.', 'e', 'E']):
                return float(normalized)
            return int(normalized)
        except Exception:
            return value

    config = {
        'awmwst': 19.0,
        'awnebenkosten': 0.0,
        'speichergroesse': 13.5,
        'cver': 'E3DC v?.?.?',
        'enable_heatpump': True,
        'darkmode': True,
    }
    
    # config.json
    json_path = os.path.join(BASE_PATH, "config.json")
    if os.path.isfile(json_path):
        try:
            with open(json_path, "r", encoding='utf-8') as f:
                config.update(json.load(f))
        except:
            pass
    
    # e3dc.config.txt
    config_path = os.path.join(BASE_PATH, "e3dc.config.txt")
    if os.path.isfile(config_path):
        try:
            with open(config_path, "r", encoding='utf-8') as f:
                for line in f:
                    if '=' in line:
                        parts = line.split('=')
                        if len(parts) == 2:
                            key = parts[0].strip().lower()
                            value_str = parts[1].strip()
                            config[key] = _parse_numeric(value_str)
                            if key == 'darkmode':
                                config['darkmode'] = (value_str.lower() in ['1', 'true', 'on'])
        except:
            pass
    
    # E3DC_CONF.h (Versionsnummer)
    header_path = os.path.join(BASE_PATH, "E3DC_CONF.h")
    if os.path.isfile(header_path):
        try:
            with open(header_path, "r", encoding='utf-8') as f:
                for line in f:
                    if "VERSION" in line or "version" in line:
                        parts = line.split()
                        if len(parts) >= 3:
                            config['cver'] = parts[2].strip().replace('"', '')
                        break
        except:
            pass

    # Numerische Kernwerte immer robust in float/int normalisieren
    for num_key, default_value in {
        'awmwst': 19.0,
        'awnebenkosten': 0.0,
        'speichergroesse': 13.5,
    }.items():
        parsed = _parse_numeric(config.get(num_key, default_value))
        if isinstance(parsed, (int, float)):
            config[num_key] = float(parsed)
        else:
            config[num_key] = float(default_value)
    
    return config

# ============================================================
# ZEITKONVERSION (GMT → CET/CEST)
# ============================================================

_DST_CACHE = {}

def is_dst(dt):
    """Prüft, ob ein Datum in der Sommerzeit liegt (CEST, UTC+2)"""
    # Sommerzeit in Deutschland: Letzter Sonntag im März bis letzter Sonntag im Oktober
    year = dt.year
    
    if year not in _DST_CACHE:
        # Letzter Sonntag im März (Sommerzeit-Anfang)
        march_31 = datetime(year, 3, 31)
        offset_march = (march_31.weekday() + 1) % 7
        last_sunday_march = march_31 - timedelta(days=offset_march)
        
        # Letzter Sonntag im Oktober (Sommerzeit-Ende)
        oct_31 = datetime(year, 10, 31)
        offset_oct = (oct_31.weekday() + 1) % 7
        last_sunday_october = oct_31 - timedelta(days=offset_oct)
        _DST_CACHE[year] = (last_sunday_march, last_sunday_october)
    
    start, end = _DST_CACHE[year]
    return start <= dt < end

def gmt_to_cet(dt_gmt):
    """Konvertiert GMT zu CET/CEST basierend auf DST"""
    if is_dst(dt_gmt):
        return dt_gmt + timedelta(hours=2), "CEST"  # UTC+2 (Sommerzeit)
    else:
        return dt_gmt + timedelta(hours=1), "CET"   # UTC+1 (Winterzeit)

# ============================================================
# PARSING
# ============================================================

def parse_simulation_file(filepath, config):
    """
    Parst awattardebug.txt mit zwei Blöcken:
    1. "Simulation" - Simulations-Werte (SoC nach Simulation)
    2. "Data" - Echte/geplante Daten (AT, WP, Preis, PV)
    """
    
    if not os.path.isfile(filepath):
        raise FileNotFoundError(f"Datei nicht gefunden: {filepath}")
    
    # Datei-Zeitstempel
    ts = os.path.getmtime(filepath)
    dt_file_utc = datetime.utcfromtimestamp(ts) # Für Daten-Parsing (GMT-Basis)
    dt_file = datetime.fromtimestamp(ts)        # Für Anzeige (Lokalzeit)
    
    tz_name = "CEST" if is_dst(dt_file) else "CET"
    
    awmwst = config.get('awmwst', 19.0)
    awnebenkosten = config.get('awnebenkosten', 0.0)
    # Sicherstellen, dass speichergroesse eine Zahl (float) ist
    try:
        raw_val = config.get('speichergroesse', 13.5)
        # Falls es ein String ist, Kommas ersetzen; falls Liste, erstes Element nehmen
        if isinstance(raw_val, list) and len(raw_val) > 0:
            raw_val = raw_val[0]
        speichergroesse = float(str(raw_val).replace(',', '.'))
    except (ValueError, TypeError, IndexError):
        speichergroesse = 13.5  # Fallback auf Standardwert
    
    times = []
    times_dt = []
    soc_values = []
    price_values = []
    temperatur_values = []
    wp_values = []
    pv_values = []
    pv_display = []  # PV mit intelligenter Einheit (W/kW)
    
    wpmin = float('inf')
    wpmax = float('-inf')
    tmin = float('inf')
    tmax = float('-inf')
    
    after_simulation = False
    last_time_value = None  # Rohe Zeit aus der Datei (z.B. 8.5 für 8:30)
    day_count = 0  # Zählt, wie viele Mitternachtsübergänge wir gesehen haben
    
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            
            # Umschalten zwischen Blöcken
            if 'Simulation' in line:
                after_simulation = True
                last_time_value = None  # Zurücksetzen für neuen Block
                continue
            
            if line == 'Data' or line.startswith('Data'):
                after_simulation = False
                last_time_value = None  # Zurücksetzen für neuen Block
                continue
            
            if not line or line.startswith('notstrom'):
                continue
            
            parts = line.split()
            if len(parts) < 3:
                continue
            
            try:
                # Zeit aus Datei (GMT) - als Float (z.B. 8.5 = 8:30)
                time_value = float(parts[0])
                # Robuste Berechnung statt String-Split (vermeidet Fehler bei "8" statt "8.0")
                hour = int(time_value)
                minute = int(round((time_value - hour) * 60))
                
                # Erkenne Mitternachtsübergang: Wenn Zeit kleiner ist als letzte Zeit
                # (und nicht am Anfang), ist ein neuer Tag begonnen
                if last_time_value is not None and time_value < last_time_value:
                    day_count += 1
                
                last_time_value = time_value
                
                dt_gmt = datetime(
                    year=dt_file_utc.year,
                    month=dt_file_utc.month,
                    day=dt_file_utc.day,
                    hour=hour,
                    minute=minute
                )
                
                # Addiere die erkannten Tage einmal
                dt_gmt += timedelta(days=day_count)
                
                # Konvertiere GMT zu CET/CEST
                dt_local, _ = gmt_to_cet(dt_gmt)
                
                # Nach Simulation oder Data
                if after_simulation:
                    # SIMULATION BLOCK: parts[2]=SoC
                    soc = float(parts[2])
                    soc_values.append(soc)
                    # German weekday + time (in CET/CEST)
                    time_str = f"{WEEKDAYS_DE[dt_local.weekday()]} {dt_local.strftime('%H:%M')}"
                    times.append(time_str)
                    times_dt.append(dt_local)
                
                else:
                    # DATA BLOCK: parts[0]=Zeit, parts[1]=Preis, parts[3]=WP, parts[4]=PV, parts[5]=AT
                    if len(parts) >= 6:
                        preis_raw = float(parts[1])  # Preis in ct/kWh
                        wp = float(parts[3]) * speichergroesse * 4 / 100  # Wärmepumpe
                        pv = float(parts[4]) * 40 * speichergroesse  # PV Ertrag
                        at = float(parts[5])      # Außentemperatur
                        
                        # Preislogik
                        if dt_file > datetime(2024, 12, 19):
                            preis = preis_raw * (awmwst / 100 + 1) + awnebenkosten
                        else:
                            preis = preis_raw / 10 * (awmwst / 100 + 1) + awnebenkosten
                        
                        # German weekday + time (in CET/CEST)
                        time_str = f"{WEEKDAYS_DE[dt_local.weekday()]} {dt_local.strftime('%H:%M')}"
                        times.append(time_str)
                        times_dt.append(dt_local)
                        temperatur_values.append(round(at, 2))
                        wp_values.append(round(wp, 2))
                        price_values.append(round(preis, 2))
                        # PV in kW speichern
                        pv_kw = pv / 1000
                        pv_values.append(round(pv_kw, 2))
                        
                        # PV Display für Hover (intelligent formatiert)
                        if pv >= 2000:
                            pv_display.append(f"{pv_kw:.2f} kW")
                        else:
                            pv_display.append(f"{pv:.0f} W")
                        
                        tmin = min(tmin, at)
                        tmax = max(tmax, at)
                        wpmin = min(wpmin, wp)
                        wpmax = max(wpmax, wp)
            
            except (ValueError, IndexError):
                continue
    
    return {
        'times': times,
        'times_dt': times_dt,
        'tz_name': tz_name,
        'soc_values': soc_values,
        'temperatur_values': temperatur_values,
        'wp_values': wp_values,
        'price_values': price_values,
        'pv_values': pv_values,
        'pv_display': pv_display,
        'wpmin': wpmin if wpmin != float('inf') else 0,
        'wpmax': wpmax if wpmax != float('-inf') else 10,
        'tmin': tmin if tmin != float('inf') else 0,
        'tmax': tmax if tmax != float('-inf') else 30,
        'dt_file': dt_file
    }

# ============================================================
# DIAGRAMM ERSTELLEN (SINGLE FIGURE MIT OVERLAYTEN Y-ACHSEN)
# ============================================================

def create_diagram(data, config, mode, force_dark=False, force_light=False):
    """Erstellt das Plotly-Diagramm mit einem Figure und 5 overlayten Y-Achsen"""
    
    # SINGLE FIGURE (NICHT make_subplots)
    fig = go.Figure()
    
    dark_mode = config.get('darkmode', True)
    if force_dark:
        dark_mode = True
    if force_light:
        dark_mode = False
    is_mobile = (mode == "mobile")
    
    # Debug
    print(f"Erstelle Diagramm (Mode: {mode}, Dark: {dark_mode})", file=sys.stderr)
    
    # Farbschema definieren
    if dark_mode:
        c_soc_line = '#9AC353'
        c_soc_fill = 'rgba(154, 195, 83, 0.4)'
        c_price = '#BA55D3'
        c_pv = 'rgba(255,194,56,1)'
        c_wp = '#1E90FF'
        c_at = '#00FF7F'
        c_bg = '#1e1e1e'
        c_text = 'rgb(230,230,230)'
        c_grid = '#444'
        template = "plotly_dark"
    else:
        c_soc_line = '#558B2F' # Dunkleres Grün für Kontrast
        c_soc_fill = 'rgba(85, 139, 47, 0.3)'
        c_price = '#8E24AA' # Dunkleres Violett
        c_pv = '#F57F17' # Dunkleres Orange/Gelb
        c_wp = '#1565C0' # Dunkleres Blau
        c_at = '#00695C' # Dunkleres Türkis
        c_bg = '#ffffff'
        c_text = '#333333'
        c_grid = '#eee'
        template = "plotly_white"

    # Schriftgrößen und Abstände definieren
    font_size = 10 if is_mobile else 12
    margin_config = dict(l=5, r=5, t=30, b=5) if is_mobile else dict(l=50, r=50, t=50, b=80)
    
    times = data['times']
    times_dt = data['times_dt']
    
    # ========== ALLE 5 TRACES ZUM GLEICHEN FIGURE HINZUFÜGEN ==========
    
    # 1. SoC (grüne Fläche) - Y-Achse 1
    fig.add_trace(
        go.Scatter(
            x=times,
            y=data['soc_values'],
            name='SoC (%)',
            line=dict(color=c_soc_line, width=3),
            fill='tozeroy',
            fillcolor=c_soc_fill,
            yaxis='y',
            hovertemplate='SoC: %{y:.1f}%<extra></extra>'
        )
    )
    
    # 2. Strompreis (violett) - Y-Achse 3 - STUFENDIAGRAMM
    fig.add_trace(
        go.Scatter(
            x=times,
            y=data['price_values'],
            name='Preis (ct/kWh)',
            line=dict(color=c_price, width=2, shape='hv'),
            yaxis='y3',
            hovertemplate='Preis: %{y:.2f} ct<extra></extra>'
        )
    )
    
    # 3. PV Ertrag (gelb) - Y-Achse 2
    fig.add_trace(
        go.Scatter(
            x=times,
            y=data['pv_values'],
            customdata=data['pv_display'],
            name='PV (kW)',
            line=dict(color=c_pv, width=3, shape='spline'),
            yaxis='y2',
            hovertemplate='PV: %{customdata}<extra></extra>'
        )
    )
    
    # 4. Wärmepumpe (blau) - Y-Achse 4 (optional)
    if config.get('enable_heatpump', True):
        fig.add_trace(
            go.Scatter(
                x=times,
                y=data['wp_values'],
                name='WP (kW)',
                line=dict(color=c_wp, width=3, shape='spline'),
                yaxis='y4',
                hovertemplate='WP: %{y:.2f} kW<extra></extra>'
            )
        )
    
    # 5. Außentemperatur (grün/cyan) - Y-Achse 5
    fig.add_trace(
        go.Scatter(
            x=times,
            y=data['temperatur_values'],
            name='AT (°C)',
            line=dict(color=c_at, width=3, shape='spline'),
            yaxis='y5',
            hovertemplate='AT: %{y:.1f}°C<extra></extra>'
        )
    )

    # ========== X-ACHSE KONFIGURIEREN ==========
    
    ld = round(len(data['pv_values']) / 5) if data['pv_values'] else 8
    
    # ========== PRIMARY Y-ACHSE (y) für SoC ==========
    
    yaxis_config = dict(
        title=None,
        range=[0, 101],
        showgrid=False,
        zeroline=False,
        showline=True,
        showticklabels=True,
        tickfont=dict(color=c_soc_line, size=11),
        linecolor=c_soc_line,
        linewidth=2,
        nticks=8,
        side='left'
    )
    
    # ========== SEKUNDÄRE Y-ACHSEN (OVERLAYING) ==========
    
    # y3: Preis (violett) - LINKS DANEBEN mit anchor free
    yaxis3_config = dict(
        title=None,
        overlaying='y',
        side='left',
        anchor='free',
        position=0.00 if is_mobile else 0.00,
        showgrid=False,
        zeroline=False,
        showline=True,
        showticklabels=True,
        tickfont=dict(color=c_price, size=font_size-2 if is_mobile else 10),
        linecolor=c_price,
        linewidth=1.5,
        nticks=5 if is_mobile else 8,
        tickformat='.1f'
    )
    
    # y2: PV (gelb) - HAUPTACHSE RECHTS
    yaxis2_config = dict(
        title=None,
        overlaying='y',
        side='right',
        anchor='free',
        position=0.92 if is_mobile else 0.92,
        range=[0, max(data['pv_values']) * 1.1] if data['pv_values'] else [0, 1],
        showgrid=False,
        zeroline=False,
        showline=True,
        showticklabels=True,
        tickfont=dict(color=c_pv, size=font_size-2 if is_mobile else 11),
        linecolor=c_pv,
        linewidth=2,
        nticks=5 if is_mobile else 8,
        tickformat='.1f'
    )
    
    # y4: WP (blau) - ZWEITE ACHSE RECHTS mit anchor free
    yaxis4_config = dict(
        title=None,
        overlaying='y',
        side='right',
        anchor='free',
        position=1.00 if is_mobile else 1.00,  # Dicht neben Chart rechts
        showgrid=False,
        zeroline=False,
        showline=True,
        showticklabels=True,
        tickfont=dict(color=c_wp, size=font_size-1 if is_mobile else 10),
        linecolor=c_wp,
        linewidth=1.5,
        nticks=5 if is_mobile else 7,
        tickformat='.1f'
    )

    if not config.get('enable_heatpump', True):
        yaxis4_config.update({
            'showline': False,
            'showticklabels': False,
            'ticks': ''
        })
    
    # y5: AT (Außentemperatur, cyan) - DRITTE ACHSE RECHTS mit anchor free
    yaxis5_config = dict(
        title=None,
        overlaying='y',
        side='right',
        anchor='free',
        position=0.96 if is_mobile else 0.96,  # Mit ausreichend Abstand zu y4
        range=[data['tmin']-2, data['tmax']+2],
        showgrid=False,
        zeroline=False,
        showline=True,
        showticklabels=True,
        tickfont=dict(color=c_at, size=font_size-1 if is_mobile else 10),
        linecolor=c_at,
        linewidth=1.5,
        nticks=5 if is_mobile else 7,
        tickformat='.1f'
    )
    
    # y-Achse 1 (SoC) anpassen
    yaxis_config['position'] = 0.04 if is_mobile else 0.04
    yaxis_config['anchor'] = 'free'
    yaxis_config['overlaying'] = None
    yaxis_config['tickfont']['size'] = font_size-2 if is_mobile else 11
    yaxis_config['nticks'] = 5 if is_mobile else 8

    # ========== LAYOUT KONFIGURIEREN ==========
    
    fig.update_layout(
        template=template,
        # height=400 if is_mobile else 600, # Deaktiviert für Responsivität
        dragmode="pan" if is_mobile else "zoom",
        modebar_remove=['zoom', 'pan', 'zoomIn', 'zoomOut', 'autoscale', 'select'],
        
        paper_bgcolor=c_bg,
        plot_bgcolor=c_bg,
        font=dict(color=c_text, size=font_size),
        
        # X-Achse Konfiguration
        xaxis=dict(
            title=None,
            type='category',
            tickmode='linear',
            dtick=ld,
            showgrid=False,
            gridcolor='#444',
            linecolor='white',
            tickfont=dict(size=font_size),
            domain=[0.08, 0.88] if is_mobile else [0.04, 0.92],  # Genug Platz für Y-Achsen links/rechts
            autorange=False,
            range=[0, len(data['soc_values'])-1],
            nticks=6 if is_mobile else 12
        ),
        
        # Y-Achsen definieren
        yaxis=yaxis_config,
        yaxis2=yaxis2_config,
        yaxis3=yaxis3_config,
        yaxis4=yaxis4_config,
        yaxis5=yaxis5_config,
        
        hovermode='x unified',
        hoverlabel=dict(bgcolor=c_bg, font_size=font_size, font_color=c_text),
        
        legend=dict(
            orientation='h',
            yanchor='bottom',
            y=-0.45 if is_mobile else -0.15,
            xanchor='center',
            x=0.5,
            font=dict(size=font_size-2 if is_mobile else 10)
        ),
        
        autosize=True,
        margin=dict(l=5, r=5, t=50, b=100) if is_mobile else margin_config
    )

    # ========== ANNOTATIONEN ==========
    
    cver = config.get('cver', 'E3DC')
    dt_str = data['dt_file'].strftime("%d.%m.%y  %H:%M:%S")
    
    # ========== Y-ACHSEN TITEL (ANNOTATIONS) ==========
    
    anno_y = 1.12 if is_mobile else 1.08  # Etwas höher für Mobile
    
    annotations = [
        # y3: Preis (violett) - Links außen
        dict(
            x=0.00 if is_mobile else 0.00, y=anno_y,
            xref="paper", yref="paper",
            text="Preis",
            showarrow=False,
            textangle=270,
            font=dict(color=c_price, size=font_size-2 if is_mobile else font_size),
            xanchor="center"
        ),
        # yaxis: SoC (grün) - Links Standard
        dict(
            x=0.04 if is_mobile else 0.04, y=anno_y,
            xref="paper", yref="paper",
            text="SoC",
            showarrow=False,
            textangle=270,
            font=dict(color=c_soc_line, size=font_size-2 if is_mobile else font_size),
            xanchor="center"
        ),
        # yaxis2: PV (gelb) - Rechts Standard
        dict(
            x=0.92 if is_mobile else 0.92, y=anno_y,
            xref="paper", yref="paper",
            text="PV",
            showarrow=False,
            textangle=270,
            font=dict(color=c_pv, size=font_size-2 if is_mobile else font_size),
            xanchor="center"
        ),
        # yaxis5: AT (cyan) - Rechts tertiär
        dict(
            x=0.96 if is_mobile else 0.96, y=anno_y,
            xref="paper", yref="paper",
            text="AT",
            showarrow=False,
            textangle=270,
            font=dict(color=c_at, size=font_size-2 if is_mobile else font_size),
            xanchor="center"
        ),
        # Zeitstempel
        dict(
            x=1, y=-0.25 if is_mobile else -0.12,
            xref='paper',
            yref='paper',
            text=f'{dt_str}',
            showarrow=False,
            xanchor='right',
            yanchor='bottom',
            font=dict(size=font_size-2 if is_mobile else 12)
        )
    ]

    if config.get('enable_heatpump', True):
        annotations.append(dict(
            x=1.00 if is_mobile else 1.00, y=anno_y,
            xref="paper", yref="paper",
            text="WP",
            showarrow=False,
            textangle=270,
            font=dict(color=c_wp, size=font_size-2 if is_mobile else font_size),
            xanchor="center"
        ))
    
    fig.update_layout(annotations=annotations)
    
    return fig

# ============================================================
# HAUPTPROGRAMM
# ============================================================

error_file = lockfile.replace('plot_soc_running', 'plot_soc_error')

def cleanup_lock():
    """Löscht Lock-Datei"""
    if os.path.exists(lockfile):
        try:
            os.remove(lockfile)
        except:
            pass

try:
    # Lösche alte Fehlerdatei
    if os.path.exists(error_file):
        try:
            os.remove(error_file)
        except:
            pass
    
    # Prüfe Berechtigungen auf kritischen Dateien
    script_path = os.path.abspath(__file__)
    # ... (rest of checks)
    
    # Erstelle Lock-Datei
    os.makedirs(os.path.dirname(lockfile), mode=0o755, exist_ok=True)
    try:
        if os.path.exists(lockfile):
            os.remove(lockfile)
    except:
        pass
    
    try:
        Path(lockfile).touch(mode=0o666)
        set_web_file_permissions(lockfile, 0o664)
    except Exception as e:
        print(f"WARN: Could not touch lockfile {lockfile}: {e}", file=sys.stderr)
        diagram_logger.warning(f"Konnte Lock-Datei nicht erstellen: {lockfile}")
    
    print(f"Processing: {os.path.basename(input_file)} (mode: {mode})", file=sys.stderr)
    diagram_logger.info(f"Start: Verarbeite {os.path.basename(input_file)} (mode={mode})")
    
    # Config laden
    config = load_config()
    
    # Datei parsen
    data = parse_simulation_file(input_file, config)

    if not data['soc_values']:
        print("ERROR: No SOC data found in file", file=sys.stderr)
        diagram_logger.error(f"Keine SoC-Daten in {input_file} gefunden (mode={mode})")
        sys.exit(1)
    
    print(f"✓ Parsed {len(data['soc_values'])} data points", file=sys.stderr)
    diagram_logger.info(f"Datei geparst: {len(data['soc_values'])} Datenpunkte (mode={mode})")
    
    # Diagramm erstellen
    fig = create_diagram(data, config, mode, force_dark=force_dark, force_light=force_light)
    
    # Output-Verzeichnis erstellen
    os.makedirs(os.path.dirname(output_file), mode=0o755, exist_ok=True)
    
    # HTML speichern
    fig.write_html(
        output_file,
        include_plotlyjs='cdn',
        full_html=True,
        config={'displaylogo': False, 'displayModeBar': True, 'responsive': True}
    )
    
    # Berechtigungen sicherstellen (damit der Webserver sie überschreiben kann)
    set_web_file_permissions(output_file, 0o664)
    
    print(f"✓ Diagramm erstellt: {output_file}", file=sys.stderr)
    diagram_logger.info(f"✓ Diagramm erfolgreich erstellt: {os.path.basename(output_file)}")
    
    # Done-Datei
    try:
        Path(done_file).touch(mode=0o666)
        set_web_file_permissions(done_file, 0o664)
    except:
        pass
    
    try:
        last_run_file = os.path.join(WEB_ROOT, 'tmp/plot_soc_last_run')
        Path(last_run_file).touch(mode=0o666)
        set_web_file_permissions(last_run_file, 0o664)
    except:
        pass
    
    print(f"✓ Erfolgreich abgeschlossen", file=sys.stderr)
    sys.exit(0)

except Exception as e:
    print(f"ERROR: {e}", file=sys.stderr)
    import traceback
    error_msg = f"Fehler beim Erstellen des Diagramms:\n\n{str(e)}\n\n{traceback.format_exc()}"
    
    # Logge zu diagram.log
    diagram_logger.error(f"✗ Fehler beim Diagramm-Generator: {str(e)}")
    
    # Speichere Fehlermeldung auch in error_file
    try:
        os.makedirs(os.path.dirname(error_file), mode=0o755, exist_ok=True)
        with open(error_file, 'w', encoding='utf-8') as f:
            f.write(error_msg)
        set_web_file_permissions(error_file, 0o664)
    except Exception as eo:
        print(f"Fehler beim Schreiben der Fehlerdatei: {eo}", file=sys.stderr)
        diagram_logger.error(f"Konnte Fehlerdatei nicht schreiben: {eo}")
    
    print(f"ERROR: {e}", file=sys.stderr)
    traceback.print_exc(file=sys.stderr)
    cleanup_lock()
    sys.exit(1)

finally:
    # Lock-Datei löschen (as a safety net)
    cleanup_lock()
