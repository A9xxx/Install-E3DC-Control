from pymodbus.client import ModbusTcpClient
import json
import time

# Konfiguration
IP_ADDRESS = '192.168.178.88'
PORT = 502

def read_heatpump_status():
    client = ModbusTcpClient(IP_ADDRESS, port=PORT)
    
    if not client.connect():
        return "Verbindung zu Modbus fehlgeschlagen"

    try:
        # Wir lesen einen Block von 10 Input-Registern ab 10100
        # 10101: Rücklauf, 10105: Vorlauf, 10108: Aussentemp/Mittel
        response = client.read_input_registers(address=10100, count=10, slave=1)
        
        if response.isError():
            return "Fehler beim Lesen der Register"

        regs = response.registers
        
        # Mapping laut deiner .md Datei und dem Screenshot
        data = {
            "Ruecklauf_Ist": regs[1] / 10,   # Register 10101
            "Vorlauf_Ist": regs[5] / 10,     # Register 10105
            "Aussentemp_Mittel": regs[8] / 10, # Register 10108
            "Warmwasser_Ist": client.read_input_registers(10120, 1, slave=1).registers[0] / 10,
            "Timestamp": time.strftime("%H:%M:%S")
        }
        
        # --- BEISPIEL: EINEN WERT SCHREIBEN (Warmwasser-Soll) ---
        # Um das WW-Soll auf 45 Grad zu setzen (Wert 450):
        # client.write_register(address=10006, value=450, slave=1)
        
        return data

    finally:
        client.close()

# Ergebnis ausgeben
status = read_heatpump_status()
print(json.dumps(status, indent=4))